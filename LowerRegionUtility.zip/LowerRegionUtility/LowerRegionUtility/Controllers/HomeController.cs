﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.Mvc;
using DataLayer;
using System.Configuration;
using LowerRegionUtility.Models;
using System.Data;
using System.ServiceProcess;

namespace LowerRegionUtility.Controllers
{
    public class HomeController : Controller
    {
        private static readonly log4net.ILog log = log4net.LogManager.GetLogger(System.Reflection.MethodBase.GetCurrentMethod().DeclaringType);
        public ActionResult Index()
        {
            log.Info("Lower Region Utility has been started...");
            return View();
        }

        [HttpGet]
        public ActionResult Error()
        {
            return View();
        }

        [HttpGet]
        public ActionResult AuditTrailInfo()
        {
            try
            {
                DataAccessADO adoObject = new DataAccessADO();
                DataTable dataTable =   adoObject.GetAuditTrailInfo();
                return View(dataTable);
            }
            catch (Exception ex)
            {
                log.Error("Error while fetching audit trail info from database, see below error for more details");
                log.Error(ex.Message);
                log.Error(ex.StackTrace);
                return View("Error");

            }

        }

        [HttpGet]
        public ActionResult ManageSqlJobs()
        {
            log.Info("User selected for manage SQL jobs section...");
            return View();
        }

        [HttpGet]
        public ActionResult ManageServices()
        {
            log.Info("User selected for manage services section...");
            return View();
        }


        [HttpPost]
        public ActionResult TrackJobStatus(string jobName, string serverName)
        {
            try
            {
                log.Info("Tracking the status of job: " + jobName);
                DataAccessADO adoObject = new DataAccessADO();
                string result = adoObject.GetStatusOfSqlJob(jobName, serverName);
                ViewBag.JobStatus = result;
                return View();
            }
            catch (Exception ex)
            {
                log.Error("Error occured while fetching the status from database, see below stack trace: ");
                log.Error(ex.StackTrace);
                log.Error(ex.Message);
                return View("Error");
            }
            
        }

        [HttpPost]
        public ActionResult StartStopSqlJobs(string jobName, bool isStart, string serverName)
        {
            if(isStart)
                log.Info("User requesting to start the job: " + jobName + " on database server: " + serverName);
            else
                log.Info("User requesting to stop the job: " + jobName + " on database server: " + serverName);
            DataAccessADO objAdo = new DataAccessADO();
            bool isExecutionSuccess = false;
            try
            {
                isExecutionSuccess = objAdo.ManageAgentSqlJobs(jobName, isStart, serverName, System.Web.HttpContext.Current.User.Identity.Name);
            }
            catch (Exception ex)
            {
                log.Error("Error while starting/stopping the job, please see below stack trace: ");
                log.Error(ex.StackTrace);
                log.Error(ex.Message);                
            }
            
            ViewBag.IsStart = isStart;
            string responseMessage = string.Empty;
            if (isExecutionSuccess)
            {
                if(isStart)
                {
                    responseMessage = "SQL job - " + jobName + " has been successfully started!";                                   
                }
                
                else
                {
                    responseMessage = "SQL job - " + jobName + " has been successfully stopped!";                              
                }

                log.Info(responseMessage);
                ViewBag.ResponseMessage = responseMessage;
                return View();
            }
               
            else
            {
                if(isStart)
                {
                    responseMessage = "SQL job - " + jobName + " has been failed to start. Kindly check logs for more details.";                                        
                }
               
                else
                {
                    responseMessage = "SQL job - " + jobName + " has been failed to stop. Kindly check logs for more details";                    
                    
                }

                log.Error(responseMessage);
                ViewBag.ResponseMessage = responseMessage;
                return View();
            }
               
        }

        [HttpPost]
        public ActionResult GetDatabaseServers(string region)
        {
            try
            {
                log.Info("Getting the database server names from config for: " + region + " region." );
                List<SelectListItem> listOfDBServerNames = new List<SelectListItem>();
                List<string> listOfServers = ConfigurationManager.AppSettings[region + "DBServers"].Trim().Split(',').ToList<string>();
                foreach (string server in listOfServers)
                {
                    listOfDBServerNames.Add(new SelectListItem { Text = server, Value = server });
                }
                return View(listOfDBServerNames);
            }
            catch (Exception ex)
            {
                log.Error(ex.StackTrace);
                log.Error(ex.Message);
                return View("Error");
            }
            
        }

        [HttpPost]
        public ActionResult GetWindowsServers(string region)
        {
            try
            {
                log.Info("Getting the windows server names from config for: " + region + " region.");
                List<SelectListItem> listOfWindowsServerNames = new List<SelectListItem>();
                List<string> listOfServers = ConfigurationManager.AppSettings[region + "WindowsServers"].Trim().Split(',').ToList<string>();
                foreach (string server in listOfServers)
                {
                    listOfWindowsServerNames.Add(new SelectListItem { Text = server, Value = server });
                }
                return View(listOfWindowsServerNames);
            }
            catch (Exception ex)
            {
                log.Error(ex.StackTrace);
                log.Error(ex.Message);
                return View("Error");
            }
        }



        [HttpPost]
        public ActionResult GetAllSqlJobs(string serverName)
        {
            try
            {
                log.Info("Getting all the SQL jobs from database server: " + serverName);
                DataAccessADO dataObject = new DataAccessADO();
                List<SelectListItem> listOfJobNames = new List<SelectListItem>();
                List<string> listOfSqlJobs = dataObject.GetAllSqlJobs(serverName);
                foreach (string jobName in listOfSqlJobs)
                {
                    listOfJobNames.Add(new SelectListItem { Text = jobName, Value = jobName });
                }

                return View(listOfJobNames);
            }
            catch (Exception ex)
            {
                log.Error("Error while getting all the SQL jobs from database, please see below stacktrace: ");
                log.Error(ex.StackTrace);
                log.Error(ex.Message);
                return View("Error");
            }
           
        }

        [HttpPost]
        public ActionResult GetAllWindowsServices(string serverName)
        {
            try
            {
                log.Info("Getting all the windows services from server: " + serverName);
                
                List<SelectListItem> listOfJobNames = new List<SelectListItem>();
                ServiceController[] serviceNames = ServiceController.GetServices(serverName);
                List<string> listOfServices = (from x in serviceNames select x.ServiceName).ToList();
                foreach (string  serviceName in listOfServices)
                {
                    listOfJobNames.Add(new SelectListItem { Text = serviceName, Value = serviceName});
                }
            }
            catch (Exception ex)
            {
                log.Error("Error while getting all the windows services from server, please see below stacktrace: ");
                log.Error(ex.StackTrace);
                log.Error(ex.Message);
                return View("Error");
            }

        }

        public ActionResult About()
        {
            ViewBag.Message = "Your application description page.";

            return View();
        }

        public ActionResult Contact()
        {
            ViewBag.Message = "Your contact page.";

            return View();
        }
    }
}