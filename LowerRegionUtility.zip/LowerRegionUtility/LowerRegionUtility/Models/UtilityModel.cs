﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;

namespace LowerRegionUtility.Models
{
    public class UtilityModel
    {       
        

    }
    

    public enum LowerRegion
    {
        DEV,
        STAGE,
        CT
    }
}