﻿using System;
using System.Collections.Generic;
using System.Configuration;
using System.Data;
using System.Data.SqlClient;
using System.IO;
using System.Linq;
using System.Reflection;
using System.Security.Policy;
using System.Text;
using System.Threading.Tasks;
using System.Xml.Linq;
using System.Web;

namespace DataLayer
{
    public class DataAccessADO
    {
        public DataTable GetAuditTrailInfo()
        {
            try
            {
                string connectionString = ConfigurationManager.ConnectionStrings["AuditTrailConnectionString"].ConnectionString;
                string getAuditTrailInfoQuery = ConfigurationManager.AppSettings["GetAuditTrailInfoQuery"].ToString();
                using (SqlConnection con = new SqlConnection(connectionString))
                {
                    SqlCommand cmd = new SqlCommand(getAuditTrailInfoQuery, con);
                    cmd.CommandType = CommandType.Text;
                    con.Open();
                    SqlDataReader reader = cmd.ExecuteReader();
                    DataTable tableData = new DataTable();
                    tableData.Load(reader);

                    return tableData;
                }
            }
            catch (Exception ex)
            {
                throw ex;
            }

        }

        public List<string> GetAllSqlJobs(string serverName)
        {
            try
            {
                List<string> listOfAllSqlJobs = new List<string>();
                //listOfAllSqlJobs.Add("Job1");
                //listOfAllSqlJobs.Add("Job2");
                //listOfAllSqlJobs.Add("Job3");

                string connectionString = ConfigurationManager.ConnectionStrings["ConnectionString"].ConnectionString;
                connectionString = connectionString.Replace("$SERVER", serverName);
                using (SqlConnection con = new SqlConnection(connectionString))
                {
                    SqlCommand cmd = new SqlCommand(ConfigurationManager.AppSettings["GetAllSqlJobsQuery"], con);
                    cmd.CommandType = CommandType.Text;
                    con.Open();
                    SqlDataReader reader = cmd.ExecuteReader();
                    while (reader.Read())
                    {
                        listOfAllSqlJobs.Add(reader[0].ToString() ?? string.Empty);
                    }
                }

                return listOfAllSqlJobs;
            }
            catch (Exception ex)
            {
                throw ex;
            }

        }

        private void InsertAuditTrailInfo(string sqlJobName, bool isStart, bool isExecutionSuccess, string serverName, string userName)
        {
            try
            {
                string connectionString = ConfigurationManager.ConnectionStrings["AuditTrailConnectionString"].ConnectionString;
                connectionString = connectionString.Replace("$SERVER", serverName);
                string activityPerformed = string.Empty;
                string status = string.Empty;
                status = isExecutionSuccess ? "Success" : "Failure";
                if (isStart)
                    activityPerformed = "User requested to start the SQL job: " + sqlJobName;
                else
                    activityPerformed = "User requested to stop the SQL job: " + sqlJobName;
                using (SqlConnection con = new SqlConnection(connectionString))
                {
                    SqlCommand audtitTrailInsertCmd = new SqlCommand(ConfigurationManager.AppSettings["InsertAuditInfoStoredProc"], con);
                    audtitTrailInsertCmd.CommandType = CommandType.StoredProcedure;
                    audtitTrailInsertCmd.Parameters.AddWithValue("@userName", userName);
                    audtitTrailInsertCmd.Parameters.AddWithValue("@activityDate", DateTime.Now);
                    audtitTrailInsertCmd.Parameters.AddWithValue("@activity", activityPerformed);
                    audtitTrailInsertCmd.Parameters.AddWithValue("@databaseServer", serverName);
                    audtitTrailInsertCmd.Parameters.AddWithValue("@status", status);
                    con.Open();
                    int result = audtitTrailInsertCmd.ExecuteNonQuery();
                }
            }
            catch (Exception ex)
            {
                throw ex;
            }

        }

        public bool ManageAgentSqlJobs(string sqlJobName, bool isStart, string serverName, string userName = "")
        {
            int data = 0;
            try
            {
                string startSpName = ConfigurationManager.AppSettings["StartSQLJobStoredProc"] ;
                string stopSpName = ConfigurationManager.AppSettings["StopSQLJobStoredProc"];
                string connectionString = ConfigurationManager.ConnectionStrings["ConnectionString"].ConnectionString;
                connectionString = connectionString.Replace("$SERVER", serverName);
                string activityPerformed = string.Empty;
                if (isStart)
                    activityPerformed = "User requested to start the SQL job: " + sqlJobName;
                else
                    activityPerformed = "User requested to stop the SQL job: " + sqlJobName;

                //Reading XML for getting the sql job's parameters
                //#region XML read
                //string path = System.Web.Hosting.HostingEnvironment.MapPath("~/Content/SqlJobsData.xml");
                //XElement root = XElement.Load(path);
                //XElement regionRoot = (from x in root.Elements() where x.Attribute("region").Value.Equals("DEV") select x).FirstOrDefault();

                //XElement jobRoot = (from x in regionRoot.Elements() where x.Attribute("jobname").Value.Equals(sqlJobName) select x).FirstOrDefault();
                //List<string> listOfParameters = (from x in jobRoot.Elements() select x.Value).ToList();

                //#endregion

                using (SqlConnection con = new SqlConnection(connectionString))
                {
                    SqlCommand cmd = new SqlCommand(isStart ? startSpName : stopSpName, con);
                    cmd.CommandType = CommandType.StoredProcedure;
                    cmd.Parameters.AddWithValue("@job_name", sqlJobName);
                    //foreach (string param in listOfParameters)
                    //{
                    //    cmd.Parameters.AddWithValue(param, "00:00:20.000");
                    //}
                    con.Open();
                    data = cmd.ExecuteNonQuery();
                    con.Close();
                    
                    InsertAuditTrailInfo(sqlJobName, isStart, data == -1, serverName, userName);
                    
                    return data == -1;
                }
            }
            catch (Exception ex)
            {
                //log error
                InsertAuditTrailInfo(sqlJobName, isStart, false, serverName, userName);
                throw ex;
            }
        }

        public string GetStatusOfSqlJob(string jobName, string serverName)
        {
            try
            {
                string connectionString = ConfigurationManager.ConnectionStrings["ConnectionString"].ConnectionString;
                connectionString = connectionString.Replace("$SERVER", serverName);
                using (SqlConnection con = new SqlConnection(connectionString))
                {
                    string response = string.Empty;
                    SqlParameter outPut = new SqlParameter("@response", SqlDbType.VarChar, 200) { Direction = ParameterDirection.Output };
                    SqlCommand cmd = new SqlCommand(ConfigurationManager.AppSettings["GetSqlJobStatusStoredProc"], con);
                    cmd.CommandType = CommandType.StoredProcedure;
                    cmd.Parameters.AddWithValue("@sqlJobName", jobName);
                    cmd.Parameters.Add(outPut);

                    con.Open();
                    cmd.ExecuteReader();
                    string status = outPut.SqlValue.ToString();
                    if (!string.IsNullOrEmpty(status))
                        status = "Job status: " + status;
                    else
                        status = "Something went wrong in SQL procedure, kindly check logs!";

                    return status;
                }
            }
            catch (Exception ex)
            {
                throw ex;
            }
        }
    }
}
