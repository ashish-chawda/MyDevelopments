using System;
using System.Text;
using System.Reflection;
using SEM.Logging;
using log4net;

namespace L4NLogging
{
    public sealed class L4NLogger
    {
        #region Singleton object
        /// <summary>
        /// Retrive the logger from the logger depository
        /// </summary>
        private static readonly ILog logger =
            LogManager.GetLogger(MethodBase.GetCurrentMethod().DeclaringType);

        /// <summary>
        /// The singleton object of this.
        /// </summary>
        private static L4NLogger thisLogger;
        
        #endregion

        #region Constructor
        /// <summary>
        /// Private constructor prevent outside class from creating an instance
        /// </summary>
        private L4NLogger() { }
        #endregion

        #region Class Members
        /// <summary>
        /// Creates the logger.
        /// </summary>
        /// <param name="sessionId">The session id.</param>
        /// <returns></returns>
        public static L4NLogger CreateLogger()
        {
            
            if (null == thisLogger)
            {
                lock (m_lock)
                {
                    if (null == thisLogger)
                    {
                        thisLogger = new L4NLogger();
                    }
                }
            }

            return thisLogger;
        }

        /// <summary>
        /// Gets the logger. Used for the static properity to return this.
        /// </summary>
        /// <value>The logger.</value>
        public static L4NLogger Logger
        {
            get
            {
                if (null != thisLogger)
                {
                    return thisLogger;
                }
                else
                {
                    throw new Exception(
                      "Call method CreateLogger() to create a logger first."
                      );
                }
            }
        }

        #endregion

        #region Public Methods

        /// <summary>
        /// Logs the debug.
        /// </summary>
        /// <param name="title">The title.</param>
        /// <param name="debugMessage">The debug message.</param>
        public void LogDebug( string debugMessage)
        {
            string message = constructMessageString() + buildLogMessage(debugMessage);
            //System.Text.UTF8Encoding encoding = new System.Text.UTF8Encoding();
            //Byte[] bt = encoding.GetBytes(message);
            //CachedEntry ce = new CachedEntry(bt, 0, bt.Length);
            //qm.Enqueue(ce);
            logger.Debug(message);
        }

        /// <summary>
        /// Logs the debug.
        /// </summary>
        /// <param name="title">The title.</param>
        /// <param name="debugMessage">The debug message.</param>
        public void LogDebug(string title, string debugMessage)
        {
            string message = constructMessageString() + buildLogMessage(debugMessage);
            //System.Text.UTF8Encoding encoding = new System.Text.UTF8Encoding();
            //Byte[] bt = encoding.GetBytes(message);
            //CachedEntry ce = new CachedEntry(bt, 0, bt.Length);
            //qm.Enqueue(ce);
            logger.Debug(message);
        }

        /// <summary>
        /// Logs the debug.
        /// </summary>
        /// <param name="title">The title.</param>
        /// <param name="debugMessage">The debug message.</param>
        public void LogDebug(string title, object debugMessage)
        {
            string message = constructMessageString() + buildLogMessage(debugMessage);
            //System.Text.UTF8Encoding encoding = new System.Text.UTF8Encoding();
            //Byte[] bt = encoding.GetBytes(message);
            //CachedEntry ce = new CachedEntry(bt, 0, bt.Length);
            //qm.Enqueue(ce);
           logger.Debug(message);
        }

        /// <summary>
        /// Logs the information.
        /// </summary>
        /// <param name="title">The title.</param>
        /// <param name="information">The information.</param>
        public void LogInformation(string title, string information)
        {
            string message = constructMessageString() + buildLogMessage(information);
          
            //System.Text.UTF8Encoding encoding = new System.Text.UTF8Encoding();
            //Byte[] bt = encoding.GetBytes(message);
            //CachedEntry ce = new CachedEntry(bt, 0, bt.Length);
            //qm.Enqueue(ce);

            logger.Info(message);
        }

        /// <summary>
        /// Logs the information.
        /// </summary>
        /// <param name="title">The title.</param>
        /// <param name="information">The information.</param>
        public void LogInformation(string title, object information)
        {
            string message = constructMessageString() + buildLogMessage(information);
            //System.Text.UTF8Encoding encoding = new System.Text.UTF8Encoding();
            //Byte[] bt = encoding.GetBytes(message);
            //CachedEntry ce = new CachedEntry(bt, 0, bt.Length);
            //qm.Enqueue(ce );
            logger.Info(message);
        }


        #endregion

        #region Helping private methods

        /// <summary>
        /// Builds the log message.
        /// </summary>
        /// <param name="message">The message.</param>
        /// <returns></returns>
        private string buildLogMessage(string message)
        {
            lock (m_lock)
            {
                StringBuilder xmlString = new StringBuilder();
                xmlString.Append(message);
                return xmlString.ToString();
            }
        }


        /// <summary>
        /// Builds the log message.
        /// </summary>
        /// <param name="messageObject">The message object.</param>
        /// <returns></returns>
        private string buildLogMessage(object messageObject)
        {
            lock (m_lock)
            {
                StringBuilder xmlString = new StringBuilder();
                if (messageObject != null)
                {
                    xmlString.Append(LogXMLSerializer.SerializeObject(messageObject));
                }
                return xmlString.ToString();
            }
        }
        private string constructMessageString()
        {
             return  " " ;
        }

        #endregion

        #region private variable

        /// <summary>
        /// lock object
        /// </summary>
        private static object m_lock = new object();

        #endregion
    }
    
    public sealed class L4NErrorLogger
    {
        #region Singleton object
        /// <summary>
        /// Retrive the logger from the logger depository
        /// </summary>
        private static readonly ILog logger =
            LogManager.GetLogger(MethodBase.GetCurrentMethod().DeclaringType);

        /// <summary>
        /// The singleton object of this.
        /// </summary>
        private static L4NErrorLogger thisLogger;
        
        #endregion

        #region Constructor
        /// <summary>
        /// Private constructor prevent outside class from creating an instance
        /// </summary>
        private L4NErrorLogger() { }
        #endregion

        #region Class Members
        /// <summary>
        /// Creates the logger.
        /// </summary>
        /// <param name="sessionId">The session id.</param>
        /// <returns></returns>
        public static L4NErrorLogger CreateLogger()
        {
            
            if (null == thisLogger)
            {
                lock (m_lock)
                {
                    if (null == thisLogger)
                    {
                        thisLogger = new L4NErrorLogger();
                    }
                }
            }

            return thisLogger;
        }

        /// <summary>
        /// Gets the logger. Used for the static properity to return this.
        /// </summary>
        /// <value>The logger.</value>
        public static L4NErrorLogger Logger
        {
            get
            {
                if (null != thisLogger)
                {
                    return thisLogger;
                }
                else
                {
                    throw new Exception(
                      "Call method CreateLogger() to create a logger first."
                      );
                }
            }
        }

        #endregion

        #region Public Methods

               /// <summary>
        /// Logs the error.
        /// </summary>
        /// <param name="title">The title.</param>
        /// <param name="errorMessage">The error message.</param>
        public void LogError(string title, string errorMessage)
        {
            string message = constructMessageString() + buildLogMessage(errorMessage);

            //System.Text.UTF8Encoding encoding = new System.Text.UTF8Encoding();
            //Byte[] bt = encoding.GetBytes(message);
            //CachedEntry ce = new CachedEntry(bt, 0, bt.Length);
            //qm.Enqueue(ce );

            logger.Error(message);
        }

        /// <summary>
        /// Logs the error.
        /// </summary>
        /// <param name="title">The title.</param>
        /// <param name="errorMessage">The error message.</param>
        public void LogError(string title, object errorMessage)
        {
            string message = constructMessageString() + buildLogMessage(errorMessage);

            //System.Text.UTF8Encoding encoding = new System.Text.UTF8Encoding();
            //Byte[] bt = encoding.GetBytes(message);
            //CachedEntry ce = new CachedEntry(bt, 0, bt.Length);
            //qm.Enqueue(ce);

             logger.Error(message);
        }

        #endregion

        #region Helping private methods

        /// <summary>
        /// Builds the log message.
        /// </summary>
        /// <param name="message">The message.</param>
        /// <returns></returns>
        private string buildLogMessage(string message)
        {
            lock (m_lock)
            {
                StringBuilder xmlString = new StringBuilder();
                xmlString.Append(message);
                return xmlString.ToString();
            }
        }


        /// <summary>
        /// Builds the log message.
        /// </summary>
        /// <param name="messageObject">The message object.</param>
        /// <returns></returns>
        private string buildLogMessage(object messageObject)
        {
            lock (m_lock)
            {
                StringBuilder xmlString = new StringBuilder();
                if (messageObject != null)
                {
                    xmlString.Append(LogXMLSerializer.SerializeObject(messageObject));
                }
                return xmlString.ToString();
            }
        }
        private string constructMessageString()
        {
             return  " " ;
        }

        #endregion

        #region private variable

        /// <summary>
        /// lock object
        /// </summary>
        private static object m_lock = new object();

        #endregion
    }
}

