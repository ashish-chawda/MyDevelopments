﻿using System.Web;
using System.Web.Optimization;

namespace NZ1JIlCreationWebUtility
{
    public class BundleConfig
    {
        // For more information on Bundling, visit http://go.microsoft.com/fwlink/?LinkId=254725
        public static void RegisterBundles(BundleCollection bundles)
        {
            bundles.IgnoreList.Clear();

            bundles.Add(new ScriptBundle("~/Scripts/jquery").
               Include("~/Scripts/Jquery.js", "~/Scripts/Popper.js"));
            bundles.Add(new ScriptBundle("~/Scripts/bootstrapquery").
                Include("~/Scripts/bootstrapmin.js"));
            bundles.Add(new ScriptBundle("~/bundles/modernizr").Include(
                       "~/Scripts/modernizr-*"));            
            bundles.Add(new StyleBundle("~/Content/bootstrapstylesheet").
               Include("~/Content/bootstrapmin.css", "~/Content/bootstrapgrid.min.css", "~/Content/Animate.css"));
        }
    }
}