﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Reflection;
using System.Web;
using System.Web.Mvc;
using System.Web.Providers.Entities;
using Newtonsoft.Json;
using NZ1JIlCreationWebUtility.Models;
using IO = System.IO;
using System.Configuration;
using System.Text.RegularExpressions;


namespace NZ1JIlCreationWebUtility.Controllers
{
    public class HomeController : Controller
    {
        List<FilteredJobs> listOfJobs = new List<FilteredJobs>();
        List<FilteredJobs> listOfDevJobsToUpdate = new List<FilteredJobs>();
        List<FilteredJobs> listOfStageJobsToUpdate = new List<FilteredJobs>();
        List<FilteredJobs> listOfCtJobsToUpdate = new List<FilteredJobs>();
        List<FilteredJobs> listOfProdJobsToUpdate = new List<FilteredJobs>();
        bool isJilCreated;
        bool isDevJobsAdded; bool isStageJobsAdded; bool isCtJobsAdded; bool isProdJobsAdded;
        bool isAsaServerAdded; bool isGwyServerAdded; bool isSchedulerServerAdded; bool isLocalHostServerAdded;
        string fileName = string.Empty;
        // private static string LowerRegionBisSubstring = string.Empty;

        [HttpGet]
        public ActionResult Index()
        {
            try
            {
                isJilCreated = false;
                fileName = string.Empty;
                listOfJobs.Clear();
                listOfDevJobsToUpdate.Clear();
                listOfStageJobsToUpdate.Clear();
                listOfCtJobsToUpdate.Clear();
                listOfProdJobsToUpdate.Clear();
                isDevJobsAdded = false; isStageJobsAdded = false; isCtJobsAdded = false; isProdJobsAdded = false;
                foreach (var file in IO.Directory.GetFiles(IO.Path.GetTempPath()))
                {
                    if (file.Contains(StringConstants.UPDATED_JOBS))
                        IO.File.Delete(file);
                }

                return View();
            }
            catch (Exception)
            {
                return View("Error");
            }
        }

        [HttpGet]
        public JsonResult GetWrongNamingConventionJobs(string ID)
        {
            List<FilteredJobs> listOfWrongNamingConventionJobs = new List<FilteredJobs>();
            int returnCount = 0;
            if (Session[ID + "ListOfJobsOriginal"] != null)
                listOfJobs = JsonConvert.DeserializeObject<List<FilteredJobs>>((string)Session[ID + "ListOfJobsOriginal"]);

            if (listOfJobs.Count > 0)
            {
                //listOfWrongNamingConventionJobs.AddRange(from x in listOfJobs where x.Insert_job.ToLower().Contains("bsl-app-od") select x);
                //                listOfJobs.RemoveAll(x => x.Insert_job.ToLower().Contains("bsl-app-od"));
                // listOfJobs.RemoveAll(x => x.Insert_job.ToLower().Contains("box"));
                foreach (FilteredJobs item in listOfJobs)
                {
                    if (item.Insert_job.ToLower().Contains(ConfigurationManager.AppSettings["DevBisSubString"]) || item.Insert_job.ToLower().Contains(ConfigurationManager.AppSettings["DevBslSubString"]) || item.Insert_job.ToLower().Contains(ConfigurationManager.AppSettings["StageBisSubString"]) || item.Insert_job.ToLower().Contains(ConfigurationManager.AppSettings["StageBslSubString"]) || item.Insert_job.ToLower().Contains(ConfigurationManager.AppSettings["CtBisSubString"]) || item.Insert_job.ToLower().Contains(ConfigurationManager.AppSettings["CtBslSubString"]) || item.Insert_job.ToLower().Contains(ConfigurationManager.AppSettings["ProdBisSubString"]) || item.Insert_job.ToLower().Contains(ConfigurationManager.AppSettings["ProdBslSubString"]))
                    {
                        int splitCount = item.Insert_job.Split(StringConstants.SPLIT_WITH_HYPHEN).Count();
                        string processId = string.Empty;
                        if (splitCount > 4)
                        {
                            int num;
                            if (item.Insert_job.ToLower().Contains(ConfigurationManager.AppSettings["LowerRegionBslSubstring"]))
                                processId = item.Insert_job.Split(StringConstants.SPLIT_WITH_HYPHEN)[3].Trim();
                            else
                                processId = item.Insert_job.Split(StringConstants.SPLIT_WITH_HYPHEN)[4].Trim();

                            bool isNumber = Int32.TryParse(processId, out num);
                            if (isNumber)
                            {
                                if (!string.IsNullOrEmpty(item.Owner) && (item.Insert_job.ToLower().Contains(ConfigurationManager.AppSettings["DevBisSubString"]) || item.Insert_job.ToLower().Contains(ConfigurationManager.AppSettings["DevBslSubString"])) && !item.Owner.ToLower().Contains(ConfigurationManager.AppSettings["DevOwnerPrefix"]) && !item.Owner.ToLower().Contains(ConfigurationManager.AppSettings["NewDevOwnerPrefix"]))
                                    listOfWrongNamingConventionJobs.Add(item);
                                if (!string.IsNullOrEmpty(item.Machine) && (item.Insert_job.ToLower().Contains(ConfigurationManager.AppSettings["DevBisSubString"]) || item.Insert_job.ToLower().Contains(ConfigurationManager.AppSettings["DevBslSubString"])) && (!item.Machine.ToLower().Contains(ConfigurationManager.AppSettings["DevRealMachineSubString"]) && !item.Machine.ToLower().Contains(ConfigurationManager.AppSettings["DevVirtualMachineSubString"]) && !item.Machine.ToLower().Contains(ConfigurationManager.AppSettings["NonProdSchedulerMachineName"]) && !item.Machine.ToLower().Contains(ConfigurationManager.AppSettings["DevMachineSubString"])))
                                    listOfWrongNamingConventionJobs.Add(item);
                                if (!string.IsNullOrEmpty(item.Owner) && (item.Insert_job.ToLower().Contains(ConfigurationManager.AppSettings["StageBisSubString"]) || item.Insert_job.ToLower().Contains(ConfigurationManager.AppSettings["StageBslSubString"])) && !item.Owner.ToLower().Contains(ConfigurationManager.AppSettings["StageOwnerPrefix"]) && !item.Owner.ToLower().Contains(ConfigurationManager.AppSettings["NewStageOwnerPrefix"]))
                                    listOfWrongNamingConventionJobs.Add(item);
                                if (!string.IsNullOrEmpty(item.Machine) && (item.Insert_job.ToLower().Contains(ConfigurationManager.AppSettings["StageBisSubString"]) || item.Insert_job.ToLower().Contains(ConfigurationManager.AppSettings["StageBslSubString"])) && (!item.Machine.ToLower().Contains(ConfigurationManager.AppSettings["StageRealMachineSubString"]) && !item.Machine.ToLower().Contains(ConfigurationManager.AppSettings["StageVirtualMachineSubString"]) && !item.Machine.ToLower().Contains(ConfigurationManager.AppSettings["StageMachineSubString"]) && !item.Machine.ToLower().Contains(ConfigurationManager.AppSettings["NonProdSchedulerMachineName"])))
                                    listOfWrongNamingConventionJobs.Add(item);
                                if (!string.IsNullOrEmpty(item.Owner) && (item.Insert_job.ToLower().Contains(ConfigurationManager.AppSettings["CtBisSubString"]) || item.Insert_job.ToLower().Contains(ConfigurationManager.AppSettings["CtBslSubString"])) && !item.Owner.ToLower().Contains(ConfigurationManager.AppSettings["CtOwnerPrefix"]) && !item.Owner.ToLower().Contains(ConfigurationManager.AppSettings["NewCtOwnerPrefix"]))
                                    listOfWrongNamingConventionJobs.Add(item);
                                if (!string.IsNullOrEmpty(item.Machine) && (item.Insert_job.ToLower().Contains(ConfigurationManager.AppSettings["CtBisSubString"]) || item.Insert_job.ToLower().Contains(ConfigurationManager.AppSettings["CtBslSubString"])) && (!item.Machine.ToLower().Contains(ConfigurationManager.AppSettings["CtRealMachineSubString"]) && !item.Machine.ToLower().Contains(ConfigurationManager.AppSettings["CtVirtualMachineSubString"]) && !item.Machine.ToLower().Contains(ConfigurationManager.AppSettings["CtMachineSubString"]) && !item.Machine.ToLower().Contains(ConfigurationManager.AppSettings["NonProdSchedulerMachineName"])))
                                    listOfWrongNamingConventionJobs.Add(item);
                                if (!string.IsNullOrEmpty(item.Owner) && (item.Insert_job.ToLower().Contains(ConfigurationManager.AppSettings["ProductionBisSubstring"]) || item.Insert_job.ToLower().Contains(ConfigurationManager.AppSettings["LowerRegionBslSubstring"])) && (!item.Owner.ToLower().Contains(ConfigurationManager.AppSettings["ProductionOwnerSuffix"]) && item.Owner.ToLower().Contains(ConfigurationManager.AppSettings["DevOwnerPrefix"]) && item.Owner.ToLower().Contains(ConfigurationManager.AppSettings["StageOwnerPrefix"]) && item.Owner.ToLower().Contains(ConfigurationManager.AppSettings["CtOwnerPrefix"])))
                                    listOfWrongNamingConventionJobs.Add(item);
                                if (!string.IsNullOrEmpty(item.Machine) && (item.Insert_job.ToLower().Contains(ConfigurationManager.AppSettings["ProductionBisSubstring"]) || item.Insert_job.ToLower().Contains(ConfigurationManager.AppSettings["LowerRegionBslSubstring"])) && (item.Machine.ToLower().Contains(ConfigurationManager.AppSettings["DevVirtualMachineSubString"]) && item.Machine.ToLower().Contains(ConfigurationManager.AppSettings["DevMachineSubString"]) && item.Machine.ToLower().Contains(ConfigurationManager.AppSettings["DevRealMachineSubString"]) && item.Machine.ToLower().Contains(ConfigurationManager.AppSettings["StageVirtualMachineSubString"]) && item.Machine.ToLower().Contains(ConfigurationManager.AppSettings["StageRealMachineSubString"]) && item.Machine.ToLower().Contains(ConfigurationManager.AppSettings["CtVirtualMachineSubString"]) && item.Machine.ToLower().Contains(ConfigurationManager.AppSettings["CtRealMachineSubString"]) && item.Machine.ToLower().Contains(ConfigurationManager.AppSettings["StageMachineSubString"]) && item.Machine.ToLower().Contains(ConfigurationManager.AppSettings["CtMachineSubString"]) && item.Machine.ToLower().Contains(ConfigurationManager.AppSettings["NonProdSchedulerMachineName"])))
                                    listOfWrongNamingConventionJobs.Add(item);
                            }
                            else
                            {
                                if (processId.Equals("gen"))
                                {
                                    if (!string.IsNullOrEmpty(item.Owner) && (item.Insert_job.ToLower().Contains(ConfigurationManager.AppSettings["DevBisSubString"]) || item.Insert_job.ToLower().Contains(ConfigurationManager.AppSettings["DevBslSubString"])) && !item.Owner.ToLower().Contains(ConfigurationManager.AppSettings["DevOwnerPrefix"]) && !item.Owner.ToLower().Contains(ConfigurationManager.AppSettings["NewDevOwnerPrefix"]))
                                        listOfWrongNamingConventionJobs.Add(item);
                                    if (!string.IsNullOrEmpty(item.Machine) && (item.Insert_job.ToLower().Contains(ConfigurationManager.AppSettings["DevBisSubString"]) || item.Insert_job.ToLower().Contains(ConfigurationManager.AppSettings["DevBslSubString"])) && (!item.Machine.ToLower().Contains(ConfigurationManager.AppSettings["DevRealMachineSubString"]) && !item.Machine.ToLower().Contains(ConfigurationManager.AppSettings["DevVirtualMachineSubString"]) && !item.Machine.ToLower().Contains(ConfigurationManager.AppSettings["NonProdSchedulerMachineName"]) && !item.Machine.ToLower().Contains(ConfigurationManager.AppSettings["DevMachineSubString"])))
                                        listOfWrongNamingConventionJobs.Add(item);
                                    if (!string.IsNullOrEmpty(item.Owner) && (item.Insert_job.ToLower().Contains(ConfigurationManager.AppSettings["StageBisSubString"]) || item.Insert_job.ToLower().Contains(ConfigurationManager.AppSettings["StageBslSubString"])) && !item.Owner.ToLower().Contains(ConfigurationManager.AppSettings["StageOwnerPrefix"]) && !item.Owner.ToLower().Contains(ConfigurationManager.AppSettings["NewStageOwnerPrefix"]))
                                        listOfWrongNamingConventionJobs.Add(item);
                                    if (!string.IsNullOrEmpty(item.Machine) && (item.Insert_job.ToLower().Contains(ConfigurationManager.AppSettings["StageBisSubString"]) || item.Insert_job.ToLower().Contains(ConfigurationManager.AppSettings["StageBslSubString"])) && (!item.Machine.ToLower().Contains(ConfigurationManager.AppSettings["StageRealMachineSubString"]) && !item.Machine.ToLower().Contains(ConfigurationManager.AppSettings["StageVirtualMachineSubString"]) && !item.Machine.ToLower().Contains(ConfigurationManager.AppSettings["StageMachineSubString"]) && !item.Machine.ToLower().Contains(ConfigurationManager.AppSettings["NonProdSchedulerMachineName"])))
                                        listOfWrongNamingConventionJobs.Add(item);
                                    if (!string.IsNullOrEmpty(item.Owner) && (item.Insert_job.ToLower().Contains(ConfigurationManager.AppSettings["CtBisSubString"]) || item.Insert_job.ToLower().Contains(ConfigurationManager.AppSettings["CtBslSubString"])) && !item.Owner.ToLower().Contains(ConfigurationManager.AppSettings["CtOwnerPrefix"]) && !item.Owner.ToLower().Contains(ConfigurationManager.AppSettings["NewCtOwnerPrefix"]))
                                        listOfWrongNamingConventionJobs.Add(item);
                                    if (!string.IsNullOrEmpty(item.Machine) && (item.Insert_job.ToLower().Contains(ConfigurationManager.AppSettings["CtBisSubString"]) || item.Insert_job.ToLower().Contains(ConfigurationManager.AppSettings["CtBslSubString"])) && (!item.Machine.ToLower().Contains(ConfigurationManager.AppSettings["CtRealMachineSubString"]) && !item.Machine.ToLower().Contains(ConfigurationManager.AppSettings["CtVirtualMachineSubString"]) && !item.Machine.ToLower().Contains(ConfigurationManager.AppSettings["CtMachineSubString"]) && !item.Machine.ToLower().Contains(ConfigurationManager.AppSettings["NonProdSchedulerMachineName"])))
                                        listOfWrongNamingConventionJobs.Add(item);
                                    if (!string.IsNullOrEmpty(item.Owner) && (item.Insert_job.ToLower().Contains(ConfigurationManager.AppSettings["ProductionBisSubstring"]) || item.Insert_job.ToLower().Contains(ConfigurationManager.AppSettings["LowerRegionBslSubstring"])) && (!item.Owner.ToLower().Contains(ConfigurationManager.AppSettings["ProductionOwnerSuffix"]) && item.Owner.ToLower().Contains(ConfigurationManager.AppSettings["DevOwnerPrefix"]) && item.Owner.ToLower().Contains(ConfigurationManager.AppSettings["StageOwnerPrefix"]) && item.Owner.ToLower().Contains(ConfigurationManager.AppSettings["CtOwnerPrefix"])))
                                        listOfWrongNamingConventionJobs.Add(item);
                                    if (!string.IsNullOrEmpty(item.Machine) && (item.Insert_job.ToLower().Contains(ConfigurationManager.AppSettings["ProductionBisSubstring"]) || item.Insert_job.ToLower().Contains(ConfigurationManager.AppSettings["LowerRegionBslSubstring"])) && (item.Machine.ToLower().Contains(ConfigurationManager.AppSettings["DevVirtualMachineSubString"]) && item.Machine.ToLower().Contains(ConfigurationManager.AppSettings["DevMachineSubString"]) && item.Machine.ToLower().Contains(ConfigurationManager.AppSettings["DevRealMachineSubString"]) && item.Machine.ToLower().Contains(ConfigurationManager.AppSettings["StageVirtualMachineSubString"]) && item.Machine.ToLower().Contains(ConfigurationManager.AppSettings["StageRealMachineSubString"]) && item.Machine.ToLower().Contains(ConfigurationManager.AppSettings["CtVirtualMachineSubString"]) && item.Machine.ToLower().Contains(ConfigurationManager.AppSettings["CtRealMachineSubString"]) && item.Machine.ToLower().Contains(ConfigurationManager.AppSettings["StageMachineSubString"]) && item.Machine.ToLower().Contains(ConfigurationManager.AppSettings["CtMachineSubString"]) && item.Machine.ToLower().Contains(ConfigurationManager.AppSettings["NonProdSchedulerMachineName"])))
                                        listOfWrongNamingConventionJobs.Add(item);
                                }
                                else
                                {
                                    listOfWrongNamingConventionJobs.Add(item);
                                }
                            }
                        }
                        else
                        {
                            listOfWrongNamingConventionJobs.Add(item);
                        }
                    }
                    else
                    {
                        listOfWrongNamingConventionJobs.Add(item);
                    }
                }
            }

            returnCount = listOfWrongNamingConventionJobs.Distinct().ToList<FilteredJobs>().Count;
            Session[ID + "WrongNamingListOfJobs"] = JsonConvert.SerializeObject(listOfWrongNamingConventionJobs.Distinct().ToList<FilteredJobs>());

            return Json(new { success = returnCount }, JsonRequestBehavior.AllowGet);
        }


        [HttpGet]
        public FileResult GetWrongNamingConventionFile(string ID)
        {
            List<FilteredJobs> wrongNamingList = JsonConvert.DeserializeObject<List<FilteredJobs>>((string)Session[ID + "WrongNamingListOfJobs"]);
            fileName = ConfigurationManager.AppSettings["WrongNamingConventionFileName"];
            FileOperations fileObj = new FileOperations();
            foreach (var file in IO.Directory.GetFiles(IO.Path.GetTempPath()))
            {
                if (file.ToLower().Contains(ConfigurationManager.AppSettings["WrongNamingConventionFileName"].ToLower().Split('.').First().Trim()))
                    IO.File.Delete(file);
            }

            Session[ID + "WrongNamingFileName"] = fileName;
            fileObj.PrintDataToOutputFile(wrongNamingList, IO.Path.Combine(IO.Path.GetTempPath(), fileName));
            if (IO.File.Exists(IO.Path.Combine(IO.Path.GetTempPath(), fileName)) && IO.File.ReadAllBytes(IO.Path.Combine(IO.Path.GetTempPath(), fileName)).Length > 0)
            {
                return File(IO.Path.Combine(IO.Path.GetTempPath(), fileName), StringConstants.FILE_TYPE, fileName);
            }
            else
                return null;
        }

        [HttpGet]
        public void ConvertJILFileForAnotherRegions(string ID, bool devCheckBoxValue, bool stageCheckBoxValue, bool ctCheckBoxValue, bool prodCheckBoxValue)
        {
            string fileName = Session[ID + "FileName"] as string;
            if (string.IsNullOrEmpty(fileName))
            {
                if (devCheckBoxValue)
                    fileName = "DEV_ConvertedJobs.jil";
                else if (stageCheckBoxValue)
                    fileName = "STAGE_ConvertedJobs.jil";
                else if (ctCheckBoxValue)
                    fileName = "CT_ConvertedJobs.jil";
                else if (prodCheckBoxValue)
                    fileName = "PROD_ConvertedJobs.jil";
            }
            List<FilteredJobs> listOfGeneratedJobs = Session[ID + "ListOfJobs"] as List<FilteredJobs>;
            List<FilteredJobs> listOfJobsToWrite = ConvertJil(listOfGeneratedJobs, devCheckBoxValue, stageCheckBoxValue, ctCheckBoxValue, prodCheckBoxValue);
            if (devCheckBoxValue)
            {
                fileName = fileName.Replace(ConfigurationManager.AppSettings["UpdatedFileNameSuffix"], ConfigurationManager.AppSettings["ConvertedToDevFileName"]);
                fileName = fileName.Replace(ConfigurationManager.AppSettings["ConvertedToStageFileName"], ConfigurationManager.AppSettings["ConvertedToDevFileName"]);
                fileName = fileName.Replace(ConfigurationManager.AppSettings["ConvertedToCtFileName"], ConfigurationManager.AppSettings["ConvertedToDevFileName"]);
                fileName = fileName.Replace(ConfigurationManager.AppSettings["ConvertedToProdFileName"], ConfigurationManager.AppSettings["ConvertedToDevFileName"]);
                fileName = fileName.Replace("STAGE_ConvertedJobs", "DEV_ConvertedJobs");
                fileName = fileName.Replace("CT_ConvertedJobs", "DEV_ConvertedJobs");
                fileName = fileName.Replace("PROD_ConvertedJobs", "DEV_ConvertedJobs");
            }
            else if (stageCheckBoxValue)
            {
                fileName = fileName.Replace(ConfigurationManager.AppSettings["UpdatedFileNameSuffix"], ConfigurationManager.AppSettings["ConvertedToStageFileName"]);
                fileName = fileName.Replace(ConfigurationManager.AppSettings["ConvertedToDevFileName"], ConfigurationManager.AppSettings["ConvertedToStageFileName"]);
                fileName = fileName.Replace(ConfigurationManager.AppSettings["ConvertedToCtFileName"], ConfigurationManager.AppSettings["ConvertedToStageFileName"]);
                fileName = fileName.Replace(ConfigurationManager.AppSettings["ConvertedToProdFileName"], ConfigurationManager.AppSettings["ConvertedToStageFileName"]);
                fileName = fileName.Replace("DEV_ConvertedJobs", "STAGE_ConvertedJobs");
                fileName = fileName.Replace("CT_ConvertedJobs", "STAGE_ConvertedJobs");
                fileName = fileName.Replace("PROD_ConvertedJobs", "STAGE_ConvertedJobs");
            }
            else if (ctCheckBoxValue)
            {
                fileName = fileName.Replace(ConfigurationManager.AppSettings["UpdatedFileNameSuffix"], ConfigurationManager.AppSettings["ConvertedToCtFileName"]);
                fileName = fileName.Replace(ConfigurationManager.AppSettings["ConvertedToDevFileName"], ConfigurationManager.AppSettings["ConvertedToCtFileName"]);
                fileName = fileName.Replace(ConfigurationManager.AppSettings["ConvertedToStageFileName"], ConfigurationManager.AppSettings["ConvertedToCtFileName"]);
                fileName = fileName.Replace(ConfigurationManager.AppSettings["ConvertedToProdFileName"], ConfigurationManager.AppSettings["ConvertedToCtFileName"]);
                fileName = fileName.Replace("DEV_ConvertedJobs", "CT_ConvertedJobs");
                fileName = fileName.Replace("STAGE_ConvertedJobs", "CT_ConvertedJobs");
                fileName = fileName.Replace("PROD_ConvertedJobs", "CT_ConvertedJobs");

            }
            else if (prodCheckBoxValue)
            {
                fileName = fileName.Replace(ConfigurationManager.AppSettings["UpdatedFileNameSuffix"], ConfigurationManager.AppSettings["ConvertedToProdFileName"]);
                fileName = fileName.Replace(ConfigurationManager.AppSettings["ConvertedToDevFileName"], ConfigurationManager.AppSettings["ConvertedToProdFileName"]);
                fileName = fileName.Replace(ConfigurationManager.AppSettings["ConvertedToStageFileName"], ConfigurationManager.AppSettings["ConvertedToProdFileName"]);
                fileName = fileName.Replace(ConfigurationManager.AppSettings["ConvertedToCtFileName"], ConfigurationManager.AppSettings["ConvertedToProdFileName"]);
                fileName = fileName.Replace("DEV_ConvertedJobs", "PROD_ConvertedJobs");
                fileName = fileName.Replace("STAGE_ConvertedJobs", "PROD_ConvertedJobs");
                fileName = fileName.Replace("CT_ConvertedJobs", "PROD_ConvertedJobs");
            }

            Session[ID + "FileName"] = fileName;
            FileOperations fileObj = new FileOperations();
            foreach (var file in IO.Directory.GetFiles(IO.Path.GetTempPath()))
            {
                if (file.ToLower().Contains(ConfigurationManager.AppSettings["UpdatedFileNameSuffix"].ToLower()) || file.ToLower().Contains("converted"))
                    IO.File.Delete(file);
            }
            fileObj.PrintDataToOutputFile(listOfJobsToWrite, IO.Path.Combine(IO.Path.GetTempPath(), fileName));
            //return File(IO.Path.Combine(IO.Path.GetTempPath(), fileName), StringConstants.FILE_TYPE, fileName);
        }

        private List<FilteredJobs> ConvertJil(List<FilteredJobs> listOfJobs, bool devCheckBoxValue, bool stageCheckBoxValue, bool ctCheckBoxValue, bool prodCheckBoxValue)
        {
            foreach (FilteredJobs job in listOfJobs)
            {
                if (!(string.IsNullOrEmpty(job.DateCondition) || job.DateCondition.Contains("0")))
                {
                    job.TimeZone = "timezone: " + ConfigurationManager.AppSettings["TimeZoneValue"];
                }

                if (!string.IsNullOrEmpty(job.Command) && (job.Command.Contains(@"\:-D") || job.Command.Contains(@"\\:-D")))
                {
                    job.Command = job.Command.Replace(@"\\:-D", @":-D");
                    job.Command = job.Command.Replace(@"\:-D", @":-D");
                }

                job.Machine = job.Machine.ToLower();
                if (devCheckBoxValue)
                {
                    if (!string.IsNullOrEmpty(job.Header))
                    {
                        job.Header = job.Header.Replace(ConfigurationManager.AppSettings["StageBisSubString"], ConfigurationManager.AppSettings["DevBisSubString"]);
                        job.Header = job.Header.Replace(ConfigurationManager.AppSettings["CtBisSubString"], ConfigurationManager.AppSettings["DevBisSubString"]);
                        job.Header = job.Header.Replace(ConfigurationManager.AppSettings["ProdBisSubString"], ConfigurationManager.AppSettings["DevBisSubString"]);
                    }
                    if (!string.IsNullOrEmpty(job.Insert_job))
                    {
                        job.Insert_job = job.Insert_job.Replace(ConfigurationManager.AppSettings["StageBisSubString"], ConfigurationManager.AppSettings["DevBisSubString"]);
                        job.Insert_job = job.Insert_job.Replace(ConfigurationManager.AppSettings["CtBisSubString"], ConfigurationManager.AppSettings["DevBisSubString"]);
                        job.Insert_job = job.Insert_job.Replace(ConfigurationManager.AppSettings["ProdBisSubString"], ConfigurationManager.AppSettings["DevBisSubString"]);
                    }
                    if (!string.IsNullOrEmpty(job.Boxname))
                    {
                        job.Boxname = job.Boxname.Replace(ConfigurationManager.AppSettings["StageBisSubString"], ConfigurationManager.AppSettings["DevBisSubString"]);
                        job.Boxname = job.Boxname.Replace(ConfigurationManager.AppSettings["CtBisSubString"], ConfigurationManager.AppSettings["DevBisSubString"]);
                        job.Boxname = job.Boxname.Replace(ConfigurationManager.AppSettings["ProdBisSubString"], ConfigurationManager.AppSettings["DevBisSubString"]);
                    }
                    if (!string.IsNullOrEmpty(job.Condition))
                    {
                        job.Condition = job.Condition.Replace(ConfigurationManager.AppSettings["StageBisSubString"], ConfigurationManager.AppSettings["DevBisSubString"]);
                        job.Condition = job.Condition.Replace(ConfigurationManager.AppSettings["CtBisSubString"], ConfigurationManager.AppSettings["DevBisSubString"]);
                        job.Condition = job.Condition.Replace(ConfigurationManager.AppSettings["ProdBisSubString"], ConfigurationManager.AppSettings["DevBisSubString"]);
                    }
                    if (!string.IsNullOrEmpty(job.Box_Success))
                    {
                        job.Box_Success = job.Box_Success.Replace(ConfigurationManager.AppSettings["StageBisSubString"], ConfigurationManager.AppSettings["DevBisSubString"]);
                        job.Box_Success = job.Box_Success.Replace(ConfigurationManager.AppSettings["CtBisSubString"], ConfigurationManager.AppSettings["DevBisSubString"]);
                        job.Box_Success = job.Box_Success.Replace(ConfigurationManager.AppSettings["ProdBisSubString"], ConfigurationManager.AppSettings["DevBisSubString"]);
                    }
                    if (!string.IsNullOrEmpty(job.Box_Failure))
                    {
                        job.Box_Failure = job.Box_Failure.Replace(ConfigurationManager.AppSettings["StageBisSubString"], ConfigurationManager.AppSettings["DevBisSubString"]);
                        job.Box_Failure = job.Box_Failure.Replace(ConfigurationManager.AppSettings["CtBisSubString"], ConfigurationManager.AppSettings["DevBisSubString"]);
                        job.Box_Failure = job.Box_Failure.Replace(ConfigurationManager.AppSettings["ProdBisSubString"], ConfigurationManager.AppSettings["DevBisSubString"]);
                    }
                    if (!string.IsNullOrEmpty(job.Machine))
                    {
                        job.Machine = job.Machine.Replace(ConfigurationManager.AppSettings["StageVirtualMachineSubString"], ConfigurationManager.AppSettings["DevVirtualMachineSubString"]);
                        job.Machine = job.Machine.Replace(ConfigurationManager.AppSettings["StageRealMachineSubString"], ConfigurationManager.AppSettings["DevRealMachineSubString"]);
                        job.Machine = job.Machine.Replace(ConfigurationManager.AppSettings["StageMachineSubString"], ConfigurationManager.AppSettings["DevMachineSubString"]);
                        job.Machine = job.Machine.Replace(ConfigurationManager.AppSettings["CtVirtualMachineSubString"], ConfigurationManager.AppSettings["DevVirtualMachineSubString"]);
                        job.Machine = job.Machine.Replace(ConfigurationManager.AppSettings["CtRealMachineSubString"], ConfigurationManager.AppSettings["DevRealMachineSubString"]);
                        job.Machine = job.Machine.Replace(ConfigurationManager.AppSettings["CtMachineSubString"], ConfigurationManager.AppSettings["DevMachineSubString"]);                        

                        //need to check for below
                        if (job.Machine.Contains("od_") && !job.Machine.Contains("_alp"))
                        {
                            job.Machine = job.Machine.Replace("proasa", "asa");
                            job.Machine = job.Machine.Replace("_2008", "");
                            job.Machine = job.Machine + "_alp";
                        }

                        if (job.Machine.Contains("progwy"))
                        {
                            job.Machine = job.Machine.Split(':').First().Trim() + ": " + ConfigurationManager.AppSettings["DevGwyAsaMachine"];
                        }
                    }

                    if (!string.IsNullOrEmpty(job.Owner))
                    {
                        //job.Owner = job.Owner.Replace(ConfigurationManager.AppSettings["StageOwnerPre"], ConfigurationManager.AppSettings["DevOwnerPre"]);
                        //job.Owner = job.Owner.Replace(ConfigurationManager.AppSettings["CtOwnerPre"], ConfigurationManager.AppSettings["DevOwnerPre"]);
                        //string ownerName = job.Owner.Split(':').Last().Trim();
                        //if (!ownerName.Contains("_") && !job.Owner.Contains(ConfigurationManager.AppSettings["NewOwnerName"]))
                        //    job.Owner = job.Owner.Split(':').First().Trim() + ":  DEV_" + ownerName;

                        //job.Owner = job.Owner.Replace(ConfigurationManager.AppSettings["ProductionOwnerSuffix"].ToUpper(), ConfigurationManager.AppSettings["NonProductionOwnerSuffix"].ToUpper());
                        job.Owner = Regex.Replace(job.Owner, ConfigurationManager.AppSettings["StageOwnerPre"], ConfigurationManager.AppSettings["DevOwnerPre"], RegexOptions.IgnoreCase);
                        job.Owner = Regex.Replace(job.Owner, ConfigurationManager.AppSettings["CtOwnerPre"], ConfigurationManager.AppSettings["DevOwnerPre"], RegexOptions.IgnoreCase);
                        job.Owner = Regex.Replace(job.Owner, ConfigurationManager.AppSettings["NewStageOwnerPre"], ConfigurationManager.AppSettings["NewDevOwnerPre"], RegexOptions.IgnoreCase);
                        job.Owner = Regex.Replace(job.Owner, ConfigurationManager.AppSettings["NewCtOwnerPre"], ConfigurationManager.AppSettings["NewDevOwnerPre"], RegexOptions.IgnoreCase);
                        job.Owner = Regex.Replace(job.Owner, "CT_", ConfigurationManager.AppSettings["DevOwnerPre"] + "_", RegexOptions.IgnoreCase);
                        //string ownerName = job.Owner.Split(':').Last().Trim();
                        //if (!ownerName.Contains("_") && !job.Owner.Contains(ConfigurationManager.AppSettings["NewOwnerName"]))
                        //    job.Owner = job.Owner.Split(':').First().Trim() + ":  DEV_" + ownerName;

                        job.Owner = Regex.Replace(job.Owner, ConfigurationManager.AppSettings["ProductionOwnerSuffix"], ConfigurationManager.AppSettings["NonProductionOwnerSuffix"].ToUpper(), RegexOptions.IgnoreCase);
                        if (!job.Owner.Contains(ConfigurationManager.AppSettings["DevOwnerPrefix"].ToUpper()) && !job.Owner.Contains(ConfigurationManager.AppSettings["NewDevOwnerPre"]))
                        {
                            job.Owner = job.Owner.Replace("AsysActionAcct", "DEV_AsysActionAcct");
                            job.Owner = job.Owner.Replace("AsysWinUnixAcct", "DEV_AsysWinUnixAcct");
                        }
                        if (job.Owner.Contains("AsysActionAcct") && !job.Owner.ToUpper().Contains(ConfigurationManager.AppSettings["NonProductionOwnerSuffix"].ToUpper()))
                        {
                            job.Owner = job.Owner.Replace("AsysActionAcct", "AsysActionAcct@CORP");
                        }
                        if (job.Owner.Contains("BM_"))
                            job.Owner = job.Owner.Replace("BM_", ConfigurationManager.AppSettings["DevOwnerPrefix"].ToUpper());

                        if(job.Owner.Contains(ConfigurationManager.AppSettings["ProductionOwnerSuffix"].ToUpper()))
                        {
                            job.Owner = job.Owner.Replace(ConfigurationManager.AppSettings["ProductionOwnerSuffix"].ToUpper(), ConfigurationManager.AppSettings["NonProductionOwnerSuffix"].ToUpper());
                        }
                    }

                    //adding changes in new attributes similar to owner
                    if (!string.IsNullOrEmpty(job.Ftp_Local_User))
                    {
                        //job.Ftp_Local_User = job.Ftp_Local_User.Replace(ConfigurationManager.AppSettings["StageOwnerPre"], ConfigurationManager.AppSettings["DevOwnerPre"]);
                        //job.Ftp_Local_User = job.Ftp_Local_User.Replace(ConfigurationManager.AppSettings["CtOwnerPre"], ConfigurationManager.AppSettings["DevOwnerPre"]);
                        //string ownerName = job.Ftp_Local_User.Split(':').Last().Trim();
                        //if (!ownerName.Contains("_") && !job.Ftp_Local_User.Contains(ConfigurationManager.AppSettings["NewOwnerName"]))
                        //    job.Ftp_Local_User = job.Ftp_Local_User.Split(':').First().Trim() + ":  DEV_" + ownerName;

                        //job.Ftp_Local_User = job.Ftp_Local_User.Replace(ConfigurationManager.AppSettings["ProductionOwnerSuffix"].ToUpper(), ConfigurationManager.AppSettings["NonProductionOwnerSuffix"].ToUpper());
                        job.Ftp_Local_User = Regex.Replace(job.Ftp_Local_User, ConfigurationManager.AppSettings["StageOwnerPre"], ConfigurationManager.AppSettings["DevOwnerPre"], RegexOptions.IgnoreCase);
                        job.Ftp_Local_User = Regex.Replace(job.Ftp_Local_User, ConfigurationManager.AppSettings["CtOwnerPre"], ConfigurationManager.AppSettings["DevOwnerPre"], RegexOptions.IgnoreCase);
                        job.Ftp_Local_User = Regex.Replace(job.Ftp_Local_User, ConfigurationManager.AppSettings["NewStageOwnerPre"], ConfigurationManager.AppSettings["NewDevOwnerPre"], RegexOptions.IgnoreCase);
                        job.Ftp_Local_User = Regex.Replace(job.Ftp_Local_User, ConfigurationManager.AppSettings["NewCtOwnerPre"], ConfigurationManager.AppSettings["NewDevOwnerPre"], RegexOptions.IgnoreCase);
                        //string ownerName = job.Ftp_Local_User.Split(':').Last().Trim();
                        //if (!ownerName.Contains("_") && !job.Ftp_Local_User.Contains(ConfigurationManager.AppSettings["NewOwnerName"]))
                        //    job.Ftp_Local_User = job.Ftp_Local_User.Split(':').First().Trim() + ":  DEV_" + ownerName;

                        job.Ftp_Local_User = Regex.Replace(job.Ftp_Local_User, ConfigurationManager.AppSettings["ProductionOwnerSuffix"], ConfigurationManager.AppSettings["NonProductionOwnerSuffix"].ToUpper(), RegexOptions.IgnoreCase);
                        if (!job.Ftp_Local_User.Contains(ConfigurationManager.AppSettings["DevOwnerPrefix"].ToUpper()) && !job.Ftp_Local_User.Contains(ConfigurationManager.AppSettings["NewDevOwnerPre"]))
                            job.Ftp_Local_User = job.Ftp_Local_User.Replace("AsysActionAcct", "DEV_AsysActionAcct");
                        if (job.Ftp_Local_User.Contains("AsysActionAcct") && !job.Ftp_Local_User.ToUpper().Contains(ConfigurationManager.AppSettings["NonProductionOwnerSuffix"].ToUpper()))
                        {
                            job.Ftp_Local_User = job.Ftp_Local_User.Replace("AsysActionAcct", "AsysActionAcct@CORP");
                        }
                        if (job.Ftp_Local_User.Contains("BM_"))
                            job.Ftp_Local_User = job.Ftp_Local_User.Replace("BM_", ConfigurationManager.AppSettings["DevOwnerPrefix"].ToUpper());
                    }

                    if (!string.IsNullOrEmpty(job.Watch_File_Win_User))
                    {
                        //job.Watch_File_Win_User = job.Watch_File_Win_User.Replace(ConfigurationManager.AppSettings["StageOwnerPre"], ConfigurationManager.AppSettings["DevOwnerPre"]);
                        //job.Watch_File_Win_User = job.Watch_File_Win_User.Replace(ConfigurationManager.AppSettings["CtOwnerPre"], ConfigurationManager.AppSettings["DevOwnerPre"]);
                        //string ownerName = job.Watch_File_Win_User.Split(':').Last().Trim();
                        //if (!ownerName.Contains("_") && !job.Watch_File_Win_User.Contains(ConfigurationManager.AppSettings["NewOwnerName"]))
                        //    job.Watch_File_Win_User = job.Watch_File_Win_User.Split(':').First().Trim() + ":  DEV_" + ownerName;

                        //job.Watch_File_Win_User = job.Watch_File_Win_User.Replace(ConfigurationManager.AppSettings["ProductionOwnerSuffix"].ToUpper(), ConfigurationManager.AppSettings["NonProductionOwnerSuffix"].ToUpper());
                        job.Watch_File_Win_User = Regex.Replace(job.Watch_File_Win_User, ConfigurationManager.AppSettings["StageOwnerPre"], ConfigurationManager.AppSettings["DevOwnerPre"], RegexOptions.IgnoreCase);
                        job.Watch_File_Win_User = Regex.Replace(job.Watch_File_Win_User, ConfigurationManager.AppSettings["CtOwnerPre"], ConfigurationManager.AppSettings["DevOwnerPre"], RegexOptions.IgnoreCase);
                        job.Watch_File_Win_User = Regex.Replace(job.Watch_File_Win_User, ConfigurationManager.AppSettings["NewStageOwnerPre"], ConfigurationManager.AppSettings["NewDevOwnerPre"], RegexOptions.IgnoreCase);
                        job.Watch_File_Win_User = Regex.Replace(job.Watch_File_Win_User, ConfigurationManager.AppSettings["NewCtOwnerPre"], ConfigurationManager.AppSettings["NewDevOwnerPre"], RegexOptions.IgnoreCase);
                        //string ownerName = job.Watch_File_Win_User.Split(':').Last().Trim();
                        //if (!ownerName.Contains("_") && !job.Watch_File_Win_User.Contains(ConfigurationManager.AppSettings["NewOwnerName"]))
                        //    job.Watch_File_Win_User = job.Watch_File_Win_User.Split(':').First().Trim() + ":  DEV_" + ownerName;

                        job.Watch_File_Win_User = Regex.Replace(job.Watch_File_Win_User, ConfigurationManager.AppSettings["ProductionOwnerSuffix"], ConfigurationManager.AppSettings["NonProductionOwnerSuffix"].ToUpper(), RegexOptions.IgnoreCase);
                        if (!job.Watch_File_Win_User.Contains(ConfigurationManager.AppSettings["DevOwnerPrefix"].ToUpper()) && !job.Watch_File_Win_User.Contains(ConfigurationManager.AppSettings["NewDevOwnerPre"]))
                            job.Watch_File_Win_User = job.Watch_File_Win_User.Replace("AsysActionAcct", "DEV_AsysActionAcct");
                        if (job.Watch_File_Win_User.Contains("AsysActionAcct") && !job.Watch_File_Win_User.ToUpper().Contains(ConfigurationManager.AppSettings["NonProductionOwnerSuffix"].ToUpper()))
                        {
                            job.Watch_File_Win_User = job.Watch_File_Win_User.Replace("AsysActionAcct", "AsysActionAcct@CORP");
                        }
                        if (job.Watch_File_Win_User.Contains("BM_"))
                            job.Watch_File_Win_User = job.Watch_File_Win_User.Replace("BM_", ConfigurationManager.AppSettings["DevOwnerPrefix"].ToUpper());
                    }


                    if (!string.IsNullOrEmpty(job.Command))
                    {
                        job.Command = Regex.Replace(job.Command, ConfigurationManager.AppSettings["CtCommandPath"], ConfigurationManager.AppSettings["DevNASCommandPath"], RegexOptions.IgnoreCase);
                        job.Command = Regex.Replace(job.Command, ConfigurationManager.AppSettings["StageCommandPath"], ConfigurationManager.AppSettings["DevNASCommandPath"], RegexOptions.IgnoreCase);
                        job.Command = job.Command.Replace(ConfigurationManager.AppSettings["OldDevCommandPath"].Replace("$$$$", "$$"), ConfigurationManager.AppSettings["DevNASCommandPath"]);
                        job.Command = job.Command.Replace(ConfigurationManager.AppSettings["DevCommandPath"].Replace("$$$$", "$$"), ConfigurationManager.AppSettings["DevNASCommandPath"]);
                        job.Command = job.Command.Replace(ConfigurationManager.AppSettings["CtCommandPath"].Replace("$$$$", "$$"), ConfigurationManager.AppSettings["DevNASCommandPath"]);
                        job.Command = job.Command.Replace(ConfigurationManager.AppSettings["StageCommandPath"].Replace("$$$$", "$$"), ConfigurationManager.AppSettings["DevNASCommandPath"]);
                        job.Command = job.Command.Replace(ConfigurationManager.AppSettings["CtNASCommandPath"].Replace("$$$$", "$$"), ConfigurationManager.AppSettings["DevNASCommandPath"]);
                        job.Command = job.Command.Replace(ConfigurationManager.AppSettings["StageNASCommandPath"].Replace("$$$$", "$$"), ConfigurationManager.AppSettings["DevNASCommandPath"]);
                        job.Command = Regex.Replace(job.Command, ConfigurationManager.AppSettings["NonProdFileStoreRootLocation"], ConfigurationManager.AppSettings["DevNASCommandPath"], RegexOptions.IgnoreCase);
                        job.Command = Regex.Replace(job.Command, ConfigurationManager.AppSettings["DalProdFileStoreRootLocation"], ConfigurationManager.AppSettings["DevNASCommandPath"], RegexOptions.IgnoreCase);
                        job.Command = Regex.Replace(job.Command, ConfigurationManager.AppSettings["ChiProdFileStoreRootLocation"], ConfigurationManager.AppSettings["DevNASCommandPath"], RegexOptions.IgnoreCase);
                        job.Command = Regex.Replace(job.Command, ConfigurationManager.AppSettings["StageOldAsaMachine01"], ConfigurationManager.AppSettings["DevNASCommandPath"], RegexOptions.IgnoreCase);
                        job.Command = Regex.Replace(job.Command, ConfigurationManager.AppSettings["StageOldAsaMachine02"], ConfigurationManager.AppSettings["DevNASCommandPath"], RegexOptions.IgnoreCase);
                        job.Command = Regex.Replace(job.Command, ConfigurationManager.AppSettings["StageNewAsaMachine01"], ConfigurationManager.AppSettings["DevNASCommandPath"], RegexOptions.IgnoreCase);
                        job.Command = Regex.Replace(job.Command, ConfigurationManager.AppSettings["StageNewAsaMachine02"], ConfigurationManager.AppSettings["DevNASCommandPath"], RegexOptions.IgnoreCase);
                        job.Command = Regex.Replace(job.Command, ConfigurationManager.AppSettings["CtOldAsaMachine01"], ConfigurationManager.AppSettings["DevNASCommandPath"], RegexOptions.IgnoreCase);
                        job.Command = Regex.Replace(job.Command, ConfigurationManager.AppSettings["CtOldAsaMachine02"], ConfigurationManager.AppSettings["DevNASCommandPath"], RegexOptions.IgnoreCase);
                        job.Command = Regex.Replace(job.Command, ConfigurationManager.AppSettings["CtNewAsaMachine01"], ConfigurationManager.AppSettings["DevNASCommandPath"], RegexOptions.IgnoreCase);
                        job.Command = Regex.Replace(job.Command, ConfigurationManager.AppSettings["CtNewAsaMachine02"], ConfigurationManager.AppSettings["DevNASCommandPath"], RegexOptions.IgnoreCase);
                        job.Command = Regex.Replace(job.Command, ConfigurationManager.AppSettings["DevGwyNewAsaMachine01"], ConfigurationManager.AppSettings["DevNASCommandPath"], RegexOptions.IgnoreCase);
                        job.Command = Regex.Replace(job.Command, ConfigurationManager.AppSettings["DevGwyNewAsaMachine02"], ConfigurationManager.AppSettings["DevNASCommandPath"], RegexOptions.IgnoreCase);
                        job.Command = Regex.Replace(job.Command, ConfigurationManager.AppSettings["StageGwyNewAsaMachine01"], ConfigurationManager.AppSettings["DevNASCommandPath"], RegexOptions.IgnoreCase);
                        job.Command = Regex.Replace(job.Command, ConfigurationManager.AppSettings["StageGwyNewAsaMachine02"], ConfigurationManager.AppSettings["DevNASCommandPath"], RegexOptions.IgnoreCase);
                        job.Command = Regex.Replace(job.Command, ConfigurationManager.AppSettings["CtGwyNewAsaMachine01"], ConfigurationManager.AppSettings["DevNASCommandPath"], RegexOptions.IgnoreCase);
                        job.Command = Regex.Replace(job.Command, ConfigurationManager.AppSettings["CtGwyNewAsaMachine02"], ConfigurationManager.AppSettings["DevNASCommandPath"], RegexOptions.IgnoreCase);
                        job.Command = Regex.Replace(job.Command, ConfigurationManager.AppSettings["NonProdSchedulerNASMachine"], ConfigurationManager.AppSettings["DevNASCommandPath"], RegexOptions.IgnoreCase);
                        job.Command = Regex.Replace(job.Command, ConfigurationManager.AppSettings["OldIncomingFilesPath"], ConfigurationManager.AppSettings["NewIncomingFilesPath"], RegexOptions.IgnoreCase);
                        job.Command = Regex.Replace(job.Command, ConfigurationManager.AppSettings["ProdFileNameExtension"], ConfigurationManager.AppSettings["DevFileNameExtension"], RegexOptions.IgnoreCase);
                        job.Command = Regex.Replace(job.Command, ConfigurationManager.AppSettings["StageFileNameExtension"], ConfigurationManager.AppSettings["DevFileNameExtension"], RegexOptions.IgnoreCase);
                        job.Command = Regex.Replace(job.Command, ConfigurationManager.AppSettings["CtFileNameExtension"], ConfigurationManager.AppSettings["DevFileNameExtension"], RegexOptions.IgnoreCase);
                        job.Command = job.Command.Replace("$$$$", "$$");
                        job.Command = job.Command.Replace(StringConstants.STAGE_BIS_JOBS_SUBSTRING, StringConstants.DEV_BIS_JOBS_SUBSTRING);
                        job.Command = job.Command.Replace(StringConstants.CT_BIS_JOBS_SUBSTRING, StringConstants.DEV_BIS_JOBS_SUBSTRING);
                        job.Command = job.Command.Replace(StringConstants.PROD_BIS_JOBS_SUBSTRING, StringConstants.DEV_BIS_JOBS_SUBSTRING);
                    }

                    //adding changes in new attributes similar to command
                    if (!string.IsNullOrEmpty(job.Ftp_Local_Name))
                    {
                        job.Ftp_Local_Name = Regex.Replace(job.Ftp_Local_Name, ConfigurationManager.AppSettings["CtCommandPath"], ConfigurationManager.AppSettings["DevNASCommandPath"], RegexOptions.IgnoreCase);
                        job.Ftp_Local_Name = Regex.Replace(job.Ftp_Local_Name, ConfigurationManager.AppSettings["StageCommandPath"], ConfigurationManager.AppSettings["DevNASCommandPath"], RegexOptions.IgnoreCase);
                        job.Ftp_Local_Name = job.Ftp_Local_Name.Replace(ConfigurationManager.AppSettings["OldDevCommandPath"].Replace("$$$$", "$$"), ConfigurationManager.AppSettings["DevNASCommandPath"]);
                        job.Ftp_Local_Name = job.Ftp_Local_Name.Replace(ConfigurationManager.AppSettings["DevCommandPath"].Replace("$$$$", "$$"), ConfigurationManager.AppSettings["DevNASCommandPath"]);
                        job.Ftp_Local_Name = job.Ftp_Local_Name.Replace(ConfigurationManager.AppSettings["CtCommandPath"].Replace("$$$$", "$$"), ConfigurationManager.AppSettings["DevNASCommandPath"]);
                        job.Ftp_Local_Name = job.Ftp_Local_Name.Replace(ConfigurationManager.AppSettings["StageCommandPath"].Replace("$$$$", "$$"), ConfigurationManager.AppSettings["DevNASCommandPath"]);
                        job.Ftp_Local_Name = job.Ftp_Local_Name.Replace(ConfigurationManager.AppSettings["CtNASCommandPath"].Replace("$$$$", "$$"), ConfigurationManager.AppSettings["DevNASCommandPath"]);
                        job.Ftp_Local_Name = job.Ftp_Local_Name.Replace(ConfigurationManager.AppSettings["StageNASCommandPath"].Replace("$$$$", "$$"), ConfigurationManager.AppSettings["DevNASCommandPath"]);
                        job.Ftp_Local_Name = Regex.Replace(job.Ftp_Local_Name, ConfigurationManager.AppSettings["NonProdFileStoreRootLocation"], ConfigurationManager.AppSettings["DevNASCommandPath"], RegexOptions.IgnoreCase);
                        job.Ftp_Local_Name = Regex.Replace(job.Ftp_Local_Name, ConfigurationManager.AppSettings["DalProdFileStoreRootLocation"], ConfigurationManager.AppSettings["DevNASCommandPath"], RegexOptions.IgnoreCase);
                        job.Ftp_Local_Name = Regex.Replace(job.Ftp_Local_Name, ConfigurationManager.AppSettings["ChiProdFileStoreRootLocation"], ConfigurationManager.AppSettings["DevNASCommandPath"], RegexOptions.IgnoreCase);
                        job.Ftp_Local_Name = Regex.Replace(job.Ftp_Local_Name, ConfigurationManager.AppSettings["StageOldAsaMachine01"], ConfigurationManager.AppSettings["DevNASCommandPath"], RegexOptions.IgnoreCase);
                        job.Ftp_Local_Name = Regex.Replace(job.Ftp_Local_Name, ConfigurationManager.AppSettings["StageOldAsaMachine02"], ConfigurationManager.AppSettings["DevNASCommandPath"], RegexOptions.IgnoreCase);
                        job.Ftp_Local_Name = Regex.Replace(job.Ftp_Local_Name, ConfigurationManager.AppSettings["StageNewAsaMachine01"], ConfigurationManager.AppSettings["DevNASCommandPath"], RegexOptions.IgnoreCase);
                        job.Ftp_Local_Name = Regex.Replace(job.Ftp_Local_Name, ConfigurationManager.AppSettings["StageNewAsaMachine02"], ConfigurationManager.AppSettings["DevNASCommandPath"], RegexOptions.IgnoreCase);
                        job.Ftp_Local_Name = Regex.Replace(job.Ftp_Local_Name, ConfigurationManager.AppSettings["CtOldAsaMachine01"], ConfigurationManager.AppSettings["DevNASCommandPath"], RegexOptions.IgnoreCase);
                        job.Ftp_Local_Name = Regex.Replace(job.Ftp_Local_Name, ConfigurationManager.AppSettings["CtOldAsaMachine02"], ConfigurationManager.AppSettings["DevNASCommandPath"], RegexOptions.IgnoreCase);
                        job.Ftp_Local_Name = Regex.Replace(job.Ftp_Local_Name, ConfigurationManager.AppSettings["CtNewAsaMachine01"], ConfigurationManager.AppSettings["DevNASCommandPath"], RegexOptions.IgnoreCase);
                        job.Ftp_Local_Name = Regex.Replace(job.Ftp_Local_Name, ConfigurationManager.AppSettings["CtNewAsaMachine02"], ConfigurationManager.AppSettings["DevNASCommandPath"], RegexOptions.IgnoreCase);
                        job.Ftp_Local_Name = Regex.Replace(job.Ftp_Local_Name, ConfigurationManager.AppSettings["DevGwyNewAsaMachine01"], ConfigurationManager.AppSettings["DevNASCommandPath"], RegexOptions.IgnoreCase);
                        job.Ftp_Local_Name = Regex.Replace(job.Ftp_Local_Name, ConfigurationManager.AppSettings["DevGwyNewAsaMachine02"], ConfigurationManager.AppSettings["DevNASCommandPath"], RegexOptions.IgnoreCase);
                        job.Ftp_Local_Name = Regex.Replace(job.Ftp_Local_Name, ConfigurationManager.AppSettings["StageGwyNewAsaMachine01"], ConfigurationManager.AppSettings["DevNASCommandPath"], RegexOptions.IgnoreCase);
                        job.Ftp_Local_Name = Regex.Replace(job.Ftp_Local_Name, ConfigurationManager.AppSettings["StageGwyNewAsaMachine02"], ConfigurationManager.AppSettings["DevNASCommandPath"], RegexOptions.IgnoreCase);
                        job.Ftp_Local_Name = Regex.Replace(job.Ftp_Local_Name, ConfigurationManager.AppSettings["CtGwyNewAsaMachine01"], ConfigurationManager.AppSettings["DevNASCommandPath"], RegexOptions.IgnoreCase);
                        job.Ftp_Local_Name = Regex.Replace(job.Ftp_Local_Name, ConfigurationManager.AppSettings["CtGwyNewAsaMachine02"], ConfigurationManager.AppSettings["DevNASCommandPath"], RegexOptions.IgnoreCase);
                        job.Ftp_Local_Name = Regex.Replace(job.Ftp_Local_Name, ConfigurationManager.AppSettings["NonProdSchedulerNASMachine"], ConfigurationManager.AppSettings["DevNASCommandPath"], RegexOptions.IgnoreCase);
                        job.Ftp_Local_Name = Regex.Replace(job.Ftp_Local_Name, ConfigurationManager.AppSettings["OldIncomingFilesPath"], ConfigurationManager.AppSettings["NewIncomingFilesPath"], RegexOptions.IgnoreCase);
                        job.Ftp_Local_Name = Regex.Replace(job.Ftp_Local_Name, ConfigurationManager.AppSettings["ProdFileNameExtension"], ConfigurationManager.AppSettings["DevFileNameExtension"], RegexOptions.IgnoreCase);
                        job.Ftp_Local_Name = Regex.Replace(job.Ftp_Local_Name, ConfigurationManager.AppSettings["StageFileNameExtension"], ConfigurationManager.AppSettings["DevFileNameExtension"], RegexOptions.IgnoreCase);
                        job.Ftp_Local_Name = Regex.Replace(job.Ftp_Local_Name, ConfigurationManager.AppSettings["CtFileNameExtension"], ConfigurationManager.AppSettings["DevFileNameExtension"], RegexOptions.IgnoreCase);
                        job.Ftp_Local_Name = job.Ftp_Local_Name.Replace("$$$$", "$$");
                    }

                    if (!string.IsNullOrEmpty(job.Watch_File))
                    {
                        job.Watch_File = Regex.Replace(job.Watch_File, ConfigurationManager.AppSettings["CtCommandPath"], ConfigurationManager.AppSettings["DevNASCommandPath"], RegexOptions.IgnoreCase);
                        job.Watch_File = Regex.Replace(job.Watch_File, ConfigurationManager.AppSettings["StageCommandPath"], ConfigurationManager.AppSettings["DevNASCommandPath"], RegexOptions.IgnoreCase);
                        job.Watch_File = job.Watch_File.Replace(ConfigurationManager.AppSettings["OldDevCommandPath"].Replace("$$$$", "$$"), ConfigurationManager.AppSettings["DevNASCommandPath"]);
                        job.Watch_File = job.Watch_File.Replace(ConfigurationManager.AppSettings["DevCommandPath"].Replace("$$$$", "$$"), ConfigurationManager.AppSettings["DevNASCommandPath"]);
                        job.Watch_File = job.Watch_File.Replace(ConfigurationManager.AppSettings["CtCommandPath"].Replace("$$$$", "$$"), ConfigurationManager.AppSettings["DevNASCommandPath"]);
                        job.Watch_File = job.Watch_File.Replace(ConfigurationManager.AppSettings["StageCommandPath"].Replace("$$$$", "$$"), ConfigurationManager.AppSettings["DevNASCommandPath"]);
                        job.Watch_File = job.Watch_File.Replace(ConfigurationManager.AppSettings["CtNASCommandPath"].Replace("$$$$", "$$"), ConfigurationManager.AppSettings["DevNASCommandPath"]);
                        job.Watch_File = job.Watch_File.Replace(ConfigurationManager.AppSettings["StageNASCommandPath"].Replace("$$$$", "$$"), ConfigurationManager.AppSettings["DevNASCommandPath"]);
                        job.Watch_File = Regex.Replace(job.Watch_File, ConfigurationManager.AppSettings["NonProdFileStoreRootLocation"], ConfigurationManager.AppSettings["DevNASCommandPath"], RegexOptions.IgnoreCase);
                        job.Watch_File = Regex.Replace(job.Watch_File, ConfigurationManager.AppSettings["DalProdFileStoreRootLocation"], ConfigurationManager.AppSettings["DevNASCommandPath"], RegexOptions.IgnoreCase);
                        job.Watch_File = Regex.Replace(job.Watch_File, ConfigurationManager.AppSettings["ChiProdFileStoreRootLocation"], ConfigurationManager.AppSettings["DevNASCommandPath"], RegexOptions.IgnoreCase);
                        job.Watch_File = Regex.Replace(job.Watch_File, ConfigurationManager.AppSettings["StageOldAsaMachine01"], ConfigurationManager.AppSettings["DevNASCommandPath"], RegexOptions.IgnoreCase);
                        job.Watch_File = Regex.Replace(job.Watch_File, ConfigurationManager.AppSettings["StageOldAsaMachine02"], ConfigurationManager.AppSettings["DevNASCommandPath"], RegexOptions.IgnoreCase);
                        job.Watch_File = Regex.Replace(job.Watch_File, ConfigurationManager.AppSettings["StageNewAsaMachine01"], ConfigurationManager.AppSettings["DevNASCommandPath"], RegexOptions.IgnoreCase);
                        job.Watch_File = Regex.Replace(job.Watch_File, ConfigurationManager.AppSettings["StageNewAsaMachine02"], ConfigurationManager.AppSettings["DevNASCommandPath"], RegexOptions.IgnoreCase);
                        job.Watch_File = Regex.Replace(job.Watch_File, ConfigurationManager.AppSettings["CtOldAsaMachine01"], ConfigurationManager.AppSettings["DevNASCommandPath"], RegexOptions.IgnoreCase);
                        job.Watch_File = Regex.Replace(job.Watch_File, ConfigurationManager.AppSettings["CtOldAsaMachine02"], ConfigurationManager.AppSettings["DevNASCommandPath"], RegexOptions.IgnoreCase);
                        job.Watch_File = Regex.Replace(job.Watch_File, ConfigurationManager.AppSettings["CtNewAsaMachine01"], ConfigurationManager.AppSettings["DevNASCommandPath"], RegexOptions.IgnoreCase);
                        job.Watch_File = Regex.Replace(job.Watch_File, ConfigurationManager.AppSettings["CtNewAsaMachine02"], ConfigurationManager.AppSettings["DevNASCommandPath"], RegexOptions.IgnoreCase);
                        job.Watch_File = Regex.Replace(job.Watch_File, ConfigurationManager.AppSettings["DevGwyNewAsaMachine01"], ConfigurationManager.AppSettings["DevNASCommandPath"], RegexOptions.IgnoreCase);
                        job.Watch_File = Regex.Replace(job.Watch_File, ConfigurationManager.AppSettings["DevGwyNewAsaMachine02"], ConfigurationManager.AppSettings["DevNASCommandPath"], RegexOptions.IgnoreCase);
                        job.Watch_File = Regex.Replace(job.Watch_File, ConfigurationManager.AppSettings["StageGwyNewAsaMachine01"], ConfigurationManager.AppSettings["DevNASCommandPath"], RegexOptions.IgnoreCase);
                        job.Watch_File = Regex.Replace(job.Watch_File, ConfigurationManager.AppSettings["StageGwyNewAsaMachine02"], ConfigurationManager.AppSettings["DevNASCommandPath"], RegexOptions.IgnoreCase);
                        job.Watch_File = Regex.Replace(job.Watch_File, ConfigurationManager.AppSettings["CtGwyNewAsaMachine01"], ConfigurationManager.AppSettings["DevNASCommandPath"], RegexOptions.IgnoreCase);
                        job.Watch_File = Regex.Replace(job.Watch_File, ConfigurationManager.AppSettings["CtGwyNewAsaMachine02"], ConfigurationManager.AppSettings["DevNASCommandPath"], RegexOptions.IgnoreCase);
                        job.Watch_File = Regex.Replace(job.Watch_File, ConfigurationManager.AppSettings["NonProdSchedulerNASMachine"], ConfigurationManager.AppSettings["DevNASCommandPath"], RegexOptions.IgnoreCase);
                        job.Watch_File = Regex.Replace(job.Watch_File, ConfigurationManager.AppSettings["OldIncomingFilesPath"], ConfigurationManager.AppSettings["NewIncomingFilesPath"], RegexOptions.IgnoreCase);
                        job.Watch_File = Regex.Replace(job.Watch_File, ConfigurationManager.AppSettings["ProdFileNameExtension"], ConfigurationManager.AppSettings["DevFileNameExtension"], RegexOptions.IgnoreCase);
                        job.Watch_File = Regex.Replace(job.Watch_File, ConfigurationManager.AppSettings["StageFileNameExtension"], ConfigurationManager.AppSettings["DevFileNameExtension"], RegexOptions.IgnoreCase);
                        job.Watch_File = Regex.Replace(job.Watch_File, ConfigurationManager.AppSettings["CtFileNameExtension"], ConfigurationManager.AppSettings["DevFileNameExtension"], RegexOptions.IgnoreCase);
                        job.Watch_File = job.Watch_File.Replace("$$$$", "$$");
                    }

                }
                else if (stageCheckBoxValue)
                {
                    if (!string.IsNullOrEmpty(job.Header))
                    {
                        job.Header = job.Header.Replace(ConfigurationManager.AppSettings["DevBisSubString"], ConfigurationManager.AppSettings["StageBisSubString"]);
                        job.Header = job.Header.Replace(ConfigurationManager.AppSettings["CtBisSubString"], ConfigurationManager.AppSettings["StageBisSubString"]);
                        job.Header = job.Header.Replace(ConfigurationManager.AppSettings["ProdBisSubString"], ConfigurationManager.AppSettings["StageBisSubString"]);
                    }
                    if (!string.IsNullOrEmpty(job.Insert_job))
                    {
                        job.Insert_job = job.Insert_job.Replace(ConfigurationManager.AppSettings["DevBisSubString"], ConfigurationManager.AppSettings["StageBisSubString"]);
                        job.Insert_job = job.Insert_job.Replace(ConfigurationManager.AppSettings["CtBisSubString"], ConfigurationManager.AppSettings["StageBisSubString"]);
                        job.Insert_job = job.Insert_job.Replace(ConfigurationManager.AppSettings["ProdBisSubString"], ConfigurationManager.AppSettings["StageBisSubString"]);
                    }
                    if (!string.IsNullOrEmpty(job.Boxname))
                    {
                        job.Boxname = job.Boxname.Replace(ConfigurationManager.AppSettings["DevBisSubString"], ConfigurationManager.AppSettings["StageBisSubString"]);
                        job.Boxname = job.Boxname.Replace(ConfigurationManager.AppSettings["CtBisSubString"], ConfigurationManager.AppSettings["StageBisSubString"]);
                        job.Boxname = job.Boxname.Replace(ConfigurationManager.AppSettings["ProdBisSubString"], ConfigurationManager.AppSettings["StageBisSubString"]);
                    }
                    if (!string.IsNullOrEmpty(job.Condition))
                    {
                        job.Condition = job.Condition.Replace(ConfigurationManager.AppSettings["DevBisSubString"], ConfigurationManager.AppSettings["StageBisSubString"]);
                        job.Condition = job.Condition.Replace(ConfigurationManager.AppSettings["CtBisSubString"], ConfigurationManager.AppSettings["StageBisSubString"]);
                        job.Condition = job.Condition.Replace(ConfigurationManager.AppSettings["ProdBisSubString"], ConfigurationManager.AppSettings["StageBisSubString"]);
                    }
                    if (!string.IsNullOrEmpty(job.Box_Success))
                    {
                        job.Box_Success = job.Box_Success.Replace(ConfigurationManager.AppSettings["DevBisSubString"], ConfigurationManager.AppSettings["StageBisSubString"]);
                        job.Box_Success = job.Box_Success.Replace(ConfigurationManager.AppSettings["CtBisSubString"], ConfigurationManager.AppSettings["StageBisSubString"]);
                        job.Box_Success = job.Box_Success.Replace(ConfigurationManager.AppSettings["ProdBisSubString"], ConfigurationManager.AppSettings["StageBisSubString"]);
                    }
                    if (!string.IsNullOrEmpty(job.Box_Failure))
                    {
                        job.Box_Failure = job.Box_Failure.Replace(ConfigurationManager.AppSettings["DevBisSubString"], ConfigurationManager.AppSettings["StageBisSubString"]);
                        job.Box_Failure = job.Box_Failure.Replace(ConfigurationManager.AppSettings["CtBisSubString"], ConfigurationManager.AppSettings["StageBisSubString"]);
                        job.Box_Failure = job.Box_Failure.Replace(ConfigurationManager.AppSettings["ProdBisSubString"], ConfigurationManager.AppSettings["StageBisSubString"]);
                    }
                    if (!string.IsNullOrEmpty(job.Machine))
                    {

                        job.Machine = job.Machine.ToLower().Replace(ConfigurationManager.AppSettings["DevMachineSubString"], ConfigurationManager.AppSettings["StageMachineSubString"]);
                        job.Machine = job.Machine.ToLower().Replace(ConfigurationManager.AppSettings["DevRealMachineSubString"], ConfigurationManager.AppSettings["StageRealMachineSubString"]);
                        job.Machine = job.Machine.ToLower().Replace(ConfigurationManager.AppSettings["DevVirtualMachineSubString"], ConfigurationManager.AppSettings["StageVirtualMachineSubString"]);
                        job.Machine = job.Machine.ToLower().Replace(ConfigurationManager.AppSettings["CtVirtualMachineSubString"], ConfigurationManager.AppSettings["StageVirtualMachineSubString"]);
                        job.Machine = job.Machine.ToLower().Replace(ConfigurationManager.AppSettings["CtRealMachineSubString"], ConfigurationManager.AppSettings["StageRealMachineSubString"]);
                        job.Machine = job.Machine.ToLower().Replace(ConfigurationManager.AppSettings["CtMachineSubString"], ConfigurationManager.AppSettings["StageMachineSubString"]);

                        //need to check for below
                        if (job.Machine.Contains("od_") && !job.Machine.Contains("_bt1"))
                        {
                            job.Machine = job.Machine.Replace("proasa", "asa");
                            job.Machine = job.Machine.Replace("_2008", "");
                            job.Machine = job.Machine + "_bt1";
                        }

                        if (job.Machine.Contains("progwy"))
                        {
                            job.Machine = job.Machine.Split(':').First().Trim() + ": " + ConfigurationManager.AppSettings["StageGwyAsaMachine"];
                        }
                    }

                    if (!string.IsNullOrEmpty(job.Owner))
                    {
                        //job.Owner = job.Owner.Replace(ConfigurationManager.AppSettings["DevOwnerPre"], ConfigurationManager.AppSettings["StageOwnerPre"]);
                        //job.Owner = job.Owner.Replace(ConfigurationManager.AppSettings["CtOwnerPre"], ConfigurationManager.AppSettings["StageOwnerPre"]);
                        //string ownerName = job.Owner.Split(':').Last().Trim();
                        //if (!ownerName.Contains("_") && !job.Owner.Contains(ConfigurationManager.AppSettings["NewOwnerName"]))
                        //    job.Owner = job.Owner.Split(':').First().Trim() + ":  STA_" + ownerName;

                        //job.Owner = job.Owner.Replace(ConfigurationManager.AppSettings["ProductionOwnerSuffix"].ToUpper(), ConfigurationManager.AppSettings["NonProductionOwnerSuffix"].ToUpper());
                        job.Owner = Regex.Replace(job.Owner, ConfigurationManager.AppSettings["DevOwnerPre"], ConfigurationManager.AppSettings["StageOwnerPre"], RegexOptions.IgnoreCase);
                        job.Owner = Regex.Replace(job.Owner, ConfigurationManager.AppSettings["CtOwnerPre"], ConfigurationManager.AppSettings["StageOwnerPre"], RegexOptions.IgnoreCase);
                        job.Owner = Regex.Replace(job.Owner, ConfigurationManager.AppSettings["NewDevOwnerPre"], ConfigurationManager.AppSettings["NewStageOwnerPre"], RegexOptions.IgnoreCase);
                        job.Owner = Regex.Replace(job.Owner, ConfigurationManager.AppSettings["NewCtOwnerPre"], ConfigurationManager.AppSettings["NewStageOwnerPre"], RegexOptions.IgnoreCase);
                        job.Owner = Regex.Replace(job.Owner, "CT_", ConfigurationManager.AppSettings["StageOwnerPre"] + "_", RegexOptions.IgnoreCase);

                        //string ownerName = job.Owner.Split(':').Last().Trim();
                        //if (!ownerName.Contains("_") && !job.Owner.Contains(ConfigurationManager.AppSettings["NewOwnerName"]))
                        //    job.Owner = job.Owner.Split(':').First().Trim() + ":  STA_" + ownerName;

                        job.Owner = Regex.Replace(job.Owner, ConfigurationManager.AppSettings["ProductionOwnerSuffix"], ConfigurationManager.AppSettings["NonProductionOwnerSuffix"].ToUpper(), RegexOptions.IgnoreCase);
                        if (!job.Owner.Contains(ConfigurationManager.AppSettings["StageOwnerPrefix"].ToUpper()) && !job.Owner.Contains(ConfigurationManager.AppSettings["NewStageOwnerPre"]))
                        {
                            job.Owner = job.Owner.Replace("AsysActionAcct", "STA_AsysActionAcct");
                            job.Owner = job.Owner.Replace("AsysWinUnixAcct", "STA_AsysWinUnixAcct");
                        }
                        if (job.Owner.Contains("AsysActionAcct") && !job.Owner.ToUpper().Contains(ConfigurationManager.AppSettings["NonProductionOwnerSuffix"].ToUpper()))
                        {
                            job.Owner = job.Owner.Replace("AsysActionAcct", "AsysActionAcct@CORP");
                        }
                        if (job.Owner.Contains("BM_"))
                            job.Owner = job.Owner.Replace("BM_", ConfigurationManager.AppSettings["StageOwnerPrefix"].ToUpper());

                        if (job.Owner.Contains(ConfigurationManager.AppSettings["ProductionOwnerSuffix"].ToUpper()))
                        {
                            job.Owner = job.Owner.Replace(ConfigurationManager.AppSettings["ProductionOwnerSuffix"].ToUpper(), ConfigurationManager.AppSettings["NonProductionOwnerSuffix"].ToUpper());
                        }
                    }

                    //adding changes in new atrributes similar to owner
                    if (!string.IsNullOrEmpty(job.Ftp_Local_User))
                    {
                        //job.Ftp_Local_User = job.Ftp_Local_User.Replace(ConfigurationManager.AppSettings["DevOwnerPre"], ConfigurationManager.AppSettings["StageOwnerPre"]);
                        //job.Ftp_Local_User = job.Ftp_Local_User.Replace(ConfigurationManager.AppSettings["CtOwnerPre"], ConfigurationManager.AppSettings["StageOwnerPre"]);
                        //string ownerName = job.Ftp_Local_User.Split(':').Last().Trim();
                        //if (!ownerName.Contains("_") && !job.Ftp_Local_User.Contains(ConfigurationManager.AppSettings["NewOwnerName"]))
                        //    job.Ftp_Local_User = job.Ftp_Local_User.Split(':').First().Trim() + ":  STA_" + ownerName;

                        //job.Ftp_Local_User = job.Ftp_Local_User.Replace(ConfigurationManager.AppSettings["ProductionOwnerSuffix"].ToUpper(), ConfigurationManager.AppSettings["NonProductionOwnerSuffix"].ToUpper());
                        job.Ftp_Local_User = Regex.Replace(job.Ftp_Local_User, ConfigurationManager.AppSettings["DevOwnerPre"], ConfigurationManager.AppSettings["StageOwnerPre"], RegexOptions.IgnoreCase);
                        job.Ftp_Local_User = Regex.Replace(job.Ftp_Local_User, ConfigurationManager.AppSettings["CtOwnerPre"], ConfigurationManager.AppSettings["StageOwnerPre"], RegexOptions.IgnoreCase);
                        job.Ftp_Local_User = Regex.Replace(job.Ftp_Local_User, ConfigurationManager.AppSettings["NewDevOwnerPre"], ConfigurationManager.AppSettings["NewStageOwnerPre"], RegexOptions.IgnoreCase);
                        job.Ftp_Local_User = Regex.Replace(job.Ftp_Local_User, ConfigurationManager.AppSettings["NewCtOwnerPre"], ConfigurationManager.AppSettings["NewStageOwnerPre"], RegexOptions.IgnoreCase);


                        //string ownerName = job.Ftp_Local_User.Split(':').Last().Trim();
                        //if (!ownerName.Contains("_") && !job.Ftp_Local_User.Contains(ConfigurationManager.AppSettings["NewOwnerName"]))
                        //    job.Ftp_Local_User = job.Ftp_Local_User.Split(':').First().Trim() + ":  STA_" + ownerName;

                        job.Ftp_Local_User = Regex.Replace(job.Ftp_Local_User, ConfigurationManager.AppSettings["ProductionOwnerSuffix"], ConfigurationManager.AppSettings["NonProductionOwnerSuffix"].ToUpper(), RegexOptions.IgnoreCase);
                        if (!job.Ftp_Local_User.Contains(ConfigurationManager.AppSettings["StageOwnerPrefix"].ToUpper()) && !job.Ftp_Local_User.Contains(ConfigurationManager.AppSettings["NewStageOwnerPre"]))
                            job.Ftp_Local_User = job.Ftp_Local_User.Replace("AsysActionAcct", "STA_AsysActionAcct");
                        if (job.Ftp_Local_User.Contains("AsysActionAcct") && !job.Ftp_Local_User.ToUpper().Contains(ConfigurationManager.AppSettings["NonProductionOwnerSuffix"].ToUpper()))
                        {
                            job.Ftp_Local_User = job.Ftp_Local_User.Replace("AsysActionAcct", "AsysActionAcct@CORP");
                        }
                        if (job.Ftp_Local_User.Contains("BM_"))
                            job.Ftp_Local_User = job.Ftp_Local_User.Replace("BM_", ConfigurationManager.AppSettings["StageOwnerPrefix"].ToUpper());
                    }

                    if (!string.IsNullOrEmpty(job.Watch_File_Win_User))
                    {
                        //job.Watch_File_Win_User = job.Watch_File_Win_User.Replace(ConfigurationManager.AppSettings["DevOwnerPre"], ConfigurationManager.AppSettings["StageOwnerPre"]);
                        //job.Watch_File_Win_User = job.Watch_File_Win_User.Replace(ConfigurationManager.AppSettings["CtOwnerPre"], ConfigurationManager.AppSettings["StageOwnerPre"]);
                        //string ownerName = job.Watch_File_Win_User.Split(':').Last().Trim();
                        //if (!ownerName.Contains("_") && !job.Watch_File_Win_User.Contains(ConfigurationManager.AppSettings["NewOwnerName"]))
                        //    job.Watch_File_Win_User = job.Watch_File_Win_User.Split(':').First().Trim() + ":  STA_" + ownerName;

                        //job.Watch_File_Win_User = job.Watch_File_Win_User.Replace(ConfigurationManager.AppSettings["ProductionOwnerSuffix"].ToUpper(), ConfigurationManager.AppSettings["NonProductionOwnerSuffix"].ToUpper());
                        job.Watch_File_Win_User = Regex.Replace(job.Watch_File_Win_User, ConfigurationManager.AppSettings["DevOwnerPre"], ConfigurationManager.AppSettings["StageOwnerPre"], RegexOptions.IgnoreCase);
                        job.Watch_File_Win_User = Regex.Replace(job.Watch_File_Win_User, ConfigurationManager.AppSettings["CtOwnerPre"], ConfigurationManager.AppSettings["StageOwnerPre"], RegexOptions.IgnoreCase);
                        job.Watch_File_Win_User = Regex.Replace(job.Watch_File_Win_User, ConfigurationManager.AppSettings["NewDevOwnerPre"], ConfigurationManager.AppSettings["NewStageOwnerPre"], RegexOptions.IgnoreCase);
                        job.Watch_File_Win_User = Regex.Replace(job.Watch_File_Win_User, ConfigurationManager.AppSettings["NewCtOwnerPre"], ConfigurationManager.AppSettings["NewStageOwnerPre"], RegexOptions.IgnoreCase);


                        //string ownerName = job.Watch_File_Win_User.Split(':').Last().Trim();
                        //if (!ownerName.Contains("_") && !job.Watch_File_Win_User.Contains(ConfigurationManager.AppSettings["NewOwnerName"]))
                        //    job.Watch_File_Win_User = job.Watch_File_Win_User.Split(':').First().Trim() + ":  STA_" + ownerName;

                        job.Watch_File_Win_User = Regex.Replace(job.Watch_File_Win_User, ConfigurationManager.AppSettings["ProductionOwnerSuffix"], ConfigurationManager.AppSettings["NonProductionOwnerSuffix"].ToUpper(), RegexOptions.IgnoreCase);
                        if (!job.Watch_File_Win_User.Contains(ConfigurationManager.AppSettings["StageOwnerPrefix"].ToUpper()) && !job.Watch_File_Win_User.Contains(ConfigurationManager.AppSettings["NewStageOwnerPre"]))
                            job.Watch_File_Win_User = job.Watch_File_Win_User.Replace("AsysActionAcct", "STA_AsysActionAcct");
                        if (job.Watch_File_Win_User.Contains("AsysActionAcct") && !job.Watch_File_Win_User.ToUpper().Contains(ConfigurationManager.AppSettings["NonProductionOwnerSuffix"].ToUpper()))
                        {
                            job.Watch_File_Win_User = job.Watch_File_Win_User.Replace("AsysActionAcct", "AsysActionAcct@CORP");
                        }
                        if (job.Watch_File_Win_User.Contains("BM_"))
                            job.Watch_File_Win_User = job.Watch_File_Win_User.Replace("BM_", ConfigurationManager.AppSettings["StageOwnerPrefix"].ToUpper());
                    }

                    if (!string.IsNullOrEmpty(job.Command))
                    {
                        job.Command = Regex.Replace(job.Command, ConfigurationManager.AppSettings["DevCommandPath"], ConfigurationManager.AppSettings["StageNASCommandPath"], RegexOptions.IgnoreCase);
                        job.Command = job.Command.Replace(ConfigurationManager.AppSettings["DevCommandPath"].Replace("$$$$", "$$"), ConfigurationManager.AppSettings["StageNASCommandPath"]);
                        job.Command = job.Command.Replace(ConfigurationManager.AppSettings["OldDevCommandPath"].Replace("$$$$", "$$"), ConfigurationManager.AppSettings["StageNASCommandPath"]);
                        job.Command = job.Command.Replace(ConfigurationManager.AppSettings["StageCommandPath"].Replace("$$$$", "$$"), ConfigurationManager.AppSettings["StageNASCommandPath"]);
                        job.Command = job.Command.Replace(ConfigurationManager.AppSettings["CtCommandPath"].Replace("$$$$", "$$"), ConfigurationManager.AppSettings["StageNASCommandPath"]);
                        job.Command = job.Command.Replace(ConfigurationManager.AppSettings["DevNASCommandPath"].Replace("$$$$", "$$"), ConfigurationManager.AppSettings["StageNASCommandPath"]);
                        job.Command = job.Command.Replace(ConfigurationManager.AppSettings["CtNASCommandPath"].Replace("$$$$", "$$"), ConfigurationManager.AppSettings["StageNASCommandPath"]);
                        job.Command = Regex.Replace(job.Command, ConfigurationManager.AppSettings["NonProdFileStoreRootLocation"], ConfigurationManager.AppSettings["StageNASCommandPath"], RegexOptions.IgnoreCase);
                        job.Command = Regex.Replace(job.Command, ConfigurationManager.AppSettings["DalProdFileStoreRootLocation"], ConfigurationManager.AppSettings["StageNASCommandPath"], RegexOptions.IgnoreCase);
                        job.Command = Regex.Replace(job.Command, ConfigurationManager.AppSettings["ChiProdFileStoreRootLocation"], ConfigurationManager.AppSettings["StageNASCommandPath"], RegexOptions.IgnoreCase);
                        job.Command = Regex.Replace(job.Command, ConfigurationManager.AppSettings["DevOldAsaMachine01"], ConfigurationManager.AppSettings["StageNASCommandPath"], RegexOptions.IgnoreCase);
                        job.Command = Regex.Replace(job.Command, ConfigurationManager.AppSettings["DevOldAsaMachine02"], ConfigurationManager.AppSettings["StageNASCommandPath"], RegexOptions.IgnoreCase);
                        job.Command = Regex.Replace(job.Command, ConfigurationManager.AppSettings["DevNewAsaMachine01"], ConfigurationManager.AppSettings["StageNASCommandPath"], RegexOptions.IgnoreCase);
                        job.Command = Regex.Replace(job.Command, ConfigurationManager.AppSettings["DevNewAsaMachine02"], ConfigurationManager.AppSettings["StageNASCommandPath"], RegexOptions.IgnoreCase);
                        job.Command = Regex.Replace(job.Command, ConfigurationManager.AppSettings["CtOldAsaMachine01"], ConfigurationManager.AppSettings["StageNASCommandPath"], RegexOptions.IgnoreCase);
                        job.Command = Regex.Replace(job.Command, ConfigurationManager.AppSettings["CtOldAsaMachine02"], ConfigurationManager.AppSettings["StageNASCommandPath"], RegexOptions.IgnoreCase);
                        job.Command = Regex.Replace(job.Command, ConfigurationManager.AppSettings["CtNewAsaMachine01"], ConfigurationManager.AppSettings["StageNASCommandPath"], RegexOptions.IgnoreCase);
                        job.Command = Regex.Replace(job.Command, ConfigurationManager.AppSettings["CtNewAsaMachine02"], ConfigurationManager.AppSettings["StageNASCommandPath"], RegexOptions.IgnoreCase);
                        job.Command = Regex.Replace(job.Command, ConfigurationManager.AppSettings["DevGwyNewAsaMachine01"], ConfigurationManager.AppSettings["StageNASCommandPath"], RegexOptions.IgnoreCase);
                        job.Command = Regex.Replace(job.Command, ConfigurationManager.AppSettings["DevGwyNewAsaMachine02"], ConfigurationManager.AppSettings["StageNASCommandPath"], RegexOptions.IgnoreCase);
                        job.Command = Regex.Replace(job.Command, ConfigurationManager.AppSettings["StageGwyNewAsaMachine01"], ConfigurationManager.AppSettings["StageNASCommandPath"], RegexOptions.IgnoreCase);
                        job.Command = Regex.Replace(job.Command, ConfigurationManager.AppSettings["StageGwyNewAsaMachine02"], ConfigurationManager.AppSettings["StageNASCommandPath"], RegexOptions.IgnoreCase);
                        job.Command = Regex.Replace(job.Command, ConfigurationManager.AppSettings["CtGwyNewAsaMachine01"], ConfigurationManager.AppSettings["StageNASCommandPath"], RegexOptions.IgnoreCase);
                        job.Command = Regex.Replace(job.Command, ConfigurationManager.AppSettings["CtGwyNewAsaMachine02"], ConfigurationManager.AppSettings["StageNASCommandPath"], RegexOptions.IgnoreCase);
                        job.Command = Regex.Replace(job.Command, ConfigurationManager.AppSettings["NonProdSchedulerNASMachine"], ConfigurationManager.AppSettings["StageNASCommandPath"], RegexOptions.IgnoreCase);
                        job.Command = Regex.Replace(job.Command, ConfigurationManager.AppSettings["OldIncomingFilesPath"], ConfigurationManager.AppSettings["NewIncomingFilesPath"], RegexOptions.IgnoreCase);
                        job.Command = Regex.Replace(job.Command, ConfigurationManager.AppSettings["ProdFileNameExtension"], ConfigurationManager.AppSettings["StageFileNameExtension"], RegexOptions.IgnoreCase);
                        job.Command = Regex.Replace(job.Command, ConfigurationManager.AppSettings["DevFileNameExtension"], ConfigurationManager.AppSettings["StageFileNameExtension"], RegexOptions.IgnoreCase);
                        job.Command = Regex.Replace(job.Command, ConfigurationManager.AppSettings["CtFileNameExtension"], ConfigurationManager.AppSettings["StageFileNameExtension"], RegexOptions.IgnoreCase);
                        job.Command = job.Command.Replace("$$$$", "$$");
                        job.Command = job.Command.Replace(StringConstants.DEV_BIS_JOBS_SUBSTRING, StringConstants.STAGE_BIS_JOBS_SUBSTRING);
                        job.Command = job.Command.Replace(StringConstants.CT_BIS_JOBS_SUBSTRING, StringConstants.STAGE_BIS_JOBS_SUBSTRING);
                        job.Command = job.Command.Replace(StringConstants.PROD_BIS_JOBS_SUBSTRING, StringConstants.STAGE_BIS_JOBS_SUBSTRING);
                    }

                    //adding changes in new attributes similar to command
                    if (!string.IsNullOrEmpty(job.Ftp_Local_Name))
                    {
                        job.Ftp_Local_Name = Regex.Replace(job.Ftp_Local_Name, ConfigurationManager.AppSettings["DevCommandPath"], ConfigurationManager.AppSettings["StageNASCommandPath"], RegexOptions.IgnoreCase);
                        job.Ftp_Local_Name = job.Ftp_Local_Name.Replace(ConfigurationManager.AppSettings["DevCommandPath"].Replace("$$$$", "$$"), ConfigurationManager.AppSettings["StageNASCommandPath"]);
                        job.Ftp_Local_Name = job.Ftp_Local_Name.Replace(ConfigurationManager.AppSettings["OldDevCommandPath"].Replace("$$$$", "$$"), ConfigurationManager.AppSettings["StageNASCommandPath"]);
                        job.Ftp_Local_Name = job.Ftp_Local_Name.Replace(ConfigurationManager.AppSettings["StageCommandPath"].Replace("$$$$", "$$"), ConfigurationManager.AppSettings["StageNASCommandPath"]);
                        job.Ftp_Local_Name = job.Ftp_Local_Name.Replace(ConfigurationManager.AppSettings["CtCommandPath"].Replace("$$$$", "$$"), ConfigurationManager.AppSettings["StageNASCommandPath"]);
                        job.Ftp_Local_Name = job.Ftp_Local_Name.Replace(ConfigurationManager.AppSettings["DevNASCommandPath"].Replace("$$$$", "$$"), ConfigurationManager.AppSettings["StageNASCommandPath"]);
                        job.Ftp_Local_Name = job.Ftp_Local_Name.Replace(ConfigurationManager.AppSettings["CtNASCommandPath"].Replace("$$$$", "$$"), ConfigurationManager.AppSettings["StageNASCommandPath"]);
                        job.Ftp_Local_Name = Regex.Replace(job.Ftp_Local_Name, ConfigurationManager.AppSettings["NonProdFileStoreRootLocation"], ConfigurationManager.AppSettings["StageNASCommandPath"], RegexOptions.IgnoreCase);
                        job.Ftp_Local_Name = Regex.Replace(job.Ftp_Local_Name, ConfigurationManager.AppSettings["DalProdFileStoreRootLocation"], ConfigurationManager.AppSettings["StageNASCommandPath"], RegexOptions.IgnoreCase);
                        job.Ftp_Local_Name = Regex.Replace(job.Ftp_Local_Name, ConfigurationManager.AppSettings["ChiProdFileStoreRootLocation"], ConfigurationManager.AppSettings["StageNASCommandPath"], RegexOptions.IgnoreCase);
                        job.Ftp_Local_Name = Regex.Replace(job.Ftp_Local_Name, ConfigurationManager.AppSettings["DevOldAsaMachine01"], ConfigurationManager.AppSettings["StageNASCommandPath"], RegexOptions.IgnoreCase);
                        job.Ftp_Local_Name = Regex.Replace(job.Ftp_Local_Name, ConfigurationManager.AppSettings["DevOldAsaMachine02"], ConfigurationManager.AppSettings["StageNASCommandPath"], RegexOptions.IgnoreCase);
                        job.Ftp_Local_Name = Regex.Replace(job.Ftp_Local_Name, ConfigurationManager.AppSettings["DevNewAsaMachine01"], ConfigurationManager.AppSettings["StageNASCommandPath"], RegexOptions.IgnoreCase);
                        job.Ftp_Local_Name = Regex.Replace(job.Ftp_Local_Name, ConfigurationManager.AppSettings["DevNewAsaMachine02"], ConfigurationManager.AppSettings["StageNASCommandPath"], RegexOptions.IgnoreCase);
                        job.Ftp_Local_Name = Regex.Replace(job.Ftp_Local_Name, ConfigurationManager.AppSettings["CtOldAsaMachine01"], ConfigurationManager.AppSettings["StageNASCommandPath"], RegexOptions.IgnoreCase);
                        job.Ftp_Local_Name = Regex.Replace(job.Ftp_Local_Name, ConfigurationManager.AppSettings["CtOldAsaMachine02"], ConfigurationManager.AppSettings["StageNASCommandPath"], RegexOptions.IgnoreCase);
                        job.Ftp_Local_Name = Regex.Replace(job.Ftp_Local_Name, ConfigurationManager.AppSettings["CtNewAsaMachine01"], ConfigurationManager.AppSettings["StageNASCommandPath"], RegexOptions.IgnoreCase);
                        job.Ftp_Local_Name = Regex.Replace(job.Ftp_Local_Name, ConfigurationManager.AppSettings["CtNewAsaMachine02"], ConfigurationManager.AppSettings["StageNASCommandPath"], RegexOptions.IgnoreCase);
                        job.Ftp_Local_Name = Regex.Replace(job.Ftp_Local_Name, ConfigurationManager.AppSettings["DevGwyNewAsaMachine01"], ConfigurationManager.AppSettings["StageNASCommandPath"], RegexOptions.IgnoreCase);
                        job.Ftp_Local_Name = Regex.Replace(job.Ftp_Local_Name, ConfigurationManager.AppSettings["DevGwyNewAsaMachine02"], ConfigurationManager.AppSettings["StageNASCommandPath"], RegexOptions.IgnoreCase);
                        job.Ftp_Local_Name = Regex.Replace(job.Ftp_Local_Name, ConfigurationManager.AppSettings["StageGwyNewAsaMachine01"], ConfigurationManager.AppSettings["StageNASCommandPath"], RegexOptions.IgnoreCase);
                        job.Ftp_Local_Name = Regex.Replace(job.Ftp_Local_Name, ConfigurationManager.AppSettings["StageGwyNewAsaMachine02"], ConfigurationManager.AppSettings["StageNASCommandPath"], RegexOptions.IgnoreCase);
                        job.Ftp_Local_Name = Regex.Replace(job.Ftp_Local_Name, ConfigurationManager.AppSettings["CtGwyNewAsaMachine01"], ConfigurationManager.AppSettings["StageNASCommandPath"], RegexOptions.IgnoreCase);
                        job.Ftp_Local_Name = Regex.Replace(job.Ftp_Local_Name, ConfigurationManager.AppSettings["CtGwyNewAsaMachine02"], ConfigurationManager.AppSettings["StageNASCommandPath"], RegexOptions.IgnoreCase);
                        job.Ftp_Local_Name = Regex.Replace(job.Ftp_Local_Name, ConfigurationManager.AppSettings["NonProdSchedulerNASMachine"], ConfigurationManager.AppSettings["StageNASCommandPath"], RegexOptions.IgnoreCase);
                        job.Ftp_Local_Name = Regex.Replace(job.Ftp_Local_Name, ConfigurationManager.AppSettings["OldIncomingFilesPath"], ConfigurationManager.AppSettings["NewIncomingFilesPath"], RegexOptions.IgnoreCase);
                        job.Ftp_Local_Name = Regex.Replace(job.Ftp_Local_Name, ConfigurationManager.AppSettings["ProdFileNameExtension"], ConfigurationManager.AppSettings["StageFileNameExtension"], RegexOptions.IgnoreCase);
                        job.Ftp_Local_Name = Regex.Replace(job.Ftp_Local_Name, ConfigurationManager.AppSettings["DevFileNameExtension"], ConfigurationManager.AppSettings["StageFileNameExtension"], RegexOptions.IgnoreCase);
                        job.Ftp_Local_Name = Regex.Replace(job.Ftp_Local_Name, ConfigurationManager.AppSettings["CtFileNameExtension"], ConfigurationManager.AppSettings["StageFileNameExtension"], RegexOptions.IgnoreCase);
                        job.Ftp_Local_Name = job.Ftp_Local_Name.Replace("$$$$", "$$");
                    }

                    if (!string.IsNullOrEmpty(job.Watch_File))
                    {

                        job.Watch_File = job.Watch_File.Replace(ConfigurationManager.AppSettings["DevCommandPath"].Replace("$$$$", "$$"), ConfigurationManager.AppSettings["StageNASCommandPath"]);
                        job.Watch_File = job.Watch_File.Replace(ConfigurationManager.AppSettings["OldDevCommandPath"].Replace("$$$$", "$$"), ConfigurationManager.AppSettings["StageNASCommandPath"]);
                        job.Watch_File = job.Watch_File.Replace(ConfigurationManager.AppSettings["StageCommandPath"].Replace("$$$$", "$$"), ConfigurationManager.AppSettings["StageNASCommandPath"]);
                        job.Watch_File = job.Watch_File.Replace(ConfigurationManager.AppSettings["CtCommandPath"].Replace("$$$$", "$$"), ConfigurationManager.AppSettings["StageNASCommandPath"]);
                        job.Watch_File = job.Watch_File.Replace(ConfigurationManager.AppSettings["DevNASCommandPath"].Replace("$$$$", "$$"), ConfigurationManager.AppSettings["StageNASCommandPath"]);
                        job.Watch_File = job.Watch_File.Replace(ConfigurationManager.AppSettings["CtNASCommandPath"].Replace("$$$$", "$$"), ConfigurationManager.AppSettings["StageNASCommandPath"]);
                        job.Watch_File = Regex.Replace(job.Watch_File, ConfigurationManager.AppSettings["NonProdFileStoreRootLocation"], ConfigurationManager.AppSettings["StageNASCommandPath"], RegexOptions.IgnoreCase);
                        job.Watch_File = Regex.Replace(job.Watch_File, ConfigurationManager.AppSettings["DalProdFileStoreRootLocation"], ConfigurationManager.AppSettings["StageNASCommandPath"], RegexOptions.IgnoreCase);
                        job.Watch_File = Regex.Replace(job.Watch_File, ConfigurationManager.AppSettings["ChiProdFileStoreRootLocation"], ConfigurationManager.AppSettings["StageNASCommandPath"], RegexOptions.IgnoreCase);
                        job.Watch_File = Regex.Replace(job.Watch_File, ConfigurationManager.AppSettings["DevOldAsaMachine01"], ConfigurationManager.AppSettings["StageNASCommandPath"], RegexOptions.IgnoreCase);
                        job.Watch_File = Regex.Replace(job.Watch_File, ConfigurationManager.AppSettings["DevOldAsaMachine02"], ConfigurationManager.AppSettings["StageNASCommandPath"], RegexOptions.IgnoreCase);
                        job.Watch_File = Regex.Replace(job.Watch_File, ConfigurationManager.AppSettings["DevNewAsaMachine01"], ConfigurationManager.AppSettings["StageNASCommandPath"], RegexOptions.IgnoreCase);
                        job.Watch_File = Regex.Replace(job.Watch_File, ConfigurationManager.AppSettings["DevNewAsaMachine02"], ConfigurationManager.AppSettings["StageNASCommandPath"], RegexOptions.IgnoreCase);
                        job.Watch_File = Regex.Replace(job.Watch_File, ConfigurationManager.AppSettings["CtOldAsaMachine01"], ConfigurationManager.AppSettings["StageNASCommandPath"], RegexOptions.IgnoreCase);
                        job.Watch_File = Regex.Replace(job.Watch_File, ConfigurationManager.AppSettings["CtOldAsaMachine02"], ConfigurationManager.AppSettings["StageNASCommandPath"], RegexOptions.IgnoreCase);
                        job.Watch_File = Regex.Replace(job.Watch_File, ConfigurationManager.AppSettings["CtNewAsaMachine01"], ConfigurationManager.AppSettings["StageNASCommandPath"], RegexOptions.IgnoreCase);
                        job.Watch_File = Regex.Replace(job.Watch_File, ConfigurationManager.AppSettings["CtNewAsaMachine02"], ConfigurationManager.AppSettings["StageNASCommandPath"], RegexOptions.IgnoreCase);
                        job.Watch_File = Regex.Replace(job.Watch_File, ConfigurationManager.AppSettings["DevGwyNewAsaMachine01"], ConfigurationManager.AppSettings["StageNASCommandPath"], RegexOptions.IgnoreCase);
                        job.Watch_File = Regex.Replace(job.Watch_File, ConfigurationManager.AppSettings["DevGwyNewAsaMachine02"], ConfigurationManager.AppSettings["StageNASCommandPath"], RegexOptions.IgnoreCase);
                        job.Watch_File = Regex.Replace(job.Watch_File, ConfigurationManager.AppSettings["StageGwyNewAsaMachine01"], ConfigurationManager.AppSettings["StageNASCommandPath"], RegexOptions.IgnoreCase);
                        job.Watch_File = Regex.Replace(job.Watch_File, ConfigurationManager.AppSettings["StageGwyNewAsaMachine02"], ConfigurationManager.AppSettings["StageNASCommandPath"], RegexOptions.IgnoreCase);
                        job.Watch_File = Regex.Replace(job.Watch_File, ConfigurationManager.AppSettings["CtGwyNewAsaMachine01"], ConfigurationManager.AppSettings["StageNASCommandPath"], RegexOptions.IgnoreCase);
                        job.Watch_File = Regex.Replace(job.Watch_File, ConfigurationManager.AppSettings["CtGwyNewAsaMachine02"], ConfigurationManager.AppSettings["StageNASCommandPath"], RegexOptions.IgnoreCase);
                        job.Watch_File = Regex.Replace(job.Watch_File, ConfigurationManager.AppSettings["NonProdSchedulerNASMachine"], ConfigurationManager.AppSettings["StageNASCommandPath"], RegexOptions.IgnoreCase);
                        job.Watch_File = Regex.Replace(job.Watch_File, ConfigurationManager.AppSettings["OldIncomingFilesPath"], ConfigurationManager.AppSettings["NewIncomingFilesPath"], RegexOptions.IgnoreCase);
                        job.Watch_File = Regex.Replace(job.Watch_File, ConfigurationManager.AppSettings["ProdFileNameExtension"], ConfigurationManager.AppSettings["StageFileNameExtension"], RegexOptions.IgnoreCase);
                        job.Watch_File = Regex.Replace(job.Watch_File, ConfigurationManager.AppSettings["DevFileNameExtension"], ConfigurationManager.AppSettings["StageFileNameExtension"], RegexOptions.IgnoreCase);
                        job.Watch_File = Regex.Replace(job.Watch_File, ConfigurationManager.AppSettings["CtFileNameExtension"], ConfigurationManager.AppSettings["StageFileNameExtension"], RegexOptions.IgnoreCase);
                        job.Watch_File = job.Watch_File.Replace("$$$$", "$$");
                    }
                }
                else if (ctCheckBoxValue)
                {
                    if (!string.IsNullOrEmpty(job.Header))
                    {
                        job.Header = job.Header.Replace(ConfigurationManager.AppSettings["DevBisSubString"], ConfigurationManager.AppSettings["CtBisSubString"]);
                        job.Header = job.Header.Replace(ConfigurationManager.AppSettings["StageBisSubString"], ConfigurationManager.AppSettings["CtBisSubString"]);
                        job.Header = job.Header.Replace(ConfigurationManager.AppSettings["ProdBisSubString"], ConfigurationManager.AppSettings["CtBisSubString"]);
                    }
                    if (!string.IsNullOrEmpty(job.Insert_job))
                    {
                        job.Insert_job = job.Insert_job.Replace(ConfigurationManager.AppSettings["DevBisSubString"], ConfigurationManager.AppSettings["CtBisSubString"]);
                        job.Insert_job = job.Insert_job.Replace(ConfigurationManager.AppSettings["StageBisSubString"], ConfigurationManager.AppSettings["CtBisSubString"]);
                        job.Insert_job = job.Insert_job.Replace(ConfigurationManager.AppSettings["ProdBisSubString"], ConfigurationManager.AppSettings["CtBisSubString"]);
                    }
                    if (!string.IsNullOrEmpty(job.Boxname))
                    {
                        job.Boxname = job.Boxname.Replace(ConfigurationManager.AppSettings["DevBisSubString"], ConfigurationManager.AppSettings["CtBisSubString"]);
                        job.Boxname = job.Boxname.Replace(ConfigurationManager.AppSettings["StageBisSubString"], ConfigurationManager.AppSettings["CtBisSubString"]);
                        job.Boxname = job.Boxname.Replace(ConfigurationManager.AppSettings["ProdBisSubString"], ConfigurationManager.AppSettings["CtBisSubString"]);
                    }
                    if (!string.IsNullOrEmpty(job.Condition))
                    {
                        job.Condition = job.Condition.Replace(ConfigurationManager.AppSettings["DevBisSubString"], ConfigurationManager.AppSettings["CtBisSubString"]);
                        job.Condition = job.Condition.Replace(ConfigurationManager.AppSettings["StageBisSubString"], ConfigurationManager.AppSettings["CtBisSubString"]);
                        job.Condition = job.Condition.Replace(ConfigurationManager.AppSettings["ProdBisSubString"], ConfigurationManager.AppSettings["CtBisSubString"]);
                    }
                    if (!string.IsNullOrEmpty(job.Box_Success))
                    {
                        job.Box_Success = job.Box_Success.Replace(ConfigurationManager.AppSettings["DevBisSubString"], ConfigurationManager.AppSettings["CtBisSubString"]);
                        job.Box_Success = job.Box_Success.Replace(ConfigurationManager.AppSettings["StageBisSubString"], ConfigurationManager.AppSettings["CtBisSubString"]);
                        job.Box_Success = job.Box_Success.Replace(ConfigurationManager.AppSettings["ProdBisSubString"], ConfigurationManager.AppSettings["CtBisSubString"]);
                    }
                    if (!string.IsNullOrEmpty(job.Box_Failure))
                    {
                        job.Box_Failure = job.Box_Failure.Replace(ConfigurationManager.AppSettings["DevBisSubString"], ConfigurationManager.AppSettings["CtBisSubString"]);
                        job.Box_Failure = job.Box_Failure.Replace(ConfigurationManager.AppSettings["StageBisSubString"], ConfigurationManager.AppSettings["CtBisSubString"]);
                        job.Box_Failure = job.Box_Failure.Replace(ConfigurationManager.AppSettings["ProdBisSubString"], ConfigurationManager.AppSettings["CtBisSubString"]);
                    }
                    if (!string.IsNullOrEmpty(job.Machine))
                    {
                        job.Machine = job.Machine.ToLower().Replace(ConfigurationManager.AppSettings["DevRealMachineSubString"], ConfigurationManager.AppSettings["CtRealMachineSubString"]);
                        job.Machine = job.Machine.ToLower().Replace(ConfigurationManager.AppSettings["DevMachineSubString"], ConfigurationManager.AppSettings["CtMachineSubString"]);
                        job.Machine = job.Machine.ToLower().Replace(ConfigurationManager.AppSettings["DevVirtualMachineSubString"], ConfigurationManager.AppSettings["CtVirtualMachineSubString"]);
                        job.Machine = job.Machine.ToLower().Replace(ConfigurationManager.AppSettings["StageVirtualMachineSubString"], ConfigurationManager.AppSettings["CtVirtualMachineSubString"]);
                        job.Machine = job.Machine.ToLower().Replace(ConfigurationManager.AppSettings["StageRealMachineSubString"], ConfigurationManager.AppSettings["CtRealMachineSubString"]);
                        job.Machine = job.Machine.ToLower().Replace(ConfigurationManager.AppSettings["StageMachineSubString"], ConfigurationManager.AppSettings["CtMachineSubString"]);

                        //need to check for below
                        if (job.Machine.Contains("od_") && !job.Machine.Contains("_bt2"))
                        {
                            job.Machine = job.Machine.Replace("proasa", "asa");
                            job.Machine = job.Machine.Replace("_2008", "");
                            job.Machine = job.Machine + "_bt2";
                        }

                        if (job.Machine.Contains("progwy"))
                        {
                            job.Machine = job.Machine.Split(':').First().Trim() + ": " + ConfigurationManager.AppSettings["CtGwyAsaMachine"];
                        }
                    }

                    if (!string.IsNullOrEmpty(job.Owner))
                    {
                        //job.Owner = job.Owner.Replace(ConfigurationManager.AppSettings["DevOwnerPre"], ConfigurationManager.AppSettings["CtOwnerPre"]);
                        //job.Owner = job.Owner.Replace(ConfigurationManager.AppSettings["StageOwnerPre"], ConfigurationManager.AppSettings["CtOwnerPre"]);
                        //string ownerName = job.Owner.Split(':').Last().Trim();
                        //if (!ownerName.Contains("_") && !job.Owner.Contains(ConfigurationManager.AppSettings["NewOwnerName"]))
                        //    job.Owner = job.Owner.Split(':').First().Trim() + ":  CT1_" + ownerName;

                        //job.Owner = job.Owner.Replace(ConfigurationManager.AppSettings["ProductionOwnerSuffix"].ToUpper(), ConfigurationManager.AppSettings["NonProductionOwnerSuffix"].ToUpper());
                        job.Owner = Regex.Replace(job.Owner, ConfigurationManager.AppSettings["DevOwnerPre"], ConfigurationManager.AppSettings["CtOwnerPre"], RegexOptions.IgnoreCase);
                        job.Owner = Regex.Replace(job.Owner, ConfigurationManager.AppSettings["StageOwnerPre"], ConfigurationManager.AppSettings["CtOwnerPre"], RegexOptions.IgnoreCase);
                        job.Owner = Regex.Replace(job.Owner, ConfigurationManager.AppSettings["NewDevOwnerPre"], ConfigurationManager.AppSettings["NewCtOwnerPre"], RegexOptions.IgnoreCase);
                        job.Owner = Regex.Replace(job.Owner, ConfigurationManager.AppSettings["NewStageOwnerPre"], ConfigurationManager.AppSettings["NewCtOwnerPre"], RegexOptions.IgnoreCase);

                        //string ownerName = job.Owner.Split(':').Last().Trim();
                        //if (!ownerName.Contains("_") && !job.Owner.Contains(ConfigurationManager.AppSettings["NewOwnerName"]))
                        //    job.Owner = job.Owner.Split(':').First().Trim() + ":  CT1_" + ownerName;

                        job.Owner = Regex.Replace(job.Owner, ConfigurationManager.AppSettings["ProductionOwnerSuffix"], ConfigurationManager.AppSettings["NonProductionOwnerSuffix"].ToUpper(), RegexOptions.IgnoreCase);
                        if (!job.Owner.Contains(ConfigurationManager.AppSettings["CtOwnerPrefix"].ToUpper()) && !job.Owner.Contains(ConfigurationManager.AppSettings["NewCtOwnerPre"]))
                        {
                            job.Owner = job.Owner.Replace("AsysActionAcct", "CT1_AsysActionAcct");
                            job.Owner = job.Owner.Replace("AsysWinUnixAcct", "CT_AsysWinUnixAcct");
                        }
                        if (job.Owner.Contains("AsysActionAcct") && !job.Owner.ToUpper().Contains(ConfigurationManager.AppSettings["NonProductionOwnerSuffix"].ToUpper()))
                        {
                            job.Owner = job.Owner.Replace("AsysActionAcct", "AsysActionAcct@CORP");
                        }
                        if (job.Owner.Contains("BM_"))
                            job.Owner = job.Owner.Replace("BM_", ConfigurationManager.AppSettings["CtOwnerPrefix"].ToUpper());

                        if (job.Owner.Contains(ConfigurationManager.AppSettings["ProductionOwnerSuffix"].ToUpper()))
                        {
                            job.Owner = job.Owner.Replace(ConfigurationManager.AppSettings["ProductionOwnerSuffix"].ToUpper(), ConfigurationManager.AppSettings["NonProductionOwnerSuffix"].ToUpper());
                        }

                        job.Owner = job.Owner.Replace("CT1_AsysWinUnixAcct", "CT_AsysWinUnixAcct");
                    }

                    //adding changes in new attributes similar to owner
                    if (!string.IsNullOrEmpty(job.Ftp_Local_User))
                    {
                        //job.Ftp_Local_User = job.Ftp_Local_User.Replace(ConfigurationManager.AppSettings["DevOwnerPre"], ConfigurationManager.AppSettings["CtOwnerPre"]);
                        //job.Ftp_Local_User = job.Ftp_Local_User.Replace(ConfigurationManager.AppSettings["StageOwnerPre"], ConfigurationManager.AppSettings["CtOwnerPre"]);
                        //string ownerName = job.Ftp_Local_User.Split(':').Last().Trim();
                        //if (!ownerName.Contains("_") && !job.Ftp_Local_User.Contains(ConfigurationManager.AppSettings["NewOwnerName"]))
                        //    job.Ftp_Local_User = job.Ftp_Local_User.Split(':').First().Trim() + ":  CT1_" + ownerName;

                        //job.Ftp_Local_User = job.Ftp_Local_User.Replace(ConfigurationManager.AppSettings["ProductionOwnerSuffix"].ToUpper(), ConfigurationManager.AppSettings["NonProductionOwnerSuffix"].ToUpper());
                        job.Ftp_Local_User = Regex.Replace(job.Ftp_Local_User, ConfigurationManager.AppSettings["DevOwnerPre"], ConfigurationManager.AppSettings["CtOwnerPre"], RegexOptions.IgnoreCase);
                        job.Ftp_Local_User = Regex.Replace(job.Ftp_Local_User, ConfigurationManager.AppSettings["StageOwnerPre"], ConfigurationManager.AppSettings["CtOwnerPre"], RegexOptions.IgnoreCase);
                        job.Ftp_Local_User = Regex.Replace(job.Ftp_Local_User, ConfigurationManager.AppSettings["NewDevOwnerPre"], ConfigurationManager.AppSettings["NewCtOwnerPre"], RegexOptions.IgnoreCase);
                        job.Ftp_Local_User = Regex.Replace(job.Ftp_Local_User, ConfigurationManager.AppSettings["NewStageOwnerPre"], ConfigurationManager.AppSettings["NewCtOwnerPre"], RegexOptions.IgnoreCase);

                        //string ownerName = job.Ftp_Local_User.Split(':').Last().Trim();
                        //if (!ownerName.Contains("_") && !job.Ftp_Local_User.Contains(ConfigurationManager.AppSettings["NewOwnerName"]))
                        //    job.Ftp_Local_User = job.Ftp_Local_User.Split(':').First().Trim() + ":  CT1_" + ownerName;

                        job.Ftp_Local_User = Regex.Replace(job.Ftp_Local_User, ConfigurationManager.AppSettings["ProductionOwnerSuffix"], ConfigurationManager.AppSettings["NonProductionOwnerSuffix"].ToUpper(), RegexOptions.IgnoreCase);
                        if (!job.Ftp_Local_User.Contains(ConfigurationManager.AppSettings["CtOwnerPrefix"].ToUpper()) && !job.Ftp_Local_User.Contains(ConfigurationManager.AppSettings["NewCtOwnerPre"]))
                            job.Ftp_Local_User = job.Ftp_Local_User.Replace("AsysActionAcct", "CT1_AsysActionAcct");
                        if (job.Ftp_Local_User.Contains("AsysActionAcct") && !job.Ftp_Local_User.ToUpper().Contains(ConfigurationManager.AppSettings["NonProductionOwnerSuffix"].ToUpper()))
                        {
                            job.Ftp_Local_User = job.Ftp_Local_User.Replace("AsysActionAcct", "AsysActionAcct@CORP");
                        }
                        if (job.Ftp_Local_User.Contains("BM_"))
                            job.Ftp_Local_User = job.Ftp_Local_User.Replace("BM_", ConfigurationManager.AppSettings["CtOwnerPrefix"].ToUpper());
                    }

                    if (!string.IsNullOrEmpty(job.Watch_File_Win_User))
                    {
                        //job.Watch_File_Win_User = job.Watch_File_Win_User.Replace(ConfigurationManager.AppSettings["DevOwnerPre"], ConfigurationManager.AppSettings["CtOwnerPre"]);
                        //job.Watch_File_Win_User = job.Watch_File_Win_User.Replace(ConfigurationManager.AppSettings["StageOwnerPre"], ConfigurationManager.AppSettings["CtOwnerPre"]);
                        //string ownerName = job.Watch_File_Win_User.Split(':').Last().Trim();
                        //if (!ownerName.Contains("_") && !job.Watch_File_Win_User.Contains(ConfigurationManager.AppSettings["NewOwnerName"]))
                        //    job.Watch_File_Win_User = job.Watch_File_Win_User.Split(':').First().Trim() + ":  CT1_" + ownerName;

                        //job.Watch_File_Win_User = job.Watch_File_Win_User.Replace(ConfigurationManager.AppSettings["ProductionOwnerSuffix"].ToUpper(), ConfigurationManager.AppSettings["NonProductionOwnerSuffix"].ToUpper());
                        job.Watch_File_Win_User = Regex.Replace(job.Watch_File_Win_User, ConfigurationManager.AppSettings["DevOwnerPre"], ConfigurationManager.AppSettings["CtOwnerPre"], RegexOptions.IgnoreCase);
                        job.Watch_File_Win_User = Regex.Replace(job.Watch_File_Win_User, ConfigurationManager.AppSettings["StageOwnerPre"], ConfigurationManager.AppSettings["CtOwnerPre"], RegexOptions.IgnoreCase);
                        job.Watch_File_Win_User = Regex.Replace(job.Watch_File_Win_User, ConfigurationManager.AppSettings["NewDevOwnerPre"], ConfigurationManager.AppSettings["NewCtOwnerPre"], RegexOptions.IgnoreCase);
                        job.Watch_File_Win_User = Regex.Replace(job.Watch_File_Win_User, ConfigurationManager.AppSettings["NewStageOwnerPre"], ConfigurationManager.AppSettings["NewCtOwnerPre"], RegexOptions.IgnoreCase);

                        //string ownerName = job.Watch_File_Win_User.Split(':').Last().Trim();
                        //if (!ownerName.Contains("_") && !job.Watch_File_Win_User.Contains(ConfigurationManager.AppSettings["NewOwnerName"]))
                        //    job.Watch_File_Win_User = job.Watch_File_Win_User.Split(':').First().Trim() + ":  CT1_" + ownerName;

                        job.Watch_File_Win_User = Regex.Replace(job.Watch_File_Win_User, ConfigurationManager.AppSettings["ProductionOwnerSuffix"], ConfigurationManager.AppSettings["NonProductionOwnerSuffix"].ToUpper(), RegexOptions.IgnoreCase);
                        if (!job.Watch_File_Win_User.Contains(ConfigurationManager.AppSettings["CtOwnerPrefix"].ToUpper()) && !job.Watch_File_Win_User.Contains(ConfigurationManager.AppSettings["NewCtOwnerPre"]))
                            job.Watch_File_Win_User = job.Watch_File_Win_User.Replace("AsysActionAcct", "CT1_AsysActionAcct");
                        if (job.Watch_File_Win_User.Contains("AsysActionAcct") && !job.Watch_File_Win_User.ToUpper().Contains(ConfigurationManager.AppSettings["NonProductionOwnerSuffix"].ToUpper()))
                        {
                            job.Watch_File_Win_User = job.Watch_File_Win_User.Replace("AsysActionAcct", "AsysActionAcct@CORP");
                        }
                        if (job.Watch_File_Win_User.Contains("BM_"))
                            job.Watch_File_Win_User = job.Watch_File_Win_User.Replace("BM_", ConfigurationManager.AppSettings["CtOwnerPrefix"].ToUpper());
                    }


                    if (!string.IsNullOrEmpty(job.Command))
                    {
                        job.Command = Regex.Replace(job.Command, ConfigurationManager.AppSettings["DevCommandPath"], ConfigurationManager.AppSettings["CtNASCommandPath"], RegexOptions.IgnoreCase);
                        job.Command = job.Command.Replace(ConfigurationManager.AppSettings["DevCommandPath"].Replace("$$$$", "$$"), ConfigurationManager.AppSettings["CtNASCommandPath"]);
                        job.Command = job.Command.Replace(ConfigurationManager.AppSettings["OldDevCommandPath"].Replace("$$$$", "$$"), ConfigurationManager.AppSettings["CtNASCommandPath"]);
                        job.Command = job.Command.Replace(ConfigurationManager.AppSettings["StageCommandPath"].Replace("$$$$", "$$"), ConfigurationManager.AppSettings["CtNASCommandPath"]);
                        job.Command = job.Command.Replace(ConfigurationManager.AppSettings["CtCommandPath"].Replace("$$$$", "$$"), ConfigurationManager.AppSettings["CtNASCommandPath"]);
                        job.Command = job.Command.Replace(ConfigurationManager.AppSettings["DevNASCommandPath"].Replace("$$$$", "$$"), ConfigurationManager.AppSettings["CtNASCommandPath"]);
                        job.Command = job.Command.Replace(ConfigurationManager.AppSettings["StageNASCommandPath"].Replace("$$$$", "$$"), ConfigurationManager.AppSettings["CtNASCommandPath"]);
                        job.Command = Regex.Replace(job.Command, ConfigurationManager.AppSettings["NonProdFileStoreRootLocation"], ConfigurationManager.AppSettings["CtNASCommandPath"], RegexOptions.IgnoreCase);
                        job.Command = Regex.Replace(job.Command, ConfigurationManager.AppSettings["DalProdFileStoreRootLocation"], ConfigurationManager.AppSettings["CtNASCommandPath"], RegexOptions.IgnoreCase);
                        job.Command = Regex.Replace(job.Command, ConfigurationManager.AppSettings["ChiProdFileStoreRootLocation"], ConfigurationManager.AppSettings["CtNASCommandPath"], RegexOptions.IgnoreCase);
                        job.Command = Regex.Replace(job.Command, ConfigurationManager.AppSettings["DevOldAsaMachine01"], ConfigurationManager.AppSettings["CtNASCommandPath"], RegexOptions.IgnoreCase);
                        job.Command = Regex.Replace(job.Command, ConfigurationManager.AppSettings["DevOldAsaMachine02"], ConfigurationManager.AppSettings["CtNASCommandPath"], RegexOptions.IgnoreCase);
                        job.Command = Regex.Replace(job.Command, ConfigurationManager.AppSettings["DevNewAsaMachine01"], ConfigurationManager.AppSettings["CtNASCommandPath"], RegexOptions.IgnoreCase);
                        job.Command = Regex.Replace(job.Command, ConfigurationManager.AppSettings["DevNewAsaMachine02"], ConfigurationManager.AppSettings["CtNASCommandPath"], RegexOptions.IgnoreCase);
                        job.Command = Regex.Replace(job.Command, ConfigurationManager.AppSettings["StageOldAsaMachine01"], ConfigurationManager.AppSettings["CtNASCommandPath"], RegexOptions.IgnoreCase);
                        job.Command = Regex.Replace(job.Command, ConfigurationManager.AppSettings["StageOldAsaMachine02"], ConfigurationManager.AppSettings["CtNASCommandPath"], RegexOptions.IgnoreCase);
                        job.Command = Regex.Replace(job.Command, ConfigurationManager.AppSettings["StageNewAsaMachine01"], ConfigurationManager.AppSettings["CtNASCommandPath"], RegexOptions.IgnoreCase);
                        job.Command = Regex.Replace(job.Command, ConfigurationManager.AppSettings["StageNewAsaMachine02"], ConfigurationManager.AppSettings["CtNASCommandPath"], RegexOptions.IgnoreCase);
                        job.Command = Regex.Replace(job.Command, ConfigurationManager.AppSettings["DevGwyNewAsaMachine01"], ConfigurationManager.AppSettings["CtNASCommandPath"], RegexOptions.IgnoreCase);
                        job.Command = Regex.Replace(job.Command, ConfigurationManager.AppSettings["DevGwyNewAsaMachine02"], ConfigurationManager.AppSettings["CtNASCommandPath"], RegexOptions.IgnoreCase);
                        job.Command = Regex.Replace(job.Command, ConfigurationManager.AppSettings["StageGwyNewAsaMachine01"], ConfigurationManager.AppSettings["CtNASCommandPath"], RegexOptions.IgnoreCase);
                        job.Command = Regex.Replace(job.Command, ConfigurationManager.AppSettings["StageGwyNewAsaMachine02"], ConfigurationManager.AppSettings["CtNASCommandPath"], RegexOptions.IgnoreCase);
                        job.Command = Regex.Replace(job.Command, ConfigurationManager.AppSettings["CtGwyNewAsaMachine01"], ConfigurationManager.AppSettings["CtNASCommandPath"], RegexOptions.IgnoreCase);
                        job.Command = Regex.Replace(job.Command, ConfigurationManager.AppSettings["CtGwyNewAsaMachine02"], ConfigurationManager.AppSettings["CtNASCommandPath"], RegexOptions.IgnoreCase);
                        job.Command = Regex.Replace(job.Command, ConfigurationManager.AppSettings["NonProdSchedulerNASMachine"], ConfigurationManager.AppSettings["CtNASCommandPath"], RegexOptions.IgnoreCase);
                        job.Command = Regex.Replace(job.Command, ConfigurationManager.AppSettings["OldIncomingFilesPath"], ConfigurationManager.AppSettings["NewIncomingFilesPath"], RegexOptions.IgnoreCase);
                        job.Command = Regex.Replace(job.Command, ConfigurationManager.AppSettings["ProdFileNameExtension"], ConfigurationManager.AppSettings["CtFileNameExtension"], RegexOptions.IgnoreCase);
                        job.Command = Regex.Replace(job.Command, ConfigurationManager.AppSettings["DevFileNameExtension"], ConfigurationManager.AppSettings["CtFileNameExtension"], RegexOptions.IgnoreCase);
                        job.Command = Regex.Replace(job.Command, ConfigurationManager.AppSettings["StageFileNameExtension"], ConfigurationManager.AppSettings["CtFileNameExtension"], RegexOptions.IgnoreCase);
                        job.Command = job.Command.Replace("$$$$", "$$");
                        job.Command = job.Command.Replace(StringConstants.DEV_BIS_JOBS_SUBSTRING, StringConstants.CT_BIS_JOBS_SUBSTRING);
                        job.Command = job.Command.Replace(StringConstants.STAGE_BIS_JOBS_SUBSTRING, StringConstants.CT_BIS_JOBS_SUBSTRING);
                        job.Command = job.Command.Replace(StringConstants.PROD_BIS_JOBS_SUBSTRING, StringConstants.CT_BIS_JOBS_SUBSTRING);
                    }

                    //adding changes in new attributes similar to command
                    if (!string.IsNullOrEmpty(job.Ftp_Local_Name))
                    {

                        job.Ftp_Local_Name = job.Ftp_Local_Name.Replace(ConfigurationManager.AppSettings["DevCommandPath"].Replace("$$$$", "$$"), ConfigurationManager.AppSettings["CtNASCommandPath"]);
                        job.Ftp_Local_Name = job.Ftp_Local_Name.Replace(ConfigurationManager.AppSettings["OldDevCommandPath"].Replace("$$$$", "$$"), ConfigurationManager.AppSettings["CtNASCommandPath"]);
                        job.Ftp_Local_Name = job.Ftp_Local_Name.Replace(ConfigurationManager.AppSettings["StageCommandPath"].Replace("$$$$", "$$"), ConfigurationManager.AppSettings["CtNASCommandPath"]);
                        job.Ftp_Local_Name = job.Ftp_Local_Name.Replace(ConfigurationManager.AppSettings["CtCommandPath"].Replace("$$$$", "$$"), ConfigurationManager.AppSettings["CtNASCommandPath"]);
                        job.Ftp_Local_Name = job.Ftp_Local_Name.Replace(ConfigurationManager.AppSettings["DevNASCommandPath"].Replace("$$$$", "$$"), ConfigurationManager.AppSettings["CtNASCommandPath"]);
                        job.Ftp_Local_Name = job.Ftp_Local_Name.Replace(ConfigurationManager.AppSettings["StageNASCommandPath"].Replace("$$$$", "$$"), ConfigurationManager.AppSettings["CtNASCommandPath"]);
                        job.Ftp_Local_Name = Regex.Replace(job.Ftp_Local_Name, ConfigurationManager.AppSettings["NonProdFileStoreRootLocation"], ConfigurationManager.AppSettings["CtNASCommandPath"], RegexOptions.IgnoreCase);
                        job.Ftp_Local_Name = Regex.Replace(job.Ftp_Local_Name, ConfigurationManager.AppSettings["DalProdFileStoreRootLocation"], ConfigurationManager.AppSettings["CtNASCommandPath"], RegexOptions.IgnoreCase);
                        job.Ftp_Local_Name = Regex.Replace(job.Ftp_Local_Name, ConfigurationManager.AppSettings["ChiProdFileStoreRootLocation"], ConfigurationManager.AppSettings["CtNASCommandPath"], RegexOptions.IgnoreCase);
                        job.Ftp_Local_Name = Regex.Replace(job.Ftp_Local_Name, ConfigurationManager.AppSettings["DevOldAsaMachine01"], ConfigurationManager.AppSettings["CtNASCommandPath"], RegexOptions.IgnoreCase);
                        job.Ftp_Local_Name = Regex.Replace(job.Ftp_Local_Name, ConfigurationManager.AppSettings["DevOldAsaMachine02"], ConfigurationManager.AppSettings["CtNASCommandPath"], RegexOptions.IgnoreCase);
                        job.Ftp_Local_Name = Regex.Replace(job.Ftp_Local_Name, ConfigurationManager.AppSettings["DevNewAsaMachine01"], ConfigurationManager.AppSettings["CtNASCommandPath"], RegexOptions.IgnoreCase);
                        job.Ftp_Local_Name = Regex.Replace(job.Ftp_Local_Name, ConfigurationManager.AppSettings["DevNewAsaMachine02"], ConfigurationManager.AppSettings["CtNASCommandPath"], RegexOptions.IgnoreCase);
                        job.Ftp_Local_Name = Regex.Replace(job.Ftp_Local_Name, ConfigurationManager.AppSettings["StageOldAsaMachine01"], ConfigurationManager.AppSettings["CtNASCommandPath"], RegexOptions.IgnoreCase);
                        job.Ftp_Local_Name = Regex.Replace(job.Ftp_Local_Name, ConfigurationManager.AppSettings["StageOldAsaMachine02"], ConfigurationManager.AppSettings["CtNASCommandPath"], RegexOptions.IgnoreCase);
                        job.Ftp_Local_Name = Regex.Replace(job.Ftp_Local_Name, ConfigurationManager.AppSettings["StageNewAsaMachine01"], ConfigurationManager.AppSettings["CtNASCommandPath"], RegexOptions.IgnoreCase);
                        job.Ftp_Local_Name = Regex.Replace(job.Ftp_Local_Name, ConfigurationManager.AppSettings["StageNewAsaMachine02"], ConfigurationManager.AppSettings["CtNASCommandPath"], RegexOptions.IgnoreCase);
                        job.Ftp_Local_Name = Regex.Replace(job.Ftp_Local_Name, ConfigurationManager.AppSettings["DevGwyNewAsaMachine01"], ConfigurationManager.AppSettings["CtNASCommandPath"], RegexOptions.IgnoreCase);
                        job.Ftp_Local_Name = Regex.Replace(job.Ftp_Local_Name, ConfigurationManager.AppSettings["DevGwyNewAsaMachine02"], ConfigurationManager.AppSettings["CtNASCommandPath"], RegexOptions.IgnoreCase);
                        job.Ftp_Local_Name = Regex.Replace(job.Ftp_Local_Name, ConfigurationManager.AppSettings["StageGwyNewAsaMachine01"], ConfigurationManager.AppSettings["CtNASCommandPath"], RegexOptions.IgnoreCase);
                        job.Ftp_Local_Name = Regex.Replace(job.Ftp_Local_Name, ConfigurationManager.AppSettings["StageGwyNewAsaMachine02"], ConfigurationManager.AppSettings["CtNASCommandPath"], RegexOptions.IgnoreCase);
                        job.Ftp_Local_Name = Regex.Replace(job.Ftp_Local_Name, ConfigurationManager.AppSettings["CtGwyNewAsaMachine01"], ConfigurationManager.AppSettings["CtNASCommandPath"], RegexOptions.IgnoreCase);
                        job.Ftp_Local_Name = Regex.Replace(job.Ftp_Local_Name, ConfigurationManager.AppSettings["CtGwyNewAsaMachine02"], ConfigurationManager.AppSettings["CtNASCommandPath"], RegexOptions.IgnoreCase);
                        job.Ftp_Local_Name = Regex.Replace(job.Ftp_Local_Name, ConfigurationManager.AppSettings["NonProdSchedulerNASMachine"], ConfigurationManager.AppSettings["CtNASCommandPath"], RegexOptions.IgnoreCase);
                        job.Ftp_Local_Name = Regex.Replace(job.Ftp_Local_Name, ConfigurationManager.AppSettings["OldIncomingFilesPath"], ConfigurationManager.AppSettings["NewIncomingFilesPath"], RegexOptions.IgnoreCase);
                        job.Ftp_Local_Name = Regex.Replace(job.Ftp_Local_Name, ConfigurationManager.AppSettings["ProdFileNameExtension"], ConfigurationManager.AppSettings["CtFileNameExtension"], RegexOptions.IgnoreCase);
                        job.Ftp_Local_Name = Regex.Replace(job.Ftp_Local_Name, ConfigurationManager.AppSettings["DevFileNameExtension"], ConfigurationManager.AppSettings["CtFileNameExtension"], RegexOptions.IgnoreCase);
                        job.Ftp_Local_Name = Regex.Replace(job.Ftp_Local_Name, ConfigurationManager.AppSettings["StageFileNameExtension"], ConfigurationManager.AppSettings["CtFileNameExtension"], RegexOptions.IgnoreCase);
                        job.Ftp_Local_Name = job.Ftp_Local_Name.Replace("$$$$", "$$");
                    }

                    if (!string.IsNullOrEmpty(job.Watch_File))
                    {

                        job.Watch_File = job.Watch_File.Replace(ConfigurationManager.AppSettings["DevCommandPath"].Replace("$$$$", "$$"), ConfigurationManager.AppSettings["CtNASCommandPath"]);
                        job.Watch_File = job.Watch_File.Replace(ConfigurationManager.AppSettings["OldDevCommandPath"].Replace("$$$$", "$$"), ConfigurationManager.AppSettings["CtNASCommandPath"]);
                        job.Watch_File = job.Watch_File.Replace(ConfigurationManager.AppSettings["StageCommandPath"].Replace("$$$$", "$$"), ConfigurationManager.AppSettings["CtNASCommandPath"]);
                        job.Watch_File = job.Watch_File.Replace(ConfigurationManager.AppSettings["CtCommandPath"].Replace("$$$$", "$$"), ConfigurationManager.AppSettings["CtNASCommandPath"]);
                        job.Watch_File = job.Watch_File.Replace(ConfigurationManager.AppSettings["DevNASCommandPath"].Replace("$$$$", "$$"), ConfigurationManager.AppSettings["CtNASCommandPath"]);
                        job.Watch_File = job.Watch_File.Replace(ConfigurationManager.AppSettings["StageNASCommandPath"].Replace("$$$$", "$$"), ConfigurationManager.AppSettings["CtNASCommandPath"]);
                        //job.Watch_File = Regex.Replace(job.Watch_File, ConfigurationManager.AppSettings["NonProdFileStoreRootLocation"], ConfigurationManager.AppSettings["CtNASCommandPath"], RegexOptions.IgnoreCase);
                        job.Watch_File = Regex.Replace(job.Watch_File, ConfigurationManager.AppSettings["DalProdFileStoreRootLocation"], ConfigurationManager.AppSettings["CtNASCommandPath"], RegexOptions.IgnoreCase);
                        job.Watch_File = Regex.Replace(job.Watch_File, ConfigurationManager.AppSettings["ChiProdFileStoreRootLocation"], ConfigurationManager.AppSettings["CtNASCommandPath"], RegexOptions.IgnoreCase);
                        job.Watch_File = Regex.Replace(job.Watch_File, ConfigurationManager.AppSettings["DevOldAsaMachine01"], ConfigurationManager.AppSettings["CtNASCommandPath"], RegexOptions.IgnoreCase);
                        job.Watch_File = Regex.Replace(job.Watch_File, ConfigurationManager.AppSettings["DevOldAsaMachine02"], ConfigurationManager.AppSettings["CtNASCommandPath"], RegexOptions.IgnoreCase);
                        job.Watch_File = Regex.Replace(job.Watch_File, ConfigurationManager.AppSettings["DevNewAsaMachine01"], ConfigurationManager.AppSettings["CtNASCommandPath"], RegexOptions.IgnoreCase);
                        job.Watch_File = Regex.Replace(job.Watch_File, ConfigurationManager.AppSettings["DevNewAsaMachine02"], ConfigurationManager.AppSettings["CtNASCommandPath"], RegexOptions.IgnoreCase);
                        job.Watch_File = Regex.Replace(job.Watch_File, ConfigurationManager.AppSettings["StageOldAsaMachine01"], ConfigurationManager.AppSettings["CtNASCommandPath"], RegexOptions.IgnoreCase);
                        job.Watch_File = Regex.Replace(job.Watch_File, ConfigurationManager.AppSettings["StageOldAsaMachine02"], ConfigurationManager.AppSettings["CtNASCommandPath"], RegexOptions.IgnoreCase);
                        job.Watch_File = Regex.Replace(job.Watch_File, ConfigurationManager.AppSettings["StageNewAsaMachine01"], ConfigurationManager.AppSettings["CtNASCommandPath"], RegexOptions.IgnoreCase);
                        job.Watch_File = Regex.Replace(job.Watch_File, ConfigurationManager.AppSettings["StageNewAsaMachine02"], ConfigurationManager.AppSettings["CtNASCommandPath"], RegexOptions.IgnoreCase);
                        job.Watch_File = Regex.Replace(job.Watch_File, ConfigurationManager.AppSettings["DevGwyNewAsaMachine01"], ConfigurationManager.AppSettings["CtNASCommandPath"], RegexOptions.IgnoreCase);
                        job.Watch_File = Regex.Replace(job.Watch_File, ConfigurationManager.AppSettings["DevGwyNewAsaMachine02"], ConfigurationManager.AppSettings["CtNASCommandPath"], RegexOptions.IgnoreCase);
                        job.Watch_File = Regex.Replace(job.Watch_File, ConfigurationManager.AppSettings["StageGwyNewAsaMachine01"], ConfigurationManager.AppSettings["CtNASCommandPath"], RegexOptions.IgnoreCase);
                        job.Watch_File = Regex.Replace(job.Watch_File, ConfigurationManager.AppSettings["StageGwyNewAsaMachine02"], ConfigurationManager.AppSettings["CtNASCommandPath"], RegexOptions.IgnoreCase);
                        job.Watch_File = Regex.Replace(job.Watch_File, ConfigurationManager.AppSettings["CtGwyNewAsaMachine01"], ConfigurationManager.AppSettings["CtNASCommandPath"], RegexOptions.IgnoreCase);
                        job.Watch_File = Regex.Replace(job.Watch_File, ConfigurationManager.AppSettings["CtGwyNewAsaMachine02"], ConfigurationManager.AppSettings["CtNASCommandPath"], RegexOptions.IgnoreCase);
                        job.Watch_File = Regex.Replace(job.Watch_File, ConfigurationManager.AppSettings["NonProdSchedulerNASMachine"], ConfigurationManager.AppSettings["CtNASCommandPath"], RegexOptions.IgnoreCase);
                        job.Watch_File = Regex.Replace(job.Watch_File, ConfigurationManager.AppSettings["OldIncomingFilesPath"], ConfigurationManager.AppSettings["NewIncomingFilesPath"], RegexOptions.IgnoreCase);
                        job.Watch_File = Regex.Replace(job.Watch_File, ConfigurationManager.AppSettings["ProdFileNameExtension"], ConfigurationManager.AppSettings["CtFileNameExtension"], RegexOptions.IgnoreCase);
                        job.Watch_File = Regex.Replace(job.Watch_File, ConfigurationManager.AppSettings["DevFileNameExtension"], ConfigurationManager.AppSettings["CtFileNameExtension"], RegexOptions.IgnoreCase);
                        job.Watch_File = Regex.Replace(job.Watch_File, ConfigurationManager.AppSettings["StageFileNameExtension"], ConfigurationManager.AppSettings["CtFileNameExtension"], RegexOptions.IgnoreCase);
                        job.Watch_File = job.Watch_File.Replace("$$$$", "$$");
                    }

                }
                else if (prodCheckBoxValue)
                {
                    if (!string.IsNullOrEmpty(job.Header))
                    {
                        job.Header = job.Header.Replace(ConfigurationManager.AppSettings["DevBisSubString"], ConfigurationManager.AppSettings["ProdBisSubString"]);
                        job.Header = job.Header.Replace(ConfigurationManager.AppSettings["StageBisSubString"], ConfigurationManager.AppSettings["ProdBisSubString"]);
                        job.Header = job.Header.Replace(ConfigurationManager.AppSettings["CtBisSubString"], ConfigurationManager.AppSettings["ProdBisSubString"]);
                    }
                    if (!string.IsNullOrEmpty(job.Insert_job))
                    {
                        job.Insert_job = job.Insert_job.Replace(ConfigurationManager.AppSettings["DevBisSubString"], ConfigurationManager.AppSettings["ProdBisSubString"]);
                        job.Insert_job = job.Insert_job.Replace(ConfigurationManager.AppSettings["StageBisSubString"], ConfigurationManager.AppSettings["ProdBisSubString"]);
                        job.Insert_job = job.Insert_job.Replace(ConfigurationManager.AppSettings["CtBisSubString"], ConfigurationManager.AppSettings["ProdBisSubString"]);
                    }
                    if (!string.IsNullOrEmpty(job.Boxname))
                    {
                        job.Boxname = job.Boxname.Replace(ConfigurationManager.AppSettings["DevBisSubString"], ConfigurationManager.AppSettings["ProdBisSubString"]);
                        job.Boxname = job.Boxname.Replace(ConfigurationManager.AppSettings["StageBisSubString"], ConfigurationManager.AppSettings["ProdBisSubString"]);
                        job.Boxname = job.Boxname.Replace(ConfigurationManager.AppSettings["CtBisSubString"], ConfigurationManager.AppSettings["ProdBisSubString"]);
                    }
                    if (!string.IsNullOrEmpty(job.Condition))
                    {
                        job.Condition = job.Condition.Replace(ConfigurationManager.AppSettings["DevBisSubString"], ConfigurationManager.AppSettings["ProdBisSubString"]);
                        job.Condition = job.Condition.Replace(ConfigurationManager.AppSettings["StageBisSubString"], ConfigurationManager.AppSettings["ProdBisSubString"]);
                        job.Condition = job.Condition.Replace(ConfigurationManager.AppSettings["CtBisSubString"], ConfigurationManager.AppSettings["ProdBisSubString"]);
                    }
                    if (!string.IsNullOrEmpty(job.Box_Success))
                    {
                        job.Box_Success = job.Box_Success.Replace(ConfigurationManager.AppSettings["DevBisSubString"], ConfigurationManager.AppSettings["ProdBisSubString"]);
                        job.Box_Success = job.Box_Success.Replace(ConfigurationManager.AppSettings["StageBisSubString"], ConfigurationManager.AppSettings["ProdBisSubString"]);
                        job.Box_Success = job.Box_Success.Replace(ConfigurationManager.AppSettings["CtBisSubString"], ConfigurationManager.AppSettings["ProdBisSubString"]);
                    }
                    if (!string.IsNullOrEmpty(job.Box_Failure))
                    {
                        job.Box_Failure = job.Box_Failure.Replace(ConfigurationManager.AppSettings["DevBisSubString"], ConfigurationManager.AppSettings["ProdBisSubString"]);
                        job.Box_Failure = job.Box_Failure.Replace(ConfigurationManager.AppSettings["StageBisSubString"], ConfigurationManager.AppSettings["ProdBisSubString"]);
                        job.Box_Failure = job.Box_Failure.Replace(ConfigurationManager.AppSettings["CtBisSubString"], ConfigurationManager.AppSettings["ProdBisSubString"]);
                    }
                    if (!string.IsNullOrEmpty(job.Machine))
                    {
                        if (job.Machine.Contains("od_asa") && job.Machine.Contains(ConfigurationManager.AppSettings["VirtualMachinePrefix"]))
                            job.Machine = job.Machine.Replace(job.Machine.Split(new string[] { "machine:" }, StringSplitOptions.None).Last().Trim(), ConfigurationManager.AppSettings["ProAsaMachineName"]);
                        if (job.Machine.Contains("od_ach_settlement"))
                            job.Machine = job.Machine.Split(new string[] { "bis-v-od_ach_settlement" }, StringSplitOptions.None).First().Trim() + ConfigurationManager.AppSettings["ProAchSettlementMachineName"];
                        if (job.Machine.Contains("od_cc_settlement"))
                            job.Machine = job.Machine.Split(new string[] { "bis-v-od_cc_settlement" }, StringSplitOptions.None).First().Trim() + ConfigurationManager.AppSettings["ProCcSettlementMachineName"];
                        if (job.Machine.Contains("od_ajb_settlement"))
                            job.Machine = job.Machine.Split(new string[] { "bis-v-od_ajb_settlement" }, StringSplitOptions.None).First().Trim() + ConfigurationManager.AppSettings["ProAjbSettlementMachineName"];
                        if (job.Machine.Contains("od_processor_settlement"))
                            job.Machine = job.Machine.Split(new string[] { "bis-v-od_processor_settlement" }, StringSplitOptions.None).First().Trim() + ConfigurationManager.AppSettings["ProProcessorSettlementMachineName"];
                        if (job.Machine.Contains("bis-r-") && job.Machine.Contains("asa"))
                            job.Machine = job.Machine.Split(new string[] { "bis-r-" }, StringSplitOptions.None).First().Trim() + ConfigurationManager.AppSettings["ProAsaMachineName"];
                        if (job.Machine.Contains("gwy"))
                        {
                            job.Machine = job.Machine.Split(':').First().Trim() + ": " + ConfigurationManager.AppSettings["ProProcessorSettlementMachineName"];
                        }
                    }

                    if (!string.IsNullOrEmpty(job.Owner))
                    {
                        //if (job.Owner.ToLower().Contains(ConfigurationManager.AppSettings["ProOwnerName"]))
                        //{
                        //    job.Owner = job.Owner.Replace(ConfigurationManager.AppSettings["DevOwnerPrefix"].ToUpper(), "");
                        //    job.Owner = job.Owner.Replace(ConfigurationManager.AppSettings["StageOwnerPrefix"].ToUpper(), "");
                        //    job.Owner = job.Owner.Replace(ConfigurationManager.AppSettings["CtOwnerPrefix"].ToUpper(), "");
                        //}
                        //else if(!job.Owner.ToLower().Contains(ConfigurationManager.AppSettings["ProOwnerName"]) && job.Owner.Contains("_"))
                        //{
                        //    job.Owner = job.Owner.Replace(ConfigurationManager.AppSettings["DevOwnerPre"], ConfigurationManager.AppSettings["ProdOwnerPre"]);
                        //    job.Owner = job.Owner.Replace(ConfigurationManager.AppSettings["StageOwnerPre"], ConfigurationManager.AppSettings["ProdOwnerPre"]);
                        //    job.Owner = job.Owner.Replace(ConfigurationManager.AppSettings["CtOwnerPre"], ConfigurationManager.AppSettings["ProdOwnerPre"]);
                        //}

                        //job.Owner = job.Owner.Replace(ConfigurationManager.AppSettings["NonProductionOwnerSuffix"].ToUpper(), ConfigurationManager.AppSettings["ProductionOwnerSuffix"].ToUpper());

                        if (job.Owner.ToLower().Contains(ConfigurationManager.AppSettings["ProOwnerName"]) || job.Owner.ToLower().Contains(ConfigurationManager.AppSettings["LinuxProOwnerName"]))
                        {
                            job.Owner = Regex.Replace(job.Owner, ConfigurationManager.AppSettings["DevOwnerPrefix"].ToUpper(), "", RegexOptions.IgnoreCase);
                            job.Owner = Regex.Replace(job.Owner, ConfigurationManager.AppSettings["StageOwnerPrefix"].ToUpper(), "", RegexOptions.IgnoreCase);
                            job.Owner = Regex.Replace(job.Owner, ConfigurationManager.AppSettings["CtOwnerPrefix"].ToUpper(), "", RegexOptions.IgnoreCase);
                            job.Owner = Regex.Replace(job.Owner, ConfigurationManager.AppSettings["NewDevOwnerPrefix"], string.Empty, RegexOptions.IgnoreCase);
                            job.Owner = Regex.Replace(job.Owner, ConfigurationManager.AppSettings["NewStageOwnerPrefix"], string.Empty, RegexOptions.IgnoreCase);
                            job.Owner = Regex.Replace(job.Owner, ConfigurationManager.AppSettings["NewCtOwnerPrefix"], string.Empty, RegexOptions.IgnoreCase);
                            job.Owner = Regex.Replace(job.Owner, "CT_", string.Empty, RegexOptions.IgnoreCase);
                            //job.Owner = job.Owner.Replace("Dev_", "");
                            //job.Owner = job.Owner.Replace("Sta_", "");
                            //job.Owner = job.Owner.Replace("Ct1_", "");
                        }
                        else if (!job.Owner.ToLower().Contains(ConfigurationManager.AppSettings["ProOwnerName"]) && job.Owner.Contains("_"))
                        {
                            job.Owner = Regex.Replace(job.Owner, ConfigurationManager.AppSettings["DevOwnerPre"], ConfigurationManager.AppSettings["ProdOwnerPre"], RegexOptions.IgnoreCase);
                            job.Owner = Regex.Replace(job.Owner, ConfigurationManager.AppSettings["StageOwnerPre"], ConfigurationManager.AppSettings["ProdOwnerPre"], RegexOptions.IgnoreCase);
                            job.Owner = Regex.Replace(job.Owner, ConfigurationManager.AppSettings["CtOwnerPre"], ConfigurationManager.AppSettings["ProdOwnerPre"], RegexOptions.IgnoreCase);
                            job.Owner = Regex.Replace(job.Owner, ConfigurationManager.AppSettings["NewDevOwnerPre"], ConfigurationManager.AppSettings["ProdOwnerPre"], RegexOptions.IgnoreCase);
                            job.Owner = Regex.Replace(job.Owner, ConfigurationManager.AppSettings["NewStageOwnerPre"], ConfigurationManager.AppSettings["ProdOwnerPre"], RegexOptions.IgnoreCase);
                            job.Owner = Regex.Replace(job.Owner, ConfigurationManager.AppSettings["NewCtOwnerPre"], ConfigurationManager.AppSettings["ProdOwnerPre"], RegexOptions.IgnoreCase);
                            job.Owner = Regex.Replace(job.Owner, "CT_", string.Empty, RegexOptions.IgnoreCase);
                            //job.Owner = job.Owner.Replace("Dev", ConfigurationManager.AppSettings["ProdOwnerPre"]);
                            //job.Owner = job.Owner.Replace("Sta", ConfigurationManager.AppSettings["ProdOwnerPre"]);
                            //job.Owner = job.Owner.Replace("Ct1", ConfigurationManager.AppSettings["ProdOwnerPre"]);
                        }

                        job.Owner = Regex.Replace(job.Owner, ConfigurationManager.AppSettings["NonProductionOwnerSuffix"], ConfigurationManager.AppSettings["ProductionOwnerSuffix"].ToUpper(), RegexOptions.IgnoreCase);

                        if (job.Owner.ToLower().Contains("asysactionacct") && !job.Owner.ToUpper().Contains(ConfigurationManager.AppSettings["ProductionOwnerSuffix"].ToUpper()))
                        {
                            job.Owner = Regex.Replace(job.Owner, "AsysActionAcct", "AsysActionAcct@PRO", RegexOptions.IgnoreCase);
                        }
                    }

                    //adding changes in new attributes similar to owner
                    if (!string.IsNullOrEmpty(job.Ftp_Local_User))
                    {
                        //if (job.Ftp_Local_User.ToLower().Contains(ConfigurationManager.AppSettings["ProOwnerName"]))
                        //{
                        //    job.Ftp_Local_User = job.Ftp_Local_User.Replace(ConfigurationManager.AppSettings["DevOwnerPrefix"].ToUpper(), "");
                        //    job.Ftp_Local_User = job.Ftp_Local_User.Replace(ConfigurationManager.AppSettings["StageOwnerPrefix"].ToUpper(), "");
                        //    job.Ftp_Local_User = job.Ftp_Local_User.Replace(ConfigurationManager.AppSettings["CtOwnerPrefix"].ToUpper(), "");
                        //}
                        //else if(!job.Ftp_Local_User.ToLower().Contains(ConfigurationManager.AppSettings["ProOwnerName"]) && job.Ftp_Local_User.Contains("_"))
                        //{
                        //    job.Ftp_Local_User = job.Ftp_Local_User.Replace(ConfigurationManager.AppSettings["DevOwnerPre"], ConfigurationManager.AppSettings["ProdOwnerPre"]);
                        //    job.Ftp_Local_User = job.Ftp_Local_User.Replace(ConfigurationManager.AppSettings["StageOwnerPre"], ConfigurationManager.AppSettings["ProdOwnerPre"]);
                        //    job.Ftp_Local_User = job.Ftp_Local_User.Replace(ConfigurationManager.AppSettings["CtOwnerPre"], ConfigurationManager.AppSettings["ProdOwnerPre"]);
                        //}

                        //job.Ftp_Local_User = job.Ftp_Local_User.Replace(ConfigurationManager.AppSettings["NonProductionOwnerSuffix"].ToUpper(), ConfigurationManager.AppSettings["ProductionOwnerSuffix"].ToUpper());

                        if (job.Ftp_Local_User.ToLower().Contains(ConfigurationManager.AppSettings["ProOwnerName"]))
                        {
                            job.Ftp_Local_User = Regex.Replace(job.Ftp_Local_User, ConfigurationManager.AppSettings["DevOwnerPrefix"].ToUpper(), "", RegexOptions.IgnoreCase);
                            job.Ftp_Local_User = Regex.Replace(job.Ftp_Local_User, ConfigurationManager.AppSettings["StageOwnerPrefix"].ToUpper(), "", RegexOptions.IgnoreCase);
                            job.Ftp_Local_User = Regex.Replace(job.Ftp_Local_User, ConfigurationManager.AppSettings["CtOwnerPrefix"].ToUpper(), "", RegexOptions.IgnoreCase);
                            job.Ftp_Local_User = Regex.Replace(job.Ftp_Local_User, ConfigurationManager.AppSettings["NewDevOwnerPrefix"], string.Empty, RegexOptions.IgnoreCase);
                            job.Ftp_Local_User = Regex.Replace(job.Ftp_Local_User, ConfigurationManager.AppSettings["NewStageOwnerPrefix"], string.Empty, RegexOptions.IgnoreCase);
                            job.Ftp_Local_User = Regex.Replace(job.Ftp_Local_User, ConfigurationManager.AppSettings["NewCtOwnerPrefix"], string.Empty, RegexOptions.IgnoreCase);
                            //job.Ftp_Local_User = job.Ftp_Local_User.Replace("Dev_", "");
                            //job.Ftp_Local_User = job.Ftp_Local_User.Replace("Sta_", "");
                            //job.Ftp_Local_User = job.Ftp_Local_User.Replace("Ct1_", "");
                        }
                        else if (!job.Ftp_Local_User.ToLower().Contains(ConfigurationManager.AppSettings["ProOwnerName"]) && job.Ftp_Local_User.Contains("_"))
                        {
                            job.Ftp_Local_User = Regex.Replace(job.Ftp_Local_User, ConfigurationManager.AppSettings["DevOwnerPre"], ConfigurationManager.AppSettings["ProdOwnerPre"], RegexOptions.IgnoreCase);
                            job.Ftp_Local_User = Regex.Replace(job.Ftp_Local_User, ConfigurationManager.AppSettings["StageOwnerPre"], ConfigurationManager.AppSettings["ProdOwnerPre"], RegexOptions.IgnoreCase);
                            job.Ftp_Local_User = Regex.Replace(job.Ftp_Local_User, ConfigurationManager.AppSettings["CtOwnerPre"], ConfigurationManager.AppSettings["ProdOwnerPre"], RegexOptions.IgnoreCase);
                            job.Ftp_Local_User = Regex.Replace(job.Ftp_Local_User, ConfigurationManager.AppSettings["NewDevOwnerPre"], ConfigurationManager.AppSettings["ProdOwnerPre"], RegexOptions.IgnoreCase);
                            job.Ftp_Local_User = Regex.Replace(job.Ftp_Local_User, ConfigurationManager.AppSettings["NewStageOwnerPre"], ConfigurationManager.AppSettings["ProdOwnerPre"], RegexOptions.IgnoreCase);
                            job.Ftp_Local_User = Regex.Replace(job.Ftp_Local_User, ConfigurationManager.AppSettings["NewCtOwnerPre"], ConfigurationManager.AppSettings["ProdOwnerPre"], RegexOptions.IgnoreCase);
                            //job.Ftp_Local_User = job.Ftp_Local_User.Replace("Dev", ConfigurationManager.AppSettings["ProdOwnerPre"]);
                            //job.Ftp_Local_User = job.Ftp_Local_User.Replace("Sta", ConfigurationManager.AppSettings["ProdOwnerPre"]);
                            //job.Ftp_Local_User = job.Ftp_Local_User.Replace("Ct1", ConfigurationManager.AppSettings["ProdOwnerPre"]);
                        }

                        job.Ftp_Local_User = Regex.Replace(job.Ftp_Local_User, ConfigurationManager.AppSettings["NonProductionOwnerSuffix"], ConfigurationManager.AppSettings["ProductionOwnerSuffix"].ToUpper(), RegexOptions.IgnoreCase);

                        if (job.Ftp_Local_User.ToLower().Contains("asysactionacct") && !job.Ftp_Local_User.ToUpper().Contains(ConfigurationManager.AppSettings["ProductionOwnerSuffix"].ToUpper()))
                        {
                            job.Ftp_Local_User = Regex.Replace(job.Ftp_Local_User, "AsysActionAcct", "AsysActionAcct@PRO", RegexOptions.IgnoreCase);
                        }
                    }

                    if (!string.IsNullOrEmpty(job.Watch_File_Win_User))
                    {
                        //if (job.Watch_File_Win_User.ToLower().Contains(ConfigurationManager.AppSettings["ProOwnerName"]))
                        //{
                        //    job.Watch_File_Win_User = job.Watch_File_Win_User.Replace(ConfigurationManager.AppSettings["DevOwnerPrefix"].ToUpper(), "");
                        //    job.Watch_File_Win_User = job.Watch_File_Win_User.Replace(ConfigurationManager.AppSettings["StageOwnerPrefix"].ToUpper(), "");
                        //    job.Watch_File_Win_User = job.Watch_File_Win_User.Replace(ConfigurationManager.AppSettings["CtOwnerPrefix"].ToUpper(), "");
                        //}
                        //else if(!job.Watch_File_Win_User.ToLower().Contains(ConfigurationManager.AppSettings["ProOwnerName"]) && job.Watch_File_Win_User.Contains("_"))
                        //{
                        //    job.Watch_File_Win_User = job.Watch_File_Win_User.Replace(ConfigurationManager.AppSettings["DevOwnerPre"], ConfigurationManager.AppSettings["ProdOwnerPre"]);
                        //    job.Watch_File_Win_User = job.Watch_File_Win_User.Replace(ConfigurationManager.AppSettings["StageOwnerPre"], ConfigurationManager.AppSettings["ProdOwnerPre"]);
                        //    job.Watch_File_Win_User = job.Watch_File_Win_User.Replace(ConfigurationManager.AppSettings["CtOwnerPre"], ConfigurationManager.AppSettings["ProdOwnerPre"]);
                        //}

                        //job.Watch_File_Win_User = job.Watch_File_Win_User.Replace(ConfigurationManager.AppSettings["NonProductionOwnerSuffix"].ToUpper(), ConfigurationManager.AppSettings["ProductionOwnerSuffix"].ToUpper());

                        if (job.Watch_File_Win_User.ToLower().Contains(ConfigurationManager.AppSettings["ProOwnerName"]))
                        {
                            job.Watch_File_Win_User = Regex.Replace(job.Watch_File_Win_User, ConfigurationManager.AppSettings["DevOwnerPrefix"].ToUpper(), "", RegexOptions.IgnoreCase);
                            job.Watch_File_Win_User = Regex.Replace(job.Watch_File_Win_User, ConfigurationManager.AppSettings["StageOwnerPrefix"].ToUpper(), "", RegexOptions.IgnoreCase);
                            job.Watch_File_Win_User = Regex.Replace(job.Watch_File_Win_User, ConfigurationManager.AppSettings["CtOwnerPrefix"].ToUpper(), "", RegexOptions.IgnoreCase);
                            job.Watch_File_Win_User = Regex.Replace(job.Watch_File_Win_User, ConfigurationManager.AppSettings["NewDevOwnerPrefix"], string.Empty, RegexOptions.IgnoreCase);
                            job.Watch_File_Win_User = Regex.Replace(job.Watch_File_Win_User, ConfigurationManager.AppSettings["NewStageOwnerPrefix"], string.Empty, RegexOptions.IgnoreCase);
                            job.Watch_File_Win_User = Regex.Replace(job.Watch_File_Win_User, ConfigurationManager.AppSettings["NewCtOwnerPrefix"], string.Empty, RegexOptions.IgnoreCase);
                            //job.Watch_File_Win_User = job.Watch_File_Win_User.Replace("Dev_", "");
                            //job.Watch_File_Win_User = job.Watch_File_Win_User.Replace("Sta_", "");
                            //job.Watch_File_Win_User = job.Watch_File_Win_User.Replace("Ct1_", "");
                        }
                        else if (!job.Watch_File_Win_User.ToLower().Contains(ConfigurationManager.AppSettings["ProOwnerName"]) && job.Watch_File_Win_User.Contains("_"))
                        {
                            job.Watch_File_Win_User = Regex.Replace(job.Watch_File_Win_User, ConfigurationManager.AppSettings["DevOwnerPre"], ConfigurationManager.AppSettings["ProdOwnerPre"], RegexOptions.IgnoreCase);
                            job.Watch_File_Win_User = Regex.Replace(job.Watch_File_Win_User, ConfigurationManager.AppSettings["StageOwnerPre"], ConfigurationManager.AppSettings["ProdOwnerPre"], RegexOptions.IgnoreCase);
                            job.Watch_File_Win_User = Regex.Replace(job.Watch_File_Win_User, ConfigurationManager.AppSettings["CtOwnerPre"], ConfigurationManager.AppSettings["ProdOwnerPre"], RegexOptions.IgnoreCase);
                            job.Watch_File_Win_User = Regex.Replace(job.Watch_File_Win_User, ConfigurationManager.AppSettings["NewDevOwnerPre"], ConfigurationManager.AppSettings["ProdOwnerPre"], RegexOptions.IgnoreCase);
                            job.Watch_File_Win_User = Regex.Replace(job.Watch_File_Win_User, ConfigurationManager.AppSettings["NewStageOwnerPre"], ConfigurationManager.AppSettings["ProdOwnerPre"], RegexOptions.IgnoreCase);
                            job.Watch_File_Win_User = Regex.Replace(job.Watch_File_Win_User, ConfigurationManager.AppSettings["NewCtOwnerPre"], ConfigurationManager.AppSettings["ProdOwnerPre"], RegexOptions.IgnoreCase);
                            //job.Watch_File_Win_User = job.Watch_File_Win_User.Replace("Dev", ConfigurationManager.AppSettings["ProdOwnerPre"]);
                            //job.Watch_File_Win_User = job.Watch_File_Win_User.Replace("Sta", ConfigurationManager.AppSettings["ProdOwnerPre"]);
                            //job.Watch_File_Win_User = job.Watch_File_Win_User.Replace("Ct1", ConfigurationManager.AppSettings["ProdOwnerPre"]);
                        }

                        job.Watch_File_Win_User = Regex.Replace(job.Watch_File_Win_User, ConfigurationManager.AppSettings["NonProductionOwnerSuffix"], ConfigurationManager.AppSettings["ProductionOwnerSuffix"].ToUpper(), RegexOptions.IgnoreCase);

                        if (job.Watch_File_Win_User.ToLower().Contains("asysactionacct") && !job.Watch_File_Win_User.ToUpper().Contains(ConfigurationManager.AppSettings["ProductionOwnerSuffix"].ToUpper()))
                        {
                            job.Watch_File_Win_User = Regex.Replace(job.Watch_File_Win_User, "AsysActionAcct", "AsysActionAcct@PRO", RegexOptions.IgnoreCase);
                        }
                    }


                    if (!string.IsNullOrEmpty(job.Command))
                    {
                        //job.Command = Regex.Replace(job.Command, ConfigurationManager.AppSettings["DevCommandPath"], ConfigurationManager.AppSettings["DalProdFileStoreRootLocation"], RegexOptions.IgnoreCase);
                        //job.Command = Regex.Replace(job.Command, ConfigurationManager.AppSettings["StageCommandPath"], ConfigurationManager.AppSettings["DalProdFileStoreRootLocation"], RegexOptions.IgnoreCase);
                        //job.Command = Regex.Replace(job.Command, ConfigurationManager.AppSettings["CtCommandPath"], ConfigurationManager.AppSettings["DalProdFileStoreRootLocation"], RegexOptions.IgnoreCase);
                        job.Command = job.Command.Replace(ConfigurationManager.AppSettings["DevCommandPath"].Replace("$$$$", "$$"), ConfigurationManager.AppSettings["DalProdFileStoreRootLocation"]);
                        job.Command = job.Command.Replace(ConfigurationManager.AppSettings["OldDevCommandPath"].Replace("$$$$", "$$"), ConfigurationManager.AppSettings["DalProdFileStoreRootLocation"]);
                        job.Command = job.Command.Replace(ConfigurationManager.AppSettings["StageCommandPath"].Replace("$$$$", "$$"), ConfigurationManager.AppSettings["DalProdFileStoreRootLocation"]);
                        job.Command = job.Command.Replace(ConfigurationManager.AppSettings["CtCommandPath"].Replace("$$$$", "$$"), ConfigurationManager.AppSettings["DalProdFileStoreRootLocation"]);
                        job.Command = job.Command.Replace(ConfigurationManager.AppSettings["DevNASCommandPath"].Replace("$$$$", "$$"), ConfigurationManager.AppSettings["DalProdFileStoreRootLocation"]);
                        job.Command = job.Command.Replace(ConfigurationManager.AppSettings["StageNASCommandPath"].Replace("$$$$", "$$"), ConfigurationManager.AppSettings["DalProdFileStoreRootLocation"]);
                        job.Command = job.Command.Replace(ConfigurationManager.AppSettings["CtNASCommandPath"].Replace("$$$$", "$$"), ConfigurationManager.AppSettings["DalProdFileStoreRootLocation"]);
                        job.Command = Regex.Replace(job.Command, ConfigurationManager.AppSettings["DevOldAsaMachine01"], ConfigurationManager.AppSettings["DalProdFileStoreRootLocation"], RegexOptions.IgnoreCase);
                        job.Command = Regex.Replace(job.Command, ConfigurationManager.AppSettings["DevOldAsaMachine02"], ConfigurationManager.AppSettings["DalProdFileStoreRootLocation"], RegexOptions.IgnoreCase);
                        job.Command = Regex.Replace(job.Command, ConfigurationManager.AppSettings["DevNewAsaMachine01"], ConfigurationManager.AppSettings["DalProdFileStoreRootLocation"], RegexOptions.IgnoreCase);
                        job.Command = Regex.Replace(job.Command, ConfigurationManager.AppSettings["DevNewAsaMachine02"], ConfigurationManager.AppSettings["DalProdFileStoreRootLocation"], RegexOptions.IgnoreCase);
                        job.Command = Regex.Replace(job.Command, ConfigurationManager.AppSettings["StageOldAsaMachine01"], ConfigurationManager.AppSettings["DalProdFileStoreRootLocation"], RegexOptions.IgnoreCase);
                        job.Command = Regex.Replace(job.Command, ConfigurationManager.AppSettings["StageOldAsaMachine02"], ConfigurationManager.AppSettings["DalProdFileStoreRootLocation"], RegexOptions.IgnoreCase);
                        job.Command = Regex.Replace(job.Command, ConfigurationManager.AppSettings["StageNewAsaMachine01"], ConfigurationManager.AppSettings["DalProdFileStoreRootLocation"], RegexOptions.IgnoreCase);
                        job.Command = Regex.Replace(job.Command, ConfigurationManager.AppSettings["StageNewAsaMachine02"], ConfigurationManager.AppSettings["DalProdFileStoreRootLocation"], RegexOptions.IgnoreCase);
                        job.Command = Regex.Replace(job.Command, ConfigurationManager.AppSettings["DevGwyNewAsaMachine01"], ConfigurationManager.AppSettings["DalProdFileStoreRootLocation"], RegexOptions.IgnoreCase);
                        job.Command = Regex.Replace(job.Command, ConfigurationManager.AppSettings["DevGwyNewAsaMachine02"], ConfigurationManager.AppSettings["DalProdFileStoreRootLocation"], RegexOptions.IgnoreCase);
                        job.Command = Regex.Replace(job.Command, ConfigurationManager.AppSettings["StageGwyNewAsaMachine01"], ConfigurationManager.AppSettings["DalProdFileStoreRootLocation"], RegexOptions.IgnoreCase);
                        job.Command = Regex.Replace(job.Command, ConfigurationManager.AppSettings["StageGwyNewAsaMachine02"], ConfigurationManager.AppSettings["DalProdFileStoreRootLocation"], RegexOptions.IgnoreCase);
                        job.Command = Regex.Replace(job.Command, ConfigurationManager.AppSettings["CtGwyNewAsaMachine01"], ConfigurationManager.AppSettings["DalProdFileStoreRootLocation"], RegexOptions.IgnoreCase);
                        job.Command = Regex.Replace(job.Command, ConfigurationManager.AppSettings["CtGwyNewAsaMachine02"], ConfigurationManager.AppSettings["DalProdFileStoreRootLocation"], RegexOptions.IgnoreCase);
                        job.Command = Regex.Replace(job.Command, ConfigurationManager.AppSettings["NonProdFileStoreRootLocation"], ConfigurationManager.AppSettings["DalProdFileStoreRootLocation"], RegexOptions.IgnoreCase);
                        job.Command = Regex.Replace(job.Command, ConfigurationManager.AppSettings["NonProdSchedulerNASMachine"], ConfigurationManager.AppSettings["DalProdFileStoreRootLocation"], RegexOptions.IgnoreCase);
                        job.Command = Regex.Replace(job.Command, ConfigurationManager.AppSettings["OldIncomingFilesPath"], ConfigurationManager.AppSettings["NewIncomingFilesPath"], RegexOptions.IgnoreCase);
                        job.Command = Regex.Replace(job.Command, ConfigurationManager.AppSettings["CtFileNameExtension"], ConfigurationManager.AppSettings["ProdFileNameExtension"], RegexOptions.IgnoreCase);
                        job.Command = Regex.Replace(job.Command, ConfigurationManager.AppSettings["DevFileNameExtension"], ConfigurationManager.AppSettings["ProdFileNameExtension"], RegexOptions.IgnoreCase);
                        job.Command = Regex.Replace(job.Command, ConfigurationManager.AppSettings["StageFileNameExtension"], ConfigurationManager.AppSettings["ProdFileNameExtension"], RegexOptions.IgnoreCase);
                        job.Command = job.Command.Replace("$$$$", "$$");
                        job.Command = job.Command.Replace(StringConstants.DEV_BIS_JOBS_SUBSTRING, StringConstants.PROD_BIS_JOBS_SUBSTRING);
                        job.Command = job.Command.Replace(StringConstants.STAGE_BIS_JOBS_SUBSTRING, StringConstants.PROD_BIS_JOBS_SUBSTRING);
                        job.Command = job.Command.Replace(StringConstants.CT_BIS_JOBS_SUBSTRING, StringConstants.PROD_BIS_JOBS_SUBSTRING);
                    }

                    //adding changes in new attributes similar to command
                    if (!string.IsNullOrEmpty(job.Ftp_Local_Name))
                    {
                        //job.Ftp_Local_Name = Regex.Replace(job.Ftp_Local_Name, ConfigurationManager.AppSettings["DevCommandPath"], ConfigurationManager.AppSettings["DalProdFileStoreRootLocation"], RegexOptions.IgnoreCase);
                        //job.Ftp_Local_Name = Regex.Replace(job.Ftp_Local_Name, ConfigurationManager.AppSettings["StageCommandPath"], ConfigurationManager.AppSettings["DalProdFileStoreRootLocation"], RegexOptions.IgnoreCase);
                        //job.Ftp_Local_Name = Regex.Replace(job.Ftp_Local_Name, ConfigurationManager.AppSettings["CtCommandPath"], ConfigurationManager.AppSettings["DalProdFileStoreRootLocation"], RegexOptions.IgnoreCase);
                        job.Ftp_Local_Name = job.Ftp_Local_Name.Replace(ConfigurationManager.AppSettings["DevCommandPath"].Replace("$$$$", "$$"), ConfigurationManager.AppSettings["DalProdFileStoreRootLocation"]);
                        job.Ftp_Local_Name = job.Ftp_Local_Name.Replace(ConfigurationManager.AppSettings["OldDevCommandPath"].Replace("$$$$", "$$"), ConfigurationManager.AppSettings["DalProdFileStoreRootLocation"]);
                        job.Ftp_Local_Name = job.Ftp_Local_Name.Replace(ConfigurationManager.AppSettings["StageCommandPath"].Replace("$$$$", "$$"), ConfigurationManager.AppSettings["DalProdFileStoreRootLocation"]);
                        job.Ftp_Local_Name = job.Ftp_Local_Name.Replace(ConfigurationManager.AppSettings["CtCommandPath"].Replace("$$$$", "$$"), ConfigurationManager.AppSettings["DalProdFileStoreRootLocation"]);
                        job.Ftp_Local_Name = job.Ftp_Local_Name.Replace(ConfigurationManager.AppSettings["DevNASCommandPath"].Replace("$$$$", "$$"), ConfigurationManager.AppSettings["DalProdFileStoreRootLocation"]);
                        job.Ftp_Local_Name = job.Ftp_Local_Name.Replace(ConfigurationManager.AppSettings["StageNASCommandPath"].Replace("$$$$", "$$"), ConfigurationManager.AppSettings["DalProdFileStoreRootLocation"]);
                        job.Ftp_Local_Name = job.Ftp_Local_Name.Replace(ConfigurationManager.AppSettings["CtNASCommandPath"].Replace("$$$$", "$$"), ConfigurationManager.AppSettings["DalProdFileStoreRootLocation"]);
                        job.Ftp_Local_Name = Regex.Replace(job.Ftp_Local_Name, ConfigurationManager.AppSettings["DevOldAsaMachine01"], ConfigurationManager.AppSettings["DalProdFileStoreRootLocation"], RegexOptions.IgnoreCase);
                        job.Ftp_Local_Name = Regex.Replace(job.Ftp_Local_Name, ConfigurationManager.AppSettings["DevOldAsaMachine02"], ConfigurationManager.AppSettings["DalProdFileStoreRootLocation"], RegexOptions.IgnoreCase);
                        job.Ftp_Local_Name = Regex.Replace(job.Ftp_Local_Name, ConfigurationManager.AppSettings["DevNewAsaMachine01"], ConfigurationManager.AppSettings["DalProdFileStoreRootLocation"], RegexOptions.IgnoreCase);
                        job.Ftp_Local_Name = Regex.Replace(job.Ftp_Local_Name, ConfigurationManager.AppSettings["DevNewAsaMachine02"], ConfigurationManager.AppSettings["DalProdFileStoreRootLocation"], RegexOptions.IgnoreCase);
                        job.Ftp_Local_Name = Regex.Replace(job.Ftp_Local_Name, ConfigurationManager.AppSettings["StageOldAsaMachine01"], ConfigurationManager.AppSettings["DalProdFileStoreRootLocation"], RegexOptions.IgnoreCase);
                        job.Ftp_Local_Name = Regex.Replace(job.Ftp_Local_Name, ConfigurationManager.AppSettings["StageOldAsaMachine02"], ConfigurationManager.AppSettings["DalProdFileStoreRootLocation"], RegexOptions.IgnoreCase);
                        job.Ftp_Local_Name = Regex.Replace(job.Ftp_Local_Name, ConfigurationManager.AppSettings["StageNewAsaMachine01"], ConfigurationManager.AppSettings["DalProdFileStoreRootLocation"], RegexOptions.IgnoreCase);
                        job.Ftp_Local_Name = Regex.Replace(job.Ftp_Local_Name, ConfigurationManager.AppSettings["StageNewAsaMachine02"], ConfigurationManager.AppSettings["DalProdFileStoreRootLocation"], RegexOptions.IgnoreCase);
                        job.Ftp_Local_Name = Regex.Replace(job.Ftp_Local_Name, ConfigurationManager.AppSettings["DevGwyNewAsaMachine01"], ConfigurationManager.AppSettings["DalProdFileStoreRootLocation"], RegexOptions.IgnoreCase);
                        job.Ftp_Local_Name = Regex.Replace(job.Ftp_Local_Name, ConfigurationManager.AppSettings["DevGwyNewAsaMachine02"], ConfigurationManager.AppSettings["DalProdFileStoreRootLocation"], RegexOptions.IgnoreCase);
                        job.Ftp_Local_Name = Regex.Replace(job.Ftp_Local_Name, ConfigurationManager.AppSettings["StageGwyNewAsaMachine01"], ConfigurationManager.AppSettings["DalProdFileStoreRootLocation"], RegexOptions.IgnoreCase);
                        job.Ftp_Local_Name = Regex.Replace(job.Ftp_Local_Name, ConfigurationManager.AppSettings["StageGwyNewAsaMachine02"], ConfigurationManager.AppSettings["DalProdFileStoreRootLocation"], RegexOptions.IgnoreCase);
                        job.Ftp_Local_Name = Regex.Replace(job.Ftp_Local_Name, ConfigurationManager.AppSettings["CtGwyNewAsaMachine01"], ConfigurationManager.AppSettings["DalProdFileStoreRootLocation"], RegexOptions.IgnoreCase);
                        job.Ftp_Local_Name = Regex.Replace(job.Ftp_Local_Name, ConfigurationManager.AppSettings["CtGwyNewAsaMachine02"], ConfigurationManager.AppSettings["DalProdFileStoreRootLocation"], RegexOptions.IgnoreCase);
                        job.Ftp_Local_Name = Regex.Replace(job.Ftp_Local_Name, ConfigurationManager.AppSettings["NonProdFileStoreRootLocation"], ConfigurationManager.AppSettings["DalProdFileStoreRootLocation"], RegexOptions.IgnoreCase);
                        job.Ftp_Local_Name = Regex.Replace(job.Ftp_Local_Name, ConfigurationManager.AppSettings["NonProdSchedulerNASMachine"], ConfigurationManager.AppSettings["DalProdFileStoreRootLocation"], RegexOptions.IgnoreCase);
                        job.Ftp_Local_Name = Regex.Replace(job.Ftp_Local_Name, ConfigurationManager.AppSettings["OldIncomingFilesPath"], ConfigurationManager.AppSettings["NewIncomingFilesPath"], RegexOptions.IgnoreCase);
                        job.Ftp_Local_Name = Regex.Replace(job.Ftp_Local_Name, ConfigurationManager.AppSettings["CtFileNameExtension"], ConfigurationManager.AppSettings["ProdFileNameExtension"], RegexOptions.IgnoreCase);
                        job.Ftp_Local_Name = Regex.Replace(job.Ftp_Local_Name, ConfigurationManager.AppSettings["DevFileNameExtension"], ConfigurationManager.AppSettings["ProdFileNameExtension"], RegexOptions.IgnoreCase);
                        job.Ftp_Local_Name = Regex.Replace(job.Ftp_Local_Name, ConfigurationManager.AppSettings["StageFileNameExtension"], ConfigurationManager.AppSettings["ProdFileNameExtension"], RegexOptions.IgnoreCase);
                        job.Ftp_Local_Name = job.Ftp_Local_Name.Replace("$$$$", "$$");
                    }

                    if (!string.IsNullOrEmpty(job.Watch_File))
                    {
                        //job.Watch_File = Regex.Replace(job.Watch_File, ConfigurationManager.AppSettings["DevCommandPath"], ConfigurationManager.AppSettings["DalProdFileStoreRootLocation"], RegexOptions.IgnoreCase);
                        //job.Watch_File = Regex.Replace(job.Watch_File, ConfigurationManager.AppSettings["StageCommandPath"], ConfigurationManager.AppSettings["DalProdFileStoreRootLocation"], RegexOptions.IgnoreCase);
                        //job.Watch_File = Regex.Replace(job.Watch_File, ConfigurationManager.AppSettings["CtCommandPath"], ConfigurationManager.AppSettings["DalProdFileStoreRootLocation"], RegexOptions.IgnoreCase);
                        job.Watch_File = job.Watch_File.Replace(ConfigurationManager.AppSettings["DevCommandPath"].Replace("$$$$", "$$"), ConfigurationManager.AppSettings["DalProdFileStoreRootLocation"]);
                        job.Watch_File = job.Watch_File.Replace(ConfigurationManager.AppSettings["OldDevCommandPath"].Replace("$$$$", "$$"), ConfigurationManager.AppSettings["DalProdFileStoreRootLocation"]);
                        job.Watch_File = job.Watch_File.Replace(ConfigurationManager.AppSettings["StageCommandPath"].Replace("$$$$", "$$"), ConfigurationManager.AppSettings["DalProdFileStoreRootLocation"]);
                        job.Watch_File = job.Watch_File.Replace(ConfigurationManager.AppSettings["CtCommandPath"].Replace("$$$$", "$$"), ConfigurationManager.AppSettings["DalProdFileStoreRootLocation"]);
                        job.Watch_File = job.Watch_File.Replace(ConfigurationManager.AppSettings["DevNASCommandPath"].Replace("$$$$", "$$"), ConfigurationManager.AppSettings["DalProdFileStoreRootLocation"]);
                        job.Watch_File = job.Watch_File.Replace(ConfigurationManager.AppSettings["StageNASCommandPath"].Replace("$$$$", "$$"), ConfigurationManager.AppSettings["DalProdFileStoreRootLocation"]);
                        job.Watch_File = job.Watch_File.Replace(ConfigurationManager.AppSettings["CtNASCommandPath"].Replace("$$$$", "$$"), ConfigurationManager.AppSettings["DalProdFileStoreRootLocation"]);
                        job.Watch_File = Regex.Replace(job.Watch_File, ConfigurationManager.AppSettings["DevOldAsaMachine01"], ConfigurationManager.AppSettings["DalProdFileStoreRootLocation"], RegexOptions.IgnoreCase);
                        job.Watch_File = Regex.Replace(job.Watch_File, ConfigurationManager.AppSettings["DevOldAsaMachine02"], ConfigurationManager.AppSettings["DalProdFileStoreRootLocation"], RegexOptions.IgnoreCase);
                        job.Watch_File = Regex.Replace(job.Watch_File, ConfigurationManager.AppSettings["DevNewAsaMachine01"], ConfigurationManager.AppSettings["DalProdFileStoreRootLocation"], RegexOptions.IgnoreCase);
                        job.Watch_File = Regex.Replace(job.Watch_File, ConfigurationManager.AppSettings["DevNewAsaMachine02"], ConfigurationManager.AppSettings["DalProdFileStoreRootLocation"], RegexOptions.IgnoreCase);
                        job.Watch_File = Regex.Replace(job.Watch_File, ConfigurationManager.AppSettings["StageOldAsaMachine01"], ConfigurationManager.AppSettings["DalProdFileStoreRootLocation"], RegexOptions.IgnoreCase);
                        job.Watch_File = Regex.Replace(job.Watch_File, ConfigurationManager.AppSettings["StageOldAsaMachine02"], ConfigurationManager.AppSettings["DalProdFileStoreRootLocation"], RegexOptions.IgnoreCase);
                        job.Watch_File = Regex.Replace(job.Watch_File, ConfigurationManager.AppSettings["StageNewAsaMachine01"], ConfigurationManager.AppSettings["DalProdFileStoreRootLocation"], RegexOptions.IgnoreCase);
                        job.Watch_File = Regex.Replace(job.Watch_File, ConfigurationManager.AppSettings["StageNewAsaMachine02"], ConfigurationManager.AppSettings["DalProdFileStoreRootLocation"], RegexOptions.IgnoreCase);
                        job.Watch_File = Regex.Replace(job.Watch_File, ConfigurationManager.AppSettings["DevGwyNewAsaMachine01"], ConfigurationManager.AppSettings["DalProdFileStoreRootLocation"], RegexOptions.IgnoreCase);
                        job.Watch_File = Regex.Replace(job.Watch_File, ConfigurationManager.AppSettings["DevGwyNewAsaMachine02"], ConfigurationManager.AppSettings["DalProdFileStoreRootLocation"], RegexOptions.IgnoreCase);
                        job.Watch_File = Regex.Replace(job.Watch_File, ConfigurationManager.AppSettings["StageGwyNewAsaMachine01"], ConfigurationManager.AppSettings["DalProdFileStoreRootLocation"], RegexOptions.IgnoreCase);
                        job.Watch_File = Regex.Replace(job.Watch_File, ConfigurationManager.AppSettings["StageGwyNewAsaMachine02"], ConfigurationManager.AppSettings["DalProdFileStoreRootLocation"], RegexOptions.IgnoreCase);
                        job.Watch_File = Regex.Replace(job.Watch_File, ConfigurationManager.AppSettings["CtGwyNewAsaMachine01"], ConfigurationManager.AppSettings["DalProdFileStoreRootLocation"], RegexOptions.IgnoreCase);
                        job.Watch_File = Regex.Replace(job.Watch_File, ConfigurationManager.AppSettings["CtGwyNewAsaMachine02"], ConfigurationManager.AppSettings["DalProdFileStoreRootLocation"], RegexOptions.IgnoreCase);
                        job.Watch_File = Regex.Replace(job.Watch_File, ConfigurationManager.AppSettings["NonProdFileStoreRootLocation"], ConfigurationManager.AppSettings["DalProdFileStoreRootLocation"], RegexOptions.IgnoreCase);
                        job.Watch_File = Regex.Replace(job.Watch_File, ConfigurationManager.AppSettings["NonProdSchedulerNASMachine"], ConfigurationManager.AppSettings["DalProdFileStoreRootLocation"], RegexOptions.IgnoreCase);
                        job.Watch_File = Regex.Replace(job.Watch_File, ConfigurationManager.AppSettings["OldIncomingFilesPath"], ConfigurationManager.AppSettings["NewIncomingFilesPath"], RegexOptions.IgnoreCase);
                        job.Watch_File = Regex.Replace(job.Watch_File, ConfigurationManager.AppSettings["CtFileNameExtension"], ConfigurationManager.AppSettings["ProdFileNameExtension"], RegexOptions.IgnoreCase);
                        job.Watch_File = Regex.Replace(job.Watch_File, ConfigurationManager.AppSettings["DevFileNameExtension"], ConfigurationManager.AppSettings["ProdFileNameExtension"], RegexOptions.IgnoreCase);
                        job.Watch_File = Regex.Replace(job.Watch_File, ConfigurationManager.AppSettings["StageFileNameExtension"], ConfigurationManager.AppSettings["ProdFileNameExtension"], RegexOptions.IgnoreCase);
                        job.Watch_File = job.Watch_File.Replace("$$$$", "$$");
                    }
                }
            }

            return listOfJobs;
        }


        [HttpGet]
        public JsonResult GetCustomJobsUpdateCount(string billerName, string ID, bool devCheckBoxValue, bool stageCheckBoxValue, bool ctCheckBoxValue, bool prodCheckBoxValue,
            bool asaCheckBoxValue, bool gwyCheckBoxValue, bool schedulerCheckBoxValue, bool localHostCheckBoxValue)
        {
            int count = 0;
            if (!string.IsNullOrEmpty(billerName))
            {
                billerName = billerName.ToLower();
                isAsaServerAdded = false; isGwyServerAdded = false; isSchedulerServerAdded = false; isLocalHostServerAdded = false;
                Session[ID + "ASAServerAdded"] = null; Session[ID + "GWYServerAdded"] = null; Session[ID + "SCHEDULERServerAdded"] = null;
                Session[ID + "LOCALHOSTServerAdded"] = null;
                List<FilteredJobs> listOfCustomJobsUpdate = new List<FilteredJobs>();
                if (Session[ID + "DevJobsToUpdate"] != null)
                    listOfDevJobsToUpdate = JsonConvert.DeserializeObject<List<FilteredJobs>>((string)Session[ID + "DevJobsToUpdate"]);
                if (Session[ID + "StageJobsToUpdate"] != null)
                    listOfStageJobsToUpdate = JsonConvert.DeserializeObject<List<FilteredJobs>>((string)Session[ID + "StageJobsToUpdate"]);
                if (Session[ID + "CtJobsToUpdate"] != null)
                    listOfCtJobsToUpdate = JsonConvert.DeserializeObject<List<FilteredJobs>>((string)Session[ID + "CtJobsToUpdate"]);
                if (Session[ID + "ProdJobsToUpdate"] != null)
                    listOfProdJobsToUpdate = JsonConvert.DeserializeObject<List<FilteredJobs>>((string)Session[ID + "ProdJobsToUpdate"]);

                if (devCheckBoxValue)
                {
                    listOfCustomJobsUpdate.AddRange((from x in listOfDevJobsToUpdate where x.Insert_job.ToLower().Contains(billerName) select x).ToList<FilteredJobs>());
                }
                if (stageCheckBoxValue)
                {
                    listOfCustomJobsUpdate.AddRange((from x in listOfStageJobsToUpdate where x.Insert_job.ToLower().Contains(billerName) select x).ToList<FilteredJobs>());
                }
                if (ctCheckBoxValue)
                {
                    listOfCustomJobsUpdate.AddRange((from x in listOfCtJobsToUpdate where x.Insert_job.ToLower().Contains(billerName) select x).ToList<FilteredJobs>());
                }
                if (prodCheckBoxValue)
                {
                    listOfCustomJobsUpdate.AddRange((from x in listOfProdJobsToUpdate where x.Insert_job.ToLower().Contains(billerName) select x).ToList<FilteredJobs>());
                }
                if (!devCheckBoxValue && !stageCheckBoxValue && !ctCheckBoxValue && !prodCheckBoxValue)
                {
                    List<FilteredJobs> listOfAllRegionJobs = new List<FilteredJobs>();
                    listOfAllRegionJobs.AddRange((from x in listOfDevJobsToUpdate where x.Insert_job.ToLower().Contains(billerName) select x).ToList<FilteredJobs>());
                    listOfAllRegionJobs.AddRange((from x in listOfStageJobsToUpdate where x.Insert_job.ToLower().Contains(billerName) select x).ToList<FilteredJobs>());
                    listOfAllRegionJobs.AddRange((from x in listOfCtJobsToUpdate where x.Insert_job.ToLower().Contains(billerName) select x).ToList<FilteredJobs>());
                    listOfAllRegionJobs.AddRange((from x in listOfProdJobsToUpdate where x.Insert_job.ToLower().Contains(billerName) select x).ToList<FilteredJobs>());

                    listOfCustomJobsUpdate.Clear();
                    listOfCustomJobsUpdate = listOfAllRegionJobs;
                }

                List<FilteredJobs> listOfServerTypeJobs = new List<FilteredJobs>();
                if (asaCheckBoxValue)
                {
                    listOfServerTypeJobs.AddRange((from x in listOfCustomJobsUpdate
                                                   where !string.IsNullOrEmpty(x.Machine)
                                                       && !x.Machine.ToLower().Contains(ConfigurationManager.AppSettings["LocalHostMachineName"])
                                                       && !x.Machine.ToLower().Contains("gwy")
                                                       && !x.Machine.ToLower().Contains(ConfigurationManager.AppSettings["NonProdSchedulerMachineName"])
                                                       && !x.Machine.ToLower().Contains("processor_settlement")
                                                   select x).ToList<FilteredJobs>());
                    isAsaServerAdded = true;
                    Session[ID + "ASAServerAdded"] = isAsaServerAdded;
                }
                if (gwyCheckBoxValue)
                {
                    listOfServerTypeJobs.AddRange((from x in listOfCustomJobsUpdate
                                                   where !string.IsNullOrEmpty(x.Machine)
                                                       && (x.Machine.ToLower().Contains("gwy")
                                                       || x.Machine.ToLower().Contains("processor_settlement"))
                                                   select x).ToList<FilteredJobs>());
                    isGwyServerAdded = true;
                    Session[ID + "GWYServerAdded"] = isGwyServerAdded;
                }
                if (schedulerCheckBoxValue)
                {
                    listOfServerTypeJobs.AddRange((from x in listOfCustomJobsUpdate
                                                   where !string.IsNullOrEmpty(x.Machine)
                                                       && x.Machine.ToLower().Contains(ConfigurationManager.AppSettings["NonProdSchedulerMachineName"])
                                                   select x).ToList<FilteredJobs>());
                    isSchedulerServerAdded = true;
                    Session[ID + "SCHEDULERServerAdded"] = isSchedulerServerAdded;
                }
                if (localHostCheckBoxValue)
                {
                    listOfServerTypeJobs.AddRange((from x in listOfCustomJobsUpdate
                                                   where !string.IsNullOrEmpty(x.Machine)
                                                       && x.Machine.ToLower().Contains(ConfigurationManager.AppSettings["LocalHostMachineName"])
                                                   select x).ToList<FilteredJobs>());
                    isLocalHostServerAdded = true;
                    Session[ID + "LOCALHOSTServerAdded"] = isLocalHostServerAdded;
                }

                if (isAsaServerAdded || isGwyServerAdded || isSchedulerServerAdded || isLocalHostServerAdded)
                {
                    listOfCustomJobsUpdate.Clear();
                    listOfCustomJobsUpdate = listOfServerTypeJobs;
                }

                count = (from x in listOfCustomJobsUpdate where x.Insert_job.ToLower().Contains(billerName) select x).ToList<FilteredJobs>().Count;
                return Json(new { success = count }, JsonRequestBehavior.AllowGet);
            }
            else
            {
                return Json(new { success = 0 }, JsonRequestBehavior.AllowGet);
            }


        }

        [HttpGet]
        public JsonResult GetJobsForDownload(bool devCheckBoxValue, bool stageCheckBoxValue, bool ctCheckBoxValue, bool prodCheckBoxValue, string billerList, string ID,
            bool asaCheckBoxValue, bool gwyCheckBoxValue, bool schedulerCheckBoxValue, bool localHostCheckBoxValue)
        {
            DownloadOption(devCheckBoxValue, stageCheckBoxValue, ctCheckBoxValue, prodCheckBoxValue, billerList, ID, asaCheckBoxValue, gwyCheckBoxValue, schedulerCheckBoxValue, localHostCheckBoxValue);
            List<FilteredJobs> listOfJobsPresent = Session[ID + "ListOfJobs"] as List<FilteredJobs>;
            if (listOfJobsPresent != null && listOfJobsPresent.Count > 0)
                return Json(new { success = "success" }, JsonRequestBehavior.AllowGet);
            else
                return Json(new { success = "failure" }, JsonRequestBehavior.AllowGet);
        }

        [HttpGet]
        public FileResult DownloadOldJilFile(string ID)
        {
            List<FilteredJobs> listOfJobsPresent = Session[ID + "ListOfJobs"] as List<FilteredJobs>;
            if (Session[ID + "DevJobsAdded"] != null)
                isDevJobsAdded = (bool)Session[ID + "DevJobsAdded"];
            if (Session[ID + "StageJobsAdded"] != null)
                isStageJobsAdded = (bool)Session[ID + "StageJobsAdded"];
            if (Session[ID + "CtJobsAdded"] != null)
                isCtJobsAdded = (bool)Session[ID + "CtJobsAdded"];
            if (Session[ID + "ProdJobsAdded"] != null)
                isProdJobsAdded = (bool)Session[ID + "ProdJobsAdded"];

            if (Session[ID + "ASAServerAdded"] != null)
                isAsaServerAdded = (bool)Session[ID + "ASAServerAdded"];
            if (Session[ID + "GWYServerAdded"] != null)
                isGwyServerAdded = (bool)Session[ID + "GWYServerAdded"];
            if (Session[ID + "SCHEDULERServerAdded"] != null)
                isSchedulerServerAdded = (bool)Session[ID + "SCHEDULERServerAdded"];
            if (Session[ID + "LOCALHOSTServerAdded"] != null)
                isLocalHostServerAdded = (bool)Session[ID + "LOCALHOSTServerAdded"];

            if (isDevJobsAdded)
            {
                fileName += "Dev_";
            }
            if (isStageJobsAdded)
            {
                fileName += "Stage_";
            }
            if (isCtJobsAdded)
            {
                fileName += "CT_";
            }
            if (isProdJobsAdded)
            {
                fileName += "Prod_";
            }
            if (!isDevJobsAdded && !isStageJobsAdded && !isCtJobsAdded && !isProdJobsAdded)
            {
                fileName += "AllRegions_";
            }
            if (isAsaServerAdded)
            {
                fileName += "ASA_";
            }
            if (isGwyServerAdded)
            {
                fileName += "GWY_";
            }
            if (isSchedulerServerAdded)
            {
                fileName += "SCHEDULER_";
            }
            if (isLocalHostServerAdded)
            {
                fileName += "LOCALHOST_";
            }

            fileName += "Download.jil";
            FileOperations fileObj = new FileOperations();
            foreach (var file in IO.Directory.GetFiles(IO.Path.GetTempPath()))
            {
                if (file.ToLower().Contains("download"))
                    IO.File.Delete(file);
            }

            //Session[ID + "WrongNamingFileName"] = fileName;
            fileObj.PrintDataToOutputFile(listOfJobsPresent, IO.Path.Combine(IO.Path.GetTempPath(), fileName));
            if (IO.File.Exists(IO.Path.Combine(IO.Path.GetTempPath(), fileName)) && IO.File.ReadAllBytes(IO.Path.Combine(IO.Path.GetTempPath(), fileName)).Length > 0)
            {
                return File(IO.Path.Combine(IO.Path.GetTempPath(), fileName), StringConstants.FILE_TYPE, fileName);
            }
            else
                return null;
        }

        [HttpGet]
        public void DownloadOption(bool devCheckBoxValue, bool stageCheckBoxValue, bool ctCheckBoxValue, bool prodCheckBoxValue, string billerList, string ID,
            bool asaCheckBoxValue, bool gwyCheckBoxValue, bool schedulerCheckBoxValue, bool localHostCheckBoxValue)
        {

            if (Session[ID + "DevJobsToUpdate"] != null)
            {
                //listOfDevJobsToUpdate = Session[ID + "DevJobsToUpdate"] as List<FilteredJobs>;
                listOfDevJobsToUpdate = JsonConvert.DeserializeObject<List<FilteredJobs>>((string)Session[ID + "DevJobsToUpdate"]);
            }
            if (Session[ID + "StageJobsToUpdate"] != null)
            {
                //listOfStageJobsToUpdate = Session[ID + "StageJobsToUpdate"] as List<FilteredJobs>;
                listOfStageJobsToUpdate = JsonConvert.DeserializeObject<List<FilteredJobs>>((string)Session[ID + "StageJobsToUpdate"]);
            }
            if (Session[ID + "CtJobsToUpdate"] != null)
            {
                //listOfCtJobsToUpdate = Session[ID + "CtJobsToUpdate"] as List<FilteredJobs>;
                listOfCtJobsToUpdate = JsonConvert.DeserializeObject<List<FilteredJobs>>((string)Session[ID + "CtJobsToUpdate"]);
            }

            if (Session[ID + "ProdJobsToUpdate"] != null)
            {
                //listOfProdJobsToUpdate = Session[ID + "ProdJobsToUpdate"] as List<FilteredJobs>;
                listOfProdJobsToUpdate = JsonConvert.DeserializeObject<List<FilteredJobs>>((string)Session[ID + "ProdJobsToUpdate"]);
            }

            List<string> listOfBillers = new List<string>();
            if (!string.IsNullOrEmpty(billerList) && !billerList.Contains("custom:"))
                listOfBillers = billerList.TrimEnd(new char[] { StringConstants.SEMICOLON }).Split(StringConstants.SEMICOLON).ToList<string>();
            else
            {
                if (billerList.Contains("custom:"))
                {
                    listOfBillers.Add(billerList.Split(new string[] { "custom:" }, StringSplitOptions.None).Last().Trim().ToLower());
                }
            }

            isDevJobsAdded = false; isStageJobsAdded = false; isCtJobsAdded = false; isProdJobsAdded = false;
            isJilCreated = false;
            fileName = string.Empty;
            listOfJobs.Clear();
            Session[ID + "StageJobsAdded"] = null; Session[ID + "DevJobsAdded"] = null; Session[ID + "CtJobsAdded"] = null; Session[ID + "ProdJobsAdded"] = null;
            Session[ID + "FileName"] = null; Session[ID + "ASAServerAdded"] = null; Session[ID + "GWYServerAdded"] = null; Session[ID + "SCHEDULERServerAdded"] = null;
            Session[ID + "LOCALHOSTServerAdded"] = null;
            if (devCheckBoxValue && !isDevJobsAdded)
            {
                if (listOfBillers.Count > 0)
                {
                    foreach (string biller in listOfBillers)
                    {
                        listOfJobs.AddRange((from x in listOfDevJobsToUpdate where x.Insert_job.Contains(biller) select x).ToList<FilteredJobs>());
                    }
                }
                else
                    listOfJobs.AddRange(listOfDevJobsToUpdate);

                isDevJobsAdded = true;
                Session[ID + "DevJobsAdded"] = isDevJobsAdded;
            }
            if (stageCheckBoxValue && !isStageJobsAdded)
            {
                if (listOfBillers.Count > 0)
                {
                    foreach (string biller in listOfBillers)
                    {
                        listOfJobs.AddRange((from x in listOfStageJobsToUpdate where x.Insert_job.Contains(biller) select x).ToList<FilteredJobs>());
                    }
                }
                else
                    listOfJobs.AddRange(listOfStageJobsToUpdate);

                isStageJobsAdded = true;
                Session[ID + "StageJobsAdded"] = isStageJobsAdded;
            }
            if (ctCheckBoxValue && !isCtJobsAdded)
            {
                if (listOfBillers.Count > 0)
                {
                    foreach (string biller in listOfBillers)
                    {
                        listOfJobs.AddRange((from x in listOfCtJobsToUpdate where x.Insert_job.Contains(biller) select x).ToList<FilteredJobs>());
                    }
                }
                else
                    listOfJobs.AddRange(listOfCtJobsToUpdate);

                isCtJobsAdded = true;
                Session[ID + "CtJobsAdded"] = isCtJobsAdded;
            }
            if (prodCheckBoxValue && !isProdJobsAdded)
            {
                if (listOfBillers.Count > 0)
                {
                    foreach (string biller in listOfBillers)
                    {
                        listOfJobs.AddRange((from x in listOfProdJobsToUpdate where x.Insert_job.Contains(biller) select x).ToList<FilteredJobs>());
                    }
                }
                else
                    listOfJobs.AddRange(listOfProdJobsToUpdate);

                isProdJobsAdded = true;
                Session[ID + "ProdJobsAdded"] = isProdJobsAdded;
            }

            if (!devCheckBoxValue && !stageCheckBoxValue && !ctCheckBoxValue && !prodCheckBoxValue)
            {
                listOfJobs.AddRange(listOfDevJobsToUpdate); listOfJobs.AddRange(listOfStageJobsToUpdate);
                listOfJobs.AddRange(listOfCtJobsToUpdate);
                listOfJobs.AddRange(listOfProdJobsToUpdate);
                if (Session[ID + "OtherJobs"] != null)
                {
                    listOfJobs.AddRange(JsonConvert.DeserializeObject<List<FilteredJobs>>((string)Session[ID + "OtherJobs"]));
                }
                if (listOfBillers.Count > 0)
                {
                    List<FilteredJobs> listOfJobsBillerWise = new List<FilteredJobs>();
                    foreach (string biller in listOfBillers)
                    {
                        listOfJobsBillerWise.AddRange((from x in listOfJobs where x.Insert_job.Contains(biller) select x).ToList<FilteredJobs>());
                    }

                    listOfJobs.Clear();
                    listOfJobs = listOfJobsBillerWise;
                }
            }

            List<FilteredJobs> listOfServerTypeJobs = new List<FilteredJobs>();
            if (asaCheckBoxValue)
            {
                listOfServerTypeJobs.AddRange((from x in listOfJobs
                                               where !string.IsNullOrEmpty(x.Machine)
                                                   && !x.Machine.ToLower().Contains(ConfigurationManager.AppSettings["LocalHostMachineName"])
                                                   && !x.Machine.ToLower().Contains("gwy")
                                                   && !x.Machine.ToLower().Contains(ConfigurationManager.AppSettings["NonProdSchedulerMachineName"])
                                                   && !x.Machine.ToLower().Contains("processor_settlement")
                                               select x).ToList<FilteredJobs>());
                isAsaServerAdded = true;
                Session[ID + "ASAServerAdded"] = isAsaServerAdded;
            }
            if (gwyCheckBoxValue)
            {
                listOfServerTypeJobs.AddRange((from x in listOfJobs
                                               where !string.IsNullOrEmpty(x.Machine)
                                                   && (x.Machine.ToLower().Contains("gwy")
                                                   || x.Machine.ToLower().Contains("processor_settlement"))
                                               select x).ToList<FilteredJobs>());
                isGwyServerAdded = true;
                Session[ID + "GWYServerAdded"] = isGwyServerAdded;
            }
            if (schedulerCheckBoxValue)
            {
                listOfServerTypeJobs.AddRange((from x in listOfJobs
                                               where !string.IsNullOrEmpty(x.Machine)
                                                   && x.Machine.ToLower().Contains(ConfigurationManager.AppSettings["NonProdSchedulerMachineName"])
                                               select x).ToList<FilteredJobs>());
                isSchedulerServerAdded = true;
                Session[ID + "SCHEDULERServerAdded"] = isSchedulerServerAdded;
            }
            if (localHostCheckBoxValue)
            {
                listOfServerTypeJobs.AddRange((from x in listOfJobs
                                               where !string.IsNullOrEmpty(x.Machine)
                                                   && x.Machine.ToLower().Contains(ConfigurationManager.AppSettings["LocalHostMachineName"])
                                               select x).ToList<FilteredJobs>());
                isLocalHostServerAdded = true;
                Session[ID + "LOCALHOSTServerAdded"] = isLocalHostServerAdded;
            }

            if ((asaCheckBoxValue || gwyCheckBoxValue || schedulerCheckBoxValue || localHostCheckBoxValue))
            {
                listOfJobs.Clear();
                listOfJobs = listOfServerTypeJobs;
            }

            Session[ID + "ListOfJobs"] = listOfJobs.Distinct().ToList<FilteredJobs>();
        }



        [HttpGet]
        public FileResult GetUpdatedFile(string ID)
        {
            fileName = (string)Session[ID + "FileName"];
            if (IO.File.Exists(IO.Path.Combine(IO.Path.GetTempPath(), fileName)) && IO.File.ReadAllBytes(IO.Path.Combine(IO.Path.GetTempPath(), fileName)).Length > 0)
            {
                return File(IO.Path.Combine(IO.Path.GetTempPath(), fileName), StringConstants.FILE_TYPE, fileName);
            }
            else
                return null;
        }

        [HttpPost]
        public JsonResult UpdateJil(string ID)
        {
            bool isJilCreationSuccess = false;
            if (!isJilCreated)
            {
                isJilCreationSuccess = CreateNewJil(ID);
                isJilCreated = true;
            }

            if (isJilCreationSuccess)
                return Json(new { success = "success" }, JsonRequestBehavior.AllowGet);
            else
                return Json(new { success = "failure" }, JsonRequestBehavior.AllowGet);
        }

        [HttpPost]
        public ActionResult Index(HttpPostedFileBase hpf, string txtJILPath, string SessionID)
        {
            try
            {
                List<string> listOfBillers = new List<string>();
                if (hpf != null)
                {
                    string filePath = IO.Path.Combine(IO.Path.GetTempPath(), hpf.FileName);
                    if (IO.File.Exists(filePath))
                        IO.File.Delete(filePath);
                    hpf.SaveAs(filePath);
                    listOfBillers = GetListOfJobsFromJil(filePath, SessionID);
                    IO.File.Delete(filePath);
                }
                else
                {
                    listOfBillers = GetListOfJobsFromJil(txtJILPath, SessionID);
                }

                listOfJobs.Clear();
                listOfBillers.Sort();
                if (hpf != null)
                    ViewBag.FileNameSelected = "File Name:  " + hpf.FileName;
                else
                    ViewBag.FileNameSelected = "File Name:  " + IO.Path.GetFileName(txtJILPath);
                return View(listOfBillers);
            }
            catch (Exception ex)
            {
                return View("Error");
            }
        }

        private List<FilteredJobs> AnalyseJilForUpdates(List<FilteredJobs> listOfJobsFromJil, string ID)
        {
            int devTotalJobCount = 0, stageTotalJobCount = 0, ctTotalJobCount = 0, prodTotalJobCount = 0;
            int devMachineNameUpdateCount = 0, stageMachineNameUpdateCount = 0, ctMachineNameUpdateCount = 0, prodMachineNameUpdateCount = 0;
            int devPermissionUpdateCount = 0, stagePermissionUpdateCount = 0, ctPermissionUpdateCount = 0, prodPermissionUpdateCount = 0;
            int devStdOutFilePathCount = 0, stageStdOutFilePathCount = 0, ctStdOutFilePathCount = 0, prodStdOutFilePathCount = 0;
            int devStdErrFilePathCount = 0, stageStdErrFilePathCount = 0, ctStdErrFilePathCount = 0, prodStdErrFilePathCount = 0;
            int devCommandUpdateCount = 0, stageCommandUpdateCount = 0, ctCommandUpdateCount = 0, prodCommandUpdateCount = 0;
            int devOwnerUpdateCount = 0, stageOwnerUpdateCount = 0, ctOwnerUpdateCount = 0, prodOwnerUpdateCount = 0;
            int devApplicationUpdateCount = 0, stageApplicationUpdateCount = 0, ctApplicationUpdateCount = 0, prodApplicationUpdateCount = 0;
            int devDescriptionCount = 0, stageDescriptionCount = 0, ctDescriptionCount = 0, prodDescriptionCount = 0;

            int devBslInsertJobsCount = 0, stageBslInsertJobsCount = 0, ctBslInsertJobsCount = 0, prodBslInsertJobsCount = 0;
            int devBslBoxNamesCount = 0, stageBslBoxNamesCount = 0, ctBslBoxNamesCount = 0, prodBslBoxNamesCount = 0;
            int devBslConditionJobCount = 0, stageBslConditionJobCount = 0, ctBslConditionJobCount = 0, prodBslConditionJobCount = 0;

            int devUpperCaseInsertJobsCount = 0, stageUpperCaseInsertJobsCount = 0, ctUpperCaseInsertJobsCount = 0, prodUpperCaseInsertJobsCount = 0;
            int devUpperCaseBoxNamesCount = 0, stageUpperCaseBoxNamesCount = 0, ctUpperCaseBoxNamesCount = 0, prodUpperCaseBoxNamesCount = 0;
            int devUpperCaseConditionJobCount = 0, stageUpperCaseConditionJobCount = 0, ctUpperCaseConditionJobCount = 0, prodUpperCaseConditionJobCount = 0;

            int devBoxSuccessUpperCaseCount = 0, stageBoxSuccessUpperCaseCount = 0, ctBoxSuccessUpperCaseCount = 0, prodBoxSuccessUpperCaseCount = 0;
            int devBoxSuccessBslConditionCount = 0, stageBoxSuccessBslConditionCount = 0, ctBoxSuccessBslConditionCount = 0, prodBoxSuccessBslConditionCount = 0;
            int devBoxFailureUpperCaseCount = 0, stageBoxFailureUpperCaseCount = 0, ctBoxFailureUpperCaseCount = 0, prodBoxFailureUpperCaseCount = 0;
            int devBoxFailureBslConditionCount = 0, stageBoxFailureBslConditionCount = 0, ctBoxFailureBslConditionCount = 0, prodBoxFailureBslConditionCount = 0;

            int devGroupUpdateCount = 0, stageGroupUpdateCount = 0, ctGroupUpdateCount = 0, prodGroupUpdateCount = 0;
            bool isJobNeedsToBeUpdated = false;
            List<FilteredJobs> listOfJobsToBeUpdated = new List<FilteredJobs>();
            //List<FilteredJobs> listOfDevJobs = (from x in listOfJobsFromJil where x.Insert_job.Trim().Split(StringConstants.SPLIT_WITH_COLON)[1].Trim().Split(StringConstants.SPLIT_WITH_SPACE)[0].Trim().ToLower().StartsWith(StringConstants.DEV_BSL_JOBS_SUBSTRING) || x.Insert_job.Trim().Split(StringConstants.SPLIT_WITH_COLON)[1].Trim().Split(StringConstants.SPLIT_WITH_SPACE)[0].Trim().ToLower().StartsWith(StringConstants.DEV_BIS_JOBS_SUBSTRING) select x).ToList<FilteredJobs>();
            List<FilteredJobs> listOfDevJobs = (from x in listOfJobsFromJil where x.Insert_job.ToLower().Contains(StringConstants.DEV_BSL_JOBS_SUBSTRING) || x.Insert_job.ToLower().Contains(StringConstants.DEV_BIS_JOBS_SUBSTRING) select x).ToList<FilteredJobs>();
            // List<FilteredJobs> listOfStageJobs = (from x in listOfJobsFromJil where x.Insert_job.Trim().Split(StringConstants.SPLIT_WITH_COLON)[1].Trim().Split(StringConstants.SPLIT_WITH_SPACE)[0].Trim().ToLower().StartsWith(StringConstants.STAGE_BSL_JOBS_SUBSTRING) || x.Insert_job.Trim().Split(StringConstants.SPLIT_WITH_COLON)[1].Trim().Split(StringConstants.SPLIT_WITH_SPACE)[0].Trim().ToLower().StartsWith(StringConstants.STAGE_BIS_JOBS_SUBSTRING) select x).ToList<FilteredJobs>();
            List<FilteredJobs> listOfStageJobs = (from x in listOfJobsFromJil where x.Insert_job.ToLower().Contains(StringConstants.STAGE_BSL_JOBS_SUBSTRING) || x.Insert_job.ToLower().Contains(StringConstants.STAGE_BIS_JOBS_SUBSTRING) select x).ToList<FilteredJobs>();
            //List<FilteredJobs> listOfCtJobs = (from x in listOfJobsFromJil where x.Insert_job.Trim().Split(StringConstants.SPLIT_WITH_COLON)[1].Trim().Split(StringConstants.SPLIT_WITH_SPACE)[0].Trim().ToLower().StartsWith(StringConstants.CT_BSL_JOBS_SUBSTRING) || x.Insert_job.Trim().Split(StringConstants.SPLIT_WITH_COLON)[1].Trim().Split(StringConstants.SPLIT_WITH_SPACE)[0].Trim().ToLower().StartsWith(StringConstants.CT_BIS_JOBS_SUBSTRING) select x).ToList<FilteredJobs>();
            List<FilteredJobs> listOfCtJobs = (from x in listOfJobsFromJil where x.Insert_job.ToLower().Contains(StringConstants.CT_BSL_JOBS_SUBSTRING) || x.Insert_job.ToLower().Contains(StringConstants.CT_BIS_JOBS_SUBSTRING) select x).ToList<FilteredJobs>();
            //List<FilteredJobs> listOfProdJobs = (from x in listOfJobsFromJil where x.Insert_job.Trim().Split(StringConstants.SPLIT_WITH_COLON)[1].Trim().Split(StringConstants.SPLIT_WITH_SPACE)[0].Trim().ToLower().StartsWith(StringConstants.PROD_BSL_JOBS_SUBSTRING) || x.Insert_job.Trim().Split(StringConstants.SPLIT_WITH_COLON)[1].Trim().Split(StringConstants.SPLIT_WITH_SPACE)[0].Trim().ToLower().StartsWith(StringConstants.PROD_BIS_JOBS_SUBSTRING) select x).ToList<FilteredJobs>();
            List<FilteredJobs> listOfProdJobs = (from x in listOfJobsFromJil where x.Insert_job.ToLower().Contains(StringConstants.PROD_BSL_JOBS_SUBSTRING) || x.Insert_job.ToLower().Contains(StringConstants.PROD_BIS_JOBS_SUBSTRING) select x).ToList<FilteredJobs>();

            List<FilteredJobs> listOfOtherJobs = (from x in listOfJobsFromJil where !x.Insert_job.ToLower().Contains(StringConstants.BSL_SUBSTRING) && !x.Insert_job.ToLower().Contains(StringConstants.BIS_SUBSTRING) select x).ToList<FilteredJobs>();
            if (listOfOtherJobs != null && listOfOtherJobs.Count > 0)
                Session[ID + "OtherJobs"] = JsonConvert.SerializeObject(listOfOtherJobs);

            if (listOfDevJobs.Count > 0)
            {
                devTotalJobCount = listOfDevJobs.Count;
                listOfDevJobsToUpdate = GetListOfJobsToUpdate(listOfDevJobs, ref devUpperCaseInsertJobsCount, ref devUpperCaseBoxNamesCount,
                                                                ref devMachineNameUpdateCount, ref devPermissionUpdateCount,
                                                                ref devStdOutFilePathCount, ref devStdErrFilePathCount,
                                                                ref devCommandUpdateCount, ref devOwnerUpdateCount,
                                                                ref devApplicationUpdateCount, ref devUpperCaseConditionJobCount, ref devDescriptionCount,
                                                                ref devBoxSuccessUpperCaseCount, ref devBoxFailureUpperCaseCount, ref devGroupUpdateCount, ref isJobNeedsToBeUpdated);
                //Session[ID + "DevJobsToUpdate"] = listOfDevJobsToUpdate;
                Session[ID + "DevJobsToUpdate"] = JsonConvert.SerializeObject(listOfDevJobsToUpdate);
                devBslInsertJobsCount = (from x in listOfDevJobsToUpdate where (!string.IsNullOrEmpty(x.Insert_job) && x.Insert_job.Contains(StringConstants.BSL_SUBSTRING)) select x).ToList<FilteredJobs>().Count;
                devBslBoxNamesCount = (from x in listOfDevJobsToUpdate where (!string.IsNullOrEmpty(x.Boxname) && x.Boxname.Contains(StringConstants.BSL_SUBSTRING)) select x).ToList<FilteredJobs>().Count;
                devBslConditionJobCount = (from x in listOfDevJobsToUpdate where (!string.IsNullOrEmpty(x.Condition) && x.Condition.Contains(StringConstants.BSL_SUBSTRING)) select x).ToList<FilteredJobs>().Count;
                devBoxSuccessBslConditionCount = (from x in listOfDevJobsToUpdate where (!string.IsNullOrEmpty(x.Box_Success) && x.Box_Success.Contains(StringConstants.BSL_SUBSTRING)) select x).ToList<FilteredJobs>().Count;
                devBoxFailureBslConditionCount = (from x in listOfDevJobsToUpdate where (!string.IsNullOrEmpty(x.Box_Failure) && x.Box_Failure.Contains(StringConstants.BSL_SUBSTRING)) select x).ToList<FilteredJobs>().Count;
            }
            if (listOfStageJobs.Count > 0)
            {
                stageTotalJobCount = listOfStageJobs.Count;
                listOfStageJobsToUpdate = GetListOfJobsToUpdate(listOfStageJobs, ref stageUpperCaseInsertJobsCount, ref stageUpperCaseBoxNamesCount,
                                                                ref stageMachineNameUpdateCount, ref stagePermissionUpdateCount,
                                                                ref stageStdOutFilePathCount, ref stageStdErrFilePathCount,
                                                                ref stageCommandUpdateCount, ref stageOwnerUpdateCount,
                                                                ref stageApplicationUpdateCount, ref stageUpperCaseConditionJobCount, ref stageDescriptionCount,
                                                                ref stageBoxSuccessUpperCaseCount, ref stageBoxFailureUpperCaseCount, ref stageGroupUpdateCount, ref isJobNeedsToBeUpdated);
                // Session[ID + "StageJobsToUpdate"] = listOfStageJobsToUpdate;
                Session[ID + "StageJobsToUpdate"] = JsonConvert.SerializeObject(listOfStageJobsToUpdate);
                stageBslInsertJobsCount = (from x in listOfStageJobsToUpdate where (!string.IsNullOrEmpty(x.Insert_job) && x.Insert_job.Contains(StringConstants.BSL_SUBSTRING)) select x).ToList<FilteredJobs>().Count;

                stageBslBoxNamesCount = (from x in listOfStageJobsToUpdate where (!string.IsNullOrEmpty(x.Boxname) && x.Boxname.Contains(StringConstants.BSL_SUBSTRING)) select x).ToList<FilteredJobs>().Count;
                stageBslConditionJobCount = (from x in listOfStageJobsToUpdate where (!string.IsNullOrEmpty(x.Condition) && x.Condition.Contains(StringConstants.BSL_SUBSTRING)) select x).ToList<FilteredJobs>().Count;
                stageBoxSuccessBslConditionCount = (from x in listOfStageJobsToUpdate where (!string.IsNullOrEmpty(x.Box_Success) && x.Box_Success.Contains(StringConstants.BSL_SUBSTRING)) select x).ToList<FilteredJobs>().Count;
                stageBoxFailureBslConditionCount = (from x in listOfStageJobsToUpdate where (!string.IsNullOrEmpty(x.Box_Failure) && x.Box_Failure.Contains(StringConstants.BSL_SUBSTRING)) select x).ToList<FilteredJobs>().Count;
            }
            if (listOfCtJobs.Count > 0)
            {
                ctTotalJobCount = listOfCtJobs.Count;
                listOfCtJobsToUpdate = GetListOfJobsToUpdate(listOfCtJobs, ref ctUpperCaseInsertJobsCount, ref ctUpperCaseBoxNamesCount,
                                                                ref ctMachineNameUpdateCount, ref ctPermissionUpdateCount,
                                                                ref ctStdOutFilePathCount, ref ctStdErrFilePathCount,
                                                                ref ctCommandUpdateCount, ref ctOwnerUpdateCount,
                                                                ref ctApplicationUpdateCount, ref ctUpperCaseConditionJobCount, ref ctDescriptionCount
                                                                , ref ctBoxSuccessUpperCaseCount, ref ctBoxFailureUpperCaseCount, ref ctGroupUpdateCount, ref isJobNeedsToBeUpdated);
                // Session[ID + "CtJobsToUpdate"] = listOfCtJobsToUpdate;
                Session[ID + "CtJobsToUpdate"] = JsonConvert.SerializeObject(listOfCtJobsToUpdate);
                ctBslInsertJobsCount = (from x in listOfCtJobsToUpdate where (!string.IsNullOrEmpty(x.Insert_job) && x.Insert_job.Contains(StringConstants.BSL_SUBSTRING)) select x).ToList<FilteredJobs>().Count;

                ctBslBoxNamesCount = (from x in listOfCtJobsToUpdate where (!string.IsNullOrEmpty(x.Boxname) && x.Boxname.Contains(StringConstants.BSL_SUBSTRING)) select x).ToList<FilteredJobs>().Count;
                ctBslConditionJobCount = (from x in listOfCtJobsToUpdate where (!string.IsNullOrEmpty(x.Condition) && x.Condition.Contains(StringConstants.BSL_SUBSTRING)) select x).ToList<FilteredJobs>().Count;
                ctBoxSuccessBslConditionCount = (from x in listOfCtJobsToUpdate where (!string.IsNullOrEmpty(x.Box_Success) && x.Box_Success.Contains(StringConstants.BSL_SUBSTRING)) select x).ToList<FilteredJobs>().Count;
                ctBoxFailureBslConditionCount = (from x in listOfCtJobsToUpdate where (!string.IsNullOrEmpty(x.Box_Failure) && x.Box_Failure.Contains(StringConstants.BSL_SUBSTRING)) select x).ToList<FilteredJobs>().Count;
            }
            if (listOfProdJobs.Count > 0)
            {
                prodTotalJobCount = listOfProdJobs.Count;
                listOfProdJobsToUpdate = GetListOfJobsToUpdate(listOfProdJobs, ref prodUpperCaseInsertJobsCount, ref prodUpperCaseBoxNamesCount,
                                                                ref prodMachineNameUpdateCount, ref prodPermissionUpdateCount,
                                                                ref prodStdOutFilePathCount, ref prodStdErrFilePathCount,
                                                                ref prodCommandUpdateCount, ref prodOwnerUpdateCount,
                                                                ref prodApplicationUpdateCount, ref prodUpperCaseConditionJobCount, ref prodDescriptionCount,
                                                                ref prodBoxSuccessUpperCaseCount, ref prodBoxFailureUpperCaseCount, ref prodGroupUpdateCount, ref isJobNeedsToBeUpdated);

                // Session[ID + "ProdJobsToUpdate"] = listOfProdJobsToUpdate;
                Session[ID + "ProdJobsToUpdate"] = JsonConvert.SerializeObject(listOfProdJobsToUpdate);
                prodBslInsertJobsCount = (from x in listOfProdJobsToUpdate where (!string.IsNullOrEmpty(x.Insert_job) && x.Insert_job.Contains(StringConstants.BSL_SUBSTRING)) select x).ToList<FilteredJobs>().Count;

                prodBslBoxNamesCount = (from x in listOfProdJobsToUpdate where (!string.IsNullOrEmpty(x.Boxname) && x.Boxname.Contains(StringConstants.BSL_SUBSTRING)) select x).ToList<FilteredJobs>().Count;
                prodBslConditionJobCount = (from x in listOfProdJobsToUpdate where (!string.IsNullOrEmpty(x.Condition) && x.Condition.Contains(StringConstants.BSL_SUBSTRING)) select x).ToList<FilteredJobs>().Count;
                prodBoxSuccessBslConditionCount = (from x in listOfProdJobsToUpdate where (!string.IsNullOrEmpty(x.Box_Success) && x.Box_Success.Contains(StringConstants.BSL_SUBSTRING)) select x).ToList<FilteredJobs>().Count;
                prodBoxFailureBslConditionCount = (from x in listOfProdJobsToUpdate where (!string.IsNullOrEmpty(x.Box_Failure) && x.Box_Failure.Contains(StringConstants.BSL_SUBSTRING)) select x).ToList<FilteredJobs>().Count;
            }

            ViewBag.IsJobNeedsToUpdate = isJobNeedsToBeUpdated;

            ViewBag.DevTotalJobUpdateCount = devTotalJobCount;
            ViewBag.DevInsertJobUpperCaseCount = devUpperCaseInsertJobsCount;
            ViewBag.DevInsertJobBslCount = devBslInsertJobsCount;
            ViewBag.DevBoxNameBslCount = devBslBoxNamesCount;
            ViewBag.DevBoxNameUpperCaseCount = devUpperCaseBoxNamesCount;
            ViewBag.DevConditionBslCount = devBslConditionJobCount;
            ViewBag.DevConditionUpperCaseCount = devUpperCaseConditionJobCount;
            ViewBag.DevMachineNameUpdateCount = devMachineNameUpdateCount;
            ViewBag.DevPermissionUpdateCount = devPermissionUpdateCount;
            ViewBag.DevStdOutFilePathCount = devStdOutFilePathCount;
            ViewBag.DevStdErrFilePathCount = devStdErrFilePathCount;
            ViewBag.DevCommandUpdateCount = devCommandUpdateCount;
            ViewBag.DevOwnerUpdateCount = devOwnerUpdateCount;
            ViewBag.DevApplicationUpdateCount = devApplicationUpdateCount;
            ViewBag.DevDescriptionUpdateCount = devDescriptionCount;
            ViewBag.DevBoxSuccessUpperCaseCount = devBoxSuccessUpperCaseCount;
            ViewBag.DevBoxFailureUpperCaseCount = devBoxFailureUpperCaseCount;
            ViewBag.DevBoxSuccessBslConditionCount = devBoxSuccessBslConditionCount;
            ViewBag.DevBoxFailureBslConditionCount = devBoxFailureBslConditionCount;
            ViewBag.DevGroupUpdateCount = devGroupUpdateCount;


            ViewBag.StageTotalJobUpdateCount = stageTotalJobCount;
            ViewBag.StageInsertJobUpperCaseCount = stageUpperCaseInsertJobsCount;
            ViewBag.StageInsertJobBslCount = stageBslInsertJobsCount;
            ViewBag.StageBoxNameBslCount = stageBslBoxNamesCount;
            ViewBag.StageBoxNameUpperCaseCount = stageUpperCaseBoxNamesCount;
            ViewBag.StageConditionBslCount = stageBslConditionJobCount;
            ViewBag.StageConditionUpperCaseCount = stageUpperCaseConditionJobCount;
            ViewBag.StageMachineNameUpdateCount = stageMachineNameUpdateCount;
            ViewBag.StagePermissionUpdateCount = stagePermissionUpdateCount;
            ViewBag.StageStdOutFilePathCount = stageStdOutFilePathCount;
            ViewBag.StageStdErrFilePathCount = stageStdErrFilePathCount;
            ViewBag.StageCommandUpdateCount = stageCommandUpdateCount;
            ViewBag.StageOwnerUpdateCount = stageOwnerUpdateCount;
            ViewBag.StageApplicationUpdateCount = stageApplicationUpdateCount;
            ViewBag.StageDescriptionUpdateCount = stageDescriptionCount;
            ViewBag.StageBoxSuccessUpperCaseCount = stageBoxSuccessUpperCaseCount;
            ViewBag.StageBoxFailureUpperCaseCount = stageBoxFailureUpperCaseCount;
            ViewBag.StageBoxSuccessBslConditionCount = stageBoxSuccessBslConditionCount;
            ViewBag.StageBoxFailureBslConditionCount = stageBoxFailureBslConditionCount;
            ViewBag.StageGroupUpdateCount = stageGroupUpdateCount;


            ViewBag.CtTotalJobUpdateCount = ctTotalJobCount;
            ViewBag.CtInsertJobUpperCaseCount = ctUpperCaseInsertJobsCount;
            ViewBag.CtInsertJobBslCount = ctBslInsertJobsCount;
            ViewBag.CtBoxNameBslCount = ctBslBoxNamesCount;
            ViewBag.CtBoxNameUpperCaseCount = ctUpperCaseBoxNamesCount;
            ViewBag.CtConditionBslCount = ctBslConditionJobCount;
            ViewBag.CtConditionUpperCaseCount = ctUpperCaseConditionJobCount;
            ViewBag.CtMachineNameUpdateCount = ctMachineNameUpdateCount;
            ViewBag.CtPermissionUpdateCount = ctPermissionUpdateCount;
            ViewBag.CtStdOutFilePathCount = ctStdOutFilePathCount;
            ViewBag.CtStdErrFilePathCount = ctStdErrFilePathCount;
            ViewBag.CtCommandUpdateCount = ctCommandUpdateCount;
            ViewBag.CtOwnerUpdateCount = ctOwnerUpdateCount;
            ViewBag.CtApplicationUpdateCount = ctApplicationUpdateCount;
            ViewBag.CtDescriptionUpdateCount = ctDescriptionCount;
            ViewBag.CtBoxSuccessUpperCaseCount = ctBoxSuccessUpperCaseCount;
            ViewBag.CtBoxFailureUpperCaseCount = ctBoxFailureUpperCaseCount;
            ViewBag.CtBoxSuccessBslConditionCount = ctBoxSuccessBslConditionCount;
            ViewBag.CtBoxFailureBslConditionCount = ctBoxFailureBslConditionCount;
            ViewBag.CtGroupUpdateCount = ctGroupUpdateCount;


            ViewBag.ProdTotalJobUpdateCount = prodTotalJobCount;
            ViewBag.ProdInsertJobUpperCaseCount = prodUpperCaseInsertJobsCount;
            ViewBag.ProdInsertJobBslCount = prodBslInsertJobsCount;
            ViewBag.ProdBoxNameBslCount = prodBslBoxNamesCount;
            ViewBag.ProdBoxNameUpperCaseCount = prodUpperCaseBoxNamesCount;
            ViewBag.ProdConditionBslCount = prodBslConditionJobCount;
            ViewBag.ProdConditionUpperCaseCount = prodUpperCaseConditionJobCount;
            ViewBag.ProdMachineNameUpdateCount = prodMachineNameUpdateCount;
            ViewBag.ProdPermissionUpdateCount = prodPermissionUpdateCount;
            ViewBag.ProdStdOutFilePathCount = prodStdOutFilePathCount;
            ViewBag.ProdStdErrFilePathCount = prodStdErrFilePathCount;
            ViewBag.ProdCommandUpdateCount = prodCommandUpdateCount;
            ViewBag.ProdOwnerUpdateCount = prodOwnerUpdateCount;
            ViewBag.ProdApplicationUpdateCount = prodApplicationUpdateCount;
            ViewBag.ProdDescriptionUpdateCount = prodDescriptionCount;
            ViewBag.ProdBoxSuccessUpperCaseCount = prodBoxSuccessUpperCaseCount;
            ViewBag.ProdBoxFailureUpperCaseCount = prodBoxFailureUpperCaseCount;
            ViewBag.ProdBoxSuccessBslConditionCount = prodBoxSuccessBslConditionCount;
            ViewBag.ProdBoxFailureBslConditionCount = prodBoxFailureBslConditionCount;
            ViewBag.ProdGroupUpdateCount = prodGroupUpdateCount;

            return listOfJobsToBeUpdated;
        }

        private List<FilteredJobs> GetListOfJobsToUpdate(List<FilteredJobs> listOfJobsToAnalyse,
            ref int jobNameUpdateCount,
            ref int boxNameUpdateCount,
            ref int machineNameUpdateCount,
            ref int permissionUpdateCount,
            ref int stdOutFilePathCount,
            ref int stdErrFilePathCount,
            ref int commandUpdateCount,
            ref int ownerUpdateCount,
            ref int applicationUpdateCount,
            ref int conditionUpdateCount,
            ref int descriptionUpdateCount,
            ref int boxSuccessUpperCaseCount,
            ref int boxFailureUpperCaseCount,
            ref int groupUpdateCount,
            ref bool isJobNeedsToBeUpdated
            )
        {
            List<FilteredJobs> listOfJobsToBeUpdated = new List<FilteredJobs>();
            foreach (FilteredJobs job in listOfJobsToAnalyse)
            {
                //bool isJobNeedsToBeUpdated = false;
                if (job.Insert_job.Split(new string[] { StringConstants.JOB_TYPE }, StringSplitOptions.None).First().Split(':').Last().Trim().Any(ch => char.IsUpper(ch)))
                {
                    ++jobNameUpdateCount;
                    isJobNeedsToBeUpdated = true;
                }
                else if (job.Insert_job.Contains(StringConstants.BSL_SUBSTRING))
                {
                    isJobNeedsToBeUpdated = true;
                }

                if (!string.IsNullOrEmpty(job.Boxname) && job.Boxname.Any(ch => char.IsUpper(ch)))
                {
                    ++boxNameUpdateCount;
                    isJobNeedsToBeUpdated = true;
                }
                if (!string.IsNullOrEmpty(job.Machine) && !job.Machine.ToLower().Split(StringConstants.SPLIT_WITH_COLON).Last().Trim().StartsWith(StringConstants.VIRTUAL_MACHINE_PREFIX) && !job.Machine.ToLower().Split(StringConstants.SPLIT_WITH_COLON).Last().Trim().StartsWith(StringConstants.REAL_MACHINE_PREFIX) && !job.Machine.ToLower().Contains(StringConstants.LOCALHOST_SERVER))
                {
                    ++machineNameUpdateCount;
                    isJobNeedsToBeUpdated = true;
                }
                if (!string.IsNullOrEmpty(job.Permission) && !string.IsNullOrEmpty(job.Permission.Split(':').Last().Trim()))
                {
                    ++permissionUpdateCount;
                    isJobNeedsToBeUpdated = true;
                }
                if (!string.IsNullOrEmpty(job.StdOutFile) && !job.StdOutFile.ToLower().Replace("\"", string.Empty).Trim().EndsWith(StringConstants.OUT_FILE_SUFFIX))
                {
                    ++stdOutFilePathCount;
                    isJobNeedsToBeUpdated = true;
                }
                if (!string.IsNullOrEmpty(job.StdErrFile) && !job.StdErrFile.ToLower().Replace("\"", string.Empty).Trim().EndsWith(StringConstants.ERR_FILE_SUFFIX))
                {
                    ++stdErrFilePathCount;
                    isJobNeedsToBeUpdated = true;
                }
                if (job.Machine.Contains(StringConstants.NON_PROD_SCHEDULER_MACHINE) && job.Command.ToLower().Contains(StringConstants.SLEEP_BAT))
                {
                    ++commandUpdateCount;
                    isJobNeedsToBeUpdated = true;
                }
                if (job.Machine.Contains(StringConstants.NON_PROD_SCHEDULER_MACHINE) && !job.Owner.ToLower().Contains(StringConstants.NEW_OWNER))
                {
                    ++ownerUpdateCount;
                    isJobNeedsToBeUpdated = true;
                }
                if (!string.IsNullOrEmpty(job.Application) && !job.Application.Contains(ConfigurationManager.AppSettings["FileMgmtApplicationName"]) && !job.Application.Contains(ConfigurationManager.AppSettings["ASTApplicationName"]))
                {
                    ++applicationUpdateCount;
                    isJobNeedsToBeUpdated = true;
                }
                if (!string.IsNullOrEmpty(job.Condition) && (job.Condition.Contains(StringConstants.BSL_SUBSTRING) || job.Condition.Contains(StringConstants.BIS_SUBSTRING)) && job.Condition.Any(ch => char.IsUpper(ch)) && !job.Condition.Contains("v("))
                {
                    ++conditionUpdateCount;
                    isJobNeedsToBeUpdated = true;
                }
                //if (!string.IsNullOrEmpty(job.Description) && !string.IsNullOrEmpty(job.Description.Split(StringConstants.SPLIT_WITH_COLON).Last().Trim()))
                //{
                //    ++descriptionUpdateCount;
                //    isJobNeedsToBeUpdated = true;
                //}
                if (!string.IsNullOrEmpty(job.Box_Success) && job.Box_Success.Any(ch => char.IsUpper(ch)))
                {
                    ++boxSuccessUpperCaseCount;
                    isJobNeedsToBeUpdated = true;
                }
                if (!string.IsNullOrEmpty(job.Box_Failure) && job.Box_Failure.Any(ch => char.IsUpper(ch)))
                {
                    ++boxFailureUpperCaseCount;
                    isJobNeedsToBeUpdated = true;
                }

                if (!string.IsNullOrEmpty(job.Group) && !string.IsNullOrEmpty(job.Group.Split(':').Last().Trim()))
                {
                    ++groupUpdateCount;
                    isJobNeedsToBeUpdated = true;
                }

                if (isJobNeedsToBeUpdated)
                    listOfJobsToBeUpdated.Add(job);
            }

            return listOfJobsToBeUpdated;
        }
        private bool CreateNewJil(string ID)
        {
            bool isJilCreateSuccessfull = false;
            listOfJobs = Session[ID + "ListOfJobs"] as List<FilteredJobs>;
            List<FilteredJobs> listOfJobsToCreateNewJil = new List<FilteredJobs>();
            //foreach (var item in listOfJobs)
            //{
            //    listOfJobsToCreateNewJil.Add(item);
            //}
            listOfJobsToCreateNewJil.AddRange(listOfJobs);

            FileOperations fileObj = new FileOperations();
            foreach (FilteredJobs job in listOfJobsToCreateNewJil)
            {
                if (!(string.IsNullOrEmpty(job.DateCondition) || job.DateCondition.Contains("0")))
                {
                    job.TimeZone = "timezone: " + ConfigurationManager.AppSettings["TimeZoneValue"];
                }

                if (!string.IsNullOrEmpty(job.Machine))
                {
                    job.Machine = job.Machine.ToLower();
                }

                if (!string.IsNullOrEmpty(job.Header))
                {
                    job.Header = job.Header.ToLower().Trim();
                    if (job.Header.Contains(StringConstants.DEV_BSL_JOBS_SUBSTRING))
                    {
                        job.Header = job.Header.Replace(StringConstants.DEV_BSL_JOBS_SUBSTRING, StringConstants.DEV_BIS_JOBS_SUBSTRING);
                    }
                    else if (job.Header.Contains(StringConstants.STAGE_BSL_JOBS_SUBSTRING))
                    {
                        job.Header = job.Header.Replace(StringConstants.STAGE_BSL_JOBS_SUBSTRING, StringConstants.STAGE_BIS_JOBS_SUBSTRING);
                    }
                    else if (job.Header.Contains(StringConstants.CT_BSL_JOBS_SUBSTRING))
                    {
                        job.Header = job.Header.Replace(StringConstants.CT_BSL_JOBS_SUBSTRING, StringConstants.CT_BIS_JOBS_SUBSTRING);
                    }
                    else if (job.Header.Contains(StringConstants.PROD_BSL_JOBS_SUBSTRING))
                    {
                        job.Header = job.Header.Replace(StringConstants.PROD_BSL_JOBS_SUBSTRING, StringConstants.PROD_BIS_JOBS_SUBSTRING);
                    }
                }

                if (!string.IsNullOrEmpty(job.Insert_job))
                {
                    job.Insert_job = job.Insert_job.ToLower().Trim();
                    if (job.Insert_job.Contains(StringConstants.JOB_TYPE))
                    {
                        string jobName = job.Insert_job.Split(new string[] { StringConstants.JOB_TYPE }, StringSplitOptions.None).First().Trim();
                        string jobType = job.Insert_job.Split(new string[] { StringConstants.JOB_TYPE }, StringSplitOptions.None).Last().Trim().ToUpper();
                        job.Insert_job = jobName + "      " + StringConstants.JOB_TYPE + "  " + jobType;
                    }
                    

                    if (job.Insert_job.Contains(StringConstants.DEV_BSL_JOBS_SUBSTRING))
                    {
                        job.Insert_job = job.Insert_job.Replace(StringConstants.DEV_BSL_JOBS_SUBSTRING, StringConstants.DEV_BIS_JOBS_SUBSTRING);
                    }
                    else if (job.Insert_job.Contains(StringConstants.STAGE_BSL_JOBS_SUBSTRING))
                    {
                        job.Insert_job = job.Insert_job.Replace(StringConstants.STAGE_BSL_JOBS_SUBSTRING, StringConstants.STAGE_BIS_JOBS_SUBSTRING);
                    }
                    else if (job.Insert_job.Contains(StringConstants.CT_BSL_JOBS_SUBSTRING))
                    {
                        job.Insert_job = job.Insert_job.Replace(StringConstants.CT_BSL_JOBS_SUBSTRING, StringConstants.CT_BIS_JOBS_SUBSTRING);
                    }
                    else if (job.Insert_job.Contains(StringConstants.PROD_BSL_JOBS_SUBSTRING))
                    {
                        job.Insert_job = job.Insert_job.Replace(StringConstants.PROD_BSL_JOBS_SUBSTRING, StringConstants.PROD_BIS_JOBS_SUBSTRING);
                    }
                }

                if (!string.IsNullOrEmpty(job.Condition))
                {
                    //if (job.Condition.Contains(ConfigurationManager.AppSettings["LowerRegionBisSubstring"]) || job.Condition.Contains(ConfigurationManager.AppSettings["LowerRegionBslSubstring"]) || job.Condition.Contains(ConfigurationManager.AppSettings["ProductionBisSubstring"]))
                        job.Condition = job.Condition.ToLower();
                    if (job.Condition.Contains(StringConstants.DEV_BSL_JOBS_SUBSTRING))
                    {
                        job.Condition = job.Condition.Replace(StringConstants.DEV_BSL_JOBS_SUBSTRING, StringConstants.DEV_BIS_JOBS_SUBSTRING);
                    }
                    else if (job.Condition.Contains(StringConstants.STAGE_BSL_JOBS_SUBSTRING))
                    {
                        job.Condition = job.Condition.Replace(StringConstants.STAGE_BSL_JOBS_SUBSTRING, StringConstants.STAGE_BIS_JOBS_SUBSTRING);
                    }
                    else if (job.Condition.Contains(StringConstants.CT_BSL_JOBS_SUBSTRING))
                    {
                        job.Condition = job.Condition.Replace(StringConstants.CT_BSL_JOBS_SUBSTRING, StringConstants.CT_BIS_JOBS_SUBSTRING);
                    }
                    else if (job.Condition.Contains(StringConstants.PROD_BSL_JOBS_SUBSTRING))
                    {
                        job.Condition = job.Condition.Replace(StringConstants.PROD_BSL_JOBS_SUBSTRING, StringConstants.PROD_BIS_JOBS_SUBSTRING);
                    }

                    job.Condition = Regex.Replace(job.Condition, StringConstants.OD_MAM_PROCESSING, StringConstants.OD_MAM_PROCESSING, RegexOptions.IgnoreCase);
                    job.Condition = Regex.Replace(job.Condition, StringConstants.OD_EOD_PROCESSING, StringConstants.OD_EOD_PROCESSING, RegexOptions.IgnoreCase);
                    job.Condition = Regex.Replace(job.Condition, StringConstants.BILLER_TERMINATED, StringConstants.BILLER_TERMINATED, RegexOptions.IgnoreCase);
                    job.Condition = Regex.Replace(job.Condition, StringConstants.DO_NOT_RUN, StringConstants.DO_NOT_RUN, RegexOptions.IgnoreCase);
                    job.Condition = Regex.Replace(job.Condition, StringConstants.OD_TEST_PROCESSING, StringConstants.OD_TEST_PROCESSING, RegexOptions.IgnoreCase);
                    job.Condition = Regex.Replace(job.Condition, StringConstants.DALLAS_ACTIVE, StringConstants.DALLAS_ACTIVE, RegexOptions.IgnoreCase);
                    job.Condition = Regex.Replace(job.Condition, StringConstants.BOB_TEST, StringConstants.BOB_TEST, RegexOptions.IgnoreCase);
                    job.Condition = Regex.Replace(job.Condition, StringConstants.OD_MAM_DAL, StringConstants.OD_MAM_DAL, RegexOptions.IgnoreCase);
                    job.Condition = Regex.Replace(job.Condition, StringConstants.OD_MAM_CHI, StringConstants.OD_MAM_CHI, RegexOptions.IgnoreCase);
                    job.Condition = Regex.Replace(job.Condition, StringConstants.OD_PROCESSING, StringConstants.OD_PROCESSING, RegexOptions.IgnoreCase);
                    job.Condition = Regex.Replace(job.Condition, StringConstants.YES, StringConstants.YES, RegexOptions.IgnoreCase);
                    job.Condition = Regex.Replace(job.Condition, StringConstants.NO, StringConstants.NO, RegexOptions.IgnoreCase);
                }
                if (!string.IsNullOrEmpty(job.Boxname))
                {
                    job.Boxname = job.Boxname.ToLower().Trim();
                    if (job.Boxname.Contains(StringConstants.DEV_BSL_JOBS_SUBSTRING))
                    {
                        job.Boxname = job.Boxname.Replace(StringConstants.DEV_BSL_JOBS_SUBSTRING, StringConstants.DEV_BIS_JOBS_SUBSTRING);
                    }
                    else if (job.Boxname.Contains(StringConstants.STAGE_BSL_JOBS_SUBSTRING))
                    {
                        job.Boxname = job.Boxname.Replace(StringConstants.STAGE_BSL_JOBS_SUBSTRING, StringConstants.STAGE_BIS_JOBS_SUBSTRING);
                    }
                    else if (job.Boxname.Contains(StringConstants.CT_BSL_JOBS_SUBSTRING))
                    {
                        job.Boxname = job.Boxname.Replace(StringConstants.CT_BSL_JOBS_SUBSTRING, StringConstants.CT_BIS_JOBS_SUBSTRING);
                    }
                    else if (job.Boxname.Contains(StringConstants.PROD_BSL_JOBS_SUBSTRING))
                    {
                        job.Boxname = job.Boxname.Replace(StringConstants.PROD_BSL_JOBS_SUBSTRING, StringConstants.PROD_BIS_JOBS_SUBSTRING);
                    }
                }
                if (!string.IsNullOrEmpty(job.Box_Success))
                {
                    job.Box_Success = job.Box_Success.ToLower().Trim();
                    if (job.Box_Success.Contains(StringConstants.DEV_BSL_JOBS_SUBSTRING))
                    {
                        job.Box_Success = job.Box_Success.Replace(StringConstants.DEV_BSL_JOBS_SUBSTRING, StringConstants.DEV_BIS_JOBS_SUBSTRING);
                    }
                    else if (job.Box_Success.Contains(StringConstants.STAGE_BSL_JOBS_SUBSTRING))
                    {
                        job.Box_Success = job.Box_Success.Replace(StringConstants.STAGE_BSL_JOBS_SUBSTRING, StringConstants.STAGE_BIS_JOBS_SUBSTRING);
                    }
                    else if (job.Box_Success.Contains(StringConstants.CT_BSL_JOBS_SUBSTRING))
                    {
                        job.Box_Success = job.Box_Success.Replace(StringConstants.CT_BSL_JOBS_SUBSTRING, StringConstants.CT_BIS_JOBS_SUBSTRING);
                    }
                    else if (job.Box_Success.Contains(StringConstants.PROD_BSL_JOBS_SUBSTRING))
                    {
                        job.Box_Success = job.Box_Success.Replace(StringConstants.PROD_BSL_JOBS_SUBSTRING, StringConstants.PROD_BIS_JOBS_SUBSTRING);
                    }
                }
                if (!string.IsNullOrEmpty(job.Box_Failure))
                {
                    job.Box_Failure = job.Box_Failure.ToLower().Trim();
                    if (job.Box_Failure.Contains(StringConstants.DEV_BSL_JOBS_SUBSTRING))
                    {
                        job.Box_Failure = job.Box_Failure.Replace(StringConstants.DEV_BSL_JOBS_SUBSTRING, StringConstants.DEV_BIS_JOBS_SUBSTRING);
                    }
                    else if (job.Box_Failure.Contains(StringConstants.STAGE_BSL_JOBS_SUBSTRING))
                    {
                        job.Box_Failure = job.Box_Failure.Replace(StringConstants.STAGE_BSL_JOBS_SUBSTRING, StringConstants.STAGE_BIS_JOBS_SUBSTRING);
                    }
                    else if (job.Box_Failure.Contains(StringConstants.CT_BSL_JOBS_SUBSTRING))
                    {
                        job.Box_Failure = job.Box_Failure.Replace(StringConstants.CT_BSL_JOBS_SUBSTRING, StringConstants.CT_BIS_JOBS_SUBSTRING);
                    }
                    else if (job.Box_Failure.Contains(StringConstants.PROD_BSL_JOBS_SUBSTRING))
                    {
                        job.Box_Failure = job.Box_Failure.Replace(StringConstants.PROD_BSL_JOBS_SUBSTRING, StringConstants.PROD_BIS_JOBS_SUBSTRING);
                    }
                }

                if (!string.IsNullOrEmpty(job.Group))
                    job.Group = StringConstants.GROUP + ":  ";
                if (!string.IsNullOrEmpty(job.Permission) && !string.IsNullOrEmpty(job.Permission.Split(StringConstants.SPLIT_WITH_COLON).Last().Trim()))
                    job.Permission = StringConstants.PERMISSION + ": ";


                if (!string.IsNullOrEmpty(job.Command) && job.Command.Contains(ConfigurationManager.AppSettings["OldSysdateCommand"]))
                {
                    job.Command = job.Command.Replace(ConfigurationManager.AppSettings["OldSysdateCommand"], ConfigurationManager.AppSettings["NewSysdateCommand"]);
                }
                if (!string.IsNullOrEmpty(job.Command) && job.Command.Contains(ConfigurationManager.AppSettings["OldRptDateCommand"]))
                {
                    job.Command = job.Command.Replace(ConfigurationManager.AppSettings["OldRptDateCommand"], ConfigurationManager.AppSettings["NewRptDateCommand"]);
                }
                if (!string.IsNullOrEmpty(job.Command) && job.Command.Contains(ConfigurationManager.AppSettings["OldYesterdayCommand"]))
                {
                    job.Command = job.Command.Replace(ConfigurationManager.AppSettings["OldYesterdayCommand"], ConfigurationManager.AppSettings["NewYesterdayCommand"]);
                }
                if (!string.IsNullOrEmpty(job.Command) && job.Command.Contains(ConfigurationManager.AppSettings["OldLastMonthCommand"]))
                {
                    job.Command = job.Command.Replace(ConfigurationManager.AppSettings["OldLastMonthCommand"], ConfigurationManager.AppSettings["NewLastMonthCommand"]);
                }

                if (!string.IsNullOrEmpty(job.Command) && (job.Command.Contains(@"\:-D") || job.Command.Contains(@"\\:-D")))
                {
                    job.Command = job.Command.Replace(@"\\:-D", @":-D");
                    job.Command = job.Command.Replace(@"\:-D", @":-D");
                }

                //below change is added to replace FTP Key value 9 & 13 with value 16.
                // These values are configured in web.config, in case any other changes needs to be done then accordingly change the config values.

                if (!string.IsNullOrEmpty(job.Command) && job.Command.ToLower().Contains("ftpkey="))
                {
                    job.Command = Regex.Replace(job.Command, ConfigurationManager.AppSettings["OldFTPKey1"], ConfigurationManager.AppSettings["NewFTPKey1"], RegexOptions.IgnoreCase);
                    job.Command = Regex.Replace(job.Command, ConfigurationManager.AppSettings["OldFTPKey2"], ConfigurationManager.AppSettings["NewFTPKey2"], RegexOptions.IgnoreCase);
                }


                //Watch_File changes added below for all global variables

                if (!string.IsNullOrEmpty(job.Watch_File) && job.Watch_File.Contains(ConfigurationManager.AppSettings["OldSysdateCommand"]))
                {
                    job.Watch_File = job.Watch_File.Replace(ConfigurationManager.AppSettings["OldSysdateCommand"], ConfigurationManager.AppSettings["NewSysdateCommand"]);
                }
                if (!string.IsNullOrEmpty(job.Watch_File) && job.Watch_File.Contains(ConfigurationManager.AppSettings["OldRptDateCommand"]))
                {
                    job.Watch_File = job.Watch_File.Replace(ConfigurationManager.AppSettings["OldRptDateCommand"], ConfigurationManager.AppSettings["NewRptDateCommand"]);
                }
                if (!string.IsNullOrEmpty(job.Watch_File) && job.Watch_File.Contains(ConfigurationManager.AppSettings["OldYesterdayCommand"]))
                {
                    job.Watch_File = job.Watch_File.Replace(ConfigurationManager.AppSettings["OldYesterdayCommand"], ConfigurationManager.AppSettings["NewYesterdayCommand"]);
                }
                if (!string.IsNullOrEmpty(job.Watch_File) && job.Watch_File.Contains(ConfigurationManager.AppSettings["OldLastMonthCommand"]))
                {
                    job.Watch_File = job.Watch_File.Replace(ConfigurationManager.AppSettings["OldLastMonthCommand"], ConfigurationManager.AppSettings["NewLastMonthCommand"]);
                }


                //if (!string.IsNullOrEmpty(job.Application))
                //    job.Application = job.Application.Split(StringConstants.SPLIT_WITH_COLON).First() + ":  " + ConfigurationManager.AppSettings["NewApplicationName"];
                //else
                //    job.Application = StringConstants.APPLICATION + ":  " + ConfigurationManager.AppSettings["NewApplicationName"];

                if (job.Insert_job.Contains("bdc") || job.Insert_job.Contains("rdc") || job.Insert_job.Contains("settlement") || job.Insert_job.Contains("replchk") || job.Insert_job.Contains("replicationcheck"))
                {
                    job.Application = StringConstants.APPLICATION + ":  " + ConfigurationManager.AppSettings["ASTApplicationName"];
                }
                else
                {
                    job.Application = StringConstants.APPLICATION + ":  " + ConfigurationManager.AppSettings["FileMgmtApplicationName"];
                }

                if ((job.Machine.Contains(StringConstants.NON_PROD_SCHEDULER_MACHINE) || job.Machine.Contains(StringConstants.PROD_SCHEDULER_SERVER)) && job.Command.ToLower().Contains(StringConstants.SLEEP_BAT))
                {
                    job.Command = job.Command.Replace(@ConfigurationManager.AppSettings["AutoBinSleepCommand"], @ConfigurationManager.AppSettings["AsaSleepCommand"]);
                    //job.Command = job.Command.Split(StringConstants.SPLIT_WITH_COLON).First() + ": " + IO.Path.GetFileName(job.Command.ToLower().Split(new string[] {"command:"}, StringSplitOptions.None).Last().Trim().Replace("c\\:","c:").Replace("\"","")).Replace(".bat", string.Empty);
                }

                if (!string.IsNullOrEmpty(job.Machine) && (job.Machine.Contains(StringConstants.NON_PROD_SCHEDULER_MACHINE) || job.Machine.Contains(StringConstants.PROD_SCHEDULER_SERVER)) && job.Command.ToLower().Contains(StringConstants.SLEEP_BAT))
                {
                    if (job.Insert_job.Contains(ConfigurationManager.AppSettings["DevBisSubString"]) || job.Insert_job.Contains(ConfigurationManager.AppSettings["DevBslSubString"]))
                        job.Machine = StringConstants.MACHINE + ":  " + ConfigurationManager.AppSettings["DevAsaMachine"];
                    else if (job.Insert_job.Contains(ConfigurationManager.AppSettings["StageBisSubString"]) || job.Insert_job.Contains(ConfigurationManager.AppSettings["StageBslSubString"]))
                        job.Machine = StringConstants.MACHINE + ":  " + ConfigurationManager.AppSettings["StageAsaMachine"];
                    else if (job.Insert_job.Contains(ConfigurationManager.AppSettings["CtBisSubString"]) || job.Insert_job.Contains(ConfigurationManager.AppSettings["CtBslSubString"]))
                        job.Machine = StringConstants.MACHINE + ":  " + ConfigurationManager.AppSettings["CtAsaMachine"];
                    else if (job.Insert_job.Contains(ConfigurationManager.AppSettings["ProdBisSubString"]) || job.Insert_job.Contains(ConfigurationManager.AppSettings["ProdBslSubString"]))
                        job.Machine = StringConstants.MACHINE + ":  " + ConfigurationManager.AppSettings["ProAsaMachineName"];

                    if (!string.IsNullOrEmpty(job.Profile) && !job.Profile.ToLower().Contains("wrapper"))
                    {
                        job.Profile = job.Profile + " " + "wrapper";
                    }
                    else if (string.IsNullOrEmpty(job.Profile))
                    {
                        job.Profile = StringConstants.PROFILE + ": wrapper";
                    }

                }
                else if (!string.IsNullOrEmpty(job.Machine) && job.Machine.Contains(StringConstants.NON_PROD_SCHEDULER_MACHINE))
                {
                    job.Machine = StringConstants.MACHINE + ":  " + ConfigurationManager.AppSettings["LocalHostMachineName"];
                    if (!string.IsNullOrEmpty(job.Profile) && !job.Profile.ToLower().Contains("wrapper"))
                    {
                        job.Profile = job.Profile + " " + "wrapper";
                    }
                    else if (string.IsNullOrEmpty(job.Profile))
                    {
                        job.Profile = StringConstants.PROFILE + ": wrapper";
                    }
                }

                if (!string.IsNullOrEmpty(job.StdOutFile) && !job.Machine.Contains(StringConstants.NON_PROD_SCHEDULER_MACHINE) && !job.Machine.Contains(StringConstants.LOCALHOST_SERVER))
                    job.StdOutFile = job.StdOutFile.Split(StringConstants.SPLIT_WITH_COLON).First() + ":   " + @ConfigurationManager.AppSettings["StdOutFilePath"];
                else if (!string.IsNullOrEmpty(job.StdOutFile) && (job.Machine.Contains(StringConstants.NON_PROD_SCHEDULER_MACHINE) || job.Machine.Contains(StringConstants.LOCALHOST_SERVER)))
                    job.StdOutFile = job.StdOutFile.Split(StringConstants.SPLIT_WITH_COLON).First() + ":   " + @ConfigurationManager.AppSettings["SchedulerStdOutFilePath"];

                if (!string.IsNullOrEmpty(job.StdErrFile) && !job.Machine.Contains(StringConstants.NON_PROD_SCHEDULER_MACHINE) && !job.Machine.Contains(StringConstants.LOCALHOST_SERVER))
                    job.StdErrFile = job.StdErrFile.Split(StringConstants.SPLIT_WITH_COLON).First() + ":   " + @ConfigurationManager.AppSettings["StdErrorFilePath"];
                else if (!string.IsNullOrEmpty(job.StdErrFile) && (job.Machine.Contains(StringConstants.NON_PROD_SCHEDULER_MACHINE) || job.Machine.Contains(StringConstants.LOCALHOST_SERVER)))
                    job.StdErrFile = job.StdErrFile.Split(StringConstants.SPLIT_WITH_COLON).First() + ":   " + @ConfigurationManager.AppSettings["SchedulerStdErrFilePath"];



                job.Machine = Regex.Replace(job.Machine, "_test", string.Empty, RegexOptions.IgnoreCase);
                job.Machine = Regex.Replace(job.Machine, "test", string.Empty, RegexOptions.IgnoreCase);
                job.Machine = Regex.Replace(job.Machine, "bis-r-", string.Empty, RegexOptions.IgnoreCase);

                if (job.Insert_job.Contains(ConfigurationManager.AppSettings["DevBisSubString"]))
                {
                    if (!string.IsNullOrEmpty(job.Machine))
                    {
                        job.Machine = job.Machine.Replace(ConfigurationManager.AppSettings["DevOldAsaMachine01"], ConfigurationManager.AppSettings["DevNewAsaMachine01"]);
                        job.Machine = job.Machine.Replace(ConfigurationManager.AppSettings["DevOldAsaMachine02"], ConfigurationManager.AppSettings["DevNewAsaMachine01"]);
                        job.Machine = job.Machine.Replace(ConfigurationManager.AppSettings["StageVirtualMachineSubString"], ConfigurationManager.AppSettings["DevVirtualMachineSubString"]);
                        job.Machine = job.Machine.Replace(ConfigurationManager.AppSettings["StageRealMachineSubString"], ConfigurationManager.AppSettings["DevRealMachineSubString"]);
                        job.Machine = job.Machine.Replace(ConfigurationManager.AppSettings["StageOldAsaMachine01"], ConfigurationManager.AppSettings["DevNewAsaMachine01"]);
                        job.Machine = job.Machine.Replace(ConfigurationManager.AppSettings["StageOldAsaMachine02"], ConfigurationManager.AppSettings["DevNewAsaMachine01"]);
                        job.Machine = job.Machine.Replace(ConfigurationManager.AppSettings["CtVirtualMachineSubString"], ConfigurationManager.AppSettings["DevVirtualMachineSubString"]);
                        job.Machine = job.Machine.Replace(ConfigurationManager.AppSettings["CtRealMachineSubString"], ConfigurationManager.AppSettings["DevRealMachineSubString"]);
                        job.Machine = job.Machine.Replace(ConfigurationManager.AppSettings["CtOldAsaMachine01"], ConfigurationManager.AppSettings["DevNewAsaMachine01"]);
                        job.Machine = job.Machine.Replace(ConfigurationManager.AppSettings["CtOldAsaMachine02"], ConfigurationManager.AppSettings["DevNewAsaMachine01"]);
                        if ((job.Machine.Contains(ConfigurationManager.AppSettings["DevNewAsaMachine01"]) || job.Machine.Contains(ConfigurationManager.AppSettings["DevNewAsaMachine02"])) || job.Machine.Contains(ConfigurationManager.AppSettings["DevAsaRealMachine01"]) || job.Machine.Contains(ConfigurationManager.AppSettings["DevAsaRealMachine02"]) || job.Machine.Contains(ConfigurationManager.AppSettings["OldDevAsaRealMachine01"]) || job.Machine.Contains(ConfigurationManager.AppSettings["OldDevAsaRealMachine02"]))
                        {
                            job.Machine = job.Machine.Replace(ConfigurationManager.AppSettings["DevNewAsaMachine01"], ConfigurationManager.AppSettings["DevAsaMachine"]);
                            job.Machine = job.Machine.Replace(ConfigurationManager.AppSettings["DevNewAsaMachine02"], ConfigurationManager.AppSettings["DevAsaMachine"]);
                            job.Machine = job.Machine.Replace(ConfigurationManager.AppSettings["DevAsaRealMachine01"], ConfigurationManager.AppSettings["DevAsaMachine"]);
                            job.Machine = job.Machine.Replace(ConfigurationManager.AppSettings["DevAsaRealMachine02"], ConfigurationManager.AppSettings["DevAsaMachine"]);
                            job.Machine = job.Machine.Replace(ConfigurationManager.AppSettings["OldDevAsaRealMachine01"], ConfigurationManager.AppSettings["DevAsaMachine"]);
                            job.Machine = job.Machine.Replace(ConfigurationManager.AppSettings["OldDevAsaRealMachine02"], ConfigurationManager.AppSettings["DevAsaMachine"]);
                        }
                        else if (job.Machine.Contains(ConfigurationManager.AppSettings["DevGwyMachine01"]) || job.Machine.Contains(ConfigurationManager.AppSettings["DevGwyMachine02"]))
                        {
                            job.Machine = job.Machine.Replace(ConfigurationManager.AppSettings["DevGwyMachine01"], ConfigurationManager.AppSettings["DevGwyAsaMachine"]);
                            job.Machine = job.Machine.Replace(ConfigurationManager.AppSettings["DevGwyMachine02"], ConfigurationManager.AppSettings["DevGwyAsaMachine"]);
                        }

                        //need to check for below
                        if (job.Machine.Contains("od_") && !job.Machine.Contains("_alp"))
                        {
                            if (!job.Machine.Contains("_pro"))
                                job.Machine = job.Machine.Replace("pro", "");

                            job.Machine = job.Machine.Replace("_2008", "");
                            job.Machine = job.Machine + "_alp";
                        }

                        if (!job.Machine.Contains(ConfigurationManager.AppSettings["VirtualMachinePrefix"]) && !job.Machine.Contains(ConfigurationManager.AppSettings["LocalHostMachineName"]))
                        {
                            job.Machine = job.Machine.Split(':').First() + ": " + ConfigurationManager.AppSettings["VirtualMachinePrefix"] + job.Machine.Split(':').Last().Trim();
                        }
                    }
                    if (!string.IsNullOrEmpty(job.Owner))
                    {
                        job.Owner = Regex.Replace(job.Owner, ConfigurationManager.AppSettings["StageOwnerPre"], ConfigurationManager.AppSettings["DevOwnerPre"], RegexOptions.IgnoreCase);
                        job.Owner = Regex.Replace(job.Owner, ConfigurationManager.AppSettings["CtOwnerPre"], ConfigurationManager.AppSettings["DevOwnerPre"], RegexOptions.IgnoreCase);
                        job.Owner = Regex.Replace(job.Owner, ConfigurationManager.AppSettings["NewStageOwnerPre"], ConfigurationManager.AppSettings["NewDevOwnerPre"], RegexOptions.IgnoreCase);
                        job.Owner = Regex.Replace(job.Owner, ConfigurationManager.AppSettings["NewCtOwnerPre"], ConfigurationManager.AppSettings["NewDevOwnerPre"], RegexOptions.IgnoreCase);
                        //string ownerName = job.Owner.Split(':').Last().Trim();
                        //if (!ownerName.Contains("_") && !job.Owner.Contains(ConfigurationManager.AppSettings["NewOwnerName"]))
                        //    job.Owner = job.Owner.Split(':').First().Trim() + ":  DEV_" + ownerName;

                        job.Owner = Regex.Replace(job.Owner, ConfigurationManager.AppSettings["ProductionOwnerSuffix"], ConfigurationManager.AppSettings["NonProductionOwnerSuffix"].ToUpper(), RegexOptions.IgnoreCase);
                        if (!job.Owner.Contains("_") && !job.Owner.Contains(ConfigurationManager.AppSettings["DevOwnerPrefix"].ToUpper()) && !job.Owner.Contains(ConfigurationManager.AppSettings["NewDevOwnerPre"]))
                            job.Owner = job.Owner.Replace("AsysActionAcct", "DEV_AsysActionAcct");
                        if (job.Owner.Contains("AsysActionAcct") && !job.Owner.ToUpper().Contains(ConfigurationManager.AppSettings["NonProductionOwnerSuffix"].ToUpper()))
                        {
                            job.Owner = job.Owner.Replace("AsysActionAcct", "AsysActionAcct@CORP");
                        }
                        if (job.Owner.Contains("BM_"))
                            job.Owner = job.Owner.Replace("BM_", ConfigurationManager.AppSettings["DevOwnerPrefix"].ToUpper());

                        job.Owner = Regex.Replace(job.Owner, "Dev_Dev_", "DEV_", RegexOptions.IgnoreCase);
                        job.Owner = Regex.Replace(job.Owner, "Dev_", "DEV_", RegexOptions.IgnoreCase);

                    }

                    //adding changes for new attributes similar to owner
                    if (!string.IsNullOrEmpty(job.Ftp_Local_User))
                    {
                        job.Ftp_Local_User = Regex.Replace(job.Ftp_Local_User, ConfigurationManager.AppSettings["StageOwnerPre"], ConfigurationManager.AppSettings["DevOwnerPre"], RegexOptions.IgnoreCase);
                        job.Ftp_Local_User = Regex.Replace(job.Ftp_Local_User, ConfigurationManager.AppSettings["CtOwnerPre"], ConfigurationManager.AppSettings["DevOwnerPre"], RegexOptions.IgnoreCase);
                        job.Ftp_Local_User = Regex.Replace(job.Ftp_Local_User, ConfigurationManager.AppSettings["NewStageOwnerPre"], ConfigurationManager.AppSettings["NewDevOwnerPre"], RegexOptions.IgnoreCase);
                        job.Ftp_Local_User = Regex.Replace(job.Ftp_Local_User, ConfigurationManager.AppSettings["NewCtOwnerPre"], ConfigurationManager.AppSettings["NewDevOwnerPre"], RegexOptions.IgnoreCase);

                        job.Ftp_Local_User = Regex.Replace(job.Ftp_Local_User, ConfigurationManager.AppSettings["ProductionOwnerSuffix"], ConfigurationManager.AppSettings["NonProductionOwnerSuffix"].ToUpper(), RegexOptions.IgnoreCase);
                        if (!job.Ftp_Local_User.Contains("_") && !job.Ftp_Local_User.Contains(ConfigurationManager.AppSettings["DevOwnerPrefix"].ToUpper()) && !job.Ftp_Local_User.Contains(ConfigurationManager.AppSettings["NewDevOwnerPre"]))
                            job.Ftp_Local_User = job.Ftp_Local_User.Replace("AsysActionAcct", "DEV_AsysActionAcct");
                        if (job.Ftp_Local_User.Contains("AsysActionAcct") && !job.Ftp_Local_User.ToUpper().Contains(ConfigurationManager.AppSettings["NonProductionOwnerSuffix"].ToUpper()))
                        {
                            job.Ftp_Local_User = job.Ftp_Local_User.Replace("AsysActionAcct", "AsysActionAcct@CORP");
                        }
                        if (job.Ftp_Local_User.Contains("BM_"))
                            job.Ftp_Local_User = job.Ftp_Local_User.Replace("BM_", ConfigurationManager.AppSettings["DevOwnerPrefix"].ToUpper());

                        job.Ftp_Local_User = Regex.Replace(job.Ftp_Local_User, "Dev_Dev_", "DEV_", RegexOptions.IgnoreCase);
                        job.Ftp_Local_User = Regex.Replace(job.Ftp_Local_User, "Dev_", "DEV_", RegexOptions.IgnoreCase);
                    }
                    if (!string.IsNullOrEmpty(job.Watch_File_Win_User))
                    {
                        job.Watch_File_Win_User = Regex.Replace(job.Watch_File_Win_User, ConfigurationManager.AppSettings["StageOwnerPre"], ConfigurationManager.AppSettings["DevOwnerPre"], RegexOptions.IgnoreCase);
                        job.Watch_File_Win_User = Regex.Replace(job.Watch_File_Win_User, ConfigurationManager.AppSettings["CtOwnerPre"], ConfigurationManager.AppSettings["DevOwnerPre"], RegexOptions.IgnoreCase);
                        job.Watch_File_Win_User = Regex.Replace(job.Watch_File_Win_User, ConfigurationManager.AppSettings["NewStageOwnerPre"], ConfigurationManager.AppSettings["NewDevOwnerPre"], RegexOptions.IgnoreCase);
                        job.Watch_File_Win_User = Regex.Replace(job.Watch_File_Win_User, ConfigurationManager.AppSettings["NewCtOwnerPre"], ConfigurationManager.AppSettings["NewDevOwnerPre"], RegexOptions.IgnoreCase);

                        job.Watch_File_Win_User = Regex.Replace(job.Watch_File_Win_User, ConfigurationManager.AppSettings["ProductionOwnerSuffix"], ConfigurationManager.AppSettings["NonProductionOwnerSuffix"].ToUpper(), RegexOptions.IgnoreCase);
                        if (!job.Watch_File_Win_User.Contains("_") && !job.Watch_File_Win_User.Contains(ConfigurationManager.AppSettings["DevOwnerPrefix"].ToUpper()) && !job.Watch_File_Win_User.Contains(ConfigurationManager.AppSettings["NewDevOwnerPre"]))
                            job.Watch_File_Win_User = job.Watch_File_Win_User.Replace("AsysActionAcct", "DEV_AsysActionAcct");
                        if (job.Watch_File_Win_User.Contains("AsysActionAcct") && !job.Watch_File_Win_User.ToUpper().Contains(ConfigurationManager.AppSettings["NonProductionOwnerSuffix"].ToUpper()))
                        {
                            job.Watch_File_Win_User = job.Watch_File_Win_User.Replace("AsysActionAcct", "AsysActionAcct@CORP");
                        }
                        if (job.Watch_File_Win_User.Contains("BM_"))
                            job.Watch_File_Win_User = job.Watch_File_Win_User.Replace("BM_", ConfigurationManager.AppSettings["DevOwnerPrefix"].ToUpper());

                        job.Watch_File_Win_User = Regex.Replace(job.Watch_File_Win_User, "Dev_Dev_", "DEV_", RegexOptions.IgnoreCase);
                        job.Watch_File_Win_User = Regex.Replace(job.Watch_File_Win_User, "Dev_", "DEV_", RegexOptions.IgnoreCase);
                    }
                    //change completed for new attribute

                    if (!string.IsNullOrEmpty(job.Command))
                    {
                        job.Command = Regex.Replace(job.Command, ConfigurationManager.AppSettings["DevOldAsaMachine01"], ConfigurationManager.AppSettings["DevNASCommandPath"], RegexOptions.IgnoreCase);
                        job.Command = Regex.Replace(job.Command, ConfigurationManager.AppSettings["DevOldAsaMachine02"], ConfigurationManager.AppSettings["DevNASCommandPath"], RegexOptions.IgnoreCase);
                        job.Command = Regex.Replace(job.Command, ConfigurationManager.AppSettings["DevNewAsaMachine01"], ConfigurationManager.AppSettings["DevNASCommandPath"], RegexOptions.IgnoreCase);
                        job.Command = Regex.Replace(job.Command, ConfigurationManager.AppSettings["DevNewAsaMachine02"], ConfigurationManager.AppSettings["DevNASCommandPath"], RegexOptions.IgnoreCase);
                        job.Command = job.Command.Replace(ConfigurationManager.AppSettings["DevCommandPath"].Replace("$$$$", "$$"), ConfigurationManager.AppSettings["DevNASCommandPath"]);
                        job.Command = job.Command.Replace(ConfigurationManager.AppSettings["OldDevCommandPath"].Replace("$$$$", "$$"), ConfigurationManager.AppSettings["DevNASCommandPath"]);
                        job.Command = job.Command.Replace(ConfigurationManager.AppSettings["CtCommandPath"].Replace("$$$$", "$$"), ConfigurationManager.AppSettings["DevNASCommandPath"]);
                        job.Command = job.Command.Replace(ConfigurationManager.AppSettings["StageCommandPath"].Replace("$$$$", "$$"), ConfigurationManager.AppSettings["DevNASCommandPath"]);
                        job.Command = job.Command.Replace(ConfigurationManager.AppSettings["StageNASCommandPath"].Replace("$$$$", "$$"), ConfigurationManager.AppSettings["DevNASCommandPath"]);
                        job.Command = job.Command.Replace(ConfigurationManager.AppSettings["CtNASCommandPath"].Replace("$$$$", "$$"), ConfigurationManager.AppSettings["DevNASCommandPath"]);
                        job.Command = Regex.Replace(job.Command, ConfigurationManager.AppSettings["NonProdFileStoreRootLocation"], ConfigurationManager.AppSettings["DevNASCommandPath"], RegexOptions.IgnoreCase);
                        job.Command = Regex.Replace(job.Command, ConfigurationManager.AppSettings["DalProdFileStoreRootLocation"], ConfigurationManager.AppSettings["DevNASCommandPath"], RegexOptions.IgnoreCase);
                        job.Command = Regex.Replace(job.Command, ConfigurationManager.AppSettings["ChiProdFileStoreRootLocation"], ConfigurationManager.AppSettings["DevNASCommandPath"], RegexOptions.IgnoreCase);
                        job.Command = Regex.Replace(job.Command, ConfigurationManager.AppSettings["StageOldAsaMachine01"], ConfigurationManager.AppSettings["DevNASCommandPath"], RegexOptions.IgnoreCase);
                        job.Command = Regex.Replace(job.Command, ConfigurationManager.AppSettings["StageOldAsaMachine02"], ConfigurationManager.AppSettings["DevNASCommandPath"], RegexOptions.IgnoreCase);
                        job.Command = Regex.Replace(job.Command, ConfigurationManager.AppSettings["StageNewAsaMachine01"], ConfigurationManager.AppSettings["DevNASCommandPath"], RegexOptions.IgnoreCase);
                        job.Command = Regex.Replace(job.Command, ConfigurationManager.AppSettings["StageNewAsaMachine02"], ConfigurationManager.AppSettings["DevNASCommandPath"], RegexOptions.IgnoreCase);
                        job.Command = Regex.Replace(job.Command, ConfigurationManager.AppSettings["CtOldAsaMachine01"], ConfigurationManager.AppSettings["DevNASCommandPath"], RegexOptions.IgnoreCase);
                        job.Command = Regex.Replace(job.Command, ConfigurationManager.AppSettings["CtOldAsaMachine02"], ConfigurationManager.AppSettings["DevNASCommandPath"], RegexOptions.IgnoreCase);
                        job.Command = Regex.Replace(job.Command, ConfigurationManager.AppSettings["CtNewAsaMachine01"], ConfigurationManager.AppSettings["DevNASCommandPath"], RegexOptions.IgnoreCase);
                        job.Command = Regex.Replace(job.Command, ConfigurationManager.AppSettings["CtNewAsaMachine02"], ConfigurationManager.AppSettings["DevNASCommandPath"], RegexOptions.IgnoreCase);
                        job.Command = Regex.Replace(job.Command, ConfigurationManager.AppSettings["DevGwyNewAsaMachine01"], ConfigurationManager.AppSettings["DevNASCommandPath"], RegexOptions.IgnoreCase);
                        job.Command = Regex.Replace(job.Command, ConfigurationManager.AppSettings["DevGwyNewAsaMachine02"], ConfigurationManager.AppSettings["DevNASCommandPath"], RegexOptions.IgnoreCase);
                        job.Command = Regex.Replace(job.Command, ConfigurationManager.AppSettings["StageGwyNewAsaMachine01"], ConfigurationManager.AppSettings["DevNASCommandPath"], RegexOptions.IgnoreCase);
                        job.Command = Regex.Replace(job.Command, ConfigurationManager.AppSettings["StageGwyNewAsaMachine02"], ConfigurationManager.AppSettings["DevNASCommandPath"], RegexOptions.IgnoreCase);
                        job.Command = Regex.Replace(job.Command, ConfigurationManager.AppSettings["CtGwyNewAsaMachine01"], ConfigurationManager.AppSettings["DevNASCommandPath"], RegexOptions.IgnoreCase);
                        job.Command = Regex.Replace(job.Command, ConfigurationManager.AppSettings["CtGwyNewAsaMachine02"], ConfigurationManager.AppSettings["DevNASCommandPath"], RegexOptions.IgnoreCase);
                        job.Command = Regex.Replace(job.Command, ConfigurationManager.AppSettings["NonProdSchedulerNASMachine"], ConfigurationManager.AppSettings["DevNASCommandPath"], RegexOptions.IgnoreCase);
                        job.Command = job.Command.Replace("$$$$", "$$");
                        job.Command = job.Command.Replace(StringConstants.STAGE_BSL_JOBS_SUBSTRING, StringConstants.DEV_BIS_JOBS_SUBSTRING);
                        job.Command = job.Command.Replace(StringConstants.CT_BSL_JOBS_SUBSTRING, StringConstants.DEV_BIS_JOBS_SUBSTRING);
                        job.Command = job.Command.Replace(StringConstants.PROD_BSL_JOBS_SUBSTRING, StringConstants.DEV_BIS_JOBS_SUBSTRING);
                        job.Command = Regex.Replace(job.Command, ConfigurationManager.AppSettings["OldIncomingFilesPath"], ConfigurationManager.AppSettings["NewIncomingFilesPath"], RegexOptions.IgnoreCase);
                        job.Command = Regex.Replace(job.Command, ConfigurationManager.AppSettings["StageFileNameExtension"], ConfigurationManager.AppSettings["DevFileNameExtension"], RegexOptions.IgnoreCase);
                        job.Command = Regex.Replace(job.Command, ConfigurationManager.AppSettings["CtFileNameExtension"], ConfigurationManager.AppSettings["DevFileNameExtension"], RegexOptions.IgnoreCase);
                        job.Command = Regex.Replace(job.Command, ConfigurationManager.AppSettings["ProdFileNameExtension"], ConfigurationManager.AppSettings["DevFileNameExtension"], RegexOptions.IgnoreCase);

                        job.Command = Regex.Replace(job.Command, ConfigurationManager.AppSettings["OldDevRptServer01"], ConfigurationManager.AppSettings["NewDevRptServer01"], RegexOptions.IgnoreCase);
                        job.Command = Regex.Replace(job.Command, ConfigurationManager.AppSettings["OldDevRptServer02"], ConfigurationManager.AppSettings["NewDevRptServer01"], RegexOptions.IgnoreCase);
                        job.Command = Regex.Replace(job.Command, ConfigurationManager.AppSettings["OldStageRptServer01"], ConfigurationManager.AppSettings["NewDevRptServer01"], RegexOptions.IgnoreCase);
                        job.Command = Regex.Replace(job.Command, ConfigurationManager.AppSettings["OldStageRptServer02"], ConfigurationManager.AppSettings["NewDevRptServer01"], RegexOptions.IgnoreCase);
                        job.Command = Regex.Replace(job.Command, ConfigurationManager.AppSettings["OldCtRptServer01"], ConfigurationManager.AppSettings["NewDevRptServer01"], RegexOptions.IgnoreCase);
                        job.Command = Regex.Replace(job.Command, ConfigurationManager.AppSettings["OldCtRptServer02"], ConfigurationManager.AppSettings["NewDevRptServer01"], RegexOptions.IgnoreCase);


                        job.Command = Regex.Replace(job.Command, ConfigurationManager.AppSettings["NewDevRptServer02"], ConfigurationManager.AppSettings["NewDevRptServer01"], RegexOptions.IgnoreCase);
                        job.Command = Regex.Replace(job.Command, ConfigurationManager.AppSettings["NewStageRptServer01"], ConfigurationManager.AppSettings["NewDevRptServer01"], RegexOptions.IgnoreCase);
                        job.Command = Regex.Replace(job.Command, ConfigurationManager.AppSettings["NewStageRptServer02"], ConfigurationManager.AppSettings["NewDevRptServer01"], RegexOptions.IgnoreCase);
                        job.Command = Regex.Replace(job.Command, ConfigurationManager.AppSettings["NewCtRptServer01"], ConfigurationManager.AppSettings["NewDevRptServer01"], RegexOptions.IgnoreCase);
                        job.Command = Regex.Replace(job.Command, ConfigurationManager.AppSettings["NewCtRptServer02"], ConfigurationManager.AppSettings["NewDevRptServer01"], RegexOptions.IgnoreCase);

                    }

                    //adding new changes for new attributes similar to command
                    if (!string.IsNullOrEmpty(job.Ftp_Local_Name))
                    {
                        job.Ftp_Local_Name = Regex.Replace(job.Ftp_Local_Name, ConfigurationManager.AppSettings["DevOldAsaMachine01"], ConfigurationManager.AppSettings["DevNASCommandPath"], RegexOptions.IgnoreCase);
                        job.Ftp_Local_Name = Regex.Replace(job.Ftp_Local_Name, ConfigurationManager.AppSettings["DevOldAsaMachine02"], ConfigurationManager.AppSettings["DevNASCommandPath"], RegexOptions.IgnoreCase);
                        job.Ftp_Local_Name = Regex.Replace(job.Ftp_Local_Name, ConfigurationManager.AppSettings["DevNewAsaMachine01"], ConfigurationManager.AppSettings["DevNASCommandPath"], RegexOptions.IgnoreCase);
                        job.Ftp_Local_Name = Regex.Replace(job.Ftp_Local_Name, ConfigurationManager.AppSettings["DevNewAsaMachine02"], ConfigurationManager.AppSettings["DevNASCommandPath"], RegexOptions.IgnoreCase);
                        job.Ftp_Local_Name = job.Ftp_Local_Name.Replace(ConfigurationManager.AppSettings["DevCommandPath"].Replace("$$$$", "$$"), ConfigurationManager.AppSettings["DevNASCommandPath"]);
                        job.Ftp_Local_Name = job.Ftp_Local_Name.Replace(ConfigurationManager.AppSettings["OldDevCommandPath"].Replace("$$$$", "$$"), ConfigurationManager.AppSettings["DevNASCommandPath"]);
                        job.Ftp_Local_Name = job.Ftp_Local_Name.Replace(ConfigurationManager.AppSettings["CtCommandPath"].Replace("$$$$", "$$"), ConfigurationManager.AppSettings["DevNASCommandPath"]);
                        job.Ftp_Local_Name = job.Ftp_Local_Name.Replace(ConfigurationManager.AppSettings["StageCommandPath"].Replace("$$$$", "$$"), ConfigurationManager.AppSettings["DevNASCommandPath"]);
                        job.Ftp_Local_Name = job.Ftp_Local_Name.Replace(ConfigurationManager.AppSettings["StageNASCommandPath"].Replace("$$$$", "$$"), ConfigurationManager.AppSettings["DevNASCommandPath"]);
                        job.Ftp_Local_Name = job.Ftp_Local_Name.Replace(ConfigurationManager.AppSettings["CtNASCommandPath"].Replace("$$$$", "$$"), ConfigurationManager.AppSettings["DevNASCommandPath"]);
                        job.Ftp_Local_Name = Regex.Replace(job.Ftp_Local_Name, ConfigurationManager.AppSettings["NonProdFileStoreRootLocation"], ConfigurationManager.AppSettings["DevNASCommandPath"], RegexOptions.IgnoreCase);
                        job.Ftp_Local_Name = Regex.Replace(job.Ftp_Local_Name, ConfigurationManager.AppSettings["DalProdFileStoreRootLocation"], ConfigurationManager.AppSettings["DevNASCommandPath"], RegexOptions.IgnoreCase);
                        job.Ftp_Local_Name = Regex.Replace(job.Ftp_Local_Name, ConfigurationManager.AppSettings["ChiProdFileStoreRootLocation"], ConfigurationManager.AppSettings["DevNASCommandPath"], RegexOptions.IgnoreCase);
                        job.Ftp_Local_Name = Regex.Replace(job.Ftp_Local_Name, ConfigurationManager.AppSettings["StageOldAsaMachine01"], ConfigurationManager.AppSettings["DevNASCommandPath"], RegexOptions.IgnoreCase);
                        job.Ftp_Local_Name = Regex.Replace(job.Ftp_Local_Name, ConfigurationManager.AppSettings["StageOldAsaMachine02"], ConfigurationManager.AppSettings["DevNASCommandPath"], RegexOptions.IgnoreCase);
                        job.Ftp_Local_Name = Regex.Replace(job.Ftp_Local_Name, ConfigurationManager.AppSettings["StageNewAsaMachine01"], ConfigurationManager.AppSettings["DevNASCommandPath"], RegexOptions.IgnoreCase);
                        job.Ftp_Local_Name = Regex.Replace(job.Ftp_Local_Name, ConfigurationManager.AppSettings["StageNewAsaMachine02"], ConfigurationManager.AppSettings["DevNASCommandPath"], RegexOptions.IgnoreCase);
                        job.Ftp_Local_Name = Regex.Replace(job.Ftp_Local_Name, ConfigurationManager.AppSettings["CtOldAsaMachine01"], ConfigurationManager.AppSettings["DevNASCommandPath"], RegexOptions.IgnoreCase);
                        job.Ftp_Local_Name = Regex.Replace(job.Ftp_Local_Name, ConfigurationManager.AppSettings["CtOldAsaMachine02"], ConfigurationManager.AppSettings["DevNASCommandPath"], RegexOptions.IgnoreCase);
                        job.Ftp_Local_Name = Regex.Replace(job.Ftp_Local_Name, ConfigurationManager.AppSettings["CtNewAsaMachine01"], ConfigurationManager.AppSettings["DevNASCommandPath"], RegexOptions.IgnoreCase);
                        job.Ftp_Local_Name = Regex.Replace(job.Ftp_Local_Name, ConfigurationManager.AppSettings["CtNewAsaMachine02"], ConfigurationManager.AppSettings["DevNASCommandPath"], RegexOptions.IgnoreCase);
                        job.Ftp_Local_Name = Regex.Replace(job.Ftp_Local_Name, ConfigurationManager.AppSettings["DevGwyNewAsaMachine01"], ConfigurationManager.AppSettings["DevNASCommandPath"], RegexOptions.IgnoreCase);
                        job.Ftp_Local_Name = Regex.Replace(job.Ftp_Local_Name, ConfigurationManager.AppSettings["DevGwyNewAsaMachine02"], ConfigurationManager.AppSettings["DevNASCommandPath"], RegexOptions.IgnoreCase);
                        job.Ftp_Local_Name = Regex.Replace(job.Ftp_Local_Name, ConfigurationManager.AppSettings["StageGwyNewAsaMachine01"], ConfigurationManager.AppSettings["DevNASCommandPath"], RegexOptions.IgnoreCase);
                        job.Ftp_Local_Name = Regex.Replace(job.Ftp_Local_Name, ConfigurationManager.AppSettings["StageGwyNewAsaMachine02"], ConfigurationManager.AppSettings["DevNASCommandPath"], RegexOptions.IgnoreCase);
                        job.Ftp_Local_Name = Regex.Replace(job.Ftp_Local_Name, ConfigurationManager.AppSettings["CtGwyNewAsaMachine01"], ConfigurationManager.AppSettings["DevNASCommandPath"], RegexOptions.IgnoreCase);
                        job.Ftp_Local_Name = Regex.Replace(job.Ftp_Local_Name, ConfigurationManager.AppSettings["CtGwyNewAsaMachine02"], ConfigurationManager.AppSettings["DevNASCommandPath"], RegexOptions.IgnoreCase);
                        job.Ftp_Local_Name = Regex.Replace(job.Ftp_Local_Name, ConfigurationManager.AppSettings["NonProdSchedulerNASMachine"], ConfigurationManager.AppSettings["DevNASCommandPath"], RegexOptions.IgnoreCase);
                        job.Ftp_Local_Name = job.Ftp_Local_Name.Replace("$$$$", "$$");
                        job.Ftp_Local_Name = Regex.Replace(job.Ftp_Local_Name, ConfigurationManager.AppSettings["OldIncomingFilesPath"], ConfigurationManager.AppSettings["NewIncomingFilesPath"], RegexOptions.IgnoreCase);
                        job.Ftp_Local_Name = Regex.Replace(job.Ftp_Local_Name, ConfigurationManager.AppSettings["StageFileNameExtension"], ConfigurationManager.AppSettings["DevFileNameExtension"], RegexOptions.IgnoreCase);
                        job.Ftp_Local_Name = Regex.Replace(job.Ftp_Local_Name, ConfigurationManager.AppSettings["CtFileNameExtension"], ConfigurationManager.AppSettings["DevFileNameExtension"], RegexOptions.IgnoreCase);
                        job.Ftp_Local_Name = Regex.Replace(job.Ftp_Local_Name, ConfigurationManager.AppSettings["ProdFileNameExtension"], ConfigurationManager.AppSettings["DevFileNameExtension"], RegexOptions.IgnoreCase);

                        job.Ftp_Local_Name = Regex.Replace(job.Ftp_Local_Name, ConfigurationManager.AppSettings["OldDevRptServer01"], ConfigurationManager.AppSettings["NewDevRptServer01"], RegexOptions.IgnoreCase);
                        job.Ftp_Local_Name = Regex.Replace(job.Ftp_Local_Name, ConfigurationManager.AppSettings["OldDevRptServer02"], ConfigurationManager.AppSettings["NewDevRptServer01"], RegexOptions.IgnoreCase);
                        job.Ftp_Local_Name = Regex.Replace(job.Ftp_Local_Name, ConfigurationManager.AppSettings["OldStageRptServer01"], ConfigurationManager.AppSettings["NewDevRptServer01"], RegexOptions.IgnoreCase);
                        job.Ftp_Local_Name = Regex.Replace(job.Ftp_Local_Name, ConfigurationManager.AppSettings["OldStageRptServer02"], ConfigurationManager.AppSettings["NewDevRptServer01"], RegexOptions.IgnoreCase);
                        job.Ftp_Local_Name = Regex.Replace(job.Ftp_Local_Name, ConfigurationManager.AppSettings["OldCtRptServer01"], ConfigurationManager.AppSettings["NewDevRptServer01"], RegexOptions.IgnoreCase);
                        job.Ftp_Local_Name = Regex.Replace(job.Ftp_Local_Name, ConfigurationManager.AppSettings["OldCtRptServer02"], ConfigurationManager.AppSettings["NewDevRptServer01"], RegexOptions.IgnoreCase);

                        job.Ftp_Local_Name = Regex.Replace(job.Ftp_Local_Name, ConfigurationManager.AppSettings["NewDevRptServer02"], ConfigurationManager.AppSettings["NewDevRptServer01"], RegexOptions.IgnoreCase);
                        job.Ftp_Local_Name = Regex.Replace(job.Ftp_Local_Name, ConfigurationManager.AppSettings["NewStageRptServer01"], ConfigurationManager.AppSettings["NewDevRptServer01"], RegexOptions.IgnoreCase);
                        job.Ftp_Local_Name = Regex.Replace(job.Ftp_Local_Name, ConfigurationManager.AppSettings["NewStageRptServer02"], ConfigurationManager.AppSettings["NewDevRptServer01"], RegexOptions.IgnoreCase);
                        job.Ftp_Local_Name = Regex.Replace(job.Ftp_Local_Name, ConfigurationManager.AppSettings["NewCtRptServer01"], ConfigurationManager.AppSettings["NewDevRptServer01"], RegexOptions.IgnoreCase);
                        job.Ftp_Local_Name = Regex.Replace(job.Ftp_Local_Name, ConfigurationManager.AppSettings["NewCtRptServer02"], ConfigurationManager.AppSettings["NewDevRptServer01"], RegexOptions.IgnoreCase);
                    }
                    if (!string.IsNullOrEmpty(job.Watch_File))
                    {
                        job.Watch_File = Regex.Replace(job.Watch_File, ConfigurationManager.AppSettings["DevOldAsaMachine01"], ConfigurationManager.AppSettings["DevNASCommandPath"], RegexOptions.IgnoreCase);
                        job.Watch_File = Regex.Replace(job.Watch_File, ConfigurationManager.AppSettings["DevOldAsaMachine02"], ConfigurationManager.AppSettings["DevNASCommandPath"], RegexOptions.IgnoreCase);
                        job.Watch_File = Regex.Replace(job.Watch_File, ConfigurationManager.AppSettings["DevNewAsaMachine01"], ConfigurationManager.AppSettings["DevNASCommandPath"], RegexOptions.IgnoreCase);
                        job.Watch_File = Regex.Replace(job.Watch_File, ConfigurationManager.AppSettings["DevNewAsaMachine02"], ConfigurationManager.AppSettings["DevNASCommandPath"], RegexOptions.IgnoreCase);
                        job.Watch_File = job.Watch_File.Replace(ConfigurationManager.AppSettings["DevCommandPath"].Replace("$$$$", "$$"), ConfigurationManager.AppSettings["DevNASCommandPath"]);
                        job.Watch_File = job.Watch_File.Replace(ConfigurationManager.AppSettings["OldDevCommandPath"].Replace("$$$$", "$$"), ConfigurationManager.AppSettings["DevNASCommandPath"]);
                        job.Watch_File = job.Watch_File.Replace(ConfigurationManager.AppSettings["CtCommandPath"].Replace("$$$$", "$$"), ConfigurationManager.AppSettings["DevNASCommandPath"]);
                        job.Watch_File = job.Watch_File.Replace(ConfigurationManager.AppSettings["StageCommandPath"].Replace("$$$$", "$$"), ConfigurationManager.AppSettings["DevNASCommandPath"]);
                        job.Watch_File = job.Watch_File.Replace(ConfigurationManager.AppSettings["StageNASCommandPath"].Replace("$$$$", "$$"), ConfigurationManager.AppSettings["DevNASCommandPath"]);
                        job.Watch_File = job.Watch_File.Replace(ConfigurationManager.AppSettings["CtNASCommandPath"].Replace("$$$$", "$$"), ConfigurationManager.AppSettings["DevNASCommandPath"]);
                        job.Watch_File = Regex.Replace(job.Watch_File, ConfigurationManager.AppSettings["NonProdFileStoreRootLocation"], ConfigurationManager.AppSettings["DevNASCommandPath"], RegexOptions.IgnoreCase);
                        job.Watch_File = Regex.Replace(job.Watch_File, ConfigurationManager.AppSettings["DalProdFileStoreRootLocation"], ConfigurationManager.AppSettings["DevNASCommandPath"], RegexOptions.IgnoreCase);
                        job.Watch_File = Regex.Replace(job.Watch_File, ConfigurationManager.AppSettings["ChiProdFileStoreRootLocation"], ConfigurationManager.AppSettings["DevNASCommandPath"], RegexOptions.IgnoreCase);
                        job.Watch_File = Regex.Replace(job.Watch_File, ConfigurationManager.AppSettings["StageOldAsaMachine01"], ConfigurationManager.AppSettings["DevNASCommandPath"], RegexOptions.IgnoreCase);
                        job.Watch_File = Regex.Replace(job.Watch_File, ConfigurationManager.AppSettings["StageOldAsaMachine02"], ConfigurationManager.AppSettings["DevNASCommandPath"], RegexOptions.IgnoreCase);
                        job.Watch_File = Regex.Replace(job.Watch_File, ConfigurationManager.AppSettings["StageNewAsaMachine01"], ConfigurationManager.AppSettings["DevNASCommandPath"], RegexOptions.IgnoreCase);
                        job.Watch_File = Regex.Replace(job.Watch_File, ConfigurationManager.AppSettings["StageNewAsaMachine02"], ConfigurationManager.AppSettings["DevNASCommandPath"], RegexOptions.IgnoreCase);
                        job.Watch_File = Regex.Replace(job.Watch_File, ConfigurationManager.AppSettings["CtOldAsaMachine01"], ConfigurationManager.AppSettings["DevNASCommandPath"], RegexOptions.IgnoreCase);
                        job.Watch_File = Regex.Replace(job.Watch_File, ConfigurationManager.AppSettings["CtOldAsaMachine02"], ConfigurationManager.AppSettings["DevNASCommandPath"], RegexOptions.IgnoreCase);
                        job.Watch_File = Regex.Replace(job.Watch_File, ConfigurationManager.AppSettings["CtNewAsaMachine01"], ConfigurationManager.AppSettings["DevNASCommandPath"], RegexOptions.IgnoreCase);
                        job.Watch_File = Regex.Replace(job.Watch_File, ConfigurationManager.AppSettings["CtNewAsaMachine02"], ConfigurationManager.AppSettings["DevNASCommandPath"], RegexOptions.IgnoreCase);
                        job.Watch_File = Regex.Replace(job.Watch_File, ConfigurationManager.AppSettings["DevGwyNewAsaMachine01"], ConfigurationManager.AppSettings["DevNASCommandPath"], RegexOptions.IgnoreCase);
                        job.Watch_File = Regex.Replace(job.Watch_File, ConfigurationManager.AppSettings["DevGwyNewAsaMachine02"], ConfigurationManager.AppSettings["DevNASCommandPath"], RegexOptions.IgnoreCase);
                        job.Watch_File = Regex.Replace(job.Watch_File, ConfigurationManager.AppSettings["StageGwyNewAsaMachine01"], ConfigurationManager.AppSettings["DevNASCommandPath"], RegexOptions.IgnoreCase);
                        job.Watch_File = Regex.Replace(job.Watch_File, ConfigurationManager.AppSettings["StageGwyNewAsaMachine02"], ConfigurationManager.AppSettings["DevNASCommandPath"], RegexOptions.IgnoreCase);
                        job.Watch_File = Regex.Replace(job.Watch_File, ConfigurationManager.AppSettings["CtGwyNewAsaMachine01"], ConfigurationManager.AppSettings["DevNASCommandPath"], RegexOptions.IgnoreCase);
                        job.Watch_File = Regex.Replace(job.Watch_File, ConfigurationManager.AppSettings["CtGwyNewAsaMachine02"], ConfigurationManager.AppSettings["DevNASCommandPath"], RegexOptions.IgnoreCase);
                        job.Watch_File = Regex.Replace(job.Watch_File, ConfigurationManager.AppSettings["NonProdSchedulerNASMachine"], ConfigurationManager.AppSettings["DevNASCommandPath"], RegexOptions.IgnoreCase);
                        job.Watch_File = job.Watch_File.Replace("$$$$", "$$");
                        job.Watch_File = Regex.Replace(job.Watch_File, ConfigurationManager.AppSettings["OldIncomingFilesPath"], ConfigurationManager.AppSettings["NewIncomingFilesPath"], RegexOptions.IgnoreCase);
                        job.Watch_File = Regex.Replace(job.Watch_File, ConfigurationManager.AppSettings["StageFileNameExtension"], ConfigurationManager.AppSettings["DevFileNameExtension"], RegexOptions.IgnoreCase);
                        job.Watch_File = Regex.Replace(job.Watch_File, ConfigurationManager.AppSettings["CtFileNameExtension"], ConfigurationManager.AppSettings["DevFileNameExtension"], RegexOptions.IgnoreCase);
                        job.Watch_File = Regex.Replace(job.Watch_File, ConfigurationManager.AppSettings["ProdFileNameExtension"], ConfigurationManager.AppSettings["DevFileNameExtension"], RegexOptions.IgnoreCase);

                        job.Watch_File = Regex.Replace(job.Watch_File, ConfigurationManager.AppSettings["OldDevRptServer01"], ConfigurationManager.AppSettings["NewDevRptServer01"], RegexOptions.IgnoreCase);
                        job.Watch_File = Regex.Replace(job.Watch_File, ConfigurationManager.AppSettings["OldDevRptServer02"], ConfigurationManager.AppSettings["NewDevRptServer01"], RegexOptions.IgnoreCase);
                        job.Watch_File = Regex.Replace(job.Watch_File, ConfigurationManager.AppSettings["OldStageRptServer01"], ConfigurationManager.AppSettings["NewDevRptServer01"], RegexOptions.IgnoreCase);
                        job.Watch_File = Regex.Replace(job.Watch_File, ConfigurationManager.AppSettings["OldStageRptServer02"], ConfigurationManager.AppSettings["NewDevRptServer01"], RegexOptions.IgnoreCase);
                        job.Watch_File = Regex.Replace(job.Watch_File, ConfigurationManager.AppSettings["OldCtRptServer01"], ConfigurationManager.AppSettings["NewDevRptServer01"], RegexOptions.IgnoreCase);
                        job.Watch_File = Regex.Replace(job.Watch_File, ConfigurationManager.AppSettings["OldCtRptServer02"], ConfigurationManager.AppSettings["NewDevRptServer01"], RegexOptions.IgnoreCase);

                        job.Watch_File = Regex.Replace(job.Watch_File, ConfigurationManager.AppSettings["NewDevRptServer02"], ConfigurationManager.AppSettings["NewDevRptServer01"], RegexOptions.IgnoreCase);
                        job.Watch_File = Regex.Replace(job.Watch_File, ConfigurationManager.AppSettings["NewStageRptServer01"], ConfigurationManager.AppSettings["NewDevRptServer01"], RegexOptions.IgnoreCase);
                        job.Watch_File = Regex.Replace(job.Watch_File, ConfigurationManager.AppSettings["NewStageRptServer02"], ConfigurationManager.AppSettings["NewDevRptServer01"], RegexOptions.IgnoreCase);
                        job.Watch_File = Regex.Replace(job.Watch_File, ConfigurationManager.AppSettings["NewCtRptServer01"], ConfigurationManager.AppSettings["NewDevRptServer01"], RegexOptions.IgnoreCase);
                        job.Watch_File = Regex.Replace(job.Watch_File, ConfigurationManager.AppSettings["NewCtRptServer02"], ConfigurationManager.AppSettings["NewDevRptServer01"], RegexOptions.IgnoreCase);
                    }

                }
                else if (job.Insert_job.Contains(ConfigurationManager.AppSettings["StageBisSubString"]))
                {
                    if (!string.IsNullOrEmpty(job.Machine))
                    {
                        job.Machine = job.Machine.Replace(ConfigurationManager.AppSettings["StageOldAsaMachine01"], ConfigurationManager.AppSettings["StageNewAsaMachine01"]);
                        job.Machine = job.Machine.Replace(ConfigurationManager.AppSettings["StageOldAsaMachine02"], ConfigurationManager.AppSettings["StageNewAsaMachine01"]);
                        job.Machine = job.Machine.ToLower().Replace(ConfigurationManager.AppSettings["DevOldAsaMachine01"], ConfigurationManager.AppSettings["StageNewAsaMachine01"]);
                        job.Machine = job.Machine.ToLower().Replace(ConfigurationManager.AppSettings["DevOldAsaMachine02"], ConfigurationManager.AppSettings["StageNewAsaMachine01"]);
                        job.Machine = job.Machine.ToLower().Replace(ConfigurationManager.AppSettings["DevRealMachineSubString"], ConfigurationManager.AppSettings["StageRealMachineSubString"]);
                        job.Machine = job.Machine.ToLower().Replace(ConfigurationManager.AppSettings["DevVirtualMachineSubString"], ConfigurationManager.AppSettings["StageVirtualMachineSubString"]);
                        job.Machine = job.Machine.ToLower().Replace(ConfigurationManager.AppSettings["CtVirtualMachineSubString"], ConfigurationManager.AppSettings["StageVirtualMachineSubString"]);
                        job.Machine = job.Machine.ToLower().Replace(ConfigurationManager.AppSettings["CtRealMachineSubString"], ConfigurationManager.AppSettings["StageRealMachineSubString"]);
                        job.Machine = job.Machine.ToLower().Replace(ConfigurationManager.AppSettings["CtOldAsaMachine01"], ConfigurationManager.AppSettings["StageNewAsaMachine01"]);
                        job.Machine = job.Machine.ToLower().Replace(ConfigurationManager.AppSettings["CtOldAsaMachine02"], ConfigurationManager.AppSettings["StageNewAsaMachine01"]);
                        if ((job.Machine.Contains(ConfigurationManager.AppSettings["StageNewAsaMachine01"]) || job.Machine.Contains(ConfigurationManager.AppSettings["StageNewAsaMachine02"])) || job.Machine.Contains(ConfigurationManager.AppSettings["StageAsaRealMachine01"]) || job.Machine.Contains(ConfigurationManager.AppSettings["StageAsaRealMachine02"]) || job.Machine.Contains(ConfigurationManager.AppSettings["OldStageAsaRealMachine01"]) || job.Machine.Contains(ConfigurationManager.AppSettings["OldStageAsaRealMachine02"]))
                        {
                            job.Machine = job.Machine.Replace(ConfigurationManager.AppSettings["StageNewAsaMachine01"], ConfigurationManager.AppSettings["StageAsaMachine"]);
                            job.Machine = job.Machine.Replace(ConfigurationManager.AppSettings["StageNewAsaMachine02"], ConfigurationManager.AppSettings["StageAsaMachine"]);
                            job.Machine = job.Machine.Replace(ConfigurationManager.AppSettings["StageAsaRealMachine01"], ConfigurationManager.AppSettings["StageAsaMachine"]);
                            job.Machine = job.Machine.Replace(ConfigurationManager.AppSettings["StageAsaRealMachine02"], ConfigurationManager.AppSettings["StageAsaMachine"]);
                            job.Machine = job.Machine.Replace(ConfigurationManager.AppSettings["OldStageAsaRealMachine01"], ConfigurationManager.AppSettings["StageAsaMachine"]);
                            job.Machine = job.Machine.Replace(ConfigurationManager.AppSettings["OldStageAsaRealMachine02"], ConfigurationManager.AppSettings["StageAsaMachine"]);
                        }
                        else if (job.Machine.Contains(ConfigurationManager.AppSettings["StageGwyMachine01"]) || job.Machine.Contains(ConfigurationManager.AppSettings["StageGwyMachine02"]))
                        {
                            job.Machine = job.Machine.Replace(ConfigurationManager.AppSettings["StageGwyMachine01"], ConfigurationManager.AppSettings["StageGwyAsaMachine"]);
                            job.Machine = job.Machine.Replace(ConfigurationManager.AppSettings["StageGwyMachine02"], ConfigurationManager.AppSettings["StageGwyAsaMachine"]);
                        }

                        //need to check for below
                        if (job.Machine.Contains("od_") && !job.Machine.Contains("_bt1"))
                        {
                            if (!job.Machine.Contains("_pro"))
                                job.Machine = job.Machine.Replace("pro", "");

                            job.Machine = job.Machine.Replace("_2008", "");
                            job.Machine = job.Machine + "_bt1";
                        }

                        if (!job.Machine.Contains(ConfigurationManager.AppSettings["VirtualMachinePrefix"]) && !job.Machine.Contains(ConfigurationManager.AppSettings["LocalHostMachineName"]))
                        {
                            job.Machine = job.Machine.Split(':').First() + ": " + ConfigurationManager.AppSettings["VirtualMachinePrefix"] + job.Machine.Split(':').Last().Trim();
                        }
                    }

                    if (!string.IsNullOrEmpty(job.Owner))
                    {
                        job.Owner = Regex.Replace(job.Owner, ConfigurationManager.AppSettings["DevOwnerPre"], ConfigurationManager.AppSettings["StageOwnerPre"], RegexOptions.IgnoreCase);
                        job.Owner = Regex.Replace(job.Owner, ConfigurationManager.AppSettings["CtOwnerPre"], ConfigurationManager.AppSettings["StageOwnerPre"], RegexOptions.IgnoreCase);
                        job.Owner = Regex.Replace(job.Owner, ConfigurationManager.AppSettings["NewDevOwnerPre"], ConfigurationManager.AppSettings["NewStageOwnerPre"], RegexOptions.IgnoreCase);
                        job.Owner = Regex.Replace(job.Owner, ConfigurationManager.AppSettings["NewCtOwnerPre"], ConfigurationManager.AppSettings["NewStageOwnerPre"], RegexOptions.IgnoreCase);

                        //string ownerName = job.Owner.Split(':').Last().Trim();
                        //if (!ownerName.Contains("_") && !job.Owner.Contains(ConfigurationManager.AppSettings["NewOwnerName"]))
                        //    job.Owner = job.Owner.Split(':').First().Trim() + ":  STA_" + ownerName;

                        job.Owner = Regex.Replace(job.Owner, ConfigurationManager.AppSettings["ProductionOwnerSuffix"], ConfigurationManager.AppSettings["NonProductionOwnerSuffix"].ToUpper(), RegexOptions.IgnoreCase);
                        if (!job.Owner.Contains("_") && !job.Owner.Contains(ConfigurationManager.AppSettings["StageOwnerPrefix"].ToUpper()) && !job.Owner.Contains(ConfigurationManager.AppSettings["NewStageOwnerPre"]))
                            job.Owner = job.Owner.Replace("AsysActionAcct", "STA_AsysActionAcct");
                        if (job.Owner.Contains("AsysActionAcct") && !job.Owner.ToUpper().Contains(ConfigurationManager.AppSettings["NonProductionOwnerSuffix"].ToUpper()))
                        {
                            job.Owner = job.Owner.Replace("AsysActionAcct", "AsysActionAcct@CORP");
                        }
                        if (job.Owner.Contains("BM_"))
                            job.Owner = job.Owner.Replace("BM_", ConfigurationManager.AppSettings["StageOwnerPrefix"].ToUpper());

                        job.Owner = Regex.Replace(job.Owner, "Sta_Sta_", "STA_", RegexOptions.IgnoreCase);
                        job.Owner = Regex.Replace(job.Owner, "sta_", "STA_", RegexOptions.IgnoreCase);
                    }

                    //adding changes for new attributes similar to owner
                    if (!string.IsNullOrEmpty(job.Ftp_Local_User))
                    {
                        job.Ftp_Local_User = Regex.Replace(job.Ftp_Local_User, ConfigurationManager.AppSettings["DevOwnerPre"], ConfigurationManager.AppSettings["StageOwnerPre"], RegexOptions.IgnoreCase);
                        job.Ftp_Local_User = Regex.Replace(job.Ftp_Local_User, ConfigurationManager.AppSettings["CtOwnerPre"], ConfigurationManager.AppSettings["StageOwnerPre"], RegexOptions.IgnoreCase);
                        job.Ftp_Local_User = Regex.Replace(job.Ftp_Local_User, ConfigurationManager.AppSettings["NewDevOwnerPre"], ConfigurationManager.AppSettings["NewStageOwnerPre"], RegexOptions.IgnoreCase);
                        job.Ftp_Local_User = Regex.Replace(job.Ftp_Local_User, ConfigurationManager.AppSettings["NewCtOwnerPre"], ConfigurationManager.AppSettings["NewStageOwnerPre"], RegexOptions.IgnoreCase);

                        job.Ftp_Local_User = Regex.Replace(job.Ftp_Local_User, ConfigurationManager.AppSettings["ProductionOwnerSuffix"], ConfigurationManager.AppSettings["NonProductionOwnerSuffix"].ToUpper(), RegexOptions.IgnoreCase);
                        if (!job.Ftp_Local_User.Contains("_") && !job.Ftp_Local_User.Contains(ConfigurationManager.AppSettings["StageOwnerPrefix"].ToUpper()) && !job.Ftp_Local_User.Contains(ConfigurationManager.AppSettings["NewStageOwnerPre"]))
                            job.Ftp_Local_User = job.Ftp_Local_User.Replace("AsysActionAcct", "STA_AsysActionAcct");
                        if (job.Ftp_Local_User.Contains("AsysActionAcct") && !job.Ftp_Local_User.ToUpper().Contains(ConfigurationManager.AppSettings["NonProductionOwnerSuffix"].ToUpper()))
                        {
                            job.Ftp_Local_User = job.Ftp_Local_User.Replace("AsysActionAcct", "AsysActionAcct@CORP");
                        }
                        if (job.Ftp_Local_User.Contains("BM_"))
                            job.Ftp_Local_User = job.Ftp_Local_User.Replace("BM_", ConfigurationManager.AppSettings["StageOwnerPrefix"].ToUpper());

                        job.Ftp_Local_User = Regex.Replace(job.Ftp_Local_User, "Sta_Sta_", "STA_", RegexOptions.IgnoreCase);
                        job.Ftp_Local_User = Regex.Replace(job.Ftp_Local_User, "sta_", "STA_", RegexOptions.IgnoreCase);
                    }

                    if (!string.IsNullOrEmpty(job.Watch_File_Win_User))
                    {
                        job.Watch_File_Win_User = Regex.Replace(job.Watch_File_Win_User, ConfigurationManager.AppSettings["DevOwnerPre"], ConfigurationManager.AppSettings["StageOwnerPre"], RegexOptions.IgnoreCase);
                        job.Watch_File_Win_User = Regex.Replace(job.Watch_File_Win_User, ConfigurationManager.AppSettings["CtOwnerPre"], ConfigurationManager.AppSettings["StageOwnerPre"], RegexOptions.IgnoreCase);
                        job.Watch_File_Win_User = Regex.Replace(job.Watch_File_Win_User, ConfigurationManager.AppSettings["NewDevOwnerPre"], ConfigurationManager.AppSettings["NewStageOwnerPre"], RegexOptions.IgnoreCase);
                        job.Watch_File_Win_User = Regex.Replace(job.Watch_File_Win_User, ConfigurationManager.AppSettings["NewCtOwnerPre"], ConfigurationManager.AppSettings["NewStageOwnerPre"], RegexOptions.IgnoreCase);

                        job.Watch_File_Win_User = Regex.Replace(job.Watch_File_Win_User, ConfigurationManager.AppSettings["ProductionOwnerSuffix"], ConfigurationManager.AppSettings["NonProductionOwnerSuffix"].ToUpper(), RegexOptions.IgnoreCase);
                        if (!job.Watch_File_Win_User.Contains("_") && !job.Watch_File_Win_User.Contains(ConfigurationManager.AppSettings["StageOwnerPrefix"].ToUpper()) && !job.Watch_File_Win_User.Contains(ConfigurationManager.AppSettings["NewStageOwnerPre"]))
                            job.Watch_File_Win_User = job.Watch_File_Win_User.Replace("AsysActionAcct", "STA_AsysActionAcct");
                        if (job.Watch_File_Win_User.Contains("AsysActionAcct") && !job.Watch_File_Win_User.ToUpper().Contains(ConfigurationManager.AppSettings["NonProductionOwnerSuffix"].ToUpper()))
                        {
                            job.Watch_File_Win_User = job.Watch_File_Win_User.Replace("AsysActionAcct", "AsysActionAcct@CORP");
                        }
                        if (job.Watch_File_Win_User.Contains("BM_"))
                            job.Watch_File_Win_User = job.Watch_File_Win_User.Replace("BM_", ConfigurationManager.AppSettings["StageOwnerPrefix"].ToUpper());

                        job.Watch_File_Win_User = Regex.Replace(job.Watch_File_Win_User, "Sta_Sta_", "STA_", RegexOptions.IgnoreCase);
                        job.Watch_File_Win_User = Regex.Replace(job.Watch_File_Win_User, "sta_", "STA_", RegexOptions.IgnoreCase);
                    }


                    if (!string.IsNullOrEmpty(job.Command))
                    {
                        job.Command = Regex.Replace(job.Command, ConfigurationManager.AppSettings["StageOldAsaMachine01"], ConfigurationManager.AppSettings["StageNASCommandPath"], RegexOptions.IgnoreCase);
                        job.Command = Regex.Replace(job.Command, ConfigurationManager.AppSettings["StageOldAsaMachine02"], ConfigurationManager.AppSettings["StageNASCommandPath"], RegexOptions.IgnoreCase);
                        job.Command = Regex.Replace(job.Command, ConfigurationManager.AppSettings["StageNewAsaMachine01"], ConfigurationManager.AppSettings["StageNASCommandPath"], RegexOptions.IgnoreCase);
                        job.Command = Regex.Replace(job.Command, ConfigurationManager.AppSettings["StageNewAsaMachine02"], ConfigurationManager.AppSettings["StageNASCommandPath"], RegexOptions.IgnoreCase);
                        job.Command = job.Command.Replace(ConfigurationManager.AppSettings["OldDevCommandPath"].Replace("$$$$", "$$"), ConfigurationManager.AppSettings["StageNASCommandPath"]);
                        job.Command = job.Command.Replace(ConfigurationManager.AppSettings["DevCommandPath"].Replace("$$$$", "$$"), ConfigurationManager.AppSettings["StageNASCommandPath"]);
                        job.Command = job.Command.Replace(ConfigurationManager.AppSettings["StageCommandPath"].Replace("$$$$", "$$"), ConfigurationManager.AppSettings["StageNASCommandPath"]);
                        job.Command = job.Command.Replace(ConfigurationManager.AppSettings["CtCommandPath"].Replace("$$$$", "$$"), ConfigurationManager.AppSettings["StageNASCommandPath"]);
                        job.Command = job.Command.Replace(ConfigurationManager.AppSettings["DevNASCommandPath"].Replace("$$$$", "$$"), ConfigurationManager.AppSettings["StageNASCommandPath"]);
                        job.Command = job.Command.Replace(ConfigurationManager.AppSettings["CtNASCommandPath"].Replace("$$$$", "$$"), ConfigurationManager.AppSettings["StageNASCommandPath"]);
                        job.Command = Regex.Replace(job.Command, ConfigurationManager.AppSettings["NonProdFileStoreRootLocation"], ConfigurationManager.AppSettings["StageNASCommandPath"], RegexOptions.IgnoreCase);
                        job.Command = Regex.Replace(job.Command, ConfigurationManager.AppSettings["DalProdFileStoreRootLocation"], ConfigurationManager.AppSettings["StageNASCommandPath"], RegexOptions.IgnoreCase);
                        job.Command = Regex.Replace(job.Command, ConfigurationManager.AppSettings["ChiProdFileStoreRootLocation"], ConfigurationManager.AppSettings["StageNASCommandPath"], RegexOptions.IgnoreCase);
                        job.Command = Regex.Replace(job.Command, ConfigurationManager.AppSettings["DevOldAsaMachine01"], ConfigurationManager.AppSettings["StageNASCommandPath"], RegexOptions.IgnoreCase);
                        job.Command = Regex.Replace(job.Command, ConfigurationManager.AppSettings["DevOldAsaMachine02"], ConfigurationManager.AppSettings["StageNASCommandPath"], RegexOptions.IgnoreCase);
                        job.Command = Regex.Replace(job.Command, ConfigurationManager.AppSettings["DevNewAsaMachine01"], ConfigurationManager.AppSettings["StageNASCommandPath"], RegexOptions.IgnoreCase);
                        job.Command = Regex.Replace(job.Command, ConfigurationManager.AppSettings["DevNewAsaMachine02"], ConfigurationManager.AppSettings["StageNASCommandPath"], RegexOptions.IgnoreCase);
                        job.Command = Regex.Replace(job.Command, ConfigurationManager.AppSettings["CtOldAsaMachine01"], ConfigurationManager.AppSettings["StageNASCommandPath"], RegexOptions.IgnoreCase);
                        job.Command = Regex.Replace(job.Command, ConfigurationManager.AppSettings["CtOldAsaMachine02"], ConfigurationManager.AppSettings["StageNASCommandPath"], RegexOptions.IgnoreCase);
                        job.Command = Regex.Replace(job.Command, ConfigurationManager.AppSettings["CtNewAsaMachine01"], ConfigurationManager.AppSettings["StageNASCommandPath"], RegexOptions.IgnoreCase);
                        job.Command = Regex.Replace(job.Command, ConfigurationManager.AppSettings["CtNewAsaMachine02"], ConfigurationManager.AppSettings["StageNASCommandPath"], RegexOptions.IgnoreCase);
                        job.Command = Regex.Replace(job.Command, ConfigurationManager.AppSettings["DevGwyNewAsaMachine01"], ConfigurationManager.AppSettings["StageNASCommandPath"], RegexOptions.IgnoreCase);
                        job.Command = Regex.Replace(job.Command, ConfigurationManager.AppSettings["DevGwyNewAsaMachine02"], ConfigurationManager.AppSettings["StageNASCommandPath"], RegexOptions.IgnoreCase);
                        job.Command = Regex.Replace(job.Command, ConfigurationManager.AppSettings["StageGwyNewAsaMachine01"], ConfigurationManager.AppSettings["StageNASCommandPath"], RegexOptions.IgnoreCase);
                        job.Command = Regex.Replace(job.Command, ConfigurationManager.AppSettings["StageGwyNewAsaMachine02"], ConfigurationManager.AppSettings["StageNASCommandPath"], RegexOptions.IgnoreCase);
                        job.Command = Regex.Replace(job.Command, ConfigurationManager.AppSettings["CtGwyNewAsaMachine01"], ConfigurationManager.AppSettings["StageNASCommandPath"], RegexOptions.IgnoreCase);
                        job.Command = Regex.Replace(job.Command, ConfigurationManager.AppSettings["CtGwyNewAsaMachine02"], ConfigurationManager.AppSettings["StageNASCommandPath"], RegexOptions.IgnoreCase);
                        job.Command = Regex.Replace(job.Command, ConfigurationManager.AppSettings["NonProdSchedulerNASMachine"], ConfigurationManager.AppSettings["StageNASCommandPath"], RegexOptions.IgnoreCase);
                        job.Command = job.Command.Replace("$$$$", "$$");
                        job.Command = job.Command.Replace(StringConstants.DEV_BSL_JOBS_SUBSTRING, StringConstants.STAGE_BIS_JOBS_SUBSTRING);
                        job.Command = job.Command.Replace(StringConstants.CT_BSL_JOBS_SUBSTRING, StringConstants.STAGE_BIS_JOBS_SUBSTRING);
                        job.Command = job.Command.Replace(StringConstants.PROD_BSL_JOBS_SUBSTRING, StringConstants.STAGE_BIS_JOBS_SUBSTRING);
                        job.Command = Regex.Replace(job.Command, ConfigurationManager.AppSettings["OldIncomingFilesPath"], ConfigurationManager.AppSettings["NewIncomingFilesPath"], RegexOptions.IgnoreCase);
                        job.Command = Regex.Replace(job.Command, ConfigurationManager.AppSettings["DevFileNameExtension"], ConfigurationManager.AppSettings["StageFileNameExtension"], RegexOptions.IgnoreCase);
                        job.Command = Regex.Replace(job.Command, ConfigurationManager.AppSettings["CtFileNameExtension"], ConfigurationManager.AppSettings["StageFileNameExtension"], RegexOptions.IgnoreCase);
                        job.Command = Regex.Replace(job.Command, ConfigurationManager.AppSettings["ProdFileNameExtension"], ConfigurationManager.AppSettings["StageFileNameExtension"], RegexOptions.IgnoreCase);

                        job.Command = Regex.Replace(job.Command, ConfigurationManager.AppSettings["OldDevRptServer01"], ConfigurationManager.AppSettings["NewStageRptServer01"], RegexOptions.IgnoreCase);
                        job.Command = Regex.Replace(job.Command, ConfigurationManager.AppSettings["OldDevRptServer02"], ConfigurationManager.AppSettings["NewStageRptServer01"], RegexOptions.IgnoreCase);
                        job.Command = Regex.Replace(job.Command, ConfigurationManager.AppSettings["OldStageRptServer01"], ConfigurationManager.AppSettings["NewStageRptServer01"], RegexOptions.IgnoreCase);
                        job.Command = Regex.Replace(job.Command, ConfigurationManager.AppSettings["OldStageRptServer02"], ConfigurationManager.AppSettings["NewStageRptServer01"], RegexOptions.IgnoreCase);
                        job.Command = Regex.Replace(job.Command, ConfigurationManager.AppSettings["OldCtRptServer01"], ConfigurationManager.AppSettings["NewStageRptServer01"], RegexOptions.IgnoreCase);
                        job.Command = Regex.Replace(job.Command, ConfigurationManager.AppSettings["OldCtRptServer02"], ConfigurationManager.AppSettings["NewStageRptServer01"], RegexOptions.IgnoreCase);

                        job.Command = Regex.Replace(job.Command, ConfigurationManager.AppSettings["NewStageRptServer02"], ConfigurationManager.AppSettings["NewStageRptServer01"], RegexOptions.IgnoreCase);
                        job.Command = Regex.Replace(job.Command, ConfigurationManager.AppSettings["NewDevRptServer01"], ConfigurationManager.AppSettings["NewStageRptServer01"], RegexOptions.IgnoreCase);
                        job.Command = Regex.Replace(job.Command, ConfigurationManager.AppSettings["NewDevRptServer02"], ConfigurationManager.AppSettings["NewStageRptServer01"], RegexOptions.IgnoreCase);
                        job.Command = Regex.Replace(job.Command, ConfigurationManager.AppSettings["NewCtRptServer01"], ConfigurationManager.AppSettings["NewStageRptServer01"], RegexOptions.IgnoreCase);
                        job.Command = Regex.Replace(job.Command, ConfigurationManager.AppSettings["NewCtRptServer02"], ConfigurationManager.AppSettings["NewStageRptServer01"], RegexOptions.IgnoreCase);
                    }

                    //adding changes for new attributes similar to command
                    if (!string.IsNullOrEmpty(job.Ftp_Local_Name))
                    {
                        job.Ftp_Local_Name = Regex.Replace(job.Ftp_Local_Name, ConfigurationManager.AppSettings["StageOldAsaMachine01"], ConfigurationManager.AppSettings["StageNASCommandPath"], RegexOptions.IgnoreCase);
                        job.Ftp_Local_Name = Regex.Replace(job.Ftp_Local_Name, ConfigurationManager.AppSettings["StageOldAsaMachine02"], ConfigurationManager.AppSettings["StageNASCommandPath"], RegexOptions.IgnoreCase);
                        job.Ftp_Local_Name = Regex.Replace(job.Ftp_Local_Name, ConfigurationManager.AppSettings["StageNewAsaMachine01"], ConfigurationManager.AppSettings["StageNASCommandPath"], RegexOptions.IgnoreCase);
                        job.Ftp_Local_Name = Regex.Replace(job.Ftp_Local_Name, ConfigurationManager.AppSettings["StageNewAsaMachine02"], ConfigurationManager.AppSettings["StageNASCommandPath"], RegexOptions.IgnoreCase);
                        job.Ftp_Local_Name = job.Ftp_Local_Name.Replace(ConfigurationManager.AppSettings["OldDevCommandPath"].Replace("$$$$", "$$"), ConfigurationManager.AppSettings["StageNASCommandPath"]);
                        job.Ftp_Local_Name = job.Ftp_Local_Name.Replace(ConfigurationManager.AppSettings["DevCommandPath"].Replace("$$$$", "$$"), ConfigurationManager.AppSettings["StageNASCommandPath"]);
                        job.Ftp_Local_Name = job.Ftp_Local_Name.Replace(ConfigurationManager.AppSettings["StageCommandPath"].Replace("$$$$", "$$"), ConfigurationManager.AppSettings["StageNASCommandPath"]);
                        job.Ftp_Local_Name = job.Ftp_Local_Name.Replace(ConfigurationManager.AppSettings["CtCommandPath"].Replace("$$$$", "$$"), ConfigurationManager.AppSettings["StageNASCommandPath"]);
                        job.Ftp_Local_Name = job.Ftp_Local_Name.Replace(ConfigurationManager.AppSettings["DevNASCommandPath"].Replace("$$$$", "$$"), ConfigurationManager.AppSettings["StageNASCommandPath"]);
                        job.Ftp_Local_Name = job.Ftp_Local_Name.Replace(ConfigurationManager.AppSettings["CtNASCommandPath"].Replace("$$$$", "$$"), ConfigurationManager.AppSettings["StageNASCommandPath"]);
                        job.Ftp_Local_Name = Regex.Replace(job.Ftp_Local_Name, ConfigurationManager.AppSettings["NonProdFileStoreRootLocation"], ConfigurationManager.AppSettings["StageNASCommandPath"], RegexOptions.IgnoreCase);
                        job.Ftp_Local_Name = Regex.Replace(job.Ftp_Local_Name, ConfigurationManager.AppSettings["DalProdFileStoreRootLocation"], ConfigurationManager.AppSettings["StageNASCommandPath"], RegexOptions.IgnoreCase);
                        job.Ftp_Local_Name = Regex.Replace(job.Ftp_Local_Name, ConfigurationManager.AppSettings["ChiProdFileStoreRootLocation"], ConfigurationManager.AppSettings["StageNASCommandPath"], RegexOptions.IgnoreCase);
                        job.Ftp_Local_Name = Regex.Replace(job.Ftp_Local_Name, ConfigurationManager.AppSettings["DevOldAsaMachine01"], ConfigurationManager.AppSettings["StageNASCommandPath"], RegexOptions.IgnoreCase);
                        job.Ftp_Local_Name = Regex.Replace(job.Ftp_Local_Name, ConfigurationManager.AppSettings["DevOldAsaMachine02"], ConfigurationManager.AppSettings["StageNASCommandPath"], RegexOptions.IgnoreCase);
                        job.Ftp_Local_Name = Regex.Replace(job.Ftp_Local_Name, ConfigurationManager.AppSettings["DevNewAsaMachine01"], ConfigurationManager.AppSettings["StageNASCommandPath"], RegexOptions.IgnoreCase);
                        job.Ftp_Local_Name = Regex.Replace(job.Ftp_Local_Name, ConfigurationManager.AppSettings["DevNewAsaMachine02"], ConfigurationManager.AppSettings["StageNASCommandPath"], RegexOptions.IgnoreCase);
                        job.Ftp_Local_Name = Regex.Replace(job.Ftp_Local_Name, ConfigurationManager.AppSettings["CtOldAsaMachine01"], ConfigurationManager.AppSettings["StageNASCommandPath"], RegexOptions.IgnoreCase);
                        job.Ftp_Local_Name = Regex.Replace(job.Ftp_Local_Name, ConfigurationManager.AppSettings["CtOldAsaMachine02"], ConfigurationManager.AppSettings["StageNASCommandPath"], RegexOptions.IgnoreCase);
                        job.Ftp_Local_Name = Regex.Replace(job.Ftp_Local_Name, ConfigurationManager.AppSettings["CtNewAsaMachine01"], ConfigurationManager.AppSettings["StageNASCommandPath"], RegexOptions.IgnoreCase);
                        job.Ftp_Local_Name = Regex.Replace(job.Ftp_Local_Name, ConfigurationManager.AppSettings["CtNewAsaMachine02"], ConfigurationManager.AppSettings["StageNASCommandPath"], RegexOptions.IgnoreCase);
                        job.Ftp_Local_Name = Regex.Replace(job.Ftp_Local_Name, ConfigurationManager.AppSettings["DevGwyNewAsaMachine01"], ConfigurationManager.AppSettings["StageNASCommandPath"], RegexOptions.IgnoreCase);
                        job.Ftp_Local_Name = Regex.Replace(job.Ftp_Local_Name, ConfigurationManager.AppSettings["DevGwyNewAsaMachine02"], ConfigurationManager.AppSettings["StageNASCommandPath"], RegexOptions.IgnoreCase);
                        job.Ftp_Local_Name = Regex.Replace(job.Ftp_Local_Name, ConfigurationManager.AppSettings["StageGwyNewAsaMachine01"], ConfigurationManager.AppSettings["StageNASCommandPath"], RegexOptions.IgnoreCase);
                        job.Ftp_Local_Name = Regex.Replace(job.Ftp_Local_Name, ConfigurationManager.AppSettings["StageGwyNewAsaMachine02"], ConfigurationManager.AppSettings["StageNASCommandPath"], RegexOptions.IgnoreCase);
                        job.Ftp_Local_Name = Regex.Replace(job.Ftp_Local_Name, ConfigurationManager.AppSettings["CtGwyNewAsaMachine01"], ConfigurationManager.AppSettings["StageNASCommandPath"], RegexOptions.IgnoreCase);
                        job.Ftp_Local_Name = Regex.Replace(job.Ftp_Local_Name, ConfigurationManager.AppSettings["CtGwyNewAsaMachine02"], ConfigurationManager.AppSettings["StageNASCommandPath"], RegexOptions.IgnoreCase);
                        job.Ftp_Local_Name = Regex.Replace(job.Ftp_Local_Name, ConfigurationManager.AppSettings["NonProdSchedulerNASMachine"], ConfigurationManager.AppSettings["StageNASCommandPath"], RegexOptions.IgnoreCase);
                        job.Ftp_Local_Name = job.Ftp_Local_Name.Replace("$$$$", "$$");
                        job.Ftp_Local_Name = Regex.Replace(job.Ftp_Local_Name, ConfigurationManager.AppSettings["OldIncomingFilesPath"], ConfigurationManager.AppSettings["NewIncomingFilesPath"], RegexOptions.IgnoreCase);
                        job.Ftp_Local_Name = Regex.Replace(job.Ftp_Local_Name, ConfigurationManager.AppSettings["DevFileNameExtension"], ConfigurationManager.AppSettings["StageFileNameExtension"], RegexOptions.IgnoreCase);
                        job.Ftp_Local_Name = Regex.Replace(job.Ftp_Local_Name, ConfigurationManager.AppSettings["CtFileNameExtension"], ConfigurationManager.AppSettings["StageFileNameExtension"], RegexOptions.IgnoreCase);
                        job.Ftp_Local_Name = Regex.Replace(job.Ftp_Local_Name, ConfigurationManager.AppSettings["ProdFileNameExtension"], ConfigurationManager.AppSettings["StageFileNameExtension"], RegexOptions.IgnoreCase);

                        job.Ftp_Local_Name = Regex.Replace(job.Ftp_Local_Name, ConfigurationManager.AppSettings["OldDevRptServer01"], ConfigurationManager.AppSettings["NewStageRptServer01"], RegexOptions.IgnoreCase);
                        job.Ftp_Local_Name = Regex.Replace(job.Ftp_Local_Name, ConfigurationManager.AppSettings["OldDevRptServer02"], ConfigurationManager.AppSettings["NewStageRptServer01"], RegexOptions.IgnoreCase);
                        job.Ftp_Local_Name = Regex.Replace(job.Ftp_Local_Name, ConfigurationManager.AppSettings["OldStageRptServer01"], ConfigurationManager.AppSettings["NewStageRptServer01"], RegexOptions.IgnoreCase);
                        job.Ftp_Local_Name = Regex.Replace(job.Ftp_Local_Name, ConfigurationManager.AppSettings["OldStageRptServer02"], ConfigurationManager.AppSettings["NewStageRptServer01"], RegexOptions.IgnoreCase);
                        job.Ftp_Local_Name = Regex.Replace(job.Ftp_Local_Name, ConfigurationManager.AppSettings["OldCtRptServer01"], ConfigurationManager.AppSettings["NewStageRptServer01"], RegexOptions.IgnoreCase);
                        job.Ftp_Local_Name = Regex.Replace(job.Ftp_Local_Name, ConfigurationManager.AppSettings["OldCtRptServer02"], ConfigurationManager.AppSettings["NewStageRptServer01"], RegexOptions.IgnoreCase);

                        job.Ftp_Local_Name = Regex.Replace(job.Ftp_Local_Name, ConfigurationManager.AppSettings["NewStageRptServer02"], ConfigurationManager.AppSettings["NewStageRptServer01"], RegexOptions.IgnoreCase);
                        job.Ftp_Local_Name = Regex.Replace(job.Ftp_Local_Name, ConfigurationManager.AppSettings["NewDevRptServer01"], ConfigurationManager.AppSettings["NewStageRptServer01"], RegexOptions.IgnoreCase);
                        job.Ftp_Local_Name = Regex.Replace(job.Ftp_Local_Name, ConfigurationManager.AppSettings["NewDevRptServer02"], ConfigurationManager.AppSettings["NewStageRptServer01"], RegexOptions.IgnoreCase);
                        job.Ftp_Local_Name = Regex.Replace(job.Ftp_Local_Name, ConfigurationManager.AppSettings["NewCtRptServer01"], ConfigurationManager.AppSettings["NewStageRptServer01"], RegexOptions.IgnoreCase);
                        job.Ftp_Local_Name = Regex.Replace(job.Ftp_Local_Name, ConfigurationManager.AppSettings["NewCtRptServer02"], ConfigurationManager.AppSettings["NewStageRptServer01"], RegexOptions.IgnoreCase);
                    }

                    if (!string.IsNullOrEmpty(job.Watch_File))
                    {
                        job.Watch_File = Regex.Replace(job.Watch_File, ConfigurationManager.AppSettings["StageOldAsaMachine01"], ConfigurationManager.AppSettings["StageNASCommandPath"], RegexOptions.IgnoreCase);
                        job.Watch_File = Regex.Replace(job.Watch_File, ConfigurationManager.AppSettings["StageOldAsaMachine02"], ConfigurationManager.AppSettings["StageNASCommandPath"], RegexOptions.IgnoreCase);
                        job.Watch_File = Regex.Replace(job.Watch_File, ConfigurationManager.AppSettings["StageNewAsaMachine01"], ConfigurationManager.AppSettings["StageNASCommandPath"], RegexOptions.IgnoreCase);
                        job.Watch_File = Regex.Replace(job.Watch_File, ConfigurationManager.AppSettings["StageNewAsaMachine02"], ConfigurationManager.AppSettings["StageNASCommandPath"], RegexOptions.IgnoreCase);
                        job.Watch_File = job.Watch_File.Replace(ConfigurationManager.AppSettings["OldDevCommandPath"].Replace("$$$$", "$$"), ConfigurationManager.AppSettings["StageNASCommandPath"]);
                        job.Watch_File = job.Watch_File.Replace(ConfigurationManager.AppSettings["DevCommandPath"].Replace("$$$$", "$$"), ConfigurationManager.AppSettings["StageNASCommandPath"]);
                        job.Watch_File = job.Watch_File.Replace(ConfigurationManager.AppSettings["StageCommandPath"].Replace("$$$$", "$$"), ConfigurationManager.AppSettings["StageNASCommandPath"]);
                        job.Watch_File = job.Watch_File.Replace(ConfigurationManager.AppSettings["CtCommandPath"].Replace("$$$$", "$$"), ConfigurationManager.AppSettings["StageNASCommandPath"]);
                        job.Watch_File = job.Watch_File.Replace(ConfigurationManager.AppSettings["DevNASCommandPath"].Replace("$$$$", "$$"), ConfigurationManager.AppSettings["StageNASCommandPath"]);
                        job.Watch_File = job.Watch_File.Replace(ConfigurationManager.AppSettings["CtNASCommandPath"].Replace("$$$$", "$$"), ConfigurationManager.AppSettings["StageNASCommandPath"]);
                        job.Watch_File = Regex.Replace(job.Watch_File, ConfigurationManager.AppSettings["NonProdFileStoreRootLocation"], ConfigurationManager.AppSettings["StageNASCommandPath"], RegexOptions.IgnoreCase);
                        job.Watch_File = Regex.Replace(job.Watch_File, ConfigurationManager.AppSettings["DalProdFileStoreRootLocation"], ConfigurationManager.AppSettings["StageNASCommandPath"], RegexOptions.IgnoreCase);
                        job.Watch_File = Regex.Replace(job.Watch_File, ConfigurationManager.AppSettings["ChiProdFileStoreRootLocation"], ConfigurationManager.AppSettings["StageNASCommandPath"], RegexOptions.IgnoreCase);
                        job.Watch_File = Regex.Replace(job.Watch_File, ConfigurationManager.AppSettings["DevOldAsaMachine01"], ConfigurationManager.AppSettings["StageNASCommandPath"], RegexOptions.IgnoreCase);
                        job.Watch_File = Regex.Replace(job.Watch_File, ConfigurationManager.AppSettings["DevOldAsaMachine02"], ConfigurationManager.AppSettings["StageNASCommandPath"], RegexOptions.IgnoreCase);
                        job.Watch_File = Regex.Replace(job.Watch_File, ConfigurationManager.AppSettings["DevNewAsaMachine01"], ConfigurationManager.AppSettings["StageNASCommandPath"], RegexOptions.IgnoreCase);
                        job.Watch_File = Regex.Replace(job.Watch_File, ConfigurationManager.AppSettings["DevNewAsaMachine02"], ConfigurationManager.AppSettings["StageNASCommandPath"], RegexOptions.IgnoreCase);
                        job.Watch_File = Regex.Replace(job.Watch_File, ConfigurationManager.AppSettings["CtOldAsaMachine01"], ConfigurationManager.AppSettings["StageNASCommandPath"], RegexOptions.IgnoreCase);
                        job.Watch_File = Regex.Replace(job.Watch_File, ConfigurationManager.AppSettings["CtOldAsaMachine02"], ConfigurationManager.AppSettings["StageNASCommandPath"], RegexOptions.IgnoreCase);
                        job.Watch_File = Regex.Replace(job.Watch_File, ConfigurationManager.AppSettings["CtNewAsaMachine01"], ConfigurationManager.AppSettings["StageNASCommandPath"], RegexOptions.IgnoreCase);
                        job.Watch_File = Regex.Replace(job.Watch_File, ConfigurationManager.AppSettings["CtNewAsaMachine02"], ConfigurationManager.AppSettings["StageNASCommandPath"], RegexOptions.IgnoreCase);
                        job.Watch_File = Regex.Replace(job.Watch_File, ConfigurationManager.AppSettings["DevGwyNewAsaMachine01"], ConfigurationManager.AppSettings["StageNASCommandPath"], RegexOptions.IgnoreCase);
                        job.Watch_File = Regex.Replace(job.Watch_File, ConfigurationManager.AppSettings["DevGwyNewAsaMachine02"], ConfigurationManager.AppSettings["StageNASCommandPath"], RegexOptions.IgnoreCase);
                        job.Watch_File = Regex.Replace(job.Watch_File, ConfigurationManager.AppSettings["StageGwyNewAsaMachine01"], ConfigurationManager.AppSettings["StageNASCommandPath"], RegexOptions.IgnoreCase);
                        job.Watch_File = Regex.Replace(job.Watch_File, ConfigurationManager.AppSettings["StageGwyNewAsaMachine02"], ConfigurationManager.AppSettings["StageNASCommandPath"], RegexOptions.IgnoreCase);
                        job.Watch_File = Regex.Replace(job.Watch_File, ConfigurationManager.AppSettings["CtGwyNewAsaMachine01"], ConfigurationManager.AppSettings["StageNASCommandPath"], RegexOptions.IgnoreCase);
                        job.Watch_File = Regex.Replace(job.Watch_File, ConfigurationManager.AppSettings["CtGwyNewAsaMachine02"], ConfigurationManager.AppSettings["StageNASCommandPath"], RegexOptions.IgnoreCase);
                        job.Watch_File = Regex.Replace(job.Watch_File, ConfigurationManager.AppSettings["NonProdSchedulerNASMachine"], ConfigurationManager.AppSettings["StageNASCommandPath"], RegexOptions.IgnoreCase);
                        job.Watch_File = job.Watch_File.Replace("$$$$", "$$");
                        job.Watch_File = Regex.Replace(job.Watch_File, ConfigurationManager.AppSettings["OldIncomingFilesPath"], ConfigurationManager.AppSettings["NewIncomingFilesPath"], RegexOptions.IgnoreCase);
                        job.Watch_File = Regex.Replace(job.Watch_File, ConfigurationManager.AppSettings["DevFileNameExtension"], ConfigurationManager.AppSettings["StageFileNameExtension"], RegexOptions.IgnoreCase);
                        job.Watch_File = Regex.Replace(job.Watch_File, ConfigurationManager.AppSettings["CtFileNameExtension"], ConfigurationManager.AppSettings["StageFileNameExtension"], RegexOptions.IgnoreCase);
                        job.Watch_File = Regex.Replace(job.Watch_File, ConfigurationManager.AppSettings["ProdFileNameExtension"], ConfigurationManager.AppSettings["StageFileNameExtension"], RegexOptions.IgnoreCase);

                        job.Watch_File = Regex.Replace(job.Watch_File, ConfigurationManager.AppSettings["OldDevRptServer01"], ConfigurationManager.AppSettings["NewStageRptServer01"], RegexOptions.IgnoreCase);
                        job.Watch_File = Regex.Replace(job.Watch_File, ConfigurationManager.AppSettings["OldDevRptServer02"], ConfigurationManager.AppSettings["NewStageRptServer01"], RegexOptions.IgnoreCase);
                        job.Watch_File = Regex.Replace(job.Watch_File, ConfigurationManager.AppSettings["OldStageRptServer01"], ConfigurationManager.AppSettings["NewStageRptServer01"], RegexOptions.IgnoreCase);
                        job.Watch_File = Regex.Replace(job.Watch_File, ConfigurationManager.AppSettings["OldStageRptServer02"], ConfigurationManager.AppSettings["NewStageRptServer01"], RegexOptions.IgnoreCase);
                        job.Watch_File = Regex.Replace(job.Watch_File, ConfigurationManager.AppSettings["OldCtRptServer01"], ConfigurationManager.AppSettings["NewStageRptServer01"], RegexOptions.IgnoreCase);
                        job.Watch_File = Regex.Replace(job.Watch_File, ConfigurationManager.AppSettings["OldCtRptServer02"], ConfigurationManager.AppSettings["NewStageRptServer01"], RegexOptions.IgnoreCase);

                        job.Watch_File = Regex.Replace(job.Watch_File, ConfigurationManager.AppSettings["NewStageRptServer02"], ConfigurationManager.AppSettings["NewStageRptServer01"], RegexOptions.IgnoreCase);
                        job.Watch_File = Regex.Replace(job.Watch_File, ConfigurationManager.AppSettings["NewDevRptServer01"], ConfigurationManager.AppSettings["NewStageRptServer01"], RegexOptions.IgnoreCase);
                        job.Watch_File = Regex.Replace(job.Watch_File, ConfigurationManager.AppSettings["NewDevRptServer02"], ConfigurationManager.AppSettings["NewStageRptServer01"], RegexOptions.IgnoreCase);
                        job.Watch_File = Regex.Replace(job.Watch_File, ConfigurationManager.AppSettings["NewCtRptServer01"], ConfigurationManager.AppSettings["NewStageRptServer01"], RegexOptions.IgnoreCase);
                        job.Watch_File = Regex.Replace(job.Watch_File, ConfigurationManager.AppSettings["NewCtRptServer02"], ConfigurationManager.AppSettings["NewStageRptServer01"], RegexOptions.IgnoreCase);
                    }
                }
                else if (job.Insert_job.Contains(ConfigurationManager.AppSettings["CtBisSubString"]))
                {
                    if (!string.IsNullOrEmpty(job.Machine))
                    {
                        job.Machine = job.Machine.Replace(ConfigurationManager.AppSettings["CtOldAsaMachine01"], ConfigurationManager.AppSettings["CtNewAsaMachine01"]);
                        job.Machine = job.Machine.Replace(ConfigurationManager.AppSettings["CtOldAsaMachine02"], ConfigurationManager.AppSettings["CtNewAsaMachine01"]);
                        job.Machine = job.Machine.ToLower().Replace(ConfigurationManager.AppSettings["DevRealMachineSubString"], ConfigurationManager.AppSettings["CtRealMachineSubString"]);
                        job.Machine = job.Machine.ToLower().Replace(ConfigurationManager.AppSettings["DevOldAsaMachine01"], ConfigurationManager.AppSettings["CtNewAsaMachine01"]);
                        job.Machine = job.Machine.ToLower().Replace(ConfigurationManager.AppSettings["DevOldAsaMachine02"], ConfigurationManager.AppSettings["CtNewAsaMachine01"]);
                        job.Machine = job.Machine.ToLower().Replace(ConfigurationManager.AppSettings["DevVirtualMachineSubString"], ConfigurationManager.AppSettings["CtVirtualMachineSubString"]);
                        job.Machine = job.Machine.ToLower().Replace(ConfigurationManager.AppSettings["StageVirtualMachineSubString"], ConfigurationManager.AppSettings["CtVirtualMachineSubString"]);
                        job.Machine = job.Machine.ToLower().Replace(ConfigurationManager.AppSettings["StageRealMachineSubString"], ConfigurationManager.AppSettings["CtRealMachineSubString"]);
                        job.Machine = job.Machine.ToLower().Replace(ConfigurationManager.AppSettings["StageOldAsaMachine01"], ConfigurationManager.AppSettings["CtMachineSubString"]);
                        job.Machine = job.Machine.ToLower().Replace(ConfigurationManager.AppSettings["StageOldAsaMachine02"], ConfigurationManager.AppSettings["CtMachineSubString"]);
                        if ((job.Machine.Contains(ConfigurationManager.AppSettings["CtNewAsaMachine01"]) || job.Machine.Contains(ConfigurationManager.AppSettings["CtNewAsaMachine02"])) || job.Machine.Contains(ConfigurationManager.AppSettings["CtNewAsaMachine01"]) || job.Machine.Contains(ConfigurationManager.AppSettings["CtAsaRealMachine02"]) || job.Machine.Contains(ConfigurationManager.AppSettings["OldCtAsaRealMachine01"]) || job.Machine.Contains(ConfigurationManager.AppSettings["OldCtAsaRealMachine02"]))
                        {
                            job.Machine = job.Machine.Replace(ConfigurationManager.AppSettings["CtNewAsaMachine01"], ConfigurationManager.AppSettings["CtAsaMachine"]);
                            job.Machine = job.Machine.Replace(ConfigurationManager.AppSettings["CtNewAsaMachine02"], ConfigurationManager.AppSettings["CtAsaMachine"]);
                            job.Machine = job.Machine.Replace(ConfigurationManager.AppSettings["CtAsaRealMachine01"], ConfigurationManager.AppSettings["CtAsaMachine"]);
                            job.Machine = job.Machine.Replace(ConfigurationManager.AppSettings["CtAsaRealMachine02"], ConfigurationManager.AppSettings["CtAsaMachine"]);
                            job.Machine = job.Machine.Replace(ConfigurationManager.AppSettings["OldCtAsaRealMachine01"], ConfigurationManager.AppSettings["CtAsaMachine"]);
                            job.Machine = job.Machine.Replace(ConfigurationManager.AppSettings["OldCtAsaRealMachine02"], ConfigurationManager.AppSettings["CtAsaMachine"]);
                        }
                        else if (job.Machine.Contains(ConfigurationManager.AppSettings["CtGwyMachine01"]) || job.Machine.Contains(ConfigurationManager.AppSettings["CtGwyMachine02"]))
                        {
                            job.Machine = job.Machine.Replace(ConfigurationManager.AppSettings["CtGwyMachine01"], ConfigurationManager.AppSettings["CtGwyAsaMachine"]);
                            job.Machine = job.Machine.Replace(ConfigurationManager.AppSettings["CtGwyMachine02"], ConfigurationManager.AppSettings["CtGwyAsaMachine"]);
                        }


                        //need to check for below
                        if (job.Machine.Contains("od_") && !job.Machine.Contains("_bt2"))
                        {
                            if (!job.Machine.Contains("_pro"))
                                job.Machine = job.Machine.Replace("pro", "");

                            job.Machine = job.Machine.Replace("_2008", "");
                            job.Machine = job.Machine + "_bt2";
                        }

                        if (!job.Machine.Contains(ConfigurationManager.AppSettings["VirtualMachinePrefix"]) && !job.Machine.Contains(ConfigurationManager.AppSettings["LocalHostMachineName"]))
                        {
                            job.Machine = job.Machine.Split(':').First() + ": " + ConfigurationManager.AppSettings["VirtualMachinePrefix"] + job.Machine.Split(':').Last().Trim();
                        }
                    }

                    if (!string.IsNullOrEmpty(job.Owner))
                    {
                        job.Owner = Regex.Replace(job.Owner, ConfigurationManager.AppSettings["DevOwnerPre"], ConfigurationManager.AppSettings["CtOwnerPre"], RegexOptions.IgnoreCase);
                        job.Owner = Regex.Replace(job.Owner, ConfigurationManager.AppSettings["StageOwnerPre"], ConfigurationManager.AppSettings["CtOwnerPre"], RegexOptions.IgnoreCase);
                        job.Owner = Regex.Replace(job.Owner, ConfigurationManager.AppSettings["NewDevOwnerPre"], ConfigurationManager.AppSettings["NewCtOwnerPre"], RegexOptions.IgnoreCase);
                        job.Owner = Regex.Replace(job.Owner, ConfigurationManager.AppSettings["NewStageOwnerPre"], ConfigurationManager.AppSettings["NewCtOwnerPre"], RegexOptions.IgnoreCase);

                        //string ownerName = job.Owner.Split(':').Last().Trim();
                        //if (!ownerName.Contains("_") && !job.Owner.Contains(ConfigurationManager.AppSettings["NewOwnerName"]))
                        //    job.Owner = job.Owner.Split(':').First().Trim() + ":  CT1_" + ownerName;

                        job.Owner = Regex.Replace(job.Owner, ConfigurationManager.AppSettings["ProductionOwnerSuffix"], ConfigurationManager.AppSettings["NonProductionOwnerSuffix"].ToUpper(), RegexOptions.IgnoreCase);
                        if (!job.Owner.Contains("_") && !job.Owner.Contains(ConfigurationManager.AppSettings["CtOwnerPrefix"].ToUpper()) && !job.Owner.Contains(ConfigurationManager.AppSettings["NewCtOwnerPre"]))
                            job.Owner = job.Owner.Replace("AsysActionAcct", "CT1_AsysActionAcct");
                        if (job.Owner.Contains("AsysActionAcct") && !job.Owner.ToUpper().Contains(ConfigurationManager.AppSettings["NonProductionOwnerSuffix"].ToUpper()))
                        {
                            job.Owner = job.Owner.Replace("AsysActionAcct", "AsysActionAcct@CORP");
                        }
                        if (job.Owner.Contains("BM_"))
                            job.Owner = job.Owner.Replace("BM_", ConfigurationManager.AppSettings["CtOwnerPrefix"].ToUpper());

                        job.Owner = Regex.Replace(job.Owner, "Ct1_Ct1_", "CT1_", RegexOptions.IgnoreCase);
                        job.Owner = Regex.Replace(job.Owner, "ct1_", "CT1_", RegexOptions.IgnoreCase);
                    }

                    //adding changes in new attributes similar to owner
                    if (!string.IsNullOrEmpty(job.Ftp_Local_User))
                    {
                        job.Ftp_Local_User = Regex.Replace(job.Ftp_Local_User, ConfigurationManager.AppSettings["DevOwnerPre"], ConfigurationManager.AppSettings["CtOwnerPre"], RegexOptions.IgnoreCase);
                        job.Ftp_Local_User = Regex.Replace(job.Ftp_Local_User, ConfigurationManager.AppSettings["StageOwnerPre"], ConfigurationManager.AppSettings["CtOwnerPre"], RegexOptions.IgnoreCase);
                        job.Ftp_Local_User = Regex.Replace(job.Ftp_Local_User, ConfigurationManager.AppSettings["NewDevOwnerPre"], ConfigurationManager.AppSettings["NewCtOwnerPre"], RegexOptions.IgnoreCase);
                        job.Ftp_Local_User = Regex.Replace(job.Ftp_Local_User, ConfigurationManager.AppSettings["NewStageOwnerPre"], ConfigurationManager.AppSettings["NewCtOwnerPre"], RegexOptions.IgnoreCase);

                        job.Ftp_Local_User = Regex.Replace(job.Ftp_Local_User, ConfigurationManager.AppSettings["ProductionOwnerSuffix"], ConfigurationManager.AppSettings["NonProductionOwnerSuffix"].ToUpper(), RegexOptions.IgnoreCase);
                        if (!job.Ftp_Local_User.Contains("_") && !job.Ftp_Local_User.Contains(ConfigurationManager.AppSettings["CtOwnerPrefix"].ToUpper()) && !job.Ftp_Local_User.Contains(ConfigurationManager.AppSettings["NewCtOwnerPre"]))
                            job.Ftp_Local_User = job.Ftp_Local_User.Replace("AsysActionAcct", "CT1_AsysActionAcct");
                        if (job.Ftp_Local_User.Contains("AsysActionAcct") && !job.Ftp_Local_User.ToUpper().Contains(ConfigurationManager.AppSettings["NonProductionOwnerSuffix"].ToUpper()))
                        {
                            job.Ftp_Local_User = job.Ftp_Local_User.Replace("AsysActionAcct", "AsysActionAcct@CORP");
                        }
                        if (job.Ftp_Local_User.Contains("BM_"))
                            job.Ftp_Local_User = job.Ftp_Local_User.Replace("BM_", ConfigurationManager.AppSettings["CtOwnerPrefix"].ToUpper());

                        job.Ftp_Local_User = Regex.Replace(job.Ftp_Local_User, "Ct1_Ct1_", "CT1_", RegexOptions.IgnoreCase);
                        job.Ftp_Local_User = Regex.Replace(job.Ftp_Local_User, "ct1_", "CT1_", RegexOptions.IgnoreCase);
                    }

                    if (!string.IsNullOrEmpty(job.Watch_File_Win_User))
                    {
                        job.Watch_File_Win_User = Regex.Replace(job.Watch_File_Win_User, ConfigurationManager.AppSettings["DevOwnerPre"], ConfigurationManager.AppSettings["CtOwnerPre"], RegexOptions.IgnoreCase);
                        job.Watch_File_Win_User = Regex.Replace(job.Watch_File_Win_User, ConfigurationManager.AppSettings["StageOwnerPre"], ConfigurationManager.AppSettings["CtOwnerPre"], RegexOptions.IgnoreCase);
                        job.Watch_File_Win_User = Regex.Replace(job.Watch_File_Win_User, ConfigurationManager.AppSettings["NewDevOwnerPre"], ConfigurationManager.AppSettings["NewCtOwnerPre"], RegexOptions.IgnoreCase);
                        job.Watch_File_Win_User = Regex.Replace(job.Watch_File_Win_User, ConfigurationManager.AppSettings["NewStageOwnerPre"], ConfigurationManager.AppSettings["NewCtOwnerPre"], RegexOptions.IgnoreCase);

                        job.Watch_File_Win_User = Regex.Replace(job.Watch_File_Win_User, ConfigurationManager.AppSettings["ProductionOwnerSuffix"], ConfigurationManager.AppSettings["NonProductionOwnerSuffix"].ToUpper(), RegexOptions.IgnoreCase);
                        if (!job.Watch_File_Win_User.Contains("_") && !job.Watch_File_Win_User.Contains(ConfigurationManager.AppSettings["CtOwnerPrefix"].ToUpper()) && !job.Watch_File_Win_User.Contains(ConfigurationManager.AppSettings["NewCtOwnerPre"]))
                            job.Watch_File_Win_User = job.Watch_File_Win_User.Replace("AsysActionAcct", "CT1_AsysActionAcct");
                        if (job.Watch_File_Win_User.Contains("AsysActionAcct") && !job.Watch_File_Win_User.ToUpper().Contains(ConfigurationManager.AppSettings["NonProductionOwnerSuffix"].ToUpper()))
                        {
                            job.Watch_File_Win_User = job.Watch_File_Win_User.Replace("AsysActionAcct", "AsysActionAcct@CORP");
                        }
                        if (job.Watch_File_Win_User.Contains("BM_"))
                            job.Watch_File_Win_User = job.Watch_File_Win_User.Replace("BM_", ConfigurationManager.AppSettings["CtOwnerPrefix"].ToUpper());

                        job.Watch_File_Win_User = Regex.Replace(job.Watch_File_Win_User, "Ct1_Ct1_", "CT1_", RegexOptions.IgnoreCase);
                        job.Watch_File_Win_User = Regex.Replace(job.Watch_File_Win_User, "ct1_", "CT1_", RegexOptions.IgnoreCase);
                    }

                    if (!string.IsNullOrEmpty(job.Command))
                    {
                        job.Command = Regex.Replace(job.Command, ConfigurationManager.AppSettings["CtOldAsaMachine01"], ConfigurationManager.AppSettings["CtNASCommandPath"], RegexOptions.IgnoreCase);
                        job.Command = Regex.Replace(job.Command, ConfigurationManager.AppSettings["CtOldAsaMachine02"], ConfigurationManager.AppSettings["CtNASCommandPath"], RegexOptions.IgnoreCase);
                        job.Command = Regex.Replace(job.Command, ConfigurationManager.AppSettings["CtNewAsaMachine01"], ConfigurationManager.AppSettings["CtNASCommandPath"], RegexOptions.IgnoreCase);
                        job.Command = Regex.Replace(job.Command, ConfigurationManager.AppSettings["CtNewAsaMachine02"], ConfigurationManager.AppSettings["CtNASCommandPath"], RegexOptions.IgnoreCase);
                        job.Command = job.Command.Replace(ConfigurationManager.AppSettings["OldDevCommandPath"].Replace("$$$$", "$$"), ConfigurationManager.AppSettings["CtNASCommandPath"]);
                        job.Command = job.Command.Replace(ConfigurationManager.AppSettings["DevCommandPath"].Replace("$$$$", "$$"), ConfigurationManager.AppSettings["CtNASCommandPath"]);
                        job.Command = job.Command.Replace(ConfigurationManager.AppSettings["StageCommandPath"].Replace("$$$$", "$$"), ConfigurationManager.AppSettings["CtNASCommandPath"]);
                        job.Command = job.Command.Replace(ConfigurationManager.AppSettings["CtCommandPath"].Replace("$$$$", "$$"), ConfigurationManager.AppSettings["CtNASCommandPath"]);
                        job.Command = job.Command.Replace(ConfigurationManager.AppSettings["DevNASCommandPath"].Replace("$$$$", "$$"), ConfigurationManager.AppSettings["CtNASCommandPath"]);
                        job.Command = job.Command.Replace(ConfigurationManager.AppSettings["StageNASCommandPath"].Replace("$$$$", "$$"), ConfigurationManager.AppSettings["CtNASCommandPath"]);
                        job.Command = Regex.Replace(job.Command, ConfigurationManager.AppSettings["NonProdFileStoreRootLocation"], ConfigurationManager.AppSettings["CtNASCommandPath"], RegexOptions.IgnoreCase);
                        job.Command = Regex.Replace(job.Command, ConfigurationManager.AppSettings["DalProdFileStoreRootLocation"], ConfigurationManager.AppSettings["CtNASCommandPath"], RegexOptions.IgnoreCase);
                        job.Command = Regex.Replace(job.Command, ConfigurationManager.AppSettings["ChiProdFileStoreRootLocation"], ConfigurationManager.AppSettings["CtNASCommandPath"], RegexOptions.IgnoreCase);
                        job.Command = Regex.Replace(job.Command, ConfigurationManager.AppSettings["DevOldAsaMachine01"], ConfigurationManager.AppSettings["CtNASCommandPath"], RegexOptions.IgnoreCase);
                        job.Command = Regex.Replace(job.Command, ConfigurationManager.AppSettings["DevOldAsaMachine02"], ConfigurationManager.AppSettings["CtNASCommandPath"], RegexOptions.IgnoreCase);
                        job.Command = Regex.Replace(job.Command, ConfigurationManager.AppSettings["DevNewAsaMachine01"], ConfigurationManager.AppSettings["CtNASCommandPath"], RegexOptions.IgnoreCase);
                        job.Command = Regex.Replace(job.Command, ConfigurationManager.AppSettings["DevNewAsaMachine02"], ConfigurationManager.AppSettings["CtNASCommandPath"], RegexOptions.IgnoreCase);
                        job.Command = Regex.Replace(job.Command, ConfigurationManager.AppSettings["StageOldAsaMachine01"], ConfigurationManager.AppSettings["CtNASCommandPath"], RegexOptions.IgnoreCase);
                        job.Command = Regex.Replace(job.Command, ConfigurationManager.AppSettings["StageOldAsaMachine02"], ConfigurationManager.AppSettings["CtNASCommandPath"], RegexOptions.IgnoreCase);
                        job.Command = Regex.Replace(job.Command, ConfigurationManager.AppSettings["StageNewAsaMachine01"], ConfigurationManager.AppSettings["CtNASCommandPath"], RegexOptions.IgnoreCase);
                        job.Command = Regex.Replace(job.Command, ConfigurationManager.AppSettings["StageNewAsaMachine02"], ConfigurationManager.AppSettings["CtNASCommandPath"], RegexOptions.IgnoreCase);
                        job.Command = Regex.Replace(job.Command, ConfigurationManager.AppSettings["DevGwyNewAsaMachine01"], ConfigurationManager.AppSettings["CtNASCommandPath"], RegexOptions.IgnoreCase);
                        job.Command = Regex.Replace(job.Command, ConfigurationManager.AppSettings["DevGwyNewAsaMachine02"], ConfigurationManager.AppSettings["CtNASCommandPath"], RegexOptions.IgnoreCase);
                        job.Command = Regex.Replace(job.Command, ConfigurationManager.AppSettings["StageGwyNewAsaMachine01"], ConfigurationManager.AppSettings["CtNASCommandPath"], RegexOptions.IgnoreCase);
                        job.Command = Regex.Replace(job.Command, ConfigurationManager.AppSettings["StageGwyNewAsaMachine02"], ConfigurationManager.AppSettings["CtNASCommandPath"], RegexOptions.IgnoreCase);
                        job.Command = Regex.Replace(job.Command, ConfigurationManager.AppSettings["CtGwyNewAsaMachine01"], ConfigurationManager.AppSettings["CtNASCommandPath"], RegexOptions.IgnoreCase);
                        job.Command = Regex.Replace(job.Command, ConfigurationManager.AppSettings["CtGwyNewAsaMachine02"], ConfigurationManager.AppSettings["CtNASCommandPath"], RegexOptions.IgnoreCase);
                        job.Command = Regex.Replace(job.Command, ConfigurationManager.AppSettings["NonProdSchedulerNASMachine"], ConfigurationManager.AppSettings["CtNASCommandPath"], RegexOptions.IgnoreCase);
                        job.Command = job.Command.Replace("$$$$", "$$");
                        job.Command = job.Command.Replace(StringConstants.DEV_BSL_JOBS_SUBSTRING, StringConstants.CT_BIS_JOBS_SUBSTRING);
                        job.Command = job.Command.Replace(StringConstants.STAGE_BSL_JOBS_SUBSTRING, StringConstants.CT_BIS_JOBS_SUBSTRING);
                        job.Command = job.Command.Replace(StringConstants.PROD_BSL_JOBS_SUBSTRING, StringConstants.CT_BIS_JOBS_SUBSTRING);
                        job.Command = Regex.Replace(job.Command, ConfigurationManager.AppSettings["OldIncomingFilesPath"], ConfigurationManager.AppSettings["NewIncomingFilesPath"], RegexOptions.IgnoreCase);
                        job.Command = Regex.Replace(job.Command, ConfigurationManager.AppSettings["DevFileNameExtension"], ConfigurationManager.AppSettings["CtFileNameExtension"], RegexOptions.IgnoreCase);
                        job.Command = Regex.Replace(job.Command, ConfigurationManager.AppSettings["StageFileNameExtension"], ConfigurationManager.AppSettings["CtFileNameExtension"], RegexOptions.IgnoreCase);
                        job.Command = Regex.Replace(job.Command, ConfigurationManager.AppSettings["ProdFileNameExtension"], ConfigurationManager.AppSettings["CtFileNameExtension"], RegexOptions.IgnoreCase);

                        job.Command = Regex.Replace(job.Command, ConfigurationManager.AppSettings["OldDevRptServer01"], ConfigurationManager.AppSettings["NewCtRptServer01"], RegexOptions.IgnoreCase);
                        job.Command = Regex.Replace(job.Command, ConfigurationManager.AppSettings["OldDevRptServer02"], ConfigurationManager.AppSettings["NewCtRptServer01"], RegexOptions.IgnoreCase);
                        job.Command = Regex.Replace(job.Command, ConfigurationManager.AppSettings["OldStageRptServer01"], ConfigurationManager.AppSettings["NewCtRptServer01"], RegexOptions.IgnoreCase);
                        job.Command = Regex.Replace(job.Command, ConfigurationManager.AppSettings["OldStageRptServer02"], ConfigurationManager.AppSettings["NewCtRptServer01"], RegexOptions.IgnoreCase);
                        job.Command = Regex.Replace(job.Command, ConfigurationManager.AppSettings["OldCtRptServer01"], ConfigurationManager.AppSettings["NewCtRptServer01"], RegexOptions.IgnoreCase);
                        job.Command = Regex.Replace(job.Command, ConfigurationManager.AppSettings["OldCtRptServer02"], ConfigurationManager.AppSettings["NewCtRptServer01"], RegexOptions.IgnoreCase);

                        job.Command = Regex.Replace(job.Command, ConfigurationManager.AppSettings["NewCtRptServer02"], ConfigurationManager.AppSettings["NewCtRptServer01"], RegexOptions.IgnoreCase);
                        job.Command = Regex.Replace(job.Command, ConfigurationManager.AppSettings["NewStageRptServer01"], ConfigurationManager.AppSettings["NewCtRptServer01"], RegexOptions.IgnoreCase);
                        job.Command = Regex.Replace(job.Command, ConfigurationManager.AppSettings["NewStageRptServer02"], ConfigurationManager.AppSettings["NewCtRptServer01"], RegexOptions.IgnoreCase);
                        job.Command = Regex.Replace(job.Command, ConfigurationManager.AppSettings["NewDevRptServer01"], ConfigurationManager.AppSettings["NewCtRptServer01"], RegexOptions.IgnoreCase);
                        job.Command = Regex.Replace(job.Command, ConfigurationManager.AppSettings["NewDevRptServer02"], ConfigurationManager.AppSettings["NewCtRptServer01"], RegexOptions.IgnoreCase);
                    }

                    //adding changes in new attributes similar to command
                    if (!string.IsNullOrEmpty(job.Ftp_Local_Name))
                    {
                        job.Ftp_Local_Name = Regex.Replace(job.Ftp_Local_Name, ConfigurationManager.AppSettings["CtOldAsaMachine01"], ConfigurationManager.AppSettings["CtNASCommandPath"], RegexOptions.IgnoreCase);
                        job.Ftp_Local_Name = Regex.Replace(job.Ftp_Local_Name, ConfigurationManager.AppSettings["CtOldAsaMachine02"], ConfigurationManager.AppSettings["CtNASCommandPath"], RegexOptions.IgnoreCase);
                        job.Ftp_Local_Name = Regex.Replace(job.Ftp_Local_Name, ConfigurationManager.AppSettings["CtNewAsaMachine01"], ConfigurationManager.AppSettings["CtNASCommandPath"], RegexOptions.IgnoreCase);
                        job.Ftp_Local_Name = Regex.Replace(job.Ftp_Local_Name, ConfigurationManager.AppSettings["CtNewAsaMachine02"], ConfigurationManager.AppSettings["CtNASCommandPath"], RegexOptions.IgnoreCase);
                        job.Ftp_Local_Name = job.Ftp_Local_Name.Replace(ConfigurationManager.AppSettings["OldDevCommandPath"].Replace("$$$$", "$$"), ConfigurationManager.AppSettings["CtNASCommandPath"]);
                        job.Ftp_Local_Name = job.Ftp_Local_Name.Replace(ConfigurationManager.AppSettings["DevCommandPath"].Replace("$$$$", "$$"), ConfigurationManager.AppSettings["CtNASCommandPath"]);
                        job.Ftp_Local_Name = job.Ftp_Local_Name.Replace(ConfigurationManager.AppSettings["StageCommandPath"].Replace("$$$$", "$$"), ConfigurationManager.AppSettings["CtNASCommandPath"]);
                        job.Ftp_Local_Name = job.Ftp_Local_Name.Replace(ConfigurationManager.AppSettings["CtCommandPath"].Replace("$$$$", "$$"), ConfigurationManager.AppSettings["CtNASCommandPath"]);
                        job.Ftp_Local_Name = job.Ftp_Local_Name.Replace(ConfigurationManager.AppSettings["DevNASCommandPath"].Replace("$$$$", "$$"), ConfigurationManager.AppSettings["CtNASCommandPath"]);
                        job.Ftp_Local_Name = job.Ftp_Local_Name.Replace(ConfigurationManager.AppSettings["StageNASCommandPath"].Replace("$$$$", "$$"), ConfigurationManager.AppSettings["CtNASCommandPath"]);
                        job.Ftp_Local_Name = Regex.Replace(job.Ftp_Local_Name, ConfigurationManager.AppSettings["NonProdFileStoreRootLocation"], ConfigurationManager.AppSettings["CtNASCommandPath"], RegexOptions.IgnoreCase);
                        job.Ftp_Local_Name = Regex.Replace(job.Ftp_Local_Name, ConfigurationManager.AppSettings["DalProdFileStoreRootLocation"], ConfigurationManager.AppSettings["CtNASCommandPath"], RegexOptions.IgnoreCase);
                        job.Ftp_Local_Name = Regex.Replace(job.Ftp_Local_Name, ConfigurationManager.AppSettings["ChiProdFileStoreRootLocation"], ConfigurationManager.AppSettings["CtNASCommandPath"], RegexOptions.IgnoreCase);
                        job.Ftp_Local_Name = Regex.Replace(job.Ftp_Local_Name, ConfigurationManager.AppSettings["DevOldAsaMachine01"], ConfigurationManager.AppSettings["CtNASCommandPath"], RegexOptions.IgnoreCase);
                        job.Ftp_Local_Name = Regex.Replace(job.Ftp_Local_Name, ConfigurationManager.AppSettings["DevOldAsaMachine02"], ConfigurationManager.AppSettings["CtNASCommandPath"], RegexOptions.IgnoreCase);
                        job.Ftp_Local_Name = Regex.Replace(job.Ftp_Local_Name, ConfigurationManager.AppSettings["DevNewAsaMachine01"], ConfigurationManager.AppSettings["CtNASCommandPath"], RegexOptions.IgnoreCase);
                        job.Ftp_Local_Name = Regex.Replace(job.Ftp_Local_Name, ConfigurationManager.AppSettings["DevNewAsaMachine02"], ConfigurationManager.AppSettings["CtNASCommandPath"], RegexOptions.IgnoreCase);
                        job.Ftp_Local_Name = Regex.Replace(job.Ftp_Local_Name, ConfigurationManager.AppSettings["StageOldAsaMachine01"], ConfigurationManager.AppSettings["CtNASCommandPath"], RegexOptions.IgnoreCase);
                        job.Ftp_Local_Name = Regex.Replace(job.Ftp_Local_Name, ConfigurationManager.AppSettings["StageOldAsaMachine02"], ConfigurationManager.AppSettings["CtNASCommandPath"], RegexOptions.IgnoreCase);
                        job.Ftp_Local_Name = Regex.Replace(job.Ftp_Local_Name, ConfigurationManager.AppSettings["StageNewAsaMachine01"], ConfigurationManager.AppSettings["CtNASCommandPath"], RegexOptions.IgnoreCase);
                        job.Ftp_Local_Name = Regex.Replace(job.Ftp_Local_Name, ConfigurationManager.AppSettings["StageNewAsaMachine02"], ConfigurationManager.AppSettings["CtNASCommandPath"], RegexOptions.IgnoreCase);
                        job.Ftp_Local_Name = Regex.Replace(job.Ftp_Local_Name, ConfigurationManager.AppSettings["DevGwyNewAsaMachine01"], ConfigurationManager.AppSettings["CtNASCommandPath"], RegexOptions.IgnoreCase);
                        job.Ftp_Local_Name = Regex.Replace(job.Ftp_Local_Name, ConfigurationManager.AppSettings["DevGwyNewAsaMachine02"], ConfigurationManager.AppSettings["CtNASCommandPath"], RegexOptions.IgnoreCase);
                        job.Ftp_Local_Name = Regex.Replace(job.Ftp_Local_Name, ConfigurationManager.AppSettings["StageGwyNewAsaMachine01"], ConfigurationManager.AppSettings["CtNASCommandPath"], RegexOptions.IgnoreCase);
                        job.Ftp_Local_Name = Regex.Replace(job.Ftp_Local_Name, ConfigurationManager.AppSettings["StageGwyNewAsaMachine02"], ConfigurationManager.AppSettings["CtNASCommandPath"], RegexOptions.IgnoreCase);
                        job.Ftp_Local_Name = Regex.Replace(job.Ftp_Local_Name, ConfigurationManager.AppSettings["CtGwyNewAsaMachine01"], ConfigurationManager.AppSettings["CtNASCommandPath"], RegexOptions.IgnoreCase);
                        job.Ftp_Local_Name = Regex.Replace(job.Ftp_Local_Name, ConfigurationManager.AppSettings["CtGwyNewAsaMachine02"], ConfigurationManager.AppSettings["CtNASCommandPath"], RegexOptions.IgnoreCase);
                        job.Ftp_Local_Name = Regex.Replace(job.Ftp_Local_Name, ConfigurationManager.AppSettings["NonProdSchedulerNASMachine"], ConfigurationManager.AppSettings["CtNASCommandPath"], RegexOptions.IgnoreCase);
                        job.Ftp_Local_Name = job.Ftp_Local_Name.Replace("$$$$", "$$");
                        job.Ftp_Local_Name = Regex.Replace(job.Ftp_Local_Name, ConfigurationManager.AppSettings["OldIncomingFilesPath"], ConfigurationManager.AppSettings["NewIncomingFilesPath"], RegexOptions.IgnoreCase);
                        job.Ftp_Local_Name = Regex.Replace(job.Ftp_Local_Name, ConfigurationManager.AppSettings["DevFileNameExtension"], ConfigurationManager.AppSettings["CtFileNameExtension"], RegexOptions.IgnoreCase);
                        job.Ftp_Local_Name = Regex.Replace(job.Ftp_Local_Name, ConfigurationManager.AppSettings["StageFileNameExtension"], ConfigurationManager.AppSettings["CtFileNameExtension"], RegexOptions.IgnoreCase);
                        job.Ftp_Local_Name = Regex.Replace(job.Ftp_Local_Name, ConfigurationManager.AppSettings["ProdFileNameExtension"], ConfigurationManager.AppSettings["CtFileNameExtension"], RegexOptions.IgnoreCase);

                        job.Ftp_Local_Name = Regex.Replace(job.Ftp_Local_Name, ConfigurationManager.AppSettings["OldDevRptServer01"], ConfigurationManager.AppSettings["NewCtRptServer01"], RegexOptions.IgnoreCase);
                        job.Ftp_Local_Name = Regex.Replace(job.Ftp_Local_Name, ConfigurationManager.AppSettings["OldDevRptServer02"], ConfigurationManager.AppSettings["NewCtRptServer01"], RegexOptions.IgnoreCase);
                        job.Ftp_Local_Name = Regex.Replace(job.Ftp_Local_Name, ConfigurationManager.AppSettings["OldStageRptServer01"], ConfigurationManager.AppSettings["NewCtRptServer01"], RegexOptions.IgnoreCase);
                        job.Ftp_Local_Name = Regex.Replace(job.Ftp_Local_Name, ConfigurationManager.AppSettings["OldStageRptServer02"], ConfigurationManager.AppSettings["NewCtRptServer01"], RegexOptions.IgnoreCase);
                        job.Ftp_Local_Name = Regex.Replace(job.Ftp_Local_Name, ConfigurationManager.AppSettings["OldCtRptServer01"], ConfigurationManager.AppSettings["NewCtRptServer01"], RegexOptions.IgnoreCase);
                        job.Ftp_Local_Name = Regex.Replace(job.Ftp_Local_Name, ConfigurationManager.AppSettings["OldCtRptServer02"], ConfigurationManager.AppSettings["NewCtRptServer01"], RegexOptions.IgnoreCase);

                        job.Ftp_Local_Name = Regex.Replace(job.Ftp_Local_Name, ConfigurationManager.AppSettings["NewCtRptServer02"], ConfigurationManager.AppSettings["NewCtRptServer01"], RegexOptions.IgnoreCase);
                        job.Ftp_Local_Name = Regex.Replace(job.Ftp_Local_Name, ConfigurationManager.AppSettings["NewStageRptServer01"], ConfigurationManager.AppSettings["NewCtRptServer01"], RegexOptions.IgnoreCase);
                        job.Ftp_Local_Name = Regex.Replace(job.Ftp_Local_Name, ConfigurationManager.AppSettings["NewStageRptServer02"], ConfigurationManager.AppSettings["NewCtRptServer01"], RegexOptions.IgnoreCase);
                        job.Ftp_Local_Name = Regex.Replace(job.Ftp_Local_Name, ConfigurationManager.AppSettings["NewDevRptServer01"], ConfigurationManager.AppSettings["NewCtRptServer01"], RegexOptions.IgnoreCase);
                        job.Ftp_Local_Name = Regex.Replace(job.Ftp_Local_Name, ConfigurationManager.AppSettings["NewDevRptServer02"], ConfigurationManager.AppSettings["NewCtRptServer01"], RegexOptions.IgnoreCase);
                    }

                    if (!string.IsNullOrEmpty(job.Watch_File))
                    {
                        job.Watch_File = Regex.Replace(job.Watch_File, ConfigurationManager.AppSettings["CtOldAsaMachine01"], ConfigurationManager.AppSettings["CtNASCommandPath"], RegexOptions.IgnoreCase);
                        job.Watch_File = Regex.Replace(job.Watch_File, ConfigurationManager.AppSettings["CtOldAsaMachine02"], ConfigurationManager.AppSettings["CtNASCommandPath"], RegexOptions.IgnoreCase);
                        job.Watch_File = Regex.Replace(job.Watch_File, ConfigurationManager.AppSettings["CtNewAsaMachine01"], ConfigurationManager.AppSettings["CtNASCommandPath"], RegexOptions.IgnoreCase);
                        job.Watch_File = Regex.Replace(job.Watch_File, ConfigurationManager.AppSettings["CtNewAsaMachine02"], ConfigurationManager.AppSettings["CtNASCommandPath"], RegexOptions.IgnoreCase);
                        job.Watch_File = job.Watch_File.Replace(ConfigurationManager.AppSettings["OldDevCommandPath"].Replace("$$$$", "$$"), ConfigurationManager.AppSettings["CtNASCommandPath"]);
                        job.Watch_File = job.Watch_File.Replace(ConfigurationManager.AppSettings["DevCommandPath"].Replace("$$$$", "$$"), ConfigurationManager.AppSettings["CtNASCommandPath"]);
                        job.Watch_File = job.Watch_File.Replace(ConfigurationManager.AppSettings["StageCommandPath"].Replace("$$$$", "$$"), ConfigurationManager.AppSettings["CtNASCommandPath"]);
                        job.Watch_File = job.Watch_File.Replace(ConfigurationManager.AppSettings["CtCommandPath"].Replace("$$$$", "$$"), ConfigurationManager.AppSettings["CtNASCommandPath"]);
                        job.Watch_File = job.Watch_File.Replace(ConfigurationManager.AppSettings["DevNASCommandPath"].Replace("$$$$", "$$"), ConfigurationManager.AppSettings["CtNASCommandPath"]);
                        job.Watch_File = job.Watch_File.Replace(ConfigurationManager.AppSettings["StageNASCommandPath"].Replace("$$$$", "$$"), ConfigurationManager.AppSettings["CtNASCommandPath"]);
                        job.Watch_File = Regex.Replace(job.Watch_File, ConfigurationManager.AppSettings["NonProdFileStoreRootLocation"], ConfigurationManager.AppSettings["CtNASCommandPath"], RegexOptions.IgnoreCase);
                        job.Watch_File = Regex.Replace(job.Watch_File, ConfigurationManager.AppSettings["DalProdFileStoreRootLocation"], ConfigurationManager.AppSettings["CtNASCommandPath"], RegexOptions.IgnoreCase);
                        job.Watch_File = Regex.Replace(job.Watch_File, ConfigurationManager.AppSettings["ChiProdFileStoreRootLocation"], ConfigurationManager.AppSettings["CtNASCommandPath"], RegexOptions.IgnoreCase);
                        job.Watch_File = Regex.Replace(job.Watch_File, ConfigurationManager.AppSettings["DevOldAsaMachine01"], ConfigurationManager.AppSettings["CtNASCommandPath"], RegexOptions.IgnoreCase);
                        job.Watch_File = Regex.Replace(job.Watch_File, ConfigurationManager.AppSettings["DevOldAsaMachine02"], ConfigurationManager.AppSettings["CtNASCommandPath"], RegexOptions.IgnoreCase);
                        job.Watch_File = Regex.Replace(job.Watch_File, ConfigurationManager.AppSettings["DevNewAsaMachine01"], ConfigurationManager.AppSettings["CtNASCommandPath"], RegexOptions.IgnoreCase);
                        job.Watch_File = Regex.Replace(job.Watch_File, ConfigurationManager.AppSettings["DevNewAsaMachine02"], ConfigurationManager.AppSettings["CtNASCommandPath"], RegexOptions.IgnoreCase);
                        job.Watch_File = Regex.Replace(job.Watch_File, ConfigurationManager.AppSettings["StageOldAsaMachine01"], ConfigurationManager.AppSettings["CtNASCommandPath"], RegexOptions.IgnoreCase);
                        job.Watch_File = Regex.Replace(job.Watch_File, ConfigurationManager.AppSettings["StageOldAsaMachine02"], ConfigurationManager.AppSettings["CtNASCommandPath"], RegexOptions.IgnoreCase);
                        job.Watch_File = Regex.Replace(job.Watch_File, ConfigurationManager.AppSettings["StageNewAsaMachine01"], ConfigurationManager.AppSettings["CtNASCommandPath"], RegexOptions.IgnoreCase);
                        job.Watch_File = Regex.Replace(job.Watch_File, ConfigurationManager.AppSettings["StageNewAsaMachine02"], ConfigurationManager.AppSettings["CtNASCommandPath"], RegexOptions.IgnoreCase);
                        job.Watch_File = Regex.Replace(job.Watch_File, ConfigurationManager.AppSettings["DevGwyNewAsaMachine01"], ConfigurationManager.AppSettings["CtNASCommandPath"], RegexOptions.IgnoreCase);
                        job.Watch_File = Regex.Replace(job.Watch_File, ConfigurationManager.AppSettings["DevGwyNewAsaMachine02"], ConfigurationManager.AppSettings["CtNASCommandPath"], RegexOptions.IgnoreCase);
                        job.Watch_File = Regex.Replace(job.Watch_File, ConfigurationManager.AppSettings["StageGwyNewAsaMachine01"], ConfigurationManager.AppSettings["CtNASCommandPath"], RegexOptions.IgnoreCase);
                        job.Watch_File = Regex.Replace(job.Watch_File, ConfigurationManager.AppSettings["StageGwyNewAsaMachine02"], ConfigurationManager.AppSettings["CtNASCommandPath"], RegexOptions.IgnoreCase);
                        job.Watch_File = Regex.Replace(job.Watch_File, ConfigurationManager.AppSettings["CtGwyNewAsaMachine01"], ConfigurationManager.AppSettings["CtNASCommandPath"], RegexOptions.IgnoreCase);
                        job.Watch_File = Regex.Replace(job.Watch_File, ConfigurationManager.AppSettings["CtGwyNewAsaMachine02"], ConfigurationManager.AppSettings["CtNASCommandPath"], RegexOptions.IgnoreCase);
                        job.Watch_File = Regex.Replace(job.Watch_File, ConfigurationManager.AppSettings["NonProdSchedulerNASMachine"], ConfigurationManager.AppSettings["CtNASCommandPath"], RegexOptions.IgnoreCase);
                        job.Watch_File = job.Watch_File.Replace("$$$$", "$$");
                        job.Watch_File = Regex.Replace(job.Watch_File, ConfigurationManager.AppSettings["OldIncomingFilesPath"], ConfigurationManager.AppSettings["NewIncomingFilesPath"], RegexOptions.IgnoreCase);
                        job.Watch_File = Regex.Replace(job.Watch_File, ConfigurationManager.AppSettings["DevFileNameExtension"], ConfigurationManager.AppSettings["CtFileNameExtension"], RegexOptions.IgnoreCase);
                        job.Watch_File = Regex.Replace(job.Watch_File, ConfigurationManager.AppSettings["StageFileNameExtension"], ConfigurationManager.AppSettings["CtFileNameExtension"], RegexOptions.IgnoreCase);
                        job.Watch_File = Regex.Replace(job.Watch_File, ConfigurationManager.AppSettings["ProdFileNameExtension"], ConfigurationManager.AppSettings["CtFileNameExtension"], RegexOptions.IgnoreCase);

                        job.Watch_File = Regex.Replace(job.Watch_File, ConfigurationManager.AppSettings["OldDevRptServer01"], ConfigurationManager.AppSettings["NewCtRptServer01"], RegexOptions.IgnoreCase);
                        job.Watch_File = Regex.Replace(job.Watch_File, ConfigurationManager.AppSettings["OldDevRptServer02"], ConfigurationManager.AppSettings["NewCtRptServer01"], RegexOptions.IgnoreCase);
                        job.Watch_File = Regex.Replace(job.Watch_File, ConfigurationManager.AppSettings["OldStageRptServer01"], ConfigurationManager.AppSettings["NewCtRptServer01"], RegexOptions.IgnoreCase);
                        job.Watch_File = Regex.Replace(job.Watch_File, ConfigurationManager.AppSettings["OldStageRptServer02"], ConfigurationManager.AppSettings["NewCtRptServer01"], RegexOptions.IgnoreCase);
                        job.Watch_File = Regex.Replace(job.Watch_File, ConfigurationManager.AppSettings["OldCtRptServer01"], ConfigurationManager.AppSettings["NewCtRptServer01"], RegexOptions.IgnoreCase);
                        job.Watch_File = Regex.Replace(job.Watch_File, ConfigurationManager.AppSettings["OldCtRptServer02"], ConfigurationManager.AppSettings["NewCtRptServer01"], RegexOptions.IgnoreCase);

                        job.Watch_File = Regex.Replace(job.Watch_File, ConfigurationManager.AppSettings["NewCtRptServer02"], ConfigurationManager.AppSettings["NewCtRptServer01"], RegexOptions.IgnoreCase);
                        job.Watch_File = Regex.Replace(job.Watch_File, ConfigurationManager.AppSettings["NewStageRptServer01"], ConfigurationManager.AppSettings["NewCtRptServer01"], RegexOptions.IgnoreCase);
                        job.Watch_File = Regex.Replace(job.Watch_File, ConfigurationManager.AppSettings["NewStageRptServer02"], ConfigurationManager.AppSettings["NewCtRptServer01"], RegexOptions.IgnoreCase);
                        job.Watch_File = Regex.Replace(job.Watch_File, ConfigurationManager.AppSettings["NewDevRptServer01"], ConfigurationManager.AppSettings["NewCtRptServer01"], RegexOptions.IgnoreCase);
                        job.Watch_File = Regex.Replace(job.Watch_File, ConfigurationManager.AppSettings["NewDevRptServer02"], ConfigurationManager.AppSettings["NewCtRptServer01"], RegexOptions.IgnoreCase);
                    }
                }
                else if (job.Insert_job.Contains(ConfigurationManager.AppSettings["ProdBisSubString"]))
                {
                    if (!string.IsNullOrEmpty(job.Machine))
                    {
                        if (job.Machine.Contains("proasa"))
                            job.Machine = job.Machine.Replace(job.Machine.Split(new string[] { "machine:" }, StringSplitOptions.None).Last().Trim(), ConfigurationManager.AppSettings["ProAsaMachineName"]);
                        if (job.Machine.Contains("od_ach_settlement"))
                            job.Machine = job.Machine.Split(new string[] { "od_ach_settlement" }, StringSplitOptions.None).First().Trim() + " " + ConfigurationManager.AppSettings["ProAchSettlementMachineName"];
                        if (job.Machine.Contains("od_cc_settlement"))
                            job.Machine = job.Machine.Split(new string[] { "od_cc_settlement" }, StringSplitOptions.None).First().Trim() + " " + ConfigurationManager.AppSettings["ProCcSettlementMachineName"];
                        if (job.Machine.Contains("od_ajb_settlement"))
                            job.Machine = job.Machine.Split(new string[] { "od_ajb_settlement" }, StringSplitOptions.None).First().Trim() + " " + ConfigurationManager.AppSettings["ProAjbSettlementMachineName"];
                        if (job.Machine.Contains("od_processor_settlement"))
                            job.Machine = job.Machine.Split(new string[] { "od_processor_settlement" }, StringSplitOptions.None).First().Trim() + " " + ConfigurationManager.AppSettings["ProProcessorSettlementMachineName"];
                        if (job.Machine.Contains("bis-r-") && job.Machine.Contains("asa"))
                            job.Machine = job.Machine.Split(new string[] { "bis-r-" }, StringSplitOptions.None).First().Trim() + "  " + ConfigurationManager.AppSettings["ProAsaMachineName"];
                        if (job.Machine.Contains("gwy") && !job.Machine.Contains("_"))
                        {
                            job.Machine = job.Machine.Split(':').First().Trim() + ": " + ConfigurationManager.AppSettings["RealMachinePrefix"] + job.Machine.Split(':').Last().Trim();
                        }
                    }

                    if (!string.IsNullOrEmpty(job.Owner))
                    {
                        if (job.Owner.ToLower().Contains(ConfigurationManager.AppSettings["ProOwnerName"]))
                        {
                            job.Owner = Regex.Replace(job.Owner, ConfigurationManager.AppSettings["DevOwnerPrefix"].ToUpper(), "", RegexOptions.IgnoreCase);
                            job.Owner = Regex.Replace(job.Owner, ConfigurationManager.AppSettings["StageOwnerPrefix"].ToUpper(), "", RegexOptions.IgnoreCase);
                            job.Owner = Regex.Replace(job.Owner, ConfigurationManager.AppSettings["CtOwnerPrefix"].ToUpper(), "", RegexOptions.IgnoreCase);
                            //job.Owner = job.Owner.Replace("Dev_", "");
                            //job.Owner = job.Owner.Replace("Sta_", "");
                            //job.Owner = job.Owner.Replace("Ct1_", "");
                        }
                        else if (!job.Owner.ToLower().Contains(ConfigurationManager.AppSettings["ProOwnerName"]) && job.Owner.Contains("_"))
                        {
                            job.Owner = Regex.Replace(job.Owner, ConfigurationManager.AppSettings["DevOwnerPre"], ConfigurationManager.AppSettings["ProdOwnerPre"], RegexOptions.IgnoreCase);
                            job.Owner = Regex.Replace(job.Owner, ConfigurationManager.AppSettings["StageOwnerPre"], ConfigurationManager.AppSettings["ProdOwnerPre"], RegexOptions.IgnoreCase);
                            job.Owner = Regex.Replace(job.Owner, ConfigurationManager.AppSettings["CtOwnerPre"], ConfigurationManager.AppSettings["ProdOwnerPre"], RegexOptions.IgnoreCase);
                            //job.Owner = job.Owner.Replace("Dev", ConfigurationManager.AppSettings["ProdOwnerPre"]);
                            //job.Owner = job.Owner.Replace("Sta", ConfigurationManager.AppSettings["ProdOwnerPre"]);
                            //job.Owner = job.Owner.Replace("Ct1", ConfigurationManager.AppSettings["ProdOwnerPre"]);
                        }

                        job.Owner = Regex.Replace(job.Owner, ConfigurationManager.AppSettings["NonProductionOwnerSuffix"], ConfigurationManager.AppSettings["ProductionOwnerSuffix"].ToUpper(), RegexOptions.IgnoreCase);
                        if (job.Owner.ToLower().Contains("asysactionacct") && !job.Owner.ToUpper().Contains(ConfigurationManager.AppSettings["ProductionOwnerSuffix"].ToUpper()))
                        {
                            job.Owner = Regex.Replace(job.Owner, "AsysActionAcct", "AsysActionAcct@PRO", RegexOptions.IgnoreCase);
                        }

                        //if(job.Owner.Contains("@PRO"))
                        //job.Owner = job.Owner.Remove(job.Owner.LastIndexOf("@PRO") + 4);
                    }

                    //adding changes for new attributes similar to owner
                    if (!string.IsNullOrEmpty(job.Ftp_Local_User))
                    {
                        if (job.Ftp_Local_User.ToLower().Contains(ConfigurationManager.AppSettings["ProOwnerName"]))
                        {
                            job.Ftp_Local_User = Regex.Replace(job.Ftp_Local_User, ConfigurationManager.AppSettings["DevOwnerPrefix"].ToUpper(), "", RegexOptions.IgnoreCase);
                            job.Ftp_Local_User = Regex.Replace(job.Ftp_Local_User, ConfigurationManager.AppSettings["StageOwnerPrefix"].ToUpper(), "", RegexOptions.IgnoreCase);
                            job.Ftp_Local_User = Regex.Replace(job.Ftp_Local_User, ConfigurationManager.AppSettings["CtOwnerPrefix"].ToUpper(), "", RegexOptions.IgnoreCase);
                            //job.Ftp_Local_User = job.Ftp_Local_User.Replace("Dev_", "");
                            //job.Ftp_Local_User = job.Ftp_Local_User.Replace("Sta_", "");
                            //job.Ftp_Local_User = job.Ftp_Local_User.Replace("Ct1_", "");
                        }
                        else if (!job.Ftp_Local_User.ToLower().Contains(ConfigurationManager.AppSettings["ProOwnerName"]) && job.Ftp_Local_User.Contains("_"))
                        {
                            job.Ftp_Local_User = Regex.Replace(job.Ftp_Local_User, ConfigurationManager.AppSettings["DevOwnerPre"], ConfigurationManager.AppSettings["ProdOwnerPre"], RegexOptions.IgnoreCase);
                            job.Ftp_Local_User = Regex.Replace(job.Ftp_Local_User, ConfigurationManager.AppSettings["StageOwnerPre"], ConfigurationManager.AppSettings["ProdOwnerPre"], RegexOptions.IgnoreCase);
                            job.Ftp_Local_User = Regex.Replace(job.Ftp_Local_User, ConfigurationManager.AppSettings["CtOwnerPre"], ConfigurationManager.AppSettings["ProdOwnerPre"], RegexOptions.IgnoreCase);
                            //job.Ftp_Local_User = job.Ftp_Local_User.Replace("Dev", ConfigurationManager.AppSettings["ProdOwnerPre"]);
                            //job.Ftp_Local_User = job.Ftp_Local_User.Replace("Sta", ConfigurationManager.AppSettings["ProdOwnerPre"]);
                            //job.Ftp_Local_User = job.Ftp_Local_User.Replace("Ct1", ConfigurationManager.AppSettings["ProdOwnerPre"]);
                        }

                        job.Ftp_Local_User = Regex.Replace(job.Ftp_Local_User, ConfigurationManager.AppSettings["NonProductionOwnerSuffix"], ConfigurationManager.AppSettings["ProductionOwnerSuffix"].ToUpper(), RegexOptions.IgnoreCase);
                        if (job.Ftp_Local_User.ToLower().Contains("asysactionacct") && !job.Ftp_Local_User.ToUpper().Contains(ConfigurationManager.AppSettings["ProductionOwnerSuffix"].ToUpper()))
                        {
                            job.Ftp_Local_User = Regex.Replace(job.Ftp_Local_User, "AsysActionAcct", "AsysActionAcct@PRO", RegexOptions.IgnoreCase);
                        }
                    }

                    if (!string.IsNullOrEmpty(job.Watch_File_Win_User))
                    {
                        if (job.Watch_File_Win_User.ToLower().Contains(ConfigurationManager.AppSettings["ProOwnerName"]))
                        {
                            job.Watch_File_Win_User = Regex.Replace(job.Watch_File_Win_User, ConfigurationManager.AppSettings["DevOwnerPrefix"].ToUpper(), "", RegexOptions.IgnoreCase);
                            job.Watch_File_Win_User = Regex.Replace(job.Watch_File_Win_User, ConfigurationManager.AppSettings["StageOwnerPrefix"].ToUpper(), "", RegexOptions.IgnoreCase);
                            job.Watch_File_Win_User = Regex.Replace(job.Watch_File_Win_User, ConfigurationManager.AppSettings["CtOwnerPrefix"].ToUpper(), "", RegexOptions.IgnoreCase);
                            //job.Watch_File_Win_User = job.Watch_File_Win_User.Replace("Dev_", "");
                            //job.Watch_File_Win_User = job.Watch_File_Win_User.Replace("Sta_", "");
                            //job.Watch_File_Win_User = job.Watch_File_Win_User.Replace("Ct1_", "");
                        }
                        else if (!job.Watch_File_Win_User.ToLower().Contains(ConfigurationManager.AppSettings["ProOwnerName"]) && job.Watch_File_Win_User.Contains("_"))
                        {
                            job.Watch_File_Win_User = Regex.Replace(job.Watch_File_Win_User, ConfigurationManager.AppSettings["DevOwnerPre"], ConfigurationManager.AppSettings["ProdOwnerPre"], RegexOptions.IgnoreCase);
                            job.Watch_File_Win_User = Regex.Replace(job.Watch_File_Win_User, ConfigurationManager.AppSettings["StageOwnerPre"], ConfigurationManager.AppSettings["ProdOwnerPre"], RegexOptions.IgnoreCase);
                            job.Watch_File_Win_User = Regex.Replace(job.Watch_File_Win_User, ConfigurationManager.AppSettings["CtOwnerPre"], ConfigurationManager.AppSettings["ProdOwnerPre"], RegexOptions.IgnoreCase);
                            //job.Watch_File_Win_User = job.Watch_File_Win_User.Replace("Dev", ConfigurationManager.AppSettings["ProdOwnerPre"]);
                            //job.Watch_File_Win_User = job.Watch_File_Win_User.Replace("Sta", ConfigurationManager.AppSettings["ProdOwnerPre"]);
                            //job.Watch_File_Win_User = job.Watch_File_Win_User.Replace("Ct1", ConfigurationManager.AppSettings["ProdOwnerPre"]);
                        }

                        job.Watch_File_Win_User = Regex.Replace(job.Watch_File_Win_User, ConfigurationManager.AppSettings["NonProductionOwnerSuffix"], ConfigurationManager.AppSettings["ProductionOwnerSuffix"].ToUpper(), RegexOptions.IgnoreCase);
                        if (job.Watch_File_Win_User.ToLower().Contains("asysactionacct") && !job.Watch_File_Win_User.ToUpper().Contains(ConfigurationManager.AppSettings["ProductionOwnerSuffix"].ToUpper()))
                        {
                            job.Watch_File_Win_User = Regex.Replace(job.Watch_File_Win_User, "AsysActionAcct", "AsysActionAcct@PRO", RegexOptions.IgnoreCase);
                        }
                    }

                    if (!string.IsNullOrEmpty(job.Command))
                    {
                        //job.Command = Regex.Replace(job.Command, ConfigurationManager.AppSettings["DevCommandPath"], ConfigurationManager.AppSettings["DalProdFileStoreRootLocation"], RegexOptions.IgnoreCase);
                        job.Command = job.Command.Replace(ConfigurationManager.AppSettings["OldDevCommandPath"].Replace("$$$$", "$$"), ConfigurationManager.AppSettings["DalProdFileStoreRootLocation"]);
                        job.Command = job.Command.Replace(ConfigurationManager.AppSettings["DevCommandPath"].Replace("$$$$", "$$"), ConfigurationManager.AppSettings["DalProdFileStoreRootLocation"]);
                        job.Command = job.Command.Replace(ConfigurationManager.AppSettings["DevNASCommandPath"].Replace("$$$$", "$$"), ConfigurationManager.AppSettings["DalProdFileStoreRootLocation"]);
                        //job.Command = Regex.Replace(job.Command, ConfigurationManager.AppSettings["StageCommandPath"], ConfigurationManager.AppSettings["DalProdFileStoreRootLocation"], RegexOptions.IgnoreCase);
                        job.Command = job.Command.Replace(ConfigurationManager.AppSettings["StageCommandPath"].Replace("$$$$", "$$"), ConfigurationManager.AppSettings["DalProdFileStoreRootLocation"]);
                        job.Command = job.Command.Replace(ConfigurationManager.AppSettings["StageNASCommandPath"].Replace("$$$$", "$$"), ConfigurationManager.AppSettings["DalProdFileStoreRootLocation"]);
                        //job.Command = Regex.Replace(job.Command, ConfigurationManager.AppSettings["CtCommandPath"], ConfigurationManager.AppSettings["DalProdFileStoreRootLocation"], RegexOptions.IgnoreCase);
                        job.Command = job.Command.Replace(ConfigurationManager.AppSettings["CtCommandPath"].Replace("$$$$", "$$"), ConfigurationManager.AppSettings["DalProdFileStoreRootLocation"]);
                        job.Command = job.Command.Replace(ConfigurationManager.AppSettings["CtNASCommandPath"].Replace("$$$$", "$$"), ConfigurationManager.AppSettings["DalProdFileStoreRootLocation"]);
                        job.Command = Regex.Replace(job.Command, ConfigurationManager.AppSettings["DevOldAsaMachine01"], ConfigurationManager.AppSettings["DalProdFileStoreRootLocation"], RegexOptions.IgnoreCase);
                        job.Command = Regex.Replace(job.Command, ConfigurationManager.AppSettings["DevOldAsaMachine02"], ConfigurationManager.AppSettings["DalProdFileStoreRootLocation"], RegexOptions.IgnoreCase);
                        job.Command = Regex.Replace(job.Command, ConfigurationManager.AppSettings["DevNewAsaMachine01"], ConfigurationManager.AppSettings["DalProdFileStoreRootLocation"], RegexOptions.IgnoreCase);
                        job.Command = Regex.Replace(job.Command, ConfigurationManager.AppSettings["DevNewAsaMachine02"], ConfigurationManager.AppSettings["DalProdFileStoreRootLocation"], RegexOptions.IgnoreCase);
                        job.Command = Regex.Replace(job.Command, ConfigurationManager.AppSettings["StageOldAsaMachine01"], ConfigurationManager.AppSettings["DalProdFileStoreRootLocation"], RegexOptions.IgnoreCase);
                        job.Command = Regex.Replace(job.Command, ConfigurationManager.AppSettings["StageOldAsaMachine02"], ConfigurationManager.AppSettings["DalProdFileStoreRootLocation"], RegexOptions.IgnoreCase);
                        job.Command = Regex.Replace(job.Command, ConfigurationManager.AppSettings["StageNewAsaMachine01"], ConfigurationManager.AppSettings["DalProdFileStoreRootLocation"], RegexOptions.IgnoreCase);
                        job.Command = Regex.Replace(job.Command, ConfigurationManager.AppSettings["StageNewAsaMachine02"], ConfigurationManager.AppSettings["DalProdFileStoreRootLocation"], RegexOptions.IgnoreCase);
                        job.Command = Regex.Replace(job.Command, ConfigurationManager.AppSettings["DevGwyNewAsaMachine01"], ConfigurationManager.AppSettings["DalProdFileStoreRootLocation"], RegexOptions.IgnoreCase);
                        job.Command = Regex.Replace(job.Command, ConfigurationManager.AppSettings["DevGwyNewAsaMachine02"], ConfigurationManager.AppSettings["DalProdFileStoreRootLocation"], RegexOptions.IgnoreCase);
                        job.Command = Regex.Replace(job.Command, ConfigurationManager.AppSettings["StageGwyNewAsaMachine01"], ConfigurationManager.AppSettings["DalProdFileStoreRootLocation"], RegexOptions.IgnoreCase);
                        job.Command = Regex.Replace(job.Command, ConfigurationManager.AppSettings["StageGwyNewAsaMachine02"], ConfigurationManager.AppSettings["DalProdFileStoreRootLocation"], RegexOptions.IgnoreCase);
                        job.Command = Regex.Replace(job.Command, ConfigurationManager.AppSettings["NonProdFileStoreRootLocation"], ConfigurationManager.AppSettings["DalProdFileStoreRootLocation"], RegexOptions.IgnoreCase);
                        job.Command = Regex.Replace(job.Command, ConfigurationManager.AppSettings["NonProdSchedulerNASMachine"], ConfigurationManager.AppSettings["DalProdFileStoreRootLocation"], RegexOptions.IgnoreCase);
                        job.Command = job.Command.Replace("$$$$", "$$");
                        job.Command = job.Command.Replace(StringConstants.DEV_BSL_JOBS_SUBSTRING, StringConstants.PROD_BIS_JOBS_SUBSTRING);
                        job.Command = job.Command.Replace(StringConstants.STAGE_BSL_JOBS_SUBSTRING, StringConstants.PROD_BIS_JOBS_SUBSTRING);
                        job.Command = job.Command.Replace(StringConstants.CT_BSL_JOBS_SUBSTRING, StringConstants.PROD_BIS_JOBS_SUBSTRING);
                        job.Command = Regex.Replace(job.Command, ConfigurationManager.AppSettings["OldIncomingFilesPath"], ConfigurationManager.AppSettings["NewIncomingFilesPath"], RegexOptions.IgnoreCase);
                        job.Command = Regex.Replace(job.Command, ConfigurationManager.AppSettings["DevFileNameExtension"], ConfigurationManager.AppSettings["ProdFileNameExtension"], RegexOptions.IgnoreCase);
                        job.Command = Regex.Replace(job.Command, ConfigurationManager.AppSettings["StageFileNameExtension"], ConfigurationManager.AppSettings["ProdFileNameExtension"], RegexOptions.IgnoreCase);
                        job.Command = Regex.Replace(job.Command, ConfigurationManager.AppSettings["CtFileNameExtension"], ConfigurationManager.AppSettings["ProdFileNameExtension"], RegexOptions.IgnoreCase);
                    }

                    //adding changes in new attribute similar to command
                    if (!string.IsNullOrEmpty(job.Ftp_Local_Name))
                    {
                        //job.Ftp_Local_Name = Regex.Replace(job.Ftp_Local_Name, ConfigurationManager.AppSettings["DevCommandPath"], ConfigurationManager.AppSettings["DalProdFileStoreRootLocation"], RegexOptions.IgnoreCase);
                        job.Ftp_Local_Name = job.Ftp_Local_Name.Replace(ConfigurationManager.AppSettings["OldDevCommandPath"].Replace("$$$$", "$$"), ConfigurationManager.AppSettings["DalProdFileStoreRootLocation"]);
                        job.Ftp_Local_Name = job.Ftp_Local_Name.Replace(ConfigurationManager.AppSettings["DevCommandPath"].Replace("$$$$", "$$"), ConfigurationManager.AppSettings["DalProdFileStoreRootLocation"]);
                        job.Ftp_Local_Name = job.Ftp_Local_Name.Replace(ConfigurationManager.AppSettings["DevNASCommandPath"].Replace("$$$$", "$$"), ConfigurationManager.AppSettings["DalProdFileStoreRootLocation"]);
                        //job.Ftp_Local_Name = Regex.Replace(job.Ftp_Local_Name, ConfigurationManager.AppSettings["StageCommandPath"], ConfigurationManager.AppSettings["DalProdFileStoreRootLocation"], RegexOptions.IgnoreCase);
                        job.Ftp_Local_Name = job.Ftp_Local_Name.Replace(ConfigurationManager.AppSettings["StageCommandPath"].Replace("$$$$", "$$"), ConfigurationManager.AppSettings["DalProdFileStoreRootLocation"]);
                        job.Ftp_Local_Name = job.Ftp_Local_Name.Replace(ConfigurationManager.AppSettings["StageNASCommandPath"].Replace("$$$$", "$$"), ConfigurationManager.AppSettings["DalProdFileStoreRootLocation"]);
                        //job.Ftp_Local_Name = Regex.Replace(job.Ftp_Local_Name, ConfigurationManager.AppSettings["CtCommandPath"], ConfigurationManager.AppSettings["DalProdFileStoreRootLocation"], RegexOptions.IgnoreCase);
                        job.Ftp_Local_Name = job.Ftp_Local_Name.Replace(ConfigurationManager.AppSettings["CtCommandPath"].Replace("$$$$", "$$"), ConfigurationManager.AppSettings["DalProdFileStoreRootLocation"]);
                        job.Ftp_Local_Name = job.Ftp_Local_Name.Replace(ConfigurationManager.AppSettings["CtNASCommandPath"].Replace("$$$$", "$$"), ConfigurationManager.AppSettings["DalProdFileStoreRootLocation"]);
                        job.Ftp_Local_Name = Regex.Replace(job.Ftp_Local_Name, ConfigurationManager.AppSettings["DevOldAsaMachine01"], ConfigurationManager.AppSettings["DalProdFileStoreRootLocation"], RegexOptions.IgnoreCase);
                        job.Ftp_Local_Name = Regex.Replace(job.Ftp_Local_Name, ConfigurationManager.AppSettings["DevOldAsaMachine02"], ConfigurationManager.AppSettings["DalProdFileStoreRootLocation"], RegexOptions.IgnoreCase);
                        job.Ftp_Local_Name = Regex.Replace(job.Ftp_Local_Name, ConfigurationManager.AppSettings["DevNewAsaMachine01"], ConfigurationManager.AppSettings["DalProdFileStoreRootLocation"], RegexOptions.IgnoreCase);
                        job.Ftp_Local_Name = Regex.Replace(job.Ftp_Local_Name, ConfigurationManager.AppSettings["DevNewAsaMachine02"], ConfigurationManager.AppSettings["DalProdFileStoreRootLocation"], RegexOptions.IgnoreCase);
                        job.Ftp_Local_Name = Regex.Replace(job.Ftp_Local_Name, ConfigurationManager.AppSettings["StageOldAsaMachine01"], ConfigurationManager.AppSettings["DalProdFileStoreRootLocation"], RegexOptions.IgnoreCase);
                        job.Ftp_Local_Name = Regex.Replace(job.Ftp_Local_Name, ConfigurationManager.AppSettings["StageOldAsaMachine02"], ConfigurationManager.AppSettings["DalProdFileStoreRootLocation"], RegexOptions.IgnoreCase);
                        job.Ftp_Local_Name = Regex.Replace(job.Ftp_Local_Name, ConfigurationManager.AppSettings["StageNewAsaMachine01"], ConfigurationManager.AppSettings["DalProdFileStoreRootLocation"], RegexOptions.IgnoreCase);
                        job.Ftp_Local_Name = Regex.Replace(job.Ftp_Local_Name, ConfigurationManager.AppSettings["StageNewAsaMachine02"], ConfigurationManager.AppSettings["DalProdFileStoreRootLocation"], RegexOptions.IgnoreCase);
                        job.Ftp_Local_Name = Regex.Replace(job.Ftp_Local_Name, ConfigurationManager.AppSettings["DevGwyNewAsaMachine01"], ConfigurationManager.AppSettings["DalProdFileStoreRootLocation"], RegexOptions.IgnoreCase);
                        job.Ftp_Local_Name = Regex.Replace(job.Ftp_Local_Name, ConfigurationManager.AppSettings["DevGwyNewAsaMachine02"], ConfigurationManager.AppSettings["DalProdFileStoreRootLocation"], RegexOptions.IgnoreCase);
                        job.Ftp_Local_Name = Regex.Replace(job.Ftp_Local_Name, ConfigurationManager.AppSettings["StageGwyNewAsaMachine01"], ConfigurationManager.AppSettings["DalProdFileStoreRootLocation"], RegexOptions.IgnoreCase);
                        job.Ftp_Local_Name = Regex.Replace(job.Ftp_Local_Name, ConfigurationManager.AppSettings["StageGwyNewAsaMachine02"], ConfigurationManager.AppSettings["DalProdFileStoreRootLocation"], RegexOptions.IgnoreCase);
                        job.Ftp_Local_Name = Regex.Replace(job.Ftp_Local_Name, ConfigurationManager.AppSettings["NonProdFileStoreRootLocation"], ConfigurationManager.AppSettings["DalProdFileStoreRootLocation"], RegexOptions.IgnoreCase);
                        job.Ftp_Local_Name = Regex.Replace(job.Ftp_Local_Name, ConfigurationManager.AppSettings["NonProdSchedulerNASMachine"], ConfigurationManager.AppSettings["DalProdFileStoreRootLocation"], RegexOptions.IgnoreCase);
                        job.Ftp_Local_Name = job.Ftp_Local_Name.Replace("$$$$", "$$");
                        job.Ftp_Local_Name = Regex.Replace(job.Ftp_Local_Name, ConfigurationManager.AppSettings["OldIncomingFilesPath"], ConfigurationManager.AppSettings["NewIncomingFilesPath"], RegexOptions.IgnoreCase);
                        job.Ftp_Local_Name = Regex.Replace(job.Ftp_Local_Name, ConfigurationManager.AppSettings["DevFileNameExtension"], ConfigurationManager.AppSettings["ProdFileNameExtension"], RegexOptions.IgnoreCase);
                        job.Ftp_Local_Name = Regex.Replace(job.Ftp_Local_Name, ConfigurationManager.AppSettings["StageFileNameExtension"], ConfigurationManager.AppSettings["ProdFileNameExtension"], RegexOptions.IgnoreCase);
                        job.Ftp_Local_Name = Regex.Replace(job.Ftp_Local_Name, ConfigurationManager.AppSettings["CtFileNameExtension"], ConfigurationManager.AppSettings["ProdFileNameExtension"], RegexOptions.IgnoreCase);
                    }

                    if (!string.IsNullOrEmpty(job.Watch_File))
                    {
                        //job.Watch_File = Regex.Replace(job.Watch_File, ConfigurationManager.AppSettings["DevCommandPath"], ConfigurationManager.AppSettings["DalProdFileStoreRootLocation"], RegexOptions.IgnoreCase);
                        job.Watch_File = job.Watch_File.Replace(ConfigurationManager.AppSettings["OldDevCommandPath"].Replace("$$$$", "$$"), ConfigurationManager.AppSettings["DalProdFileStoreRootLocation"]);
                        job.Watch_File = job.Watch_File.Replace(ConfigurationManager.AppSettings["DevCommandPath"].Replace("$$$$", "$$"), ConfigurationManager.AppSettings["DalProdFileStoreRootLocation"]);
                        job.Watch_File = job.Watch_File.Replace(ConfigurationManager.AppSettings["DevNASCommandPath"].Replace("$$$$", "$$"), ConfigurationManager.AppSettings["DalProdFileStoreRootLocation"]);
                        //job.Watch_File = Regex.Replace(job.Watch_File, ConfigurationManager.AppSettings["StageCommandPath"], ConfigurationManager.AppSettings["DalProdFileStoreRootLocation"], RegexOptions.IgnoreCase);
                        job.Watch_File = job.Watch_File.Replace(ConfigurationManager.AppSettings["StageCommandPath"].Replace("$$$$", "$$"), ConfigurationManager.AppSettings["DalProdFileStoreRootLocation"]);
                        job.Watch_File = job.Watch_File.Replace(ConfigurationManager.AppSettings["StageNASCommandPath"].Replace("$$$$", "$$"), ConfigurationManager.AppSettings["DalProdFileStoreRootLocation"]);
                        //job.Watch_File = Regex.Replace(job.Watch_File, ConfigurationManager.AppSettings["CtCommandPath"], ConfigurationManager.AppSettings["DalProdFileStoreRootLocation"], RegexOptions.IgnoreCase);
                        job.Watch_File = job.Watch_File.Replace(ConfigurationManager.AppSettings["CtCommandPath"].Replace("$$$$", "$$"), ConfigurationManager.AppSettings["DalProdFileStoreRootLocation"]);
                        job.Watch_File = job.Watch_File.Replace(ConfigurationManager.AppSettings["CtNASCommandPath"].Replace("$$$$", "$$"), ConfigurationManager.AppSettings["DalProdFileStoreRootLocation"]);
                        job.Watch_File = Regex.Replace(job.Watch_File, ConfigurationManager.AppSettings["DevOldAsaMachine01"], ConfigurationManager.AppSettings["DalProdFileStoreRootLocation"], RegexOptions.IgnoreCase);
                        job.Watch_File = Regex.Replace(job.Watch_File, ConfigurationManager.AppSettings["DevOldAsaMachine02"], ConfigurationManager.AppSettings["DalProdFileStoreRootLocation"], RegexOptions.IgnoreCase);
                        job.Watch_File = Regex.Replace(job.Watch_File, ConfigurationManager.AppSettings["DevNewAsaMachine01"], ConfigurationManager.AppSettings["DalProdFileStoreRootLocation"], RegexOptions.IgnoreCase);
                        job.Watch_File = Regex.Replace(job.Watch_File, ConfigurationManager.AppSettings["DevNewAsaMachine02"], ConfigurationManager.AppSettings["DalProdFileStoreRootLocation"], RegexOptions.IgnoreCase);
                        job.Watch_File = Regex.Replace(job.Watch_File, ConfigurationManager.AppSettings["StageOldAsaMachine01"], ConfigurationManager.AppSettings["DalProdFileStoreRootLocation"], RegexOptions.IgnoreCase);
                        job.Watch_File = Regex.Replace(job.Watch_File, ConfigurationManager.AppSettings["StageOldAsaMachine02"], ConfigurationManager.AppSettings["DalProdFileStoreRootLocation"], RegexOptions.IgnoreCase);
                        job.Watch_File = Regex.Replace(job.Watch_File, ConfigurationManager.AppSettings["StageNewAsaMachine01"], ConfigurationManager.AppSettings["DalProdFileStoreRootLocation"], RegexOptions.IgnoreCase);
                        job.Watch_File = Regex.Replace(job.Watch_File, ConfigurationManager.AppSettings["StageNewAsaMachine02"], ConfigurationManager.AppSettings["DalProdFileStoreRootLocation"], RegexOptions.IgnoreCase);
                        job.Watch_File = Regex.Replace(job.Watch_File, ConfigurationManager.AppSettings["DevGwyNewAsaMachine01"], ConfigurationManager.AppSettings["DalProdFileStoreRootLocation"], RegexOptions.IgnoreCase);
                        job.Watch_File = Regex.Replace(job.Watch_File, ConfigurationManager.AppSettings["DevGwyNewAsaMachine02"], ConfigurationManager.AppSettings["DalProdFileStoreRootLocation"], RegexOptions.IgnoreCase);
                        job.Watch_File = Regex.Replace(job.Watch_File, ConfigurationManager.AppSettings["StageGwyNewAsaMachine01"], ConfigurationManager.AppSettings["DalProdFileStoreRootLocation"], RegexOptions.IgnoreCase);
                        job.Watch_File = Regex.Replace(job.Watch_File, ConfigurationManager.AppSettings["StageGwyNewAsaMachine02"], ConfigurationManager.AppSettings["DalProdFileStoreRootLocation"], RegexOptions.IgnoreCase);
                        job.Watch_File = Regex.Replace(job.Watch_File, ConfigurationManager.AppSettings["NonProdFileStoreRootLocation"], ConfigurationManager.AppSettings["DalProdFileStoreRootLocation"], RegexOptions.IgnoreCase);
                        job.Watch_File = Regex.Replace(job.Watch_File, ConfigurationManager.AppSettings["NonProdSchedulerNASMachine"], ConfigurationManager.AppSettings["DalProdFileStoreRootLocation"], RegexOptions.IgnoreCase);
                        job.Watch_File = job.Watch_File.Replace("$$$$", "$$");
                        job.Watch_File = Regex.Replace(job.Watch_File, ConfigurationManager.AppSettings["OldIncomingFilesPath"], ConfigurationManager.AppSettings["NewIncomingFilesPath"], RegexOptions.IgnoreCase);
                        job.Watch_File = Regex.Replace(job.Watch_File, ConfigurationManager.AppSettings["DevFileNameExtension"], ConfigurationManager.AppSettings["ProdFileNameExtension"], RegexOptions.IgnoreCase);
                        job.Watch_File = Regex.Replace(job.Watch_File, ConfigurationManager.AppSettings["StageFileNameExtension"], ConfigurationManager.AppSettings["ProdFileNameExtension"], RegexOptions.IgnoreCase);
                        job.Watch_File = Regex.Replace(job.Watch_File, ConfigurationManager.AppSettings["CtFileNameExtension"], ConfigurationManager.AppSettings["ProdFileNameExtension"], RegexOptions.IgnoreCase);
                    }
                }
            }

            if (Session[ID + "DevJobsAdded"] != null)
                isDevJobsAdded = (bool)Session[ID + "DevJobsAdded"];
            if (Session[ID + "StageJobsAdded"] != null)
                isStageJobsAdded = (bool)Session[ID + "StageJobsAdded"];
            if (Session[ID + "CtJobsAdded"] != null)
                isCtJobsAdded = (bool)Session[ID + "CtJobsAdded"];
            if (Session[ID + "ProdJobsAdded"] != null)
                isProdJobsAdded = (bool)Session[ID + "ProdJobsAdded"];

            if (Session[ID + "ASAServerAdded"] != null)
                isAsaServerAdded = (bool)Session[ID + "ASAServerAdded"];
            if (Session[ID + "GWYServerAdded"] != null)
                isGwyServerAdded = (bool)Session[ID + "GWYServerAdded"];
            if (Session[ID + "SCHEDULERServerAdded"] != null)
                isSchedulerServerAdded = (bool)Session[ID + "SCHEDULERServerAdded"];
            if (Session[ID + "LOCALHOSTServerAdded"] != null)
                isLocalHostServerAdded = (bool)Session[ID + "LOCALHOSTServerAdded"];

            if (isDevJobsAdded)
            {
                fileName += "Dev_";
            }
            if (isStageJobsAdded)
            {
                fileName += "Stage_";
            }
            if (isCtJobsAdded)
            {
                fileName += "CT_";
            }
            if (isProdJobsAdded)
            {
                fileName += "Prod_";
            }
            if (!isDevJobsAdded && !isStageJobsAdded && !isCtJobsAdded && !isProdJobsAdded)
            {
                fileName += "AllRegions_";
            }
            if (isAsaServerAdded)
            {
                fileName += "ASA_";
            }
            if (isGwyServerAdded)
            {
                fileName += "GWY_";
            }
            if (isSchedulerServerAdded)
            {
                fileName += "SCHEDULER_";
            }
            if (isLocalHostServerAdded)
            {
                fileName += "LOCALHOST_";
            }

            fileName += ConfigurationManager.AppSettings["FileNameSuffix"];
            foreach (var file in IO.Directory.GetFiles(IO.Path.GetTempPath()))
            {
                if (file.Contains(ConfigurationManager.AppSettings["UpdatedFileNameSuffix"]))
                    IO.File.Delete(file);
            }

            if (listOfJobsToCreateNewJil.Count > 0)
            {
                Session[ID + "ListOfJobs"] = listOfJobsToCreateNewJil;
                fileObj.PrintDataToOutputFile(listOfJobsToCreateNewJil, IO.Path.Combine(IO.Path.GetTempPath(), fileName));
                Session[ID + "FileName"] = fileName;
                isJilCreateSuccessfull = true;
            }

            return isJilCreateSuccessfull;
        }

        private List<string> GetListOfJobsFromJil(string txtJilPath, string ID)
        {
            List<string> billerNamesList = new List<string>();
            if (string.IsNullOrEmpty(txtJilPath))
            {
                ViewBag.Message = "Please enter valid file name.";
                ViewBag.FileExists = false;
            }
            else
            {
                if (IO.File.Exists(txtJilPath))
                {
                    List<FilteredJobs> listOfJobsFromJilFile = new List<FilteredJobs>();
                    billerNamesList = GetBillerNamesListAndListOfAllJobs(txtJilPath, ref listOfJobsFromJilFile).Distinct().ToList<string>();
                    Session[ID + "ListOfJobs"] = listOfJobsFromJilFile;
                    Session[ID + "ListOfJobsOriginal"] = JsonConvert.SerializeObject(listOfJobsFromJilFile);
                    if (listOfJobsFromJilFile.Count > 0)
                    {
                        listOfJobs = AnalyseJilForUpdates(listOfJobsFromJilFile, ID);
                        ViewBag.FileExists = true;
                        ViewBag.Message = "JIL File loaded succesfully!";
                    }
                    else
                    {
                        ViewBag.FileExists = false;
                        ViewBag.Message = "Input file is not valid. Please try again!";
                    }
                }
                else
                {
                    ViewBag.Message = "File doesnt exists, try again with different path!";
                    ViewBag.FileExists = false;
                }
            }

            return billerNamesList;
        }

        private List<string> GetBillerNamesListAndListOfAllJobs(string inputFileName, ref List<FilteredJobs> listOfJobs)
        {
            string billerName = string.Empty;
            List<string> listOfBillerNames = new List<string>();
            foreach (FilteredJobs item in listOfJobs = GetListOfJobs(inputFileName))
            {
                if (listOfJobs.Count > 0 && !string.IsNullOrEmpty(item.Insert_job))
                {
                    string insertJobName = item.Insert_job.ToLower().Split(new string[] { "insert_job:" }, StringSplitOptions.None).Last().Trim().Split(new string[] { "job_type:" }, StringSplitOptions.None).First().Trim();
                    List<string> listOfItemsInJob = insertJobName.Trim().Split('-').ToList<string>();
                    try
                    {
                        if (insertJobName.StartsWith(StringConstants.BSL_SUBSTRING) && listOfItemsInJob.Count >= 6)
                        {
                            billerName = insertJobName.Split(StringConstants.SPLIT_WITH_HYPHEN)[5].Trim();
                            listOfBillerNames.Add(billerName);
                        }
                        else if (insertJobName.StartsWith(StringConstants.BIS_SUBSTRING) && listOfItemsInJob.Count >= 6)
                        {
                            billerName = insertJobName.Split(StringConstants.SPLIT_WITH_HYPHEN)[6].Trim();
                            listOfBillerNames.Add(billerName);
                        }
                        else
                        {
                            billerName = string.Concat(insertJobName.TakeWhile(c => c != ' '));
                            listOfBillerNames.Add(billerName.Trim());
                        }
                    }
                    catch (Exception ex)
                    {
                        //SEM.Logging.SEMLogger.LogError(ex.Message + " for job name : {0}", item.Insert_job);
                        if (ex.Message.ToLower().Contains(StringConstants.INDEX))
                        {
                            billerName = string.Concat(insertJobName.TakeWhile(c => c != ' '));
                            listOfBillerNames.Add(billerName.Trim());
                            continue;
                        }
                    }
                }
            }

            return listOfBillerNames;
        }
        private List<FilteredJobs> GetListOfJobs(string inputFileName)
        {
            FilteredJobs job = new FilteredJobs();

            List<FilteredJobs> listOfJobs = new List<FilteredJobs>();
            int linesCount = IO.File.ReadLines(inputFileName).Count();
            string[] lines = new string[linesCount];
            lines = IO.File.ReadLines(inputFileName).ToArray<string>();
            for (int i = 0; i < lines.Length; i++)
            {
                if (lines[i].Trim().StartsWith(StringConstants.HEADER))
                {
                    if (job.Header != null && job.Insert_job != null)
                    {
                        listOfJobs.Add(job);
                        job = new FilteredJobs();
                    }
                    else if (job.Header == null && job.Insert_job != null)
                    {
                        listOfJobs.Add(job);
                        job = new FilteredJobs();
                    }

                    job.Header = lines[i];
                }
                else if (lines[i].Trim().StartsWith(StringConstants.INSERT_JOB))
                {
                    if (job.Insert_job != (null))
                    {
                        listOfJobs.Add(job);
                        job = new FilteredJobs();
                    }

                    job.Insert_job = lines[i];
                }

                switch (lines[i].Split(StringConstants.SPLIT_WITH_COLON)[0].Trim())
                {
                    case StringConstants.INSERT_JOB:

                        job.Insert_job = lines[i].Trim();
                        //job.Insert_job = job.Insert_job.Split(new string[] { "job_type" }, StringSplitOptions.None).First().Trim();

                        break;
                    case StringConstants.MACHINE:
                        job.Machine = lines[i].Trim();
                        break;
                    case StringConstants.BOX_NAME:
                        job.Boxname = lines[i].Trim();
                        break;
                    case StringConstants.CONDITION:
                        job.Condition = lines[i].Trim();
                        break;
                    case StringConstants.COMMAND:
                        job.Command = lines[i].Trim();
                        break;
                    case StringConstants.OWNER:
                        job.Owner = lines[i].Trim();
                        break;
                    case StringConstants.PERMISSION:
                        job.Permission = lines[i].Trim();
                        break;
                    case StringConstants.DATE_CONDITIONS:
                        job.DateCondition = lines[i].Trim();
                        break;
                    case StringConstants.DESCRIPTION:
                        job.Description = lines[i].Trim();
                        break;
                    case StringConstants.STD_OUT_FILE:
                        job.StdOutFile = lines[i].Trim();
                        break;
                    case StringConstants.STD_ERR_FILE:
                        job.StdErrFile = lines[i].Trim();
                        break;
                    case StringConstants.MAX_RUN_ALARM:
                        job.MaxRunAlarm = lines[i].Trim();
                        break;
                    case StringConstants.ALARF_IF_FAIL:
                        job.AlarmIfFail = lines[i].Trim();
                        break;
                    case StringConstants.PROFILE:
                        job.Profile = lines[i].Trim();
                        break;
                    case StringConstants.JOB_LOAD:
                        job.JobLoad = lines[i].Trim();
                        break;
                    case StringConstants.PRIORITY:
                        job.Priority = lines[i].Trim();
                        break;
                    case StringConstants.GROUP:
                        job.Group = lines[i].Trim();
                        break;
                    case StringConstants.BOX_SUCCESS:
                        job.Box_Success = lines[i].Trim();
                        break;
                    case StringConstants.BOX_FAILURE:
                        job.Box_Failure = lines[i].Trim();
                        break;
                    case StringConstants.APPLICATION:
                        job.Application = lines[i].Trim();
                        break;
                    case StringConstants.MUST_START_TIMES:
                        job.Must_Start_Times = lines[i].Trim();
                        break;
                    case StringConstants.DAYS_OF_WEEK:
                        job.Run_Day = lines[i].Trim();
                        break;
                    case StringConstants.START_TIMES:
                        job.Start_Times = lines[i].Trim();
                        break;
                    case StringConstants.RUN_CALENDAR:
                        job.Run_Calendar = lines[i].Trim();
                        break;
                    case StringConstants.N_RETRYS:
                        job.N_Retrys = lines[i].Trim();
                        break;
                    case StringConstants.MAX_EXIT_SUCCESS:
                        job.Max_Exit_Success = lines[i].Trim();
                        break;
                    case StringConstants.SUCCESS_CODES:
                        job.Success_Codes = lines[i].Trim();
                        break;
                    case StringConstants.FAIL_CODES:
                        job.Fail_Codes = lines[i].Trim();
                        break;
                    case StringConstants.MUST_COMPLETE_TIMES:
                        job.Must_Complete_Times = lines[i].Trim();
                        break;
                    case StringConstants.FTP_TRANSFER_TYPE:
                        job.Ftp_Transfer_Type = lines[i].Trim();
                        break;

                    case StringConstants.FTP_TRANSFER_DIRECTION:
                        job.Ftp_Transfer_Direction = lines[i].Trim();
                        break;
                    case StringConstants.FTP_LOCAL_NAME:
                        job.Ftp_Local_Name = lines[i].Trim();
                        break;
                    case StringConstants.FTP_REMOTE_NAME:
                        job.Ftp_Remote_Name = lines[i].Trim();
                        break;
                    case StringConstants.FTP_SERVER_NAME:
                        job.Ftp_Server_Name = lines[i].Trim();
                        break;
                    case StringConstants.FTP_SERVER_PORT:
                        job.Ftp_Server_port = lines[i].Trim();
                        break;
                    case StringConstants.FTP_USE_SSL:
                        job.Ftp_Use_Ssl = lines[i].Trim();
                        break;
                    case StringConstants.FTP_LOCAL_USER:
                        job.Ftp_Local_User = lines[i].Trim();
                        break;
                    case StringConstants.START_MINS:
                        job.Start_Mins = lines[i].Trim();
                        break;
                    case StringConstants.WATCH_FILE:
                        job.Watch_File = lines[i].Trim();
                        break;
                    case StringConstants.WATCH_FILE_RECURRSIVE:
                        job.Watch_File_Recurrsive = lines[i].Trim();
                        break;
                    case StringConstants.WATCH_FILE_TYPE:
                        job.Watch_File_Type = lines[i].Trim();
                        break;
                    case StringConstants.WATCH_FILE_WIN_USER:
                        job.Watch_File_Win_User = lines[i].Trim();
                        break;
                    case StringConstants.CONTINOUS:
                        job.Continous = lines[i].Trim();
                        break;
                    case StringConstants.WATCH_INTERVAL:
                        job.Watch_Interval = lines[i].Trim();
                        break;
                    case StringConstants.WIN_EVENT_OP:
                        job.Win_Event_Op = lines[i].Trim();
                        break;
                    case StringConstants.MONITOR_MODE:
                        job.Monitor_Mode = lines[i].Trim();
                        break;
                    case StringConstants.TERM_RUN_TIME:
                        job.Term_Run_Time = lines[i].Trim();
                        break;
                    case StringConstants.SEND_NOTIFICATION:
                        job.Send_Notification = lines[i].Trim();
                        break;
                    case StringConstants.NOTIFICATION_ID:
                        job.Notification_Id = lines[i].Trim();
                        break;
                    case StringConstants.NOTIFICATION_MSG:
                        job.Notification_Msg = lines[i].Trim();
                        break;
                    case StringConstants.EXCLUDE_CALENDAR:
                        job.Exclude_Calendar = lines[i].Trim();
                        break;
                    case StringConstants.STD_IN_FILE:
                        job.Std_In_File = lines[i].Trim();
                        break;

                    case StringConstants.JOB_TERMINATOR:
                        job.Job_terminator = lines[i].Trim();
                        break;
                    case StringConstants.WIN_LOG_NAME:
                        job.Win_log_name = lines[i].Trim();
                        break;
                    case StringConstants.WIN_EVENT_TYPE:
                        job.Win_event_type = lines[i].Trim();
                        break;
                    case StringConstants.WIN_EVENT_ID:
                        job.Win_event_id = lines[i].Trim();
                        break;
                    case StringConstants.MIN_RUN_ALARM:
                        job.Min_run_alarm = lines[i].Trim();
                        break;
                    case StringConstants.ALARM_IF_TERMINATED:
                        job.Alarm_if_terminated = lines[i].Trim();
                        break;
                    case StringConstants.STATUS:
                        job.Status = lines[i].Trim();
                        break;
                    default:
                        continue;
                }
            }

            if (job != null && !string.IsNullOrEmpty(job.Insert_job))
                listOfJobs.Add(job);

            return listOfJobs;
        }
    }
}
