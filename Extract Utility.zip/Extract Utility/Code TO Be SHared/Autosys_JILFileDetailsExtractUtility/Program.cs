﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Configuration;
using System.IO;
using System.Data;
using SEM.Logging;
using System.Text;
using Excel = Microsoft.Office.Interop.Excel;
using System.Xml;
using System.Text.RegularExpressions;
using System.Diagnostics;

namespace Autosys_JILFileDetailsExtractUtility
{
   public  class ExcelCreator
    {
        /// <summary>       
        /// Create one Excel-XML-Document with SpreadsheetML from a DataTable
        /// </summary>        
        /// <param name="dataSource">Datasource which would be exported in Excel</param>
        /// <param name="fileName">Name of exported file</param>
        public static void Create(DataTable dtSource, string strFileName)
        {
            try
            {
                // Create XMLWriter
                XmlTextWriter xtwWriter = new XmlTextWriter(strFileName, Encoding.UTF8);

                //Format the output file for reading easier
                xtwWriter.Formatting = Formatting.Indented;

                // <?xml version="1.0"?>
                xtwWriter.WriteStartDocument();

                // <?mso-application progid="Excel.Sheet"?>
                xtwWriter.WriteProcessingInstruction("mso-application", "progid=\"Excel.Sheet\"");

                // <Workbook xmlns="urn:schemas-microsoft-com:office:spreadsheet >"
                xtwWriter.WriteStartElement("Workbook", "urn:schemas-microsoft-com:office:spreadsheet");

                //Write definition of namespace
                xtwWriter.WriteAttributeString("xmlns", "o", null, "urn:schemas-microsoft-com:office:office");
                xtwWriter.WriteAttributeString("xmlns", "x", null, "urn:schemas-microsoft-com:office:excel");
                xtwWriter.WriteAttributeString("xmlns", "ss", null, "urn:schemas-microsoft-com:office:spreadsheet");
                xtwWriter.WriteAttributeString("xmlns", "html", null, "http://www.w3.org/TR/REC-html40");

                // <DocumentProperties xmlns="urn:schemas-microsoft-com:office:office">
                xtwWriter.WriteStartElement("DocumentProperties", "urn:schemas-microsoft-com:office:office");

                // Write document properties
                xtwWriter.WriteElementString("Author", Environment.UserName);
                xtwWriter.WriteElementString("LastAuthor", Environment.UserName);
                xtwWriter.WriteElementString("Created", DateTime.Now.ToString("u") + "Z");
                xtwWriter.WriteElementString("Company", "Unknown");
                xtwWriter.WriteElementString("Version", "1.000");

                // </DocumentProperties>
                xtwWriter.WriteEndElement();

                // <ExcelWorkbook xmlns="urn:schemas-microsoft-com:office:excel">
                xtwWriter.WriteStartElement("ExcelWorkbook", "urn:schemas-microsoft-com:office:excel");

                // Write settings of workbook
                xtwWriter.WriteElementString("WindowHeight", "13170");
                xtwWriter.WriteElementString("WindowWidth", "17580");
                xtwWriter.WriteElementString("WindowTopX", "120");
                xtwWriter.WriteElementString("WindowTopY", "60");
                xtwWriter.WriteElementString("ProtectStructure", "False");
                xtwWriter.WriteElementString("ProtectWindows", "False");

                // </ExcelWorkbook>
                xtwWriter.WriteEndElement();

                // <Styles>
                xtwWriter.WriteStartElement("Styles");

                // <Style ss:ID="Default" ss:Name="Normal">
                xtwWriter.WriteStartElement("Style");
                xtwWriter.WriteAttributeString("ss", "ID", null, "Default");
                xtwWriter.WriteAttributeString("ss", "Name", null, "Normal");

                // <Alignment ss:Vertical="Bottom"/>
                xtwWriter.WriteStartElement("Alignment");
                xtwWriter.WriteAttributeString("ss", "Vertical", null, "Bottom");
                xtwWriter.WriteEndElement();

                // Write null on the other properties
                xtwWriter.WriteElementString("Borders", null);
                xtwWriter.WriteElementString("Font", null);
                xtwWriter.WriteElementString("Interior", null);
                xtwWriter.WriteElementString("NumberFormat", null);
                xtwWriter.WriteElementString("Protection", null);

                // </Style>
                xtwWriter.WriteEndElement();

                // </Styles>
                xtwWriter.WriteEndElement();

                // <Worksheet ss:Name="xxx">
                xtwWriter.WriteStartElement("Worksheet");
                xtwWriter.WriteAttributeString("ss", "Name", null, dtSource.TableName);

                // <Table ss:ExpandedColumnCount="2" ss:ExpandedRowCount="3" x:FullColumns="1" x:FullRows="1" ss:DefaultColumnWidth="60">
                xtwWriter.WriteStartElement("Table");
                xtwWriter.WriteAttributeString("ss", "ExpandedColumnCount", null, dtSource.Columns.Count.ToString());
                xtwWriter.WriteAttributeString("ss", "ExpandedRowCount", null, (dtSource.Rows.Count + 1).ToString());
                xtwWriter.WriteAttributeString("x", "FullColumns", null, "1");
                xtwWriter.WriteAttributeString("x", "FullRows", null, "1");
                xtwWriter.WriteAttributeString("ss", "DefaultColumnWidth", null, "60");

                xtwWriter.WriteStartElement("Row");
                foreach (DataColumn item in dtSource.Columns)
                {
                   
                    xtwWriter.WriteStartElement("Cell");
                    xtwWriter.WriteStartElement("Data");
                    xtwWriter.WriteAttributeString("ss", "Type", null, "String");
                    xtwWriter.WriteValue(item.ColumnName);
                    // </Data>
                    xtwWriter.WriteEndElement();

                    // </Cell>
                    xtwWriter.WriteEndElement();
                     
                }

                xtwWriter.WriteEndElement(); 
                foreach (DataRow row in dtSource.Rows)
                   {
                     
                    // Run through all rows of data source
                   
                        // <Row>
                        xtwWriter.WriteStartElement("Row");

                        // Run through all cell of current rows
                        foreach (object cellValue in row.ItemArray)
                        {
                            // <Cell>
                            xtwWriter.WriteStartElement("Cell");

                            // <Data ss:Type="String">xxx</Data>
                            xtwWriter.WriteStartElement("Data");
                            xtwWriter.WriteAttributeString("ss", "Type", null, "String");

                            // Write content of cell
                            xtwWriter.WriteValue(cellValue);

                            // </Data>
                            xtwWriter.WriteEndElement();

                            // </Cell>
                            xtwWriter.WriteEndElement();
                        }
                        // </Row>
                        xtwWriter.WriteEndElement();               
                    }
               
                // </Table>
                xtwWriter.WriteEndElement();

                // <WorksheetOptions xmlns="urn:schemas-microsoft-com:office:excel">
                xtwWriter.WriteStartElement("WorksheetOptions", "urn:schemas-microsoft-com:office:excel");

                // Write settings of page
                xtwWriter.WriteStartElement("PageSetup");
                xtwWriter.WriteStartElement("Header");
                xtwWriter.WriteAttributeString("x", "Margin", null, "0.4921259845");
                xtwWriter.WriteEndElement();
                xtwWriter.WriteStartElement("Footer");
                xtwWriter.WriteAttributeString("x", "Margin", null, "0.4921259845");
                xtwWriter.WriteEndElement();
                xtwWriter.WriteStartElement("PageMargins");
                xtwWriter.WriteAttributeString("x", "Bottom", null, "0.984251969");
                xtwWriter.WriteAttributeString("x", "Left", null, "0.78740157499999996");
                xtwWriter.WriteAttributeString("x", "Right", null, "0.78740157499999996");
                xtwWriter.WriteAttributeString("x", "Top", null, "0.984251969");
                xtwWriter.WriteEndElement();
                xtwWriter.WriteEndElement();

                // <Selected/>
                xtwWriter.WriteElementString("Selected", null);

                // <Panes>
                xtwWriter.WriteStartElement("Panes");

                // <Pane>
                xtwWriter.WriteStartElement("Pane");

                // Write settings of active field
                xtwWriter.WriteElementString("Number", "1");
                xtwWriter.WriteElementString("ActiveRow", "1");
                xtwWriter.WriteElementString("ActiveCol", "1");

                // </Pane>
                xtwWriter.WriteEndElement();

                // </Panes>
                xtwWriter.WriteEndElement();

                // <ProtectObjects>False</ProtectObjects>
                xtwWriter.WriteElementString("ProtectObjects", "False");

                // <ProtectScenarios>False</ProtectScenarios>
                xtwWriter.WriteElementString("ProtectScenarios", "False");

                // </WorksheetOptions>
                xtwWriter.WriteEndElement();

                // </Worksheet>
                xtwWriter.WriteEndElement();

                // </Workbook>
                xtwWriter.WriteEndElement();

                // Write file on hard disk
                xtwWriter.Flush();
                xtwWriter.Close();
            }
            catch (Exception ex)
            {
                Console.WriteLine(ex.Message);
            }
        }
    }

    public class Program
    {
        static int Main(string[] args)
        {
            int result = 0;
            try
            {
                Stopwatch timer = new Stopwatch();
                timer.Start();
                List<string> listOfNewParameters = new List<string>();
                SEMLogger logger = new SEMLogger(@"\Autosys_JILFileDetailsExtractUtility\log4net.config");
                SEMLogger.LogInformation("Logger initialized..." + Environment.NewLine);
                FileOperations fileOperationsObj = new FileOperations();
                JilOperations jilOperationsObj = new JilOperations();
                string inputFileName = ConfigurationManager.AppSettings[StringConstants.INPUT_FILENAME_WITHPATH];
                if (inputFileName.Contains("$$sysdate"))
                {
                    inputFileName = inputFileName.Replace("$$sysdate", System.DateTime.Now.ToString("yyyyMMdd"));
                }
                SEMLogger.LogInformation("Checking if configured input file exists or not.");
                if (!File.Exists(inputFileName))
                {
                    SEMLogger.LogInformation(StringConstants.INPUT_FILE_DOESNOTEXISTS);
                    return 4;
                }

                SEMLogger.LogInformation("Configured input file exists, proceeding further in execution.");
                string functionToBePerformed = ConfigurationManager.AppSettings[StringConstants.FUNCTION_TOBE_PERFORMED] ?? string.Empty;
                string outputFileName = ConfigurationManager.AppSettings[StringConstants.OUTPUT_FILENAME_WITHPATH];
                
                if (outputFileName.Contains("$$sysdate"))
                {
                    outputFileName = outputFileName.Replace("$$sysdate", System.DateTime.Now.ToString("yyyyMMdd"));
                }
                if (!functionToBePerformed.Equals(StringConstants.FUNCTION_PERFORMED11))
                {
                    if (!File.Exists(outputFileName))
                    {
                        SEMLogger.LogInformation(StringConstants.OUTPUT_FILE_DOESNOTEXISTS);
                        FileStream outFile = File.Create(outputFileName);
                        outFile.Close();
                    }

                    SEMLogger.LogInformation("Erasing output file contents as file already exists.");
                    //erasing output file contents
                    FileStream fileStream = File.Open(outputFileName, FileMode.Open);
                    fileStream.SetLength(0);
                    fileStream.Close();
                }

                //getting the flag which decides the function to be performed
                // string functionToBePerformed = ConfigurationManager.AppSettings[StringConstants.FUNCTION_TOBE_PERFORMED] ?? string.Empty;
                switch (functionToBePerformed)
                {
                    
                    case StringConstants.FUNCTION_PERFORMED01:
                        // for extracting all jobs
                       
                        using (StreamWriter writerObj = new StreamWriter(outputFileName, true))
                        {
                            Console.WriteLine(StringConstants.FETCHING_JOBS_FROMINPUT);
                            foreach (FilteredJobs item in jilOperationsObj.GetListOfJobs(inputFileName, ref listOfNewParameters))
                            {
                                writerObj.WriteLine(item.Insert_job.Trim());
                            }
                        }
                        break;

                    

                    case StringConstants.FUNCTION_PERFORMED02:
                        SEMLogger.LogInformation("Performing function 9 of JilExtractUtility i.e. getting all data from JIL file into a CSV file.");
                        string dailyExtractFilePath = ConfigurationManager.AppSettings["DailyExtractFilePath"];
                        List<FilteredJobs> filteredJobs = new List<FilteredJobs>();
                        int billercount = 0;
                        JobDetail objJobDetail;
                        string billerName = string.Empty;
                        List<JobDetail> listOfJobDetail = new List<JobDetail>();
                        List<string> lines = new List<string>();
                        List<FilteredJobs> listOFilteredJobs = new List<FilteredJobs>();
                        string extractFilePath = ConfigurationManager.AppSettings["DailyExtractFilePath"];
                        if (extractFilePath.Contains("$$sysdate"))
                        {
                            dailyExtractFilePath = extractFilePath.Replace("$$sysdate", System.DateTime.Now.ToString("yyyyMMdd"));
                        }
                        SEMLogger.LogInformation("Getting job status from daily extract file...");
                        Dictionary<string, string> dictionaryOfJobsWithLastRunDate = new Dictionary<string, string>();
                        Dictionary<string, string> dictionaryOfJobsWithLastRunTimings = new Dictionary<string, string>();
                         Dictionary<string, string> dictionaryOfJobsWithStartRunDate = new Dictionary<string, string>();
                        Dictionary<string, string> dictionaryOfJobsWithStartRunTimings = new Dictionary<string, string>();

                        Dictionary<string, string> dictionaryOfJobsWithStatus = GetDictionaryObjectOfJobFromExtractFile(extractFilePath, ref dictionaryOfJobsWithLastRunDate, ref dictionaryOfJobsWithLastRunTimings, ref dictionaryOfJobsWithStartRunDate, ref dictionaryOfJobsWithStartRunTimings);                       
                        SEMLogger.LogInformation("Completed fetching all job status from daily extract file.");                        
                        List<string> listOfBillers = jilOperationsObj.GetBillerNamesListAndListOfAllJobs(inputFileName, ref listOFilteredJobs).Distinct().ToList<string>();

                        #region tempcode
                        //below code is temporary and must be commented when not required
                        

                        //List<string> listOfHours = new List<string>();
                        //foreach (var item in listOFilteredJobs)
                        //{
                        //    try
                        //    {
                        //        if (dictionaryOfJobsWithLastRunTimings[item.Insert_job].Contains(':'))
                        //            listOfHours.Add(dictionaryOfJobsWithLastRunTimings[item.Insert_job].Split(':').First().Trim());
                        //    }
                        //    catch (Exception ex)
                        //    {
                        //        if(ex.Message.Contains("given key"))
                        //        continue;
                        //    }
                        //}

                        //listOfHours = listOfHours.Distinct().ToList<string>();
                        //listOfHours.Sort();
                        //Dictionary<string, string> dictSpecificJobs = new Dictionary<string, string>();
                        //List<string> listOfJobsAsPerHours = new List<string>();
                        //List<string> listOfJobsToWriteWithHrs = new List<string>();
                        //List<string> listOfAllJobs = (from x in listOFilteredJobs select x.Insert_job).ToList<string>();
                        //foreach (var item in listOfAllJobs)
                        //{                           
                        //    try
                        //    {
                        //        dictSpecificJobs.Add((string)(from x in dictionaryOfJobsWithLastRunTimings where x.Key.Trim().Equals(item.Trim()) select x.Key).FirstOrDefault(), (string)(from x in dictionaryOfJobsWithLastRunTimings where x.Key.Trim().Equals(item.Trim()) select x.Value).FirstOrDefault());
                        //    }
                        //    catch (Exception)
                        //    {
                        //        continue;
                        //    }
                        //}

                       
                        //foreach (var item in listOfHours)
                        //{                            
                        //    listOfJobsAsPerHours.Add("Hour " + item + ": ");
                        //    List<string> listOfPhaseJobs = (from x in dictSpecificJobs where x.Value.Trim().StartsWith(item) select x.Key.Trim()).Distinct().ToList<string>();
                        //    List<string> billers = new List<string>();
                        //    foreach (var job in listOfPhaseJobs)
                        //    {
                        //        if (job.StartsWith("bsl"))
                        //            billers.Add(job.Split('-')[5].Trim());
                        //        else if (job.StartsWith("bis"))
                        //            billers.Add(job.Split('-')[6].Trim());
                        //        else
                        //            billers.Add(job);
                        //    }
                            
                        //    billers = billers.Distinct().ToList<string>();
                        //    listOfJobsAsPerHours.AddRange(billers);
                        //    int jobsCount = 0;
                        //    foreach (var biller in billers)
                        //    {
                        //        jobsCount += (from x in listOFilteredJobs where x.Insert_job.Contains("-" + biller + "-") select x).Count();
                        //    }
                        //    listOfJobsAsPerHours.Add(string.Format("Count of jobs for above billers in hours {0} is : {1}", item, jobsCount));                               
                        //}




                        //fileOperationsObj.PrintDataToTextFileFromListOfString(listOfJobsAsPerHours, @"D:\AutoSys Upgrade\Production JIL Development\Production JIL from jobs list\Phase-7\Phase-7_ListOfHours.txt");
                        ////temp code end
                        #endregion 

                        foreach (var biller in listOfBillers)
                        {
                            Console.WriteLine(StringConstants.BILLERCOUNT_AND_PENDINGBILLERS, ++billercount, listOfBillers.Count - (billercount));
                            SEMLogger.LogInformation("Getting jil information for biller: {0}", biller);                            
                            filteredJobs.Clear();
                            foreach (var item in listOFilteredJobs)
                            {
                                string insertJobName = item.Insert_job;
                                List<string> listOfItemsInJob = insertJobName.Trim().Split('-').ToList<string>();
                                try
                                {
                                    if (insertJobName.StartsWith(StringConstants.BSL_JOBS_SUBSTRING))
                                    {
                                        if (listOfItemsInJob.Count >= 6)
                                            billerName = item.Insert_job.Split(StringConstants.SPLIT_WITH_HYPHEN)[5].Trim();

                                        if (billerName.Equals(biller))
                                            filteredJobs.Add(item);
                                    }
                                    else if (insertJobName.StartsWith(StringConstants.BIS_JOBS_SUBSTRING))
                                    {
                                        if (listOfItemsInJob.Count >= 6)
                                            billerName = insertJobName.Split(StringConstants.SPLIT_WITH_HYPHEN)[6].Trim();

                                        if (billerName.Equals(biller))
                                            filteredJobs.Add(item);
                                    }
                                    else
                                    {
                                        //insertJobName = string.Concat(insertJobName.TakeWhile(c => c != ' '));
                                        if (insertJobName.Equals(biller))
                                        {
                                            filteredJobs.Add(item);
                                        }
                                    }
                                }
                                catch (Exception ex)
                                {
                                    SEMLogger.LogError("Error while getting the information of jobs for biller : {0}. Please see below error message: \n {1}", biller, ex.Message);
                                    insertJobName = string.Concat(insertJobName.TakeWhile(c => c != ' '));
                                    if (insertJobName.Equals(biller))
                                        filteredJobs.Add(item);
                                    if (ex.Message.ToLower().Contains(StringConstants.INDEX))
                                        continue;
                                }
                            }

                            SEMLogger.LogInformation("Total no. of jobs found for biller: {0} is: {1}", biller, filteredJobs.Count);
                            foreach (var item in filteredJobs)
                            {                                
                                string sourceFilePath = string.Empty;
                                string destFilePath = string.Empty;
                                objJobDetail = new JobDetail();
                                objJobDetail.RunDay = string.IsNullOrEmpty(item.Run_Day) ? "N/A" : item.Run_Day.Replace(StringConstants.COMMA, StringConstants.COLON).Trim();
                                objJobDetail.Schedule = string.IsNullOrEmpty(item.Start_Times) ? "N/A" : item.Start_Times;
                                objJobDetail.BillerName = biller.ToLower();
                                objJobDetail.BoxName = string.IsNullOrEmpty(item.Boxname) ? "N/A" : item.Boxname;
                                objJobDetail.Command = item.Command;
                                objJobDetail.JobName = item.Insert_job;

                                objJobDetail.StartRun = dictionaryOfJobsWithStartRunDate.ContainsKey(objJobDetail.JobName) ? dictionaryOfJobsWithStartRunDate[objJobDetail.JobName] : "N/A";
                                objJobDetail.LastRun = dictionaryOfJobsWithLastRunDate.ContainsKey(objJobDetail.JobName) ? dictionaryOfJobsWithLastRunDate[objJobDetail.JobName] : "N/A";
                                objJobDetail.JobStatus = dictionaryOfJobsWithStatus.ContainsKey(objJobDetail.JobName) ? dictionaryOfJobsWithStatus[objJobDetail.JobName] : "N/A";
                                objJobDetail.StartRunTime = dictionaryOfJobsWithStartRunTimings.ContainsKey(objJobDetail.JobName) ? dictionaryOfJobsWithStartRunTimings[objJobDetail.JobName] : "N/A";
                                objJobDetail.LastRunTime = dictionaryOfJobsWithLastRunTimings.ContainsKey(objJobDetail.JobName) ? dictionaryOfJobsWithLastRunTimings[objJobDetail.JobName] : "N/A";

                                objJobDetail.Machine = item.Machine;
                                objJobDetail.Owner = item.Owner;
                                objJobDetail.Wrapper = string.IsNullOrEmpty(objJobDetail.Command) ? "N/A" : GetWrapperName(objJobDetail.Command);
                                objJobDetail.Wrapper = string.IsNullOrEmpty(objJobDetail.Wrapper) ? "N/A" : objJobDetail.Wrapper;
                                objJobDetail.JobType = string.IsNullOrEmpty(objJobDetail.Wrapper) ? "N/A" : GetJobType(objJobDetail.JobName);
                                objJobDetail.JobType = string.IsNullOrEmpty(objJobDetail.JobType) ? "N/A" : objJobDetail.JobType;
                                objJobDetail.FileName = string.IsNullOrEmpty(objJobDetail.Command) ? "N/A" : GetFileNameAndPath(objJobDetail.Command, ref sourceFilePath, ref destFilePath);
                                objJobDetail.FileName = string.IsNullOrEmpty(objJobDetail.FileName) ? "N/A" : objJobDetail.FileName;
                                objJobDetail.SourceFilePath = string.IsNullOrEmpty(sourceFilePath) ? "N/A" : sourceFilePath;
                                objJobDetail.DestinationFilePath = string.IsNullOrEmpty(destFilePath) ? "N/A" : destFilePath;
                                objJobDetail.N_Retry = string.IsNullOrEmpty(item.N_Retrys) ? "N/A" : item.N_Retrys;
                                objJobDetail.Profile = string.IsNullOrEmpty(item.Profile) ? "N/A" : item.Profile;
                                objJobDetail.Run_Calendar = string.IsNullOrEmpty(item.Run_Calendar) ? "N/A" : item.Run_Calendar;
                                objJobDetail.Job_Load = string.IsNullOrEmpty(item.JobLoad) ? "N/A" : item.JobLoad;
                                objJobDetail.Priority = string.IsNullOrEmpty(item.Priority) ? "N/A" : item.Priority;

                                //adding new parameters to report
                                objJobDetail.Condition = string.IsNullOrEmpty(item.Condition) ? "N/A" : item.Condition.Trim();
                                objJobDetail.Box_Success = string.IsNullOrEmpty(item.Box_Success) ? "N/A" : item.Box_Success.Trim();
                                objJobDetail.Box_Failure = string.IsNullOrEmpty(item.Box_Failure) ? "N/A" : item.Box_Failure.Trim();
                                objJobDetail.TimeZone = string.IsNullOrEmpty(item.TimeZone) ? "N/A" : item.TimeZone.Trim();
                                objJobDetail.Date_Condition = string.IsNullOrEmpty(item.DateCondition) ? "N/A" : item.DateCondition.Trim();
                                objJobDetail.Application = string.IsNullOrEmpty(item.Application) ? "N/A" : item.Application;
                                listOfJobDetail.Add(objJobDetail);
                                sourceFilePath = string.Empty;
                            }
                        }

                        SEMLogger.LogInformation("Writing job contents to CSV/XLS file.");
                        DataTable jobDetailTable = fileOperationsObj.ConvertListToDataTable(listOfJobDetail);
                        ExcelCreator.Create(jobDetailTable, outputFileName);
                        //var valueLines = jobDetailTable.AsEnumerable().Select(row => string.Join(StringConstants.COMMA, row.ItemArray));
                        //lines.AddRange(valueLines);
                        //File.WriteAllLines(outputFileName, lines);
                        SEMLogger.LogInformation("Writing of job contents to CSV file finished.");
                        break;

                      default:
                        Console.WriteLine(StringConstants.WRONG_INPUT);
                        return 4;
                }

                SEMLogger.LogInformation(StringConstants.EXECUTION_COMPLETED);
                Console.WriteLine(StringConstants.EXECUTION_COMPLETED);
                timer.Stop();
                Console.WriteLine("Time taken in for execution:  {0}", timer.Elapsed);
                Console.ReadLine();
               
            }
            catch (Exception ex)
            {
                result = 4;
                SEMLogger.LogError(ex.Message + "\nat function : " + System.Reflection.MethodBase.GetCurrentMethod().Name);
                Console.WriteLine(ex.Message);
            }

            SEMLogger.LogInformation("Return to autosys value: {0}", result);
            return result;
        }


        private static string GetFileNameAndPath(string command, ref string sourceFilePath, ref string destinationFilePath)
        {
          string fileName = string.Empty;
          try
          {              
              if (command.Contains("\\\\"))
              {
                  string result = string.Empty;
                  string path = string.Empty;
                  command = command.ToLower();
                  //string commandWithoutColon = command.Split(new string[] { "command:"}, StringSplitOptions.None).Last();
                  if (command.Contains("<yyyy>") || command.Contains("<mm>") || command.Contains("<dd>"))
                  {
                      command = command.Replace("<yyyy>", "YYYY");
                      command = command.Replace("<mm>", "MM");
                      command = command.Replace("<dd>", "DD");
                  }

                  if (command.Contains("filename"))
                  {
                      if (command.Contains("destinationfilepath") && command.Contains("isupload=0"))
                      {
                          destinationFilePath = command.Split(new string[] { "destinationfilepath=" }, StringSplitOptions.None).Last();
                          destinationFilePath = destinationFilePath.Replace("$$", "##");
                          destinationFilePath = string.Concat(destinationFilePath.TakeWhile((c) => c != '"'));
                          destinationFilePath = sourceFilePath.Replace("##", "$$");
                      }
                      if (command.Contains("destinationpath") && command.Contains("isupload=0"))
                      {
                          if (command.Contains("destinationpath="))
                          destinationFilePath = command.Split(new string[] { "destinationpath=" }, StringSplitOptions.None).Last();
                          else
                              destinationFilePath = command.Split(new string[] { "destinationpath " }, StringSplitOptions.None).Last();
                          destinationFilePath = destinationFilePath.Replace("$$", "##");
                          destinationFilePath = string.Concat(destinationFilePath.TakeWhile((c) => c != '"'));
                          destinationFilePath = destinationFilePath.Replace("##", "$$");
                      }
                      if (command.Contains("sourcepath"))
                      {
                          sourceFilePath = command.Split(new string[] { "sourcepath=" }, StringSplitOptions.None).Last();
                          sourceFilePath = sourceFilePath.Replace("$$", "##");
                          sourceFilePath = string.Concat(sourceFilePath.TakeWhile((c) => c != '$'));
                          sourceFilePath = sourceFilePath.Replace("##", "$$");
                      }
                      if (command.Contains("sourcefilepath"))
                      {
                          if(command.Contains("sourcefilepath="))
                          sourceFilePath = command.Split(new string[] { "sourcefilepath=" }, StringSplitOptions.None).Last();
                          else
                          sourceFilePath = command.Split(new string[] { "sourcefilepath " }, StringSplitOptions.None).Last();
                          sourceFilePath = sourceFilePath.Replace("$$", "##");
                          if(sourceFilePath.Contains("$"))
                          sourceFilePath = string.Concat(sourceFilePath.TakeWhile((c) => c != '$'));
                          else
                              sourceFilePath = string.Concat(sourceFilePath.TakeWhile((c) => c != '-'));
                          sourceFilePath = sourceFilePath.Replace("##", "$$");
                      }
                      if (command.Contains("destinationfilepath"))
                      {
                          if (command.Contains("destinationfilepath="))
                              destinationFilePath = command.Split(new string[] { "destinationfilepath=" }, StringSplitOptions.None).Last();
                          else
                              destinationFilePath = command.Split(new string[] { "destinationfilepath " }, StringSplitOptions.None).Last();
                          destinationFilePath = destinationFilePath.Replace("$$", "##");
                          if (destinationFilePath.Contains("$"))
                              destinationFilePath = string.Concat(destinationFilePath.TakeWhile((c) => c != '$'));
                         
                          destinationFilePath = destinationFilePath.Replace("##", "$$");
                      }

                      if(command.Contains("-filepath"))
                      {
                          sourceFilePath = command.Split(new string[] { "-filepath " }, StringSplitOptions.None).Last();
                          sourceFilePath = string.Concat(sourceFilePath.Trim().TakeWhile((c) => c != '-'));
                      }

                      if(command.Contains("filename="))
                      path = command.Split(new string[] { "filename=" }, StringSplitOptions.None).Last();
                      else if(command.Contains("filename "))
                          path = command.Split(new string[] { "filename " }, StringSplitOptions.None).Last();
                      result = string.Concat(path.TakeWhile((c) => c != '$'));
                  }
                  else
                  {
                      path = command.Substring(command.IndexOf("\\\\"));
                      if (!command.Contains("rename"))
                          path = path.Replace("\"", string.Empty).TrimEnd(new char[] { '\\' });
                      if (path.ToUpper().Contains("DO"))
                      {
                          if (command.Contains("rename"))
                          {
                              path = path.Trim().Split(new string[] { " \"" }, StringSplitOptions.None)[0];
                              path = path.Replace("\"", string.Empty).TrimEnd(new char[] { '\\' });
                          }
                          else
                          {
                              if ((command.Trim().StartsWith("copy") || command.Trim().StartsWith("move")) && path.Contains(" \\\\"))
                              destinationFilePath = path.Trim().Split(new string[] { " \\\\" }, StringSplitOptions.None)[1];
                              else if (command.Trim().StartsWith("for"))
                              {
                                  if (command.Contains("copy"))
                                  {
                                      if (command.Contains("copy "))
                                      destinationFilePath = path.Trim().Split(new string[] { "copy " }, StringSplitOptions.None)[1];
                                      else
                                          destinationFilePath = path.Trim().Split(new string[] { "copy" }, StringSplitOptions.None)[1];

                                      if(destinationFilePath.Contains(" \\\\"))
                                      destinationFilePath = destinationFilePath.Trim().Split(new string[] { " \\\\" }, StringSplitOptions.None)[1];
                                      destinationFilePath = string.Concat(destinationFilePath.TakeWhile((c) => c != '&'));
                                  }
                                  else if (command.Contains("move"))
                                  {
                                      if (command.Contains("move "))
                                      destinationFilePath = path.Trim().Split(new string[] { "move " }, StringSplitOptions.None)[1];
                                      else
                                          destinationFilePath = path.Trim().Split(new string[] { "move" }, StringSplitOptions.None)[1];

                                      if (destinationFilePath.Contains(" \\\\"))
                                      destinationFilePath = destinationFilePath.Trim().Split(new string[] { " \\\\" }, StringSplitOptions.None)[1];
                                      destinationFilePath = string.Concat(destinationFilePath.TakeWhile((c) => c != '&'));
                                  }
                              }
                             
                              path = path.Trim().Split(new string[] { " \\\\" }, StringSplitOptions.None)[0];                              
                          }

                          result = string.Concat(path.TakeWhile((c) => c != '/'));
                          sourceFilePath = result.Split('/')[0];
                          
                          result = Path.GetFileName(sourceFilePath);
                      }
                      else
                      {
                          if (command.Contains("rename"))
                          {
                              path = path.Trim().Split(new string[] { " \"" }, StringSplitOptions.None)[0];
                              path = path.Replace("\"", string.Empty).TrimEnd(new char[] { '\\' });
                          }


                          if ((command.Trim().StartsWith("copy") || command.Trim().StartsWith("move")) && path.Contains(" \\\\"))
                              destinationFilePath = path.Trim().Split(new string[] { " \\\\" }, StringSplitOptions.None)[1];

                          sourceFilePath = path.Trim().Split(new string[] { " \\\\" }, StringSplitOptions.None)[0];
                          if (sourceFilePath.Contains("-o"))
                              sourceFilePath = sourceFilePath.Split(new string[] { "-o" }, StringSplitOptions.None).First();

                          result = Path.GetFileName(sourceFilePath.Replace("/", string.Empty));
                          if (result.Contains(")"))
                              result = result.Split(new string[] { ")" }, StringSplitOptions.None).First();
                      }

                      if (result.Contains(' '))
                      {
                          string firstFileName = result.Split(' ')[0].Trim();
                          string secondFileName = result.Split(' ')[1].Trim();
                          if (!string.IsNullOrEmpty(secondFileName) && (secondFileName.Contains(firstFileName) || firstFileName.Contains(secondFileName)))
                              result = secondFileName;

                      }
                  }

                  if (result.Contains(' '))
                      result = result.Split(new string[] { " " }, StringSplitOptions.None).First();
                  fileName = result;
              }
              else
              {
                  if (command.Contains("folderpath"))
                  {
                      sourceFilePath = command.Split(new string[] { "folderpath=" }, StringSplitOptions.None).Last();
                      sourceFilePath = string.Concat(sourceFilePath.TakeWhile((c) => c != '$'));

                      fileName = command.Split(new string[] { "filename=" }, StringSplitOptions.None).Last();
                      fileName = string.Concat(fileName.TakeWhile((c) => c != '"'));
                  }
              }

              if (sourceFilePath.Contains(".exe "))
              {
                  sourceFilePath = string.Empty;
              }
              if (destinationFilePath.Contains(".exe "))
              {
                  destinationFilePath = string.Empty;
              }
          }
          catch (Exception ex)
          {
              SEMLogger.LogError(ex.Message + "\nat function : " + System.Reflection.MethodBase.GetCurrentMethod().Name);
              Console.WriteLine(ex.Message);
          }

            return fileName;
        }

        private static string GetJobType(string jobName)
        {
            string jobType = string.Empty;            
            if (jobName.ToLower().Contains("bdc"))
            {
                jobType = StringConstants.BDC_JOBTYPE;
            }
            else if (jobName.ToLower().Contains("rdc"))
            {
                jobType = StringConstants.RDC_JOBTYPE;
            }
            else if (jobName.ToLower().Contains("eod"))
            {
                jobType = StringConstants.EOD_JOBTYPE;
            }
            else if (jobName.ToLower().Contains("remit"))
            {
                jobType = StringConstants.REMIT_JOBTYPE;
            }
            else if (jobName.ToLower().Contains("ajb") && jobName.ToLower().Contains("settlement"))
            {
                jobType = StringConstants.AJBSETTLEMENT_JOBTYPE;
            }
            else if (jobName.ToLower().Contains("settlement"))
            {
                jobType = StringConstants.SETTLEMENT_JOBTYPE;
            }
            else if (jobName.ToLower().Contains("sleep"))
            {
                jobType = StringConstants.SLEEP_JOBTYPE;
            }
            else if (jobName.ToLower().Contains("mam"))
            {
                jobType = StringConstants.MAM_JOBTYPE;
            }
            else if (jobName.ToLower().Contains("memo"))
            {
                jobType = StringConstants.MEMO_JOBTYPE;
            }
            else if (jobName.ToLower().Contains("replcheck") || jobName.ToLower().Contains("replicationcheck") || jobName.ToLower().Contains("replicationchk"))
            {
                jobType = StringConstants.REPLCHK_JOBTYPE;
            }
            else if (jobName.ToLower().Contains("test"))
            {
                jobType = StringConstants.TEST_JOBTYPE;
            }
            else if (jobName.ToLower().Contains("move"))
            {
                jobType = StringConstants.MOVE_JOBTYPE;
            }
            else if (jobName.ToLower().Contains("rename"))
            {
                jobType = StringConstants.RENAME_JOBTYPE;
            }
            else if (jobName.ToLower().Contains("remove"))
            {
                jobType = StringConstants.REMOVE_JOBTYPE;
            }
            else if (jobName.ToLower().Contains("-del-") || jobName.ToLower().Contains("delete"))
            {
                jobType = StringConstants.DELETE_JOBTYPE;
            }
            else if (jobName.ToLower().Contains("copy"))
            {
                jobType = StringConstants.COPY_JOBTYPE;
            }
            else if (jobName.ToLower().Contains("upload"))
            {
                jobType = StringConstants.UPLOAD_JOBTYPE;
            }
            else if (jobName.ToLower().Contains("download"))
            {
                jobType = StringConstants.DOWNLOAD_JOBTYPE;
            }
            else if (jobName.ToLower().Contains("archive"))
            {
                jobType = StringConstants.ARCHIVE_JOBTYPE;
            }
            else if (jobName.ToLower().Contains("filerecheck"))
            {
                jobType = StringConstants.FILERECHECK_JOBTYPE;
            }
            else if (jobName.ToLower().Contains("filecheck"))
            {
                jobType = StringConstants.FILECHECK_JOBTYPE;
            }
            else if (jobName.ToLower().Contains("filedelivery"))
            {
                jobType = StringConstants.FILEDELIVERY_JOBTYPE;
            }
            else if (jobName.ToLower().Contains("filecreation"))
            {
                jobType = StringConstants.FILECREATION_JOBTYPE;
            }
            else if (jobName.ToLower().Contains("checkftp_as") || jobName.ToLower().Contains("checkftpas") || jobName.ToLower().Contains("checkftp-as") || jobName.ToLower().Contains("chkftp_as") || jobName.ToLower().Contains("chkftpas") )
            {
                jobType = StringConstants.CHECKFTPAS_JOBTYPE;
            }
            else if (jobName.ToLower().Contains("checkproce"))
            {
                jobType = StringConstants.CHECKPROCESSING_JOBTYPE;
            }
            else if (jobName.ToLower().Contains("checknas"))
            {
                jobType = StringConstants.CHECKNAS_JOBTYPE;
            }
            else if (jobName.ToLower().Contains("checkfile"))
            {
                jobType = StringConstants.CHECKFILE_JOBTYPE;
            }
            else if (jobName.ToLower().Contains("sent2ftp"))
            {
                jobType = StringConstants.SENT2FTP_JOBTYPE;
            }
            else if (jobName.ToLower().Contains("sendemail"))
            {
                jobType = StringConstants.SENDEMAIL_JOBTYPE;
            }
            else if (jobName.ToLower().Contains("chkprocfilntexist") || jobName.ToLower().Contains("checkprfilentexist") || jobName.ToLower().Contains("checkprocingfilentexist") || jobName.ToLower().Contains("chkprocfilentexist") || jobName.ToLower().Contains("chkproceingfilntexist"))
            {
                jobType = StringConstants.CHECKPROCESSINGNTEXIST_JOBTYPE;
            }
            

            return jobType;
        }

        private static string GetWrapperName(string command)
        {           
            string wrapperName = string.Empty;
            command = command.ToLower();
            //command = command.Replace("command:", string.Empty).Trim();
            try
            {

                if (command.Contains(".exe\""))
                {
                    command = command.Replace(".exe", ".exe#");
                    wrapperName = string.Concat(command.TakeWhile((c) => c != '#'));
                    if (wrapperName.ToUpper().Contains(@"C\"))
                    {
                        wrapperName = wrapperName.Substring(wrapperName.ToUpper().IndexOf(@"C\"));
                        wrapperName = Path.GetFileName(wrapperName);
                    }
                    else
                    {
                        try
                        {
                            wrapperName = Path.GetFileName(wrapperName);
                        }
                        catch (Exception)
                        {
                            if(wrapperName.Contains(@"\"))
                            wrapperName = wrapperName.Split(new string[] { @"\" }, StringSplitOptions.None).Last();                        
                        }
                    }

                }
                else if (command.Contains(".exe "))
                {
                    command = command.Replace(".exe ", ".exe#");
                    wrapperName = string.Concat(command.TakeWhile((c) => c != '#'));
                    if (wrapperName.ToUpper().Contains(@"C\"))
                    {
                        wrapperName = wrapperName.Substring(wrapperName.ToUpper().IndexOf(@"C\"));
                        wrapperName = Path.GetFileName(wrapperName);
                    }
                    else
                    {
                        try
                        {
                            wrapperName = Path.GetFileName(wrapperName);
                            if (wrapperName.Contains(' '))
                            {
                                string wrapper = wrapperName.Split(new string[] { " " }, StringSplitOptions.None).Last();
                                if (!wrapper.Contains(".exe"))
                                    wrapperName = wrapperName.Split(new string[] { " " }, StringSplitOptions.None).First();
                                else
                                    wrapperName = wrapper.Replace("(", string.Empty).Trim();
                            }
                        }
                        catch (Exception)
                        {
                            if (wrapperName.Contains(@"\"))
                                wrapperName = wrapperName.Split(new string[] { @"\" }, StringSplitOptions.None).Last();
                        }
                    }

                    // wrapperName = wrapperName.Substring(wrapperName.ToLower().IndexOf("command:") + 1);
                }
                else if (command.Contains(".exe"))
                {
                    try
                    {
                        wrapperName = Path.GetFileName(command);
                    }
                    catch (Exception)
                    { }
                }
                
                if (wrapperName.Contains(@"\"))
                    wrapperName = wrapperName.Split(new string[] { @"\" }, StringSplitOptions.None).Last();

                if (wrapperName.ToUpper().Contains("FOR "))
                {
                    wrapperName = wrapperName.Split(new string[] { "DO (" }, StringSplitOptions.None).Last();
                }

                if (wrapperName.ToLower().Contains("powershell"))
                {
                    wrapperName = command.Split(new string[] { "-file " }, StringSplitOptions.None).Last().Replace(".ps1", ".ps1#");
                    wrapperName = string.Concat(wrapperName.TakeWhile((c) => c != '#')).Replace("\"", string.Empty);
                    try
                    {
                        wrapperName = Path.GetFileName(wrapperName);
                    }
                    catch (Exception)
                    {                                
                    }

                    wrapperName = "PowerShell.exe " + wrapperName;
                }


                if (string.IsNullOrEmpty(wrapperName))
                {
                    command = command.Replace("\"", string.Empty);

                    if (command.Contains("do ( copy") || command.Contains("do (copy") || command.Contains("(copy") || command.Contains("( copy") || command.Trim().StartsWith("copy"))
                        wrapperName = "Copy";                    
                    else if (command.Contains("sleep.bat"))
                        wrapperName = "Sleep.bat";
                    else if (command.Contains("do ( move") || command.Contains("do (move") || command.Trim().StartsWith("move"))
                        wrapperName = "Move";
                    else if (command.Trim().StartsWith("del") || command.Trim().StartsWith("del ") || command.Contains("del ") || command.Contains("delete") || command.Contains("do ( del") || command.Contains("do (del"))
                    {
                        wrapperName = "Delete";
                        if (command.Contains(".bat"))
                        {
                            try
                            {
                                wrapperName = Path.GetFileName(command.Trim().Replace("\"", string.Empty));
                            }
                            catch (Exception)
                            {
                            }
                        }
                    }
                    else if (command.Contains("echo"))
                        wrapperName = "Echo";
                    else if (command.Contains("autorep"))
                        wrapperName = "Autorep";
                    else if (command.Contains("sendevent"))
                        wrapperName = "SendEvent";
                    else if (command.Contains("forecast"))
                        wrapperName = "Forecast";
                    else if (command.Contains("mkdir"))
                        wrapperName = "MkDir";
                    else if (command.Contains("rename ") || command.Contains("ren "))
                        wrapperName = "Rename";
                    else if (command.Trim().StartsWith("dir") || command.Trim().StartsWith("\"dir"))
                        wrapperName = "Dir";
                    else if (command.Contains("md ") && !command.Contains("cmd"))
                        wrapperName = "Md";
                    else if (command.Contains("rd "))
                        wrapperName = "Rd";
                    else if (command.Contains("job_depends"))
                        wrapperName = "Job_Depends";
                    else if (command.Contains("autocal_asc"))
                        wrapperName = "Autocal_Asc";
                    else if (command.Contains("autosys_generic"))  
                        wrapperName = "Autosys_Generic";
                    else if (command.Contains(@"7-zip\7z"))
                        wrapperName = "7-zip";
                    else
                    {
                        if (command.Contains(".bat"))
                        {
                            wrapperName = command.Trim().Split(new string[] { ".bat" }, StringSplitOptions.None).First().Trim().Replace("\"", string.Empty);
                            try
                            {
                                wrapperName = Path.GetFileName(wrapperName);
                                if (!wrapperName.Contains(".bat"))
                                    wrapperName = wrapperName + ".bat";
                            }
                            catch (Exception)
                            { }
                        }
                    }
                    
                }
            }
            catch (Exception ex)
            {
                SEMLogger.LogError(ex.Message + "\nat function : " + System.Reflection.MethodBase.GetCurrentMethod().Name);
                Console.WriteLine(ex.Message);
            }

            return wrapperName.Replace("\"", string.Empty).Trim();
        }

        private static String WildCardToRegular(String value)
        {
            return "^" + Regex.Escape(value).Replace("\\*", ".*") + "$";
        }


        private static Dictionary<string, string> GetDictionaryObjectOfJobFromExtractFile(string fileName, ref Dictionary<string, string> dictionaryOfJobsWithLastRunDates, ref Dictionary<string, string> dictionaryOfJobsWithLastRunTimings, ref Dictionary<string, string> dictionaryOfJobsWithStartRunDates, ref Dictionary<string, string> dictionaryOfJobsWithStartRunTimings)
        {
            Dictionary<string, string> dictionaryOfJobsAndItsStatus = new Dictionary<string, string>();
            try
            {
                var lines = File.ReadAllLines(@fileName).Select(x => x.Split(','));

                int count = lines.Count();
                var csvData = lines.Skip(3)
                           .SelectMany(x => x)
                           .Select((v, i) => new { Value = v, Index = i % count })
                           .Select(x => x.Value);
                foreach (var data in csvData)
                {
                    List<string> listOfItems = data.Split(' ').ToList<string>();
                    listOfItems.RemoveAll(x => x.Equals(string.Empty));
                    foreach (var item in listOfItems)
                    {
                        try
                        {
                            if (item.Length == 8 && item.Count(x => x == ':') > 1)
                            {
                                if (!dictionaryOfJobsWithStartRunTimings.ContainsKey(listOfItems[0].Trim()))
                                    dictionaryOfJobsWithStartRunTimings.Add(listOfItems[0].Trim(), item.Trim());
                                //break;
                            }
                            if (item.Length == 10 && item.Count(x => x == '/') > 1)
                            {
                                if(!dictionaryOfJobsWithStartRunDates.ContainsKey(listOfItems[0].Trim()))
                                    dictionaryOfJobsWithStartRunDates.Add(listOfItems[0].Trim(), item.Trim());                                
                            }    

                            if (item.Length == 2)
                            {
                                dictionaryOfJobsAndItsStatus.Add(listOfItems[0].Trim(), item.Trim());
                                break;
                            }
                        }
                        catch (Exception ex)
                        {
                            SEMLogger.LogError(ex.Message + "\nat function : " + System.Reflection.MethodBase.GetCurrentMethod().Name);
                            Console.WriteLine(ex.Message);
                        }
                    }
                    listOfItems.Reverse();
                    foreach (var item in listOfItems)
                    {
                        try
                        {                            
                            if (item.Length == 8 && item.Count(x => x == ':') > 1)
                            {
                                dictionaryOfJobsWithLastRunTimings.Add(listOfItems[listOfItems.Count - 1].Trim(), item.Trim());
                                //break;
                            }
                            if (item.Length == 10 && item.Count(x=> x=='/') > 1)
                            {
                                dictionaryOfJobsWithLastRunDates.Add(listOfItems[listOfItems.Count - 1].Trim(), item.Trim());
                                break;
                            }                            
                        }
                        catch (Exception ex)
                        {
                            SEMLogger.LogError(ex.Message + "\nat function : " + System.Reflection.MethodBase.GetCurrentMethod().Name);
                            Console.WriteLine(ex.Message);
                        }
                    }

                }
            }
            catch (Exception ex)
            {
                SEMLogger.LogError(ex.Message + "\nat function : " + System.Reflection.MethodBase.GetCurrentMethod().Name);
            }

            return dictionaryOfJobsAndItsStatus;
        }     
    }
}

