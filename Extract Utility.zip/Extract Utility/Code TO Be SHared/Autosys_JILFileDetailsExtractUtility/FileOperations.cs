﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.IO;
using System.Data;
using System.Reflection;
using System.Configuration;

namespace Autosys_JILFileDetailsExtractUtility
{
    public class FileOperations
    {
        public void AppendTextToFile(string rollbackpath, string rolloutPath, FilteredJobs job)
        {           
            using (StreamWriter writerObj = new StreamWriter(rollbackpath, true))
            {
                if (!job.Machine.ToLower().Contains(StringConstants.TWS_SUBSTRING) && !job.Machine.ToLower().Contains(StringConstants.CWS_SUBSTRING) && !job.Machine.ToLower().Contains(StringConstants.GWY_SUBSTRING) && !job.Machine.ToLower().Contains(StringConstants.ASYS_SUBSTRING) && !job.Insert_job.ToLower().Contains(StringConstants.BOX_SUBSTRING))
                {                    
                    job.Insert_job = job.Insert_job.Replace(StringConstants.INSERT_JOB, StringConstants.UPDATE_JOB);
                    job.Machine = job.Machine.Replace(StringConstants.OD_PROASA_NEW, StringConstants.OD_PROASA);
                    job.Machine = job.Machine.Replace(StringConstants.OD_ACH_SETTLEMENT_NEW, StringConstants.OD_ACH_SETTLEMENT);
                    job.Machine = job.Machine.Replace(StringConstants.OD_CC_SETTLEMENT_NEW, StringConstants.OD_CC_SETTLEMENT);
                    job.Machine = job.Machine.Replace(StringConstants.OD_AJB_SETTLEMENT_NEW, StringConstants.OD_AJB_SETTLEMENT);
                    job.Machine = job.Machine.Replace(StringConstants._2008_REPEAT, string.Empty);
                    job.Machine = job.Machine.Replace(StringConstants._2008, string.Empty);
                    if (!string.IsNullOrEmpty(job.Header))
                        writerObj.WriteLine(job.Header.Trim());
                    if (!string.IsNullOrEmpty(job.Insert_job))
                        writerObj.WriteLine(job.Insert_job.Trim());
                    if (!string.IsNullOrEmpty(job.Machine))
                        writerObj.WriteLine(job.Machine.Trim());
                    bool isCTJob = job.Machine.ToLower().Contains(StringConstants.BT2_SUBSTRING);
                    if (isCTJob && !string.IsNullOrEmpty(job.Command))
                    {
                        writerObj.WriteLine(job.Command.Trim());
                    }
                    writerObj.WriteLine(Environment.NewLine);
                }
            }

            using (StreamWriter writerObj = new StreamWriter(rolloutPath, true))
            {
                if (!job.Machine.ToLower().Contains(StringConstants.TWS_SUBSTRING) && !job.Machine.ToLower().Contains(StringConstants.CWS_SUBSTRING) && !job.Machine.ToLower().Contains(StringConstants.GWY_SUBSTRING) && !job.Machine.ToLower().Contains(StringConstants.ASYS_SUBSTRING) && !job.Insert_job.ToLower().Contains(StringConstants.BOX_SUBSTRING))
                {
                    bool isCTJob = job.Machine.ToLower().Contains(StringConstants.BT2_SUBSTRING);
                    job.Insert_job = job.Insert_job.Replace(StringConstants.INSERT_JOB, StringConstants.UPDATE_JOB);
                    //for PROD
                    if (!isCTJob)
                    {
                        job.Machine = job.Machine.Replace(StringConstants.OD_PROASA, StringConstants.OD_PROASA_NEW);
                        job.Machine = job.Machine.Replace(StringConstants.OD_ACH_SETTLEMENT, StringConstants.OD_ACH_SETTLEMENT_NEW);
                        job.Machine = job.Machine.Replace(StringConstants.OD_CC_SETTLEMENT, StringConstants.OD_CC_SETTLEMENT_NEW);
                        job.Machine = job.Machine.Replace(StringConstants.OD_AJB_SETTLEMENT, StringConstants.OD_AJB_SETTLEMENT_NEW);
                        job.Machine = job.Machine.Replace(StringConstants._2008_REPEAT, StringConstants._2008);
                        if (!string.IsNullOrEmpty(job.Header))
                            writerObj.WriteLine(job.Header.Trim());
                        if (!string.IsNullOrEmpty(job.Insert_job))
                            writerObj.WriteLine(job.Insert_job.Trim());
                        if (!string.IsNullOrEmpty(job.Machine))
                            writerObj.WriteLine(job.Machine.Trim());
                    }

                    if (isCTJob && !string.IsNullOrEmpty(job.Command))
                    {
                        job.Machine = job.Machine.Replace(StringConstants.OD_ASA_BT2, StringConstants.OD_ASA_BT2_TEST);
                        job.Machine = job.Machine.Replace(StringConstants.OD_ACH_SETTLEMENT_BT2, StringConstants.OD_ACH_SETTLEMENT_BT2_TEST);
                        job.Machine = job.Machine.Replace(StringConstants.OD_CC_SETTLEMENT_BT2, StringConstants.OD_CC_SETTLEMENT_BT2_TEST);
                        job.Machine = job.Machine.Replace(StringConstants.OD_AJB_SETTLEMENT_BT2, StringConstants.OD_AJB_SETTLEMENT_BT2_TEST);
                        job.Machine = job.Machine.Replace(StringConstants._TEST_REPEAT, StringConstants._TEST);
                        if (!string.IsNullOrEmpty(job.Header))
                            writerObj.WriteLine(job.Header.Trim());
                        if (!string.IsNullOrEmpty(job.Insert_job))
                            writerObj.WriteLine(job.Insert_job.Trim());
                        if (!string.IsNullOrEmpty(job.Machine))
                            writerObj.WriteLine(job.Machine.Trim());
                        job.Command = job.Command.Replace(StringConstants.OLD_CTSERVER, StringConstants.NEW_CTSERVER);
                        writerObj.WriteLine(job.Command.Trim());
                    }
                    writerObj.WriteLine(Environment.NewLine);
                }
            }
        }
        public DataTable ConvertFilePathListToDataTable(List<JobNameAndPaths> listOfJobs, ref List<string> lines)
        {
            DataTable table = new DataTable(typeof(JobNameAndPaths).Name);
            List<string> colummnNames = new List<string>();
            PropertyInfo[] props = typeof(JobNameAndPaths).GetProperties(BindingFlags.Public | BindingFlags.Instance);
            foreach (PropertyInfo prop in props)
            {
                table.Columns.Add(prop.Name);
                colummnNames.Add(prop.Name);
            }
            foreach (JobNameAndPaths item in listOfJobs)
            {

                var values = new object[props.Length];
                for (int i = 0; i < props.Length; i++)
                {
                    values[i] = props[i].GetValue(item, null);
                    values[i] = values[i] == null ? values[i] : values[i].ToString().Replace(",", string.Empty);
                }
                table.Rows.Add(values);
            }
            lines.Add(string.Join(StringConstants.COMMA, colummnNames));
            return table;
        }
        public DataTable ConvertListToDataTable(List<JobDetail> listOfJobs)
        {
            try
            {
                DataTable table = new DataTable(typeof(JobDetail).Name);
                List<string> listOfObjectsToKept = ConfigurationManager.AppSettings["FieldsToKept"].Split(',').ToList<string>();
                List<string> colummnNames = new List<string>();
                PropertyInfo[] props = typeof(JobDetail).GetProperties(BindingFlags.Public | BindingFlags.Instance);
                List<PropertyInfo> propertiesToKeep = new List<PropertyInfo>();
                foreach (PropertyInfo prop in props)
                {
                    table.Columns.Add(prop.Name);
                    colummnNames.Add(prop.Name); 
                    if(listOfObjectsToKept != null & listOfObjectsToKept.Contains(prop.Name.ToLower()))
                        propertiesToKeep.Add(prop);
                }

                if (propertiesToKeep.Count > 0)
                    props = propertiesToKeep.ToArray<PropertyInfo>();

                //table.Rows.Add(colummnNames.ToArray());
                foreach (JobDetail item in listOfJobs)
                {
                    //item.BillerName = item.BillerName.ToLower();
                    if (!item.JobName.StartsWith(StringConstants.BSL_JOBS_SUBSTRING) && !item.JobName.StartsWith(StringConstants.BIS_JOBS_SUBSTRING))
                    {
                        if (item.JobName.Contains("test"))
                            item.BillerName = "test";
                        else
                            item.BillerName = "N/A";
                    }
                    else
                    {
                        if (item.JobName.Contains("rpps"))
                        {
                            if (item.BillerName.EndsWith("001") || item.BillerName.EndsWith("002") || item.BillerName.EndsWith("003") || item.BillerName.EndsWith("004") || item.BillerName.EndsWith("005"))
                                item.BillerName = "rpps";
                        }
                        else
                        {                            
                                int num;
                                bool result = Int32.TryParse(item.BillerName, out num);
                                item.BillerName = result ? "N/A" : item.BillerName ;                           
                        }
                    }

                    var values = new object[props.Length]; 
                    //var values = props.Select(c => c.GetValue(item, null));
                    for (int i = 0; i < props.Length; i++)
                    {
                         values[i] = props[i].GetValue(item, null);
                    }

                        //for (int i = 0; i < props.Length; i++)
                        //{
                        //    try
                        //    {
                        //        values[i] = props[i].GetValue(item, null);
                        //       //// values[i] = values[i] == null ? values[i] : values[i].ToString().Replace(StringConstants.COMMA, string.Empty);                                
                        //       // if (!string.IsNullOrEmpty(values[i].ToString()) && values[i].ToString().Contains(StringConstants.INSERT))
                        //       // {
                        //       //     if (values[i].ToString().Contains(StringConstants.COLON))
                        //       //     values[i] = values[i].ToString().Trim().Split(StringConstants.SPLIT_WITH_COLON)[1].Trim().Split(StringConstants.SPLIT_WITH_SPACE)[0].Trim();

                        //       // }
                        //       // else if (!(string.IsNullOrEmpty(values[i].ToString())) && values[i].ToString().Contains(StringConstants.COMMAND))
                        //       // {
                        //       //     if (values[i].ToString().Contains(StringConstants.COLON))
                        //       //     values[i] = values[i].ToString().Substring(values[i].ToString().IndexOf(StringConstants.SPLIT_WITH_COLON) + 1).Trim();                                    
                        //       // }
                        //       // else if (!string.IsNullOrEmpty(values[i].ToString()) && (values[i].ToString().Contains(StringConstants.MACHINE) || values[i].ToString().Contains(StringConstants.OWNER)))
                        //       // {
                        //       //     if (values[i].ToString().Trim().Contains(StringConstants.COLON) && !props[i].Name.ToLower().Contains("filepath"))
                        //       //     values[i] = values[i].ToString().Trim().Split(StringConstants.SPLIT_WITH_COLON)[1].Trim();
                        //       // }
                        //       // else
                        //       // {
                        //       //     if (!string.IsNullOrEmpty(values[i].ToString()) && values[i].ToString().Contains(StringConstants.COMMAND))
                        //       //         values[i] = null;
                        //       // }
                        //    }
                        //    catch (Exception ex)
                        //    {
                        //        SEM.Logging.SEMLogger.LogError(ex.Message + "\nat function : " + System.Reflection.MethodBase.GetCurrentMethod().Name);
                        //    }
                        //}

                    table.Rows.Add(values);
                }            
              
                return table;
            }
            catch (Exception ex)
            {
                SEM.Logging.SEMLogger.LogError(ex.Message + "\nat function : " + System.Reflection.MethodBase.GetCurrentMethod().Name);
                Console.WriteLine(ex.Message);
                return null;
            }

        }
        public void CreateFile(string filePath)
        {
            if (!File.Exists(filePath))
            {
                FileStream stream = File.Create(filePath);
                stream.Close();
            }
        }
        public DirectoryInfo CreateDirectory(string path)
        {
            if (!Directory.Exists(path))
            {
                return Directory.CreateDirectory(path);
            }

            return null;
        }
       
        public void PrintDataToTextFileFromListOfString(List<string> listOfJobs, string outputFileName)
        {
            using (StreamWriter writerObj = new StreamWriter(outputFileName, true))
            {
                foreach (var item in listOfJobs)
                {
                    writerObj.WriteLine(item);                    
                }
                writerObj.WriteLine(Environment.NewLine);
            }
        }
        public void PrintDataToOutputFile(List<FilteredJobs> filteredJobs, string outputFileName)
        {
            if(filteredJobs.Count > 0)
            {
                using (StreamWriter writerObj = new StreamWriter(outputFileName, true))
                {
                    foreach (var item in filteredJobs)
                    {
                        try
                        {
                            if (!string.IsNullOrEmpty(item.Header))
                                writerObj.WriteLine(item.Header);
                            if (!string.IsNullOrEmpty(item.Insert_job))
                                writerObj.WriteLine(item.Insert_job);
                            if (!string.IsNullOrEmpty(item.Boxname))
                                writerObj.WriteLine(item.Boxname);
                            if (!string.IsNullOrEmpty(item.Command))
                                writerObj.WriteLine(item.Command);
                            if (!string.IsNullOrEmpty(item.Machine))
                                writerObj.WriteLine(item.Machine);
                            if (!string.IsNullOrEmpty(item.Owner))
                                writerObj.WriteLine(item.Owner);
                            if (!string.IsNullOrEmpty(item.Permission))
                                writerObj.WriteLine(item.Permission);
                            if (!string.IsNullOrEmpty(item.DateCondition))
                                writerObj.WriteLine(item.DateCondition);
                            if (!string.IsNullOrEmpty(item.Run_Day))
                                writerObj.WriteLine(item.Run_Day);
                            if (!string.IsNullOrEmpty(item.Start_Times))
                                writerObj.WriteLine(item.Start_Times);
                            if (!string.IsNullOrEmpty(item.Condition))
                                writerObj.WriteLine(item.Condition);
                            if (!string.IsNullOrEmpty(item.Box_Success))
                                writerObj.WriteLine(item.Box_Success);
                            if (!string.IsNullOrEmpty(item.Box_Failure))
                                writerObj.WriteLine(item.Box_Failure);
                            if (!string.IsNullOrEmpty(item.Description))
                                writerObj.WriteLine(item.Description);
                            if (!string.IsNullOrEmpty(item.N_Retrys))
                                writerObj.WriteLine(item.N_Retrys);
                            if (!string.IsNullOrEmpty(item.StdOutFile))
                                writerObj.WriteLine(item.StdOutFile);
                            if (!string.IsNullOrEmpty(item.StdErrFile))
                                writerObj.WriteLine(item.StdErrFile);
                            if (!string.IsNullOrEmpty(item.MaxRunAlarm))
                                writerObj.WriteLine(item.MaxRunAlarm);
                            if (!string.IsNullOrEmpty(item.AlarmIfFail))
                                writerObj.WriteLine(item.AlarmIfFail);
                            if (!string.IsNullOrEmpty(item.Max_Exit_Success))
                                writerObj.WriteLine(item.Max_Exit_Success);
                            if (!string.IsNullOrEmpty(item.Profile))
                                writerObj.WriteLine(item.Profile);
                            if (!string.IsNullOrEmpty(item.JobLoad))
                                writerObj.WriteLine(item.JobLoad);
                            if (!string.IsNullOrEmpty(item.Priority))
                                writerObj.WriteLine(item.Priority);
                            if (!string.IsNullOrEmpty(item.Group))
                                writerObj.WriteLine(item.Group);
                            if (!string.IsNullOrEmpty(item.Application))
                                writerObj.WriteLine(item.Application);
                            if (!string.IsNullOrEmpty(item.Must_Complete_Times))
                                writerObj.WriteLine(item.Must_Complete_Times);
                            if (!string.IsNullOrEmpty(item.Must_Start_Times))
                                writerObj.WriteLine(item.Must_Start_Times);
                            if (!string.IsNullOrEmpty(item.Run_Calendar))
                                writerObj.WriteLine(item.Run_Calendar);
                            if (!string.IsNullOrEmpty(item.Success_Codes))
                                writerObj.WriteLine(item.Success_Codes);
                            if (!string.IsNullOrEmpty(item.Fail_Codes))
                                writerObj.WriteLine(item.Fail_Codes);

                            if (!string.IsNullOrEmpty(item.Ftp_Transfer_Type))
                                writerObj.WriteLine(item.Ftp_Transfer_Type);
                            if (!string.IsNullOrEmpty(item.Ftp_Transfer_Direction))
                                writerObj.WriteLine(item.Ftp_Transfer_Direction);
                            if (!string.IsNullOrEmpty(item.Ftp_Local_Name))
                                writerObj.WriteLine(item.Ftp_Local_Name);
                            if (!string.IsNullOrEmpty(item.Ftp_Remote_Name))
                                writerObj.WriteLine(item.Ftp_Remote_Name);
                            if (!string.IsNullOrEmpty(item.Ftp_Server_Name))
                                writerObj.WriteLine(item.Ftp_Server_Name);
                            if (!string.IsNullOrEmpty(item.Ftp_Server_port))
                                writerObj.WriteLine(item.Ftp_Server_port);
                            if (!string.IsNullOrEmpty(item.Ftp_Use_Ssl))
                                writerObj.WriteLine(item.Ftp_Use_Ssl);
                            if (!string.IsNullOrEmpty(item.Ftp_Local_User))
                                writerObj.WriteLine(item.Ftp_Local_User);
                            if (!string.IsNullOrEmpty(item.Start_Mins))
                                writerObj.WriteLine(item.Start_Mins);
                            if (!string.IsNullOrEmpty(item.Watch_File))
                                writerObj.WriteLine(item.Watch_File);
                            if (!string.IsNullOrEmpty(item.Watch_File_Recurrsive))
                                writerObj.WriteLine(item.Watch_File_Recurrsive);
                            if (!string.IsNullOrEmpty(item.Watch_File_Type))
                                writerObj.WriteLine(item.Watch_File_Type);
                            if (!string.IsNullOrEmpty(item.Watch_File_Win_User))
                                writerObj.WriteLine(item.Watch_File_Win_User);
                            if (!string.IsNullOrEmpty(item.Continous))
                                writerObj.WriteLine(item.Continous);
                            if (!string.IsNullOrEmpty(item.Watch_Interval))
                                writerObj.WriteLine(item.Watch_Interval);
                            if (!string.IsNullOrEmpty(item.Win_Event_Op))
                                writerObj.WriteLine(item.Win_Event_Op);
                            if (!string.IsNullOrEmpty(item.Monitor_Mode))
                                writerObj.WriteLine(item.Monitor_Mode);
                            if (!string.IsNullOrEmpty(item.Term_Run_Time))
                                writerObj.WriteLine(item.Term_Run_Time);
                            if (!string.IsNullOrEmpty(item.Send_Notification))
                                writerObj.WriteLine(item.Send_Notification);
                            if (!string.IsNullOrEmpty(item.Notification_Id))
                                writerObj.WriteLine(item.Notification_Id);
                            if (!string.IsNullOrEmpty(item.Notification_Msg))
                                writerObj.WriteLine(item.Notification_Msg);
                            if (!string.IsNullOrEmpty(item.Exclude_Calendar))
                                writerObj.WriteLine(item.Exclude_Calendar);
                            if (!string.IsNullOrEmpty(item.Std_In_File))
                                writerObj.WriteLine(item.Std_In_File);
                            if (!string.IsNullOrEmpty(item.TimeZone))
                            {
                                writerObj.WriteLine(item.TimeZone);
                            }
                            if (!string.IsNullOrEmpty(item.Job_terminator))
                                writerObj.WriteLine(item.Job_terminator);
                            if (!string.IsNullOrEmpty(item.Win_log_name))
                                writerObj.WriteLine(item.Win_log_name);
                            if (!string.IsNullOrEmpty(item.Win_event_type))
                                writerObj.WriteLine(item.Win_event_type);
                            if (!string.IsNullOrEmpty(item.Win_event_id))
                                writerObj.WriteLine(item.Win_event_id);
                            if (!string.IsNullOrEmpty(item.Min_run_alarm))
                                writerObj.WriteLine(item.Min_run_alarm);

                            if (!string.IsNullOrEmpty(item.Status) && !item.Status.Contains("status:"))
                                writerObj.WriteLine("status: " + item.Status);
                            else if(!string.IsNullOrEmpty(item.Status))
                                writerObj.WriteLine(item.Status);

                            writerObj.WriteLine(Environment.NewLine);
                        }
                        catch (Exception ex)
                        {
                            throw ex;
                        }

                    }
                }
            }
        }
    }
}
