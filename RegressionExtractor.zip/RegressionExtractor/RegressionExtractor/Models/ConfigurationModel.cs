﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;


namespace RegressionExtractor.Models
{
    public class Products
    {
        public List<string> ListOfProducts { get; set; }
       // public List<System.Web.Mvc.SelectListItem> ListOfProducts { get; set; }
       // public string SelectedValue { get; set; }
        //public FeaturesModel Feautres { get; set; }       
    }

    public class FeaturesModel
    {
        public List<string> ListOfFeatures { get; set; }
    }

    public class BillMatrixDefects
    {
        //public int FiservInternal { get; set; }
        //public int FiservExternal { get; set; }
        //public int PDD { get; set; }
        //public int Severity1 { get; set; }
        //public int Severity2 { get; set; }
        //public int Severity3 { get; set; }
        //public int Severity4 { get; set; }
        //public int Severity5 { get; set; }
        public List<string> ListOfFeatures { get; set; }
        public List<string> SeverityType { get; set; }
        public List<int> SeverityTypeCount { get; set; }
        public List<string> DefectSourceList { get; set; }
        public List<int> DefectSourceCount { get; set; }
        public List<string> DefectCause { get; set; }
        public List<int> DefectCauseCount { get; set; }
    }

    public class BillMatrixSourceFeaturesChart
    {
        public string[] Features { get; set; }
        public List<string> DefectSourceList { get; set; }
        public List<int> DefectSourceCount { get; set; }
    }

    public class SeverityFeatureChart
    {
        public string[] Features { get; set; }
        public List<string> SeverityType { get; set; }
        public List<int> SeverityCount { get; set; }
    }

    public class CauseFeaturesChart
    {
        public string[] Features { get; set; }
        public List<string> CauseSource { get; set; }
        public List<int> CauseSourceCount { get; set; }
    }

}