﻿using NPOI.SS.UserModel;
using NPOI.XSSF.UserModel;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.Mvc;
using System.Xml.Linq;
using RegressionExtractor.Models;
using System.IO;
using System.Configuration;
using System.Reflection;

namespace RegressionExtractor.Controllers
{
    public class HomeController : Controller
    {
        [HttpPost]
        public ActionResult CauseChartBasedOnFeatures(string[] features, string columnName)
        {
            XSSFWorkbook wb = new XSSFWorkbook(ConfigurationManager.AppSettings["DefectMasterSheet"]);
            CauseFeaturesChart causeChart = new CauseFeaturesChart();
            List<IRow> listOfRowsToBeSelected = new List<IRow>();
            List<string> listOfCause = new List<string>();
            List<int> listOfCauseCount = new List<int>();
            ISheet sheet = wb.GetSheetAt(0);
            int index = (from x in sheet.GetRow(sheet.FirstRowNum).Cells where x.StringCellValue == columnName select x.ColumnIndex).FirstOrDefault();
            int descriptionIndex = (from x in sheet.GetRow(sheet.FirstRowNum).Cells where x.StringCellValue == "!Description" select x.ColumnIndex).FirstOrDefault();
            for (int i = 0; i <= sheet.LastRowNum; i++)
            {
                IRow row = sheet.GetRow(i);
                foreach (var item in features)
                {
                    if (row.Cells[descriptionIndex].StringCellValue.Contains(item + ":"))
                    {
                        listOfRowsToBeSelected.Add(row);
                    }
                }
            }

            foreach (var row in listOfRowsToBeSelected)
            {
                if (!listOfCause.Contains(row.Cells[index].StringCellValue))
                {
                    listOfCause.Add(row.Cells[index].StringCellValue);
                }
            }

            foreach (var item in listOfCause)
            {
                listOfCauseCount.Add((from x in listOfRowsToBeSelected where x.Cells[index].StringCellValue.Equals(item) select x).Count());
            }

            causeChart.Features = features;
            causeChart.CauseSource = listOfCause;
            causeChart.CauseSourceCount = listOfCauseCount;
            return PartialView(causeChart);
        }

        [HttpPost]
        public ActionResult SeverityChartBasedOnFeatures(string[] features, string columnName)
        {
            XSSFWorkbook wb = new XSSFWorkbook(ConfigurationManager.AppSettings["DefectMasterSheet"]);
            SeverityFeatureChart sevChart = new SeverityFeatureChart();
            List<IRow> listOfRowsToBeSelected = new List<IRow>();
            List<string> listOfSeverity = new List<string>();
            List<int> listOfSeverityCount = new List<int>();
            ISheet sheet = wb.GetSheetAt(0);
            int index = (from x in sheet.GetRow(sheet.FirstRowNum).Cells where x.StringCellValue == columnName select x.ColumnIndex).FirstOrDefault();
            int descriptionIndex = (from x in sheet.GetRow(sheet.FirstRowNum).Cells where x.StringCellValue == "!Description" select x.ColumnIndex).FirstOrDefault();
            for (int i = 0; i <= sheet.LastRowNum; i++)
            {
                IRow row = sheet.GetRow(i);
                foreach (var item in features)
                {
                    if (row.Cells[descriptionIndex].StringCellValue.Contains(item + ":"))
                    {
                        listOfRowsToBeSelected.Add(row);
                    }
                }
            }

            foreach (var row in listOfRowsToBeSelected)
            {
                if (!listOfSeverity.Contains(row.Cells[index].StringCellValue))
                {
                    listOfSeverity.Add(row.Cells[index].StringCellValue);
                }
            }

            foreach (var item in listOfSeverity)
            {
                listOfSeverityCount.Add((from x in listOfRowsToBeSelected where x.Cells[index].StringCellValue.Equals(item) select x).Count());
            }

            sevChart.Features = features;
            sevChart.SeverityType = listOfSeverity;
            sevChart.SeverityCount = listOfSeverityCount;
            return PartialView(sevChart);
        }

        [HttpPost]
        public ActionResult SourceChartBasedOnFeatures(string[] features, string columnName)
        {
            XSSFWorkbook wb = new XSSFWorkbook(ConfigurationManager.AppSettings["DefectMasterSheet"]);
            BillMatrixSourceFeaturesChart chartModel = new BillMatrixSourceFeaturesChart();
            List<IRow> listOfRowsToBeSelected = new List<IRow>();
            List<string> listOfDefectSource = new List<string>();
            List<int> listOfDefectSourceCount = new List<int>();
            ISheet sheet = wb.GetSheetAt(0);           
            int index = (from x in sheet.GetRow(sheet.FirstRowNum).Cells where x.StringCellValue == columnName select x.ColumnIndex).FirstOrDefault();
            int descriptionIndex = (from x in sheet.GetRow(sheet.FirstRowNum).Cells where x.StringCellValue == "!Description" select x.ColumnIndex).FirstOrDefault();
            for (int i = 0; i <= sheet.LastRowNum; i++)
            {
                IRow row = sheet.GetRow(i);
                foreach (var item in features)
                {
                    if(row.Cells[descriptionIndex].StringCellValue.Contains(item + ":"))
                    {
                        listOfRowsToBeSelected.Add(row);
                    }
                }
            }

            foreach (var row in listOfRowsToBeSelected)
            {
                if (!listOfDefectSource.Contains(row.Cells[index].StringCellValue))
                    {
                        listOfDefectSource.Add(row.Cells[index].StringCellValue);
                    }
            }

            foreach (var item in listOfDefectSource)
            {
                listOfDefectSourceCount.Add((from x in listOfRowsToBeSelected where x.Cells[index].StringCellValue.Equals(item) select x).Count());
            }

            chartModel.Features = features;
            chartModel.DefectSourceCount = listOfDefectSourceCount;
            chartModel.DefectSourceList = listOfDefectSource;
            return PartialView(chartModel);
        }

        [HttpGet]
        public FileResult DownloadDefectReport(string fileName)
        {            
            string fileLocation = (string)Session["FileLocation"];
            string filePath = Path.Combine(Path.GetTempPath(), "regression_default.xlsx");

            return File(filePath, "application/vnd.openxmlformats-officedocument.spreadsheetml.sheet", fileName);
        }

        [HttpGet]
        public string GetFeaturesDefectReport(string labelName, string downloadType, string[] features)
        {
            XSSFWorkbook wb = new XSSFWorkbook(ConfigurationManager.AppSettings["DefectMasterSheet"]);

            ISheet sheet = wb.GetSheetAt(0);            
            List<IRow> listOfRowsToBeSelected = new List<IRow>();
            int descriptionIndex = (from x in sheet.GetRow(sheet.FirstRowNum).Cells where x.StringCellValue == "!Description" select x.ColumnIndex).FirstOrDefault();
            int index = (from x in sheet.GetRow(sheet.FirstRowNum).Cells where x.StringCellValue == downloadType select x.ColumnIndex).FirstOrDefault();

            for (int i = 0; i <= sheet.LastRowNum; i++)
            {
                IRow row = sheet.GetRow(i);
                if (i == 0)
                    listOfRowsToBeSelected.Add(row);
                else
                {
                    foreach (var item in features)
                    {
                        if (row.Cells[descriptionIndex].StringCellValue.Contains(item + ":"))
                        {
                            if (row.Cells[index].StringCellValue.Equals(labelName))
                                listOfRowsToBeSelected.Add(row);
                        }
                    }
                }
            }           

            IWorkbook workbook = new XSSFWorkbook();
            ISheet extractSheet = workbook.CreateSheet(downloadType + "_Regression_Extract");

            ICellStyle style = workbook.CreateCellStyle();
            style.FillForegroundColor = IndexedColors.LightGreen.Index;
            style.FillPattern = FillPattern.SolidForeground;
            style.BorderBottom = BorderStyle.Medium;
            style.BorderLeft = BorderStyle.Medium;
            style.BorderRight = BorderStyle.Medium;
            style.BorderTop = BorderStyle.Medium;

            var font = workbook.CreateFont();
            font.FontHeightInPoints = 11;
            //font.FontName = "Calibri";
            font.Boldweight = (short)NPOI.SS.UserModel.FontBoldWeight.Bold;


            for (int i = 0; i < listOfRowsToBeSelected.Count; i++)
            {
                IRow newRow = extractSheet.CreateRow(i);
                for (int j = 0; j < listOfRowsToBeSelected[i].Cells.Count; j++)
                {
                    ICell newCell = newRow.CreateCell(j);
                    newCell.SetCellValue(listOfRowsToBeSelected[i].Cells[j].ToString());
                    if (i == 0)
                    {
                        newCell.CellStyle = style;
                        newCell.CellStyle.SetFont(font);
                    }

                    extractSheet.AutoSizeColumn(j);
                }
            }

            string executableLocation = Path.GetDirectoryName(Assembly.GetExecutingAssembly().Location);
            string xslxLocation = Path.Combine(executableLocation, "regression_default.xlsx");

            if (System.IO.File.Exists(xslxLocation))
            {
                System.IO.File.Delete(xslxLocation);
            }

            FileStream sw = System.IO.File.Create(xslxLocation);
            workbook.Write(sw);
            sw.Close();

            GC.Collect();
            // wb.Dispose();
            // string productName = (string)Session["ProductName"];
            if (string.IsNullOrEmpty(downloadType))
                downloadType = "default";
            // return File(xslxLocation, "application/vnd.openxmlformats-officedocument.spreadsheetml.sheet", "Regression_Pack_" + downloadType + ".xlsx");
            Session["FileLocation"] = xslxLocation;

            return "Regression_Pack_FeatureWise_" + downloadType + ".xlsx";
            
        }

        [HttpPost]
        public string PrepareDefectReport(string labelName, string downloadType)
        {
            XSSFWorkbook wb = new XSSFWorkbook(ConfigurationManager.AppSettings["DefectMasterSheet"]);
            
            ISheet sheet = wb.GetSheetAt(0);
            List<IRow> listOfRowsToBeSelected = new List<IRow>();
            int index = (from x in sheet.GetRow(sheet.FirstRowNum).Cells where x.StringCellValue == downloadType select x.ColumnIndex).FirstOrDefault();

            for (int i = 0; i <= sheet.LastRowNum; i++)
            {
                IRow row = sheet.GetRow(i);
                if (i == 0)
                    listOfRowsToBeSelected.Add(row);
                else
                {
                    if (row.Cells[index].StringCellValue.Equals(labelName))
                        listOfRowsToBeSelected.Add(row);
                }                
            }

            IWorkbook workbook = new XSSFWorkbook();
            
            ISheet extractSheet = workbook.CreateSheet(downloadType + "_Regression_Extract");

            ICellStyle style = workbook.CreateCellStyle();
            style.FillForegroundColor = IndexedColors.LightGreen.Index;
            style.FillPattern = FillPattern.SolidForeground;
            style.BorderBottom = BorderStyle.Medium;
            style.BorderLeft = BorderStyle.Medium;
            style.BorderRight = BorderStyle.Medium;
            style.BorderTop = BorderStyle.Medium;

            var font = workbook.CreateFont();
            font.FontHeightInPoints = 11;
            //font.FontName = "Calibri";
            font.Boldweight = (short)NPOI.SS.UserModel.FontBoldWeight.Bold;


            for (int i = 0; i < listOfRowsToBeSelected.Count; i++)
            {
                IRow newRow = extractSheet.CreateRow(i);
                for (int j = 0; j < listOfRowsToBeSelected[i].Cells.Count; j++)
                {
                    ICell newCell = newRow.CreateCell(j);
                    newCell.SetCellValue(listOfRowsToBeSelected[i].Cells[j].ToString());
                    if (i == 0)
                    {
                        newCell.CellStyle = style;
                        newCell.CellStyle.SetFont(font);
                    }

                    extractSheet.AutoSizeColumn(j);
                }
            }

            string executableLocation = Path.GetDirectoryName(Path.GetTempPath());
            string xslxLocation = Path.Combine(executableLocation, "regression_default.xlsx");

            if (System.IO.File.Exists(xslxLocation))
            {
                System.IO.File.Delete(xslxLocation);
            }

            FileStream sw = System.IO.File.Create(xslxLocation);
            workbook.Write(sw);
            sw.Close();

            GC.Collect();
            // wb.Dispose();
            // string productName = (string)Session["ProductName"];
            if (string.IsNullOrEmpty(downloadType))
                downloadType = "default";
           // return File(xslxLocation, "application/vnd.openxmlformats-officedocument.spreadsheetml.sheet", "Regression_Pack_" + downloadType + ".xlsx");
            Session["FileLocation"] = xslxLocation;

            return "Regression_Pack_" + downloadType + ".xlsx";


        }

        [HttpGet]
        public ActionResult BarchartBillMatrix(string productName)
        {
            if (!productName.Equals(string.Empty))
            {
                XSSFWorkbook wb = new XSSFWorkbook(ConfigurationManager.AppSettings["DefectMasterSheet"]);
                ISheet sheet = wb.GetSheetAt(0);// the sheet which we want to read

                List<IRow> rowsScanned = new List<IRow>();
                List<string> listOfDefectCause = new List<string>();
                List<string> listOfDefectSource = new List<string>();
                List<string> listOfSeverityType = new List<string>();               
                List<int> defectCauseCount = new List<int>();
                List<int> defectSourceCount = new List<int>();
                List<int> defectSeverityCount = new List<int>();
                List<string> listOfFeatures = new List<string>();


                //below are the index number of columns from which we want to read data.
                int defectSourceIndex = (from x in sheet.GetRow(sheet.FirstRowNum).Cells where x.StringCellValue == "!Defect Source" select x.ColumnIndex).FirstOrDefault();
                int severityIndex = (from x in sheet.GetRow(sheet.FirstRowNum).Cells where x.StringCellValue == "!Severity" select x.ColumnIndex).FirstOrDefault();
                int defectCauseIndex = (from x in sheet.GetRow(sheet.FirstRowNum).Cells where x.StringCellValue == "!Defect Cause" select x.ColumnIndex).FirstOrDefault();
                int descriptionIndex = (from x in sheet.GetRow(sheet.FirstRowNum).Cells where x.StringCellValue == "!Description" select x.ColumnIndex).FirstOrDefault();

                for (int i = 0; i <= sheet.LastRowNum; i++)
                {
                    IRow row = sheet.GetRow(i);
                    rowsScanned.Add(row);
                    if (!listOfDefectSource.Contains(row.Cells[defectSourceIndex].StringCellValue) && i != 0)
                    {
                        listOfDefectSource.Add(row.Cells[defectSourceIndex].StringCellValue);
                    }

                    if (!listOfSeverityType.Contains(row.Cells[severityIndex].StringCellValue) && i != 0)
                    {
                        listOfSeverityType.Add(row.Cells[severityIndex].StringCellValue);
                    }

                    if (!listOfDefectCause.Contains(row.Cells[defectCauseIndex].StringCellValue) && i != 0)
                    {
                        listOfDefectCause.Add(row.Cells[defectCauseIndex].StringCellValue);
                    }

                    if (!listOfFeatures.Contains(row.Cells[descriptionIndex].StringCellValue.Split(':').First().Trim()) && i != 0)
                    {
                        listOfFeatures.Add(row.Cells[descriptionIndex].StringCellValue.Split(':').First().Trim());
                    }                    
                }

                foreach (var item in listOfDefectSource)
                {
                    //int count = 0;
                    //for (int i = 0; i <= sheet.LastRowNum; i++)
                    //{
                    //    IRow row = sheet.GetRow(i);
                    //    if (row.Cells[defectSourceIndex].StringCellValue.Equals(item))
                    //        ++count;
                    //}
                    defectSourceCount.Add((from x in rowsScanned where x.Cells[defectSourceIndex].StringCellValue.Equals(item) select x).Count());
                }
                
                foreach (var item in listOfSeverityType)
                {
                    //int count = 0;
                    //for (int i = 0; i <= sheet.LastRowNum; i++)
                    //{
                    //    IRow row = sheet.GetRow(i);
                    //    if (row.Cells[severityIndex].StringCellValue.Equals(item))
                    //        ++count;
                    //}
                    //defectSeverityCount.Add(count);
                    defectSeverityCount.Add((from x in rowsScanned where x.Cells[severityIndex].StringCellValue.Equals(item) select x).Count());
                }

                foreach (var item in listOfDefectCause)
                {
                    //int count = 0;
                    //for (int i = 0; i <= sheet.LastRowNum; i++)
                    //{
                    //    IRow row = sheet.GetRow(i);
                    //    if (row.Cells[defectCauseIndex].StringCellValue.Equals(item))
                    //        ++count;
                    //}
                    //defectCauseCount.Add(count);
                    defectCauseCount.Add((from x in rowsScanned where x.Cells[defectCauseIndex].StringCellValue.Equals(item) select x).Count());
                }

                BillMatrixDefects defectData = new BillMatrixDefects();
                defectData.DefectSourceList = listOfDefectSource;
                defectData.DefectSourceCount = defectSourceCount;

                defectData.SeverityType = listOfSeverityType;
                defectData.SeverityTypeCount = defectSeverityCount;

                defectData.DefectCause = listOfDefectCause;               
                defectData.DefectCauseCount = defectCauseCount;

                defectData.ListOfFeatures = listOfFeatures;
                return PartialView(defectData);
            }
            else
            {
                return null;
            }
        }

        [HttpGet]
        public ActionResult Index()
        {
            //Session.Clear();
            Products model = new Products();           
            XElement configuration = XElement.Load(Server.MapPath("~/Content/Configuration.xml"));
            List<string> listOfProducts = (from x in configuration.Descendants("products").Elements().ToList() select x.Name.LocalName).ToList();    
            model.ListOfProducts = listOfProducts;           
            return View(model);
        }

        [HttpGet]
        public ActionResult Defects()
        {
            //Session.Clear();
            Products model = new Products();
            XElement configuration = XElement.Load(Server.MapPath("~/Content/Configuration.xml"));
            List<string> listOfProducts = (from x in configuration.Descendants("products").Elements().ToList() select x.Name.LocalName).ToList();
            model.ListOfProducts = listOfProducts;
            return View(model);

        }

        [HttpGet]        
        public ActionResult GetFeatures(string productName)
        {
            FeaturesModel featureModel = new FeaturesModel();
            if (!productName.Equals(string.Empty))
            {
                XElement configuration = XElement.Load(Server.MapPath("~/Content/Configuration.xml"));
                List<string> productFeatureList =
                        (from x in configuration.Descendants("products").Elements().Where(x => x.Name.LocalName.Equals(productName)).Descendants().Where(x => x.Name.LocalName.Equals("feature")).ToList()
                         select x.Value).ToList();

                featureModel.ListOfFeatures = productFeatureList;
            }           
            Session["ProductName"] = productName;
            return PartialView("GetFeatures", featureModel);
        }

        [HttpPost]        
        public FileResult GetRegressionPack(string[] selectedFeatures)
        {            
            XSSFWorkbook wb = new XSSFWorkbook(ConfigurationManager.AppSettings["RegressionExtractSourceFilePath"]);
            string productName = (string)Session["ProductName"];
            ISheet sheet = wb.GetSheet(productName + "_Master_Regression");
            List<IRow> listOfRowsToBeSelected = new List<IRow>();

            for (int i = 0; i < sheet.LastRowNum; i++)
            {
                IRow row = sheet.GetRow(i);
                if (i == 0)
                    listOfRowsToBeSelected.Add(row);

                foreach (var item in selectedFeatures)
                {
                    if (row.GetCell(row.Cells.Count - 1).ToString().Contains(item))
                    {
                        if (!listOfRowsToBeSelected.Contains(row))
                            listOfRowsToBeSelected.Add(row);
                        //break;
                    }
                }
            }

            IWorkbook workbook = new XSSFWorkbook();
            ISheet extractSheet = workbook.CreateSheet(productName + "_Regression_Extract");

            ICellStyle style = workbook.CreateCellStyle();
            style.FillForegroundColor = IndexedColors.LightGreen.Index;
            style.FillPattern = FillPattern.SolidForeground;
            style.BorderBottom = BorderStyle.Medium;
            style.BorderLeft = BorderStyle.Medium;
            style.BorderRight = BorderStyle.Medium;
            style.BorderTop = BorderStyle.Medium;

            var font = workbook.CreateFont();
            font.FontHeightInPoints = 11;
            //font.FontName = "Calibri";
            font.Boldweight = (short)NPOI.SS.UserModel.FontBoldWeight.Bold;


            for (int i = 0; i < listOfRowsToBeSelected.Count; i++)
            {
                IRow newRow = extractSheet.CreateRow(i);
                for (int j = 0; j < listOfRowsToBeSelected[i].Cells.Count; j++)
                {
                    ICell newCell = newRow.CreateCell(j);
                    newCell.SetCellValue(listOfRowsToBeSelected[i].Cells[j].ToString());
                    if (i == 0)
                    {
                        newCell.CellStyle = style;
                        newCell.CellStyle.SetFont(font);
                    }

                    extractSheet.AutoSizeColumn(j);
                }
            }

            string executableLocation = Path.GetDirectoryName(Assembly.GetExecutingAssembly().Location);
            string xslxLocation = Path.Combine(executableLocation, "regression_default.xlsx");

            if(System.IO.File.Exists(xslxLocation))
            {
                System.IO.File.Delete(xslxLocation);
            }

            FileStream sw = System.IO.File.Create(xslxLocation);
            workbook.Write(sw);
            sw.Close();

            GC.Collect();
           // wb.Dispose();
           // string productName = (string)Session["ProductName"];
            if (string.IsNullOrEmpty(productName))
                productName = "default";
            return File(xslxLocation, "application/vnd.openxmlformats-officedocument.spreadsheetml.sheet", "Regression_Pack_" + productName + ".xlsx");
        }


        public ActionResult About()
        {
            ViewBag.Message = "Your app description page.";

            return View();
        }

        public ActionResult Contact()
        {           
            ViewBag.Message = "Your contact page.";
            return View();
        }
    }
}
