﻿using System;
using System.Collections.Generic;
using System.Data;
using System.Data.Entity;
using System.Data.Entity.Infrastructure;
using System.Linq;
using System.Net;
using System.Net.Http;
using System.Threading.Tasks;
using System.Web.Http;
using System.Web.Http.Description;
using IPL2020WebApi;

namespace IPL2020WebApi.Controllers
{
    public class MatchesInfoController : ApiController
    {
        private IPL2020Entities db = new IPL2020Entities();

        // GET: api/MatchesInfo
        public IQueryable<MatchInfo> GetMatchInfoes()
        {
            return db.MatchInfoes;
        }

       public IQueryable<MatchInfo> GetMatchesForDate(DateTime matchDate)
        {
            var result = from x in db.MatchInfoes where x.MatchDate == matchDate select x;
            return result;
        }

        // GET: api/MatchesInfo/5
        [ResponseType(typeof(MatchInfo))]
        public async Task<IHttpActionResult> GetMatchInfo(int id)
        {
            MatchInfo matchInfo = await db.MatchInfoes.FindAsync(id);
            if (matchInfo == null)
            {
                return NotFound();
            }

            return Ok(matchInfo);
        }

        // PUT: api/MatchesInfo/5
        [ResponseType(typeof(void))]
        public async Task<IHttpActionResult> PutMatchInfo(int id, MatchInfo matchInfo)
        {
            if (!ModelState.IsValid)
            {
                return BadRequest(ModelState);
            }

            if (id != matchInfo.MatchNumber)
            {
                return BadRequest();
            }

            db.Entry(matchInfo).State = EntityState.Modified;

            try
            {
                await db.SaveChangesAsync();
            }
            catch (DbUpdateConcurrencyException)
            {
                if (!MatchInfoExists(id))
                {
                    return NotFound();
                }
                else
                {
                    throw;
                }
            }

            return StatusCode(HttpStatusCode.NoContent);
        }

        // POST: api/MatchesInfo
        [ResponseType(typeof(MatchInfo))]
        public async Task<IHttpActionResult> PostMatchInfo(MatchInfo matchInfo)
        {
            if (!ModelState.IsValid)
            {
                return BadRequest(ModelState);
            }

            db.MatchInfoes.Add(matchInfo);

            try
            {
                await db.SaveChangesAsync();
            }
            catch (DbUpdateException)
            {
                if (MatchInfoExists(matchInfo.MatchNumber))
                {
                    return Conflict();
                }
                else
                {
                    throw;
                }
            }

            return CreatedAtRoute("DefaultApi", new { id = matchInfo.MatchNumber }, matchInfo);
        }

        // DELETE: api/MatchesInfo/5
        [ResponseType(typeof(MatchInfo))]
        public async Task<IHttpActionResult> DeleteMatchInfo(int id)
        {
            MatchInfo matchInfo = await db.MatchInfoes.FindAsync(id);
            if (matchInfo == null)
            {
                return NotFound();
            }

            db.MatchInfoes.Remove(matchInfo);
            await db.SaveChangesAsync();

            return Ok(matchInfo);
        }

        protected override void Dispose(bool disposing)
        {
            if (disposing)
            {
                db.Dispose();
            }
            base.Dispose(disposing);
        }

        private bool MatchInfoExists(int id)
        {
            return db.MatchInfoes.Count(e => e.MatchNumber == id) > 0;
        }
    }
}