﻿using System;
using System.Collections.Generic;
using System.Data;
using System.Data.Entity;
using System.Data.Entity.Infrastructure;
using System.Linq;
using System.Net;
using System.Net.Http;
using System.Threading.Tasks;
using System.Web.Http;
using System.Web.Http.Description;
using IPL2020WebApi;

namespace IPL2020WebApi.Controllers
{
    public class ScoreboardController : ApiController
    {
        private IPL2020Entities db = new IPL2020Entities();

        // GET: api/Scoreboard
        public IQueryable<Scoreboard> GetScoreboards()
        {
            return db.Scoreboards;
        }

        // GET: api/Scoreboard/5
        [ResponseType(typeof(Scoreboard))]
        public async Task<IHttpActionResult> GetScoreboard(int id)
        {
            Scoreboard scoreboard = await db.Scoreboards.FindAsync(id);
            if (scoreboard == null)
            {
                return NotFound();
            }

            return Ok(scoreboard);
        }

        // PUT: api/Scoreboard/5
        [ResponseType(typeof(void))]
        public async Task<IHttpActionResult> PutScoreboard(int id, Scoreboard scoreboard)
        {
            if (!ModelState.IsValid)
            {
                return BadRequest(ModelState);
            }

            if (id != scoreboard.MatchNumber)
            {
                return BadRequest();
            }

            db.Entry(scoreboard).State = EntityState.Modified;

            try
            {
                await db.SaveChangesAsync();
            }
            catch (DbUpdateConcurrencyException)
            {
                if (!ScoreboardExists(id))
                {
                    return NotFound();
                }
                else
                {
                    throw;
                }
            }

            return StatusCode(HttpStatusCode.NoContent);
        }

        // POST: api/Scoreboard
        [ResponseType(typeof(Scoreboard))]
        public async Task<IHttpActionResult> PostScoreboard(Scoreboard scoreboard)
        {
            if (!ModelState.IsValid)
            {
                return BadRequest(ModelState);
            }

            db.Scoreboards.Add(scoreboard);

            try
            {
                await db.SaveChangesAsync();
            }
            catch (DbUpdateException)
            {
                if (ScoreboardExists(scoreboard.MatchNumber))
                {
                    return Conflict();
                }
                else
                {
                    throw;
                }
            }

            return CreatedAtRoute("DefaultApi", new { id = scoreboard.MatchNumber }, scoreboard);
        }

        // DELETE: api/Scoreboard/5
        [ResponseType(typeof(Scoreboard))]
        public async Task<IHttpActionResult> DeleteScoreboard(int id)
        {
            Scoreboard scoreboard = await db.Scoreboards.FindAsync(id);
            if (scoreboard == null)
            {
                return NotFound();
            }

            db.Scoreboards.Remove(scoreboard);
            await db.SaveChangesAsync();

            return Ok(scoreboard);
        }

        protected override void Dispose(bool disposing)
        {
            if (disposing)
            {
                db.Dispose();
            }
            base.Dispose(disposing);
        }

        private bool ScoreboardExists(int id)
        {
            return db.Scoreboards.Count(e => e.MatchNumber == id) > 0;
        }
    }
}