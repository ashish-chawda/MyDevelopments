﻿using System;
using System.Collections.Generic;
using System.Data;
using System.Data.Entity;
using System.Data.Entity.Infrastructure;
using System.Linq;
using System.Net;
using System.Net.Http;
using System.Threading.Tasks;
using System.Web.Http;
using System.Web.Http.Description;
using IPL2020WebApi;

namespace IPL2020WebApi.Controllers
{
    public class PlayersController : ApiController
    {
        private IPL2020Entities db = new IPL2020Entities();

        // GET: api/Players
        public IQueryable<PlayersInfo> GetPlayersInfoes()
        {
            return db.PlayersInfoes;
        }

        // GET: api/Players?team1Name=name&team2Name=name
        [ResponseType(typeof(PlayersInfo))]       
        public IQueryable<PlayersInfo> GetPlayersInfoes(string team1Name, string team2Name)
        {
            var result = from x in db.PlayersInfoes where x.TeamName.Equals(team1Name.Trim().ToUpper()) || x.TeamName.Equals(team2Name.Trim().ToUpper()) select x;
            return result;
        }

        // GET: api/Players?teamName=
        [ResponseType(typeof(PlayersInfo))]
        public IQueryable<PlayersInfo> GetPlayersInfoes(string teamName)
        {
            var result = from x in db.PlayersInfoes where x.TeamName.Equals(teamName.Trim().ToUpper()) select x;
            return result;
        }

        // GET: api/Players/5
        [ResponseType(typeof(PlayersInfo))]
        public async Task<IHttpActionResult> GetPlayersInfo(int id)
        {
            PlayersInfo playersInfo = await db.PlayersInfoes.FindAsync(id);
            if (playersInfo == null)
            {
                return NotFound();
            }

            return Ok(playersInfo);
        }

        // PUT: api/Players/5
        [ResponseType(typeof(void))]
        public async Task<IHttpActionResult> PutPlayersInfo(int id, PlayersInfo playersInfo)
        {
            if (!ModelState.IsValid)
            {
                return BadRequest(ModelState);
            }

            if (id != playersInfo.Id)
            {
                return BadRequest();
            }

            db.Entry(playersInfo).State = EntityState.Modified;

            try
            {
                await db.SaveChangesAsync();
            }
            catch (DbUpdateConcurrencyException)
            {
                if (!PlayersInfoExists(id))
                {
                    return NotFound();
                }
                else
                {
                    throw;
                }
            }

            return StatusCode(HttpStatusCode.NoContent);
        }

        // POST: api/Players
        [ResponseType(typeof(PlayersInfo))]
        public async Task<IHttpActionResult> PostPlayersInfo(PlayersInfo playersInfo)
        {
            if (!ModelState.IsValid)
            {
                return BadRequest(ModelState);
            }

            db.PlayersInfoes.Add(playersInfo);
            await db.SaveChangesAsync();

            return CreatedAtRoute("DefaultApi", new { id = playersInfo.Id }, playersInfo);
        }

        // DELETE: api/Players/5
        [ResponseType(typeof(PlayersInfo))]
        public async Task<IHttpActionResult> DeletePlayersInfo(int id)
        {
            PlayersInfo playersInfo = await db.PlayersInfoes.FindAsync(id);
            if (playersInfo == null)
            {
                return NotFound();
            }

            db.PlayersInfoes.Remove(playersInfo);
            await db.SaveChangesAsync();

            return Ok(playersInfo);
        }

        protected override void Dispose(bool disposing)
        {
            if (disposing)
            {
                db.Dispose();
            }
            base.Dispose(disposing);
        }

        private bool PlayersInfoExists(int id)
        {
            return db.PlayersInfoes.Count(e => e.Id == id) > 0;
        }
    }
}