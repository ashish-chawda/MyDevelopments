﻿using System;
using System.Collections.Generic;
using System.Data;
using System.Data.Entity;
using System.Data.Entity.Infrastructure;
using System.Linq;
using System.Net;
using System.Net.Http;
using System.Security.Principal;
using System.Threading.Tasks;
using System.Web.Http;
using System.Web.Http.Description;
using IPL2020WebApi;

namespace IPL2020WebApi.Controllers
{
    public class UsersController : ApiController
    {
        private IPL2020Entities db = new IPL2020Entities();

        // GET: api/Users
        public IQueryable<User> GetUsers()
        {
            return db.Users;
        }

        // GET: api/Users/5
        [ResponseType(typeof(User))]
        public async Task<IHttpActionResult> GetUser(int id)
        {
            User user = await db.Users.FindAsync(id);
            if (user == null)
            {
                return NotFound();
            }

            return Ok(user);
        }

        [ResponseType(typeof(string))]
        public string GetLoggedInUserName()
        {
            return WindowsIdentity.GetCurrent().Name;
        }

        // GET: api/Users?userName=
        [ResponseType(typeof(User))]
        public bool GetUser(string userName, string pass)
        {
            User user = (from x in db.Users where x.UserName.Equals(userName.Trim()) && x.UserPassword.Equals(pass.Trim()) select x).FirstOrDefault();
            if (user != null)
                return true;

            return false;
        }

        // PUT: api/Users/5
        [ResponseType(typeof(void))]
        public async Task<IHttpActionResult> PutUser(int id, User user)
        {
            if (!ModelState.IsValid)
            {
                return BadRequest(ModelState);
            }

            if (id != user.Id)
            {
                return BadRequest();
            }

            db.Entry(user).State = EntityState.Modified;

            try
            {
                await db.SaveChangesAsync();
            }
            catch (DbUpdateConcurrencyException)
            {
                if (!UserExists(id))
                {
                    return NotFound();
                }
                else
                {
                    throw;
                }
            }

            return StatusCode(HttpStatusCode.NoContent);
        }

        // POST: api/Users
        [ResponseType(typeof(User))]
        public async Task<IHttpActionResult> PostUser(User user)
        {
            int count = (from x in db.Users where x.UserName.Equals(user.UserName) select x).Count();
            if (count == 0)
            {
                db.Users.Add(user);
                await db.SaveChangesAsync();

                return Ok("User Registered Sucessfully !");
            }
            else
            {
                return Ok("User Already Exists");                     
            }
           
        }

        // DELETE: api/Users/5
        [ResponseType(typeof(User))]
        public async Task<IHttpActionResult> DeleteUser(int id)
        {
            User user = await db.Users.FindAsync(id);
            if (user == null)
            {
                return NotFound();
            }

            db.Users.Remove(user);
            await db.SaveChangesAsync();

            return Ok(user);
        }

        protected override void Dispose(bool disposing)
        {
            if (disposing)
            {
                db.Dispose();
            }
            base.Dispose(disposing);
        }

        private bool UserExists(int id)
        {
            return db.Users.Count(e => e.Id == id) > 0;
        }
    }
}