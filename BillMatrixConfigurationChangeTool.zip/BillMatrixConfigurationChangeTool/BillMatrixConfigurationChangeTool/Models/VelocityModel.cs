﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Xml.Linq;

namespace BillMatrixConfigurationChangeTool.Models
{
    public enum AccountRule
    {
        PayAccountRule,
        UserAccountRule
    }

    //public class PaymentVelocity
    //{
    //    public int PaymentVelocityDays { get; set; }
    //    public int PaymentVelocityTimes { get; set; }
    //}


    public class UserAccountRule
    {
        public int PaymentVelocityDays { get; set; }
        public int PaymentVelocityTimes { get; set; }
    }

    public class PayAccountRule
    {
        public int PaymentVelocityDays { get; set; }
        public int PaymentVelocityTimes { get; set; }
    }

    public class VelocityViewModel
    {
        public int BillerId { get; set; }
        public string BillerName { get; set; }
        public List<UserAccountRule> ListOfUserAccountRule { get; set; }
        public List<PayAccountRule> ListOfPayAccountRule { get; set; }
    }

    public class InfoPortalModel
    {
        public string ValidationName { get; set; }
        public string ValidationSettings { get; set; }
    }

    public class InfoPortalViewModel
    {
        public string BillerId { get; set; }
        public string BillerName { get; set; }
        public List<InfoPortalModel> InfoPortalSettings { get; set; }
    }

    public class XmlDisplay
    {
        public string BillerId { get; set; }
        public string BillerName { get; set; }
        public string OriginalXml { get; set; }
        public string UpdatedXml { get; set; }
    }
}