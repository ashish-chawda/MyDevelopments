﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.Mvc;
using System.Xml;
using System.Xml.Linq;
using BillMatrixConfigurationChangeTool.Models;
using System.Text;
using System.IO;
using System.Configuration;
using System.Diagnostics;


namespace BillMatrixConfigurationChangeTool.Controllers
{
    public class HomeController : Controller
    {
        public static readonly log4net.ILog logger;

        static HomeController()
        {
            logger = log4net.LogManager.GetLogger(System.Reflection.MethodBase.GetCurrentMethod().DeclaringType);
        }        

        [HttpGet]
        public ActionResult Index()
        {
            ViewBag.Message = "Modify this template to jump-start your ASP.NET MVC application.";
            return View();
        }

        [HttpGet]
        public ActionResult DisplayXmlChange()
        {
            try
            {
                logger.Info("Inside " + System.Reflection.MethodBase.GetCurrentMethod().Name + " method to display the original and updated XML.");
                bool isIISResetSuccess = (bool)TempData["IISSuccess"];
                ViewBag.IISSuccess = isIISResetSuccess;
                XmlDisplay displayXml = (XmlDisplay)TempData["xmlDisplayObj"];
                logger.Info("Completed execution of " + System.Reflection.MethodBase.GetCurrentMethod().Name + " method to display the original and updated XML.");
                return View(displayXml);
            }
            catch (Exception ex)
            {
                logger.Error(ex.Message, ex);
                return View("Error");
            }
        }

        [HttpPost]
        public ActionResult UpdateInfoPortalConfiguration(InfoPortalViewModel updateInfoPortalViewModel)
        {
            logger.Info("Inside " + System.Reflection.MethodBase.GetCurrentMethod().Name + " method to fetch the InfoPortal configuration and display it in a view.");
            try
            {
                XElement billerInfo = (XElement)TempData["billerInfo"];
                List<XElement> userInterfaces = (List<XElement>)TempData["userInterfaceList"];

                foreach (XElement item in userInterfaces)
                {
                    List<XElement> validationList = item.Descendants("Validations").Descendants("Validation").ToList();
                    for (int i = 0; i < validationList.Count; i++)
                    {
                        validationList.ElementAt(i).Element("Name").Value = updateInfoPortalViewModel.InfoPortalSettings.ElementAt(i).ValidationName;
                        validationList.ElementAt(i).Element("Settings").Value = updateInfoPortalViewModel.InfoPortalSettings.ElementAt(i).ValidationSettings.Replace(";", " and ");
                    }
                }

                billerInfo.Save((string)TempData["infoPortalFileName"]);
                logger.Info("Completed execution of " + System.Reflection.MethodBase.GetCurrentMethod().Name + "  method to fetch the InfoPortal configuration and display it in a view.");
                return View();
            }
            catch (Exception ex)
            {
                logger.Error(ex.Message, ex);
                return View("Error");
            }
            
        }

        [HttpPost]
        public ActionResult GetInfoPortalChange(XmlDisplay displayObj)
        {
            logger.Info("Inside " + System.Reflection.MethodBase.GetCurrentMethod().Name + " method to fetch the InfoPortal configuration from the Biller XML file.");
            try
            {
                string fileName = GetInfoPortalFilePath(displayObj.BillerId);
                logger.Info("File path for biller id: " + displayObj.BillerId + "is: " + fileName);
                TempData["infoPortalFileName"] = fileName;
                XElement billerInfo = XElement.Load(fileName);
                TempData["billerInfo"] = billerInfo;
                List<XElement> userInterfaceList = billerInfo.Descendants("UserInterfaces").Descendants("UserInterface").ToList();
                TempData["userInterfaceList"] = userInterfaceList;
                XElement userInterfaceRoot = (from x in userInterfaceList where x.Element("UIType").Value.Equals("IVR") select x).FirstOrDefault();
                List<XElement> validationList = userInterfaceRoot.Descendants("Validations").Descendants("Validation").ToList();

                List<InfoPortalModel> infoModelList = new List<InfoPortalModel>();
                foreach (XElement item in validationList)
                {
                    InfoPortalModel model = new InfoPortalModel();
                    model.ValidationName = item.Element("Name").Value;
                    model.ValidationSettings = item.Element("Settings").Value;
                    infoModelList.Add(model);
                }

                InfoPortalViewModel infoViewModel = new InfoPortalViewModel();
                infoViewModel.BillerId = displayObj.BillerId;
                infoViewModel.BillerName = displayObj.BillerName;
                infoViewModel.InfoPortalSettings = infoModelList;
                logger.Info("Successfully fetched the info portal configuration details for biller id: " + displayObj.BillerId);
                return View(infoViewModel);
            }
            catch (Exception)
            {
                return View("Error");
            }
            
        }


        private void AddDataToViewModel(XElement element, XNamespace xmlNs, ref VelocityViewModel viewModel, AccountRule ruleType)
        {
            logger.Info("Inside " + System.Reflection.MethodBase.GetCurrentMethod().Name + " method to bind data to ViewModel.");
            try
            {
                List<XElement> listOfTimeConstraint = element.Descendants(xmlNs + "AuthorizedTimeConstraints").Elements(xmlNs + "TimeConstraint").ToList();
                foreach (var item in listOfTimeConstraint)
                {
                    if (ruleType.Equals(AccountRule.UserAccountRule))
                    {
                        UserAccountRule userAcctRule = new UserAccountRule();
                        userAcctRule.PaymentVelocityDays = Convert.ToInt32(item.Attribute("days").Value);
                        userAcctRule.PaymentVelocityTimes = Convert.ToInt32(item.Attribute("times").Value);
                        viewModel.ListOfUserAccountRule.Add(userAcctRule);
                    }
                    else if (ruleType.Equals(AccountRule.PayAccountRule))
                    {
                        PayAccountRule payAcctRule = new PayAccountRule();
                        payAcctRule.PaymentVelocityDays = Convert.ToInt32(item.Attribute("days").Value);
                        payAcctRule.PaymentVelocityTimes = Convert.ToInt32(item.Attribute("times").Value);
                        viewModel.ListOfPayAccountRule.Add(payAcctRule);
                    }
                }
            }
            catch (Exception ex)
            {
                logger.Error(ex.Message, ex);
                throw;
            }
            
        }

        private string GetInfoPortalFilePath(string billerId)
        {
            logger.Info("Inside " + System.Reflection.MethodBase.GetCurrentMethod().Name + " method to get the file location of info portal configuration.");
            try
            {
                return (ConfigurationManager.AppSettings["InfoPortalLocation"]);
            }
            catch (Exception ex)
            {
                logger.Error(ex.Message, ex);
                throw;
            }
          
        }

        private List<string> GetValidationRuleFilePath(string billerId, string envmt)
        {
            logger.Info("Inside " + System.Reflection.MethodBase.GetCurrentMethod().Name + " method to get the file location of Validation Rules schema XML.");
            try
            {
                string iso = ConfigurationManager.AppSettings[billerId];
                string domainName = ConfigurationManager.AppSettings["DomainName"];
                TempData["domainName"] = domainName;
                List<string> serverList = ConfigurationManager.AppSettings[iso + envmt].Split(',').ToList();
                TempData["serverList"] = serverList;
                string validationRuleFilePath = ConfigurationManager.AppSettings["ValidationRuleFilePath"];
                List<string> pathOfValidationFile = new List<string>();
                foreach (string server in serverList)
                {
                    string filePath = string.Empty;
                    if (server.Contains("nwdp"))
                    {
                        filePath = server + domainName + validationRuleFilePath;
                    }
                    else
                    {
                        filePath = server + validationRuleFilePath;
                    }

                    if (System.IO.File.Exists(filePath))
                    {
                        pathOfValidationFile.Add(filePath);
                    }
                }

                return pathOfValidationFile;
            }
            catch (Exception ex)
            {
                logger.Error(ex.Message, ex);
                throw;
            }
            
        }

        [HttpPost]
        public ActionResult Index(string billerId, string envmt)
        {
            log4net.ThreadContext.Properties["BillerId"] = billerId;
            logger.Info("Inside " + System.Reflection.MethodBase.GetCurrentMethod().Name + " method to fetch the details from schema XML file for biller ID: " + billerId + " for " + envmt + " environment.");
            try
            {
                VelocityViewModel viewModel = new VelocityViewModel();
                viewModel.BillerId = Convert.ToInt32(billerId);
                viewModel.ListOfUserAccountRule = new List<UserAccountRule>();
                viewModel.ListOfPayAccountRule = new List<PayAccountRule>();
                List<string> fileNames = GetValidationRuleFilePath(billerId, envmt);
                TempData["fileName"] = fileNames;
                List<XElement> listOfRootNodes = new List<XElement>();
                List<XElement> listOfBillerRoot = new List<XElement>();
                var billerName = "PGE";
                viewModel.BillerName = billerName;
                foreach (string path in fileNames)
                {
                    XElement billerIdVelocityInfo = XElement.Load(path);
                    listOfRootNodes.Add(billerIdVelocityInfo);
                    var xmlNs = billerIdVelocityInfo.Name.Namespace;
                    
                    List<XElement> validationRule = billerIdVelocityInfo.Descendants().Where(e => e.Name.LocalName.Equals("ValidationRule")).ToList();
                    XElement billerValidationRule = (from x in validationRule where x.Elements().Where(y => y.Name.LocalName.Equals("BillerID")).FirstOrDefault().Value.Equals(billerId) select x).FirstOrDefault();                   
                    listOfBillerRoot.Add(billerValidationRule);

                    if (billerValidationRule != null)
                    {
                        XElement userAccountRule = billerValidationRule.Descendants().Where(x => x.Name.LocalName.Equals("UserAccountRule")).FirstOrDefault();
                        XElement payAccountRule = billerValidationRule.Descendants().Where(x => x.Name.LocalName.Equals("PayAccountRule")).FirstOrDefault();

                        if (userAccountRule.Elements().Where(x => x.Name.LocalName.Equals("AuthorizedTimeConstraints")).FirstOrDefault().HasElements)
                        {
                            AddDataToViewModel(userAccountRule, xmlNs, ref viewModel, AccountRule.UserAccountRule);
                        }
                        if (payAccountRule.Elements().Where(x => x.Name.LocalName.Equals("AuthorizedTimeConstraints")).FirstOrDefault().HasElements)
                        {
                            AddDataToViewModel(payAccountRule, xmlNs, ref viewModel, AccountRule.PayAccountRule);
                        }

                        ViewBag.BillerName = billerName;                        
                    }
                }

                TempData["billerValidationRuleXElement"] = listOfBillerRoot;
                TempData["billerInfo"] = listOfRootNodes;
                logger.Info("Successfully fetched configuraiton details for biller ID: " + billerId + " for " + envmt + " environment.");
                return View(viewModel);
            }
            catch (Exception ex)
            {
                logger.Error(ex.Message, ex);
                return View("Error");
            }
            
        }      

       [HttpPost]
        public ActionResult UpdateConfiguration(VelocityViewModel viewModelUpdated)
        {
            logger.Info("Inside " + System.Reflection.MethodBase.GetCurrentMethod().Name + " method to update the details in schema XML file for biller ID: " + viewModelUpdated.BillerId);
            try
            {
                List<XElement> billerValidRuleElement = (List<XElement>)TempData["billerValidationRuleXElement"];
                List<XElement> billerIdVelocityInfo = (List<XElement>)TempData["billerInfo"];
                List<string> fileNames = (List<string>)TempData["fileName"];
                XmlDisplay displayXml = new XmlDisplay();
                displayXml.BillerId = viewModelUpdated.BillerId.ToString();
                displayXml.BillerName = viewModelUpdated.BillerName;
                viewModelUpdated.ListOfUserAccountRule.Sort(delegate(UserAccountRule x, UserAccountRule y)
                {
                    return x.PaymentVelocityDays.CompareTo(y.PaymentVelocityDays);
                });

                viewModelUpdated.ListOfPayAccountRule.Sort(delegate(PayAccountRule x, PayAccountRule y)
                {
                    return x.PaymentVelocityDays.CompareTo(y.PaymentVelocityDays);
                });

                for (int i = 0; i < fileNames.Count; i++)
                {
                    System.IO.File.Delete(fileNames.ElementAt(i) + "." + DateTime.Now.Date.ToString("ddMMyyyy") + ".bkp");
                    System.IO.File.Copy(fileNames.ElementAt(i), fileNames.ElementAt(i) + "." + DateTime.Now.Date.ToString("ddMMyyyy") + ".bkp");
                    //XElement billerIdVelocityInfo = XElement.Load(fileName);
                    var xmlNs = billerIdVelocityInfo.ElementAt(i).Name.Namespace;
                    // XElement billerValidationRule = (from x in billerIdVelocityInfo.Descendants(xmlNs + "ValidationRule").ToList() where x.Element(xmlNs + "BillerID").Value.Equals(viewModelUpdated.BillerId.ToString()) select x).FirstOrDefault();

                    XElement displayElementOriginal = new XElement(billerValidRuleElement.ElementAt(i));

                    displayElementOriginal.Descendants().Where(x => x.Name.LocalName.Equals("UserAccountRule")).Elements().Where(x => !(x.Name.LocalName.ToString().Contains("AuthorizedTimeConstraints") || x.Name.LocalName.ToString().Contains("AttemptedTimeConstraints"))).Remove();
                    displayElementOriginal.Descendants().Where(x => x.Name.LocalName.Equals("PayAccountRule")).Elements().Where(x => !(x.Name.LocalName.ToString().Contains("AuthorizedTimeConstraints") || x.Name.LocalName.ToString().Contains("AttemptedTimeConstraints"))).Remove();
                    displayElementOriginal.Descendants().Where(x => x.Name.LocalName.Equals("AmountRule")).Elements().Where(x => !(x.Name.LocalName.ToString().Contains("AuthorizedTimeConstraints") || x.Name.LocalName.ToString().Contains("AttemptedTimeConstraints"))).Remove();
                    displayXml.OriginalXml = displayElementOriginal.ToString();

                    List<XElement> listOfUserAcctTimeConstraints = billerValidRuleElement.ElementAt(i).Descendants().Where(x => x.Name.LocalName.Equals("UserAccountRule")).Descendants().Where(x => x.Name.LocalName.Equals("AuthorizedTimeConstraints")).Descendants().Where(x => x.Name.LocalName.Equals("TimeConstraint")).ToList();
                    List<XElement> listOfPayAcctTimeConstraints = billerValidRuleElement.ElementAt(i).Descendants().Where(x => x.Name.LocalName.Equals("PayAccountRule")).Descendants().Where(x => x.Name.LocalName.Equals("AuthorizedTimeConstraints")).Descendants().Where(x => x.Name.LocalName.Equals("TimeConstraint")).ToList();

                    for (int j = 0; j < viewModelUpdated.ListOfUserAccountRule.Count; j++)
                    {
                        listOfUserAcctTimeConstraints.ElementAt(i).Attribute("days").Value = viewModelUpdated.ListOfUserAccountRule[i].PaymentVelocityDays.ToString();
                        listOfUserAcctTimeConstraints.ElementAt(i).Attribute("times").Value = viewModelUpdated.ListOfUserAccountRule[i].PaymentVelocityTimes.ToString();
                    }

                    for (int j = 0; j < viewModelUpdated.ListOfPayAccountRule.Count; j++)
                    {
                        listOfPayAcctTimeConstraints.ElementAt(i).Attribute("days").Value = viewModelUpdated.ListOfPayAccountRule[i].PaymentVelocityDays.ToString();
                        listOfPayAcctTimeConstraints.ElementAt(i).Attribute("times").Value = viewModelUpdated.ListOfPayAccountRule[i].PaymentVelocityTimes.ToString();
                    }

                    billerIdVelocityInfo.ElementAt(i).Save(fileNames.ElementAt(i));

                    XElement displayElementUpdated = new XElement(billerValidRuleElement.ElementAt(i));
                    displayElementUpdated.Descendants().Where(x => x.Name.LocalName.Equals("UserAccountRule")).Elements().Where(x => !(x.Name.LocalName.ToString().Contains("AuthorizedTimeConstraints") || x.Name.LocalName.ToString().Contains("AttemptedTimeConstraints"))).Remove();
                    displayElementUpdated.Descendants().Where(x => x.Name.LocalName.Equals("PayAccountRule")).Elements().Where(x => !(x.Name.LocalName.ToString().Contains("AuthorizedTimeConstraints") || x.Name.LocalName.ToString().Contains("AttemptedTimeConstraints"))).Remove();
                    displayElementUpdated.Descendants().Where(x => x.Name.LocalName.Equals("AmountRule")).Elements().Where(x => !(x.Name.LocalName.ToString().Contains("AuthorizedTimeConstraints") || x.Name.LocalName.ToString().Contains("AttemptedTimeConstraints"))).Remove();
                    displayXml.UpdatedXml = displayElementUpdated.ToString();
                }

                
                TempData["xmlDisplayObj"] = displayXml;
                string domainName = (string)TempData["domainName"];
                bool isRestartSuccess = ResetIIS((List<string>)TempData["serverList"], domainName);
                TempData["IISSuccess"] = isRestartSuccess;
                logger.Info("Configuraiton file updated for biller ID: " + viewModelUpdated.BillerId);
                return RedirectToAction("DisplayXmlChange", "Home");
            }
            catch (Exception ex)
            {
                logger.Error(ex.Message, ex);
                return View("Error");
            }            
        }

        private bool ResetIIS(List<string> servers, string domain)
        {
            logger.Info("Inside " + System.Reflection.MethodBase.GetCurrentMethod().Name + " method to resest IIS in background.");
            try
            {
                string str_MyProg = @"C:\Windows\System32\iisreset.exe";
                bool isResultSuccess = false;
                foreach (string server in servers)
                {
                    System.Diagnostics.ProcessStartInfo procStartInfo = new System.Diagnostics.ProcessStartInfo(str_MyProg, server + domain);

                    procStartInfo.RedirectStandardError = true;
                    procStartInfo.RedirectStandardOutput = true; // Set true to redirect the process stdout to the Process.StandardOutput StreamReader
                    procStartInfo.UseShellExecute = false;
                    procStartInfo.CreateNoWindow = true;          // Do not create the black window
                    procStartInfo.WindowStyle = System.Diagnostics.ProcessWindowStyle.Hidden;
                    // Create a process, assign its ProcessStartInfo and start it
                    System.Diagnostics.Process myProcess = new System.Diagnostics.Process();
                    myProcess.StartInfo = procStartInfo;
                    myProcess.Start();

                    // Dump the output to the log file
                    string stdOut = myProcess.StandardOutput.ReadToEnd();
                    StreamWriter logFile = new StreamWriter(ConfigurationManager.AppSettings["IISResetLogFilePath"]);
                    logFile.Write(stdOut);
                    logFile.Close();

                    if (stdOut.Contains("Internet services successfully restarted"))
                    {
                        isResultSuccess = true;
                    }
                }

                return isResultSuccess;
            }
            catch (Exception ex)
            {
                logger.Error(ex.Message, ex);
                throw;
            }            
        }

        public ActionResult About()
        {
            ViewBag.Message = "Your app description page.";

            return View();
        }

        public ActionResult Contact()
        {
            ViewBag.Message = "Your contact page.";

            return View();
        }
    }
}
