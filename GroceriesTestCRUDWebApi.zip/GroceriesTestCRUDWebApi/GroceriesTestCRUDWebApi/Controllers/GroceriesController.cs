﻿using System;
using System.Collections.Generic;
using System.Data;
using System.Data.Entity;
using System.Data.Entity.Infrastructure;
using System.Linq;
using System.Net;
using System.Net.Http;
using System.Web.Http;
using System.Web.Http.Description;
using GroceriesTestCRUDWebApi;

namespace GroceriesTestCRUDWebApi.Controllers
{
    public class GroceriesController : ApiController
    {
        private CRUDTestDBEntities db = new CRUDTestDBEntities();

        // GET: api/Groceries
        public IQueryable<Grocery> GetGroceries()
        {
            return db.Groceries;
        }

        // GET: api/Groceries/5
        [ResponseType(typeof(Grocery))]
        public IHttpActionResult GetGrocery(int id)
        {
            Grocery grocery = db.Groceries.Find(id);
            
            if (grocery == null)
            {
                return NotFound();
            }

            return Ok(grocery);
        }

        // PUT: api/Groceries/5
        [ResponseType(typeof(void))]
        [HttpPut, Route("api/groceries/{id}")]
        public IHttpActionResult PutGrocery(int id, Grocery grocery)
        {
           
            if (id != grocery.GroceryItemId)
            {
                return BadRequest();
            }

            db.Entry(grocery).State = EntityState.Modified;

            try
            {
                db.SaveChanges();
            }
            catch (DbUpdateConcurrencyException)
            {
                if (!GroceryExists(id))
                {
                    return NotFound();
                }
                else
                {
                    throw;
                }
            }

            return StatusCode(HttpStatusCode.NoContent);
        }

        // POST: api/Groceries
        [ResponseType(typeof(Grocery))]
        public IHttpActionResult PostGrocery(Grocery grocery)
        {
            

            db.Groceries.Add(grocery);
            db.SaveChanges();

            return CreatedAtRoute("DefaultApi", new { id = grocery.GroceryItemId }, grocery);
        }

        // DELETE: api/Groceries/5
        [ResponseType(typeof(Grocery))]
        [HttpDelete, Route("api/groceries/{item}")]
        public IHttpActionResult DeleteGrocery(int item)
        {
            Grocery grocery = db.Groceries.Find(item);
            if (grocery == null)
            {
                return NotFound();
            }

            db.Groceries.Remove(grocery);
            db.SaveChanges();

            return Ok(grocery);
        }

        protected override void Dispose(bool disposing)
        {
            if (disposing)
            {
                db.Dispose();
            }
            base.Dispose(disposing);
        }

        private bool GroceryExists(int id)
        {
            return db.Groceries.Count(e => e.GroceryItemId == id) > 0;
        }
    }
}