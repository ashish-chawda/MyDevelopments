﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Drawing;
using System.Windows.Forms;
using System.Runtime.InteropServices;

namespace AutoSys_Extract_ToolTest
{
    class Program
    {
        private const double minutes = 1;
        
        static void Main(string[] args)
        {
            while(true)
            {
                System.Threading.Thread.Sleep(Convert.ToInt32(3000));
                Point original = Cursor.Position;
                Point newPos = new Point(original.X + 100, original.Y + 50);
                Point newPos1 = new Point(original.X + 200, original.Y + 500);
                Point newPos2 = new Point(original.X + 300, original.Y + 30);
                //Point newPos1 = new Point(original.X + 20, original.Y);
                //Point newPos2 = new Point(original.X + 30, original.Y);
                //Cursor.Position = newPos1;
                //Cursor.Position = newPos2;
                Cursor.Position = newPos;
                System.Threading.Thread.Sleep(5000);
                Cursor.Position = newPos1;
                System.Threading.Thread.Sleep(5000);
                Cursor.Position = newPos2;
                System.Threading.Thread.Sleep(5000);
                //Cursor.Position = original;
                SendKeys.SendWait("{CAPSLOCK}");
                
            }
        }
        
    }
}
 