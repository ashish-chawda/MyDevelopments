export interface User
{
    name: string,
    contact:string,
    email:string
}