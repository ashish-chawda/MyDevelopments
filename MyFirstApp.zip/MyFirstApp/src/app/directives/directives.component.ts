import { Component, OnInit, Input } from '@angular/core';

@Component({
  selector: 'app-directives',
  templateUrl: './directives.component.html',
  styleUrls: ['./directives.component.css']
})
export class DirectivesComponent implements OnInit {

  displayName: string = "Ashish Chawda";
  namesList: string[];
  firstNameList: string[] = ['Ashish', 'Manoj', 'Moeen', 'Nikhil'];
  lastNameList: string[] = ['Chawda', 'Jadhav', 'Khan', 'Singh'];
  i: number = 0;
  isStopToggle: boolean = true;
  isStartToggle:boolean = false;
  nameChangeInterval:any;
textColor: string = "red";

  constructor() {
    this.namesList = this.firstNameList;
  }

  stopNameChange()
  {
    this.isStartToggle = false;
    clearInterval(this.nameChangeInterval);
    this.namesList = this.firstNameList;
    this.isStopToggle = true;
  }
  changeNames() {
    this.isStartToggle = true;
    this.isStopToggle = false;
   this.nameChangeInterval =  setInterval(() => {
      if (this.i % 2 == 0) {
        this.namesList = this.firstNameList;
      }
      else {
        this.namesList = this.lastNameList;
      }
      ++this.i;
    }, 2000)
  }

  ngOnInit() {
  }

}
