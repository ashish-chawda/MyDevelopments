import { Component, OnInit } from '@angular/core';

import   Grocery from '../models/GroceryModel';
import { GroceryManagerService } from '../api/grocery-manager.service';
import { HttpClient } from '@angular/common/http';
import { Route, Router } from '@angular/router';


@Component({
  selector: 'app-grocery-list',
  templateUrl: './grocery-list.component.html',
  styleUrls: ['./grocery-list.component.css']
  
})
export class GroceryListComponent implements OnInit {

  groceryList: Array<Grocery>;
  selectedItem: Grocery;
  formToggle: boolean = false;

  constructor(private groceryService: GroceryManagerService,
    private router: Router) { }

    getSelectedItem(item)
    {
      console.log("component seelcted item : " + item.GroceryItemName);
      this.selectedItem = item;   
         
      this.formToggle = !this.formToggle;
    }

    AddItem(form)
  {
    this.groceryService.save(form).subscribe( data => {
      this.getAll();
    })
  }
  deleteItem(id)
  {
    console.log("inside component: " + id)
     this.groceryService.remove(id).subscribe(data => 
      {
        console.log(data);
        this.getAll();
        
      })
  }

  EditItem(item)
  {
    item.GroceryItemId = this.selectedItem.GroceryItemId;
    console.log("Component: " + item.GroceryItemId);
    
    this.groceryService.edit(item).subscribe(data => {
      console.log('successfully edited: ' + item.GroceryItemName);
      this.getAll();
      this.formToggle = !this.formToggle;
    })
  }

  getAll()
  {
    this.groceryService.getAll().subscribe(data => {
      this.groceryList = data
    });
  }
  ngOnInit() {
   
    this.getAll();
  }

}

