export default class Grocery
{
    GroceryItemId?: number;
    GroceryItemName: string;
} 