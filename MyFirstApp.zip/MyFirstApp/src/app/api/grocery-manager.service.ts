import { Injectable } from '@angular/core';
import { HttpClient } from '@angular/common/http';
import {Observable} from 'rxjs/internal/Observable';

import Grocery from '../models/GroceryModel';
import {map} from 'rxjs/operators';

@Injectable({
  providedIn: 'root'
})
export class GroceryManagerService {

  public API = "http://localhost:53360/api";
  public GROCERY_API = `${this.API}/Groceries`;

  constructor(private http: HttpClient) { }
  
getAll(): Observable<Array<Grocery>> {
  return this.http.get<Array<Grocery>>(this.GROCERY_API);  
}

save(grocery): Observable<Grocery>{
  console.log("service add: " + grocery.GroceryItemName);
let result: Observable<Grocery>;
result = this.http.post<Grocery>(this.GROCERY_API, grocery);
console.log(result);
return result;
}

edit(item): Observable<Grocery>{
  console.log("service edit : " + item.GroceryItemName);
  
let result: Observable<Grocery>;
return this.http.put<Grocery>(`${this.GROCERY_API}/${item.GroceryItemId}`, item);


}

remove(id){
  console.log("service: " + id);
  
return this.http.delete(`${this.GROCERY_API}/${id}`);

}

get(id: string){
  return this.http.get(`${this.GROCERY_API}/${id.toString()}`);
}


}
