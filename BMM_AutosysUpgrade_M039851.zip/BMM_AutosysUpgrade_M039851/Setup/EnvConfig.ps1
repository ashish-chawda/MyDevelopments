<# ***************************************************************************

	Title: EnvConfig.ps1

	Purpose: Run the environment-specific cmd file to run Nautilus configuration.

	Usage:  powershell EnvConfig.ps1 -TargetEnv "<env>" -DeployBundle "<DeployBundle>"

	History:
	Date		Dev	Description
	09/30/2016	JSC	Created.
	10/03/2016	JSC Added error handling and variable checking.
	10/13/2016	JSC Changes and streamline after running with TFS.

*****************************************************************************#>
param
(
    [string] $TargetEnv,
	[string] $DeployBundle=""
)

$ScriptName = $MyInvocation.MyCommand.Name
Write-Output "Running $ScriptName"

# variables
$manifestFile = 'DeploymentManifest.xml'
$one = "1"
$nil = "0"
# end variables

Write-Output "TargetEnv = $TargetEnv"
Write-Output "DeployBundle = $DeployBundle"
if ($DeployBundle -eq "")
{
	$SetupDir = Get-Location
} 
else
{
	$SetupDir = "C:\deploy\$DeployBundle\Setup"
}

Write-Output "SetupDir = $SetupDir"

if(!$TargetEnv) 
{
	Write-Output "Missing parameter -TargetEnv...Exiting"
	exit 1
}

$BldBundleFldr = Split-Path $SetupDir -parent

$CMD = "$SetupDir\Nautilus.Console.exe"

& $CMD $BldBundleFldr $TargetEnv $one $nil $one


