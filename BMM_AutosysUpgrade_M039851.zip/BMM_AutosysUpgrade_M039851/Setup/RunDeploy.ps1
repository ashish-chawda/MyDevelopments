<# ***************************************************************************

	Title: RunDeploy.ps1

	Purpose: Run the DeployInstructions.bat.

	Usage:  powershell RunDeploy.ps1 -DeployBundle "<DeployBundle>"

	History:
	Date		Dev	Description
	10/14/2016	JSC	Created.

*****************************************************************************#>
param
(
    [string] $DeployBundle
)

$ScriptName = $MyInvocation.MyCommand.Name
Write-Output "Running $ScriptName"

if(!$DeployBundle) 
{
	Write-Output "Missing parameter -DeployBundle...Exiting"
	exit 1
}

$SetupDir = "C:\deploy\$DeployBundle\Setup"
Write-Output "SetupDir = $SetupDir"

Set-Location $SetupDir

& .\DeployInstructions.bat

