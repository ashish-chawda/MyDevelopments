<# ***************************************************************************

	Title: rollback.ps1

	Purpose: Roll back a deployment from the backup location. This must be run 
	         on the server being rolled back.

	Usage: powershell rollback.ps1 

	History:
	Date		Dev	Description
	03/09/2017	JSC	Created.
	03/10/2017	JSC	Added more error handling.
	03/24/2017	JSC Bug fix - $backCompFolder was not being set correctly for 
	                the rollback.
		
*****************************************************************************#>
###################################################################
#
# name: CheckForCancel 
#
# purpose: Check input and whether to exit script.
#
###################################################################
function CheckForCancel
{
	param ([string]$strInput = $input)
	if ($strInput -eq 'x' -or $strInput -eq 'X' -or $strInput -eq "")
	{
		Write-Host "Exiting without rollback..."
		exit
	}
}

###################################################################
#
# name: CheckIfExist 
#
# purpose: Confirm existence of a file or folder. Exit script if
#          not found.
#
###################################################################
function CheckIfExist
{
	param ($fileOrFolder)
	if (!(Test-Path $fileOrFolder))
	{
		Write-Host "`n$fileOrFolder not found!" -Fore red
		Write-Host "`nExiting..."
		exit
	}
}

##########################################
#
# name: main 
#
# purpose: main code block
#
##########################################
# variables
$manifestFile = 'DeploymentManifest.xml'
$hostName = $env:computername
$RobocopyOptions = @('/E', '/IS')
$realBackups = @()

CheckIfExist $manifestFile

# loading the deployment manifest
[xml]$depMan = Get-Content $manifestFile
$numberOfEnvs = ($depMan.DeploymentManifest.Manifest).Count

# display environments listed in the manifest and servers for each
for ($i = 0; $i -lt $numberOfEnvs; $i++)
{
	$env = $depMan.DeploymentManifest.Manifest.Environment[$i]
	$servers = $depMan.DeploymentManifest.Manifest.CommaDelimitedServers[$i]
	
	$obj = new-object psobject
	$obj | add-member noteproperty Environment ($env)
	$obj | add-member noteproperty Servers ($servers)
	
	write-output $obj 
}

Write-Host "`nPlease select the target environment for rollback`n" -Fore yellow

# dynamic menu to select the target environment
for ($i = 0; $i -lt $numberOfEnvs; $i++)
{
	$j = $i + 1
	Write-Host "`t$j."$depMan.DeploymentManifest.Manifest.Environment[$i] -Fore yellow
}
Write-Host "`tX. Cancel and exit" -Fore yellow
Write-Host "`nMake your selection: " -Fore yellow -NoNewLine
$input = Read-Host 

# cancel script if x or nothing entered
CheckForCancel 

$targetEnv = $input - 1
if ($targetEnv -lt 0)
{
		Write-Host "`nInvalid entry!" -Fore red
		Write-Host "`nExiting..."
		exit
}
$backupFolder = $depMan.DeploymentManifest.Manifest.BackUpDestFolder[$targetEnv]
CheckIfExist $backupFolder
#Write-Host "Backups located in $backupFolder"

$destFolder = $depMan.DeploymentManifest.Manifest.DeployInstructions.Instructions.DestFolder[$targetEnv]
#Write-Host "DestFolder is $destFolder"

$backups = Get-ChildItem -Path $backupFolder | Where-Object  {$_.PSIsContainer} | sort -descending

foreach ($backup in $backups)
{
	if ("$backup*" -notmatch $hostName) { continue }
	
	$backCompFolder = Get-ChildItem $backupFolder\$backup 
	if ($backCompFolder -match (Split-Path $destFolder -leaf))
	{
		$realBackups += $backup
	}
}

if ($realBackups.Count -eq 0)
{
	Write-Host "`nNo backups found for $destFolder `non $hostName!"  -Fore red
	Write-Host "`nConfirm that $hostName is in" $depMan.DeploymentManifest.Manifest.Environment[$targetEnv] -Fore red
	Write-Host "`nExiting..."
	exit
}

Write-Host "`nPlease select the backup folder to use for rollback`n" -Fore yellow

# dynamic menu to select backup folder
$i = 0
foreach ($realBackup in $realBackups)
{
	$j = $i + 1
	Write-Host "`t$j."$realBackups[$i] -Fore yellow
	$i++
}
Write-Host "`tX. Cancel and exit" -Fore yellow
Write-Host "`nMake your selection: " -Fore yellow -NoNewLine
$input = Read-Host 

# cancel script if x or nothing entered
CheckForCancel

$realBackup = $realBackups[$input-1]
$backCompFolder = Get-ChildItem $backupFolder\$realBackup | Split-Path -leaf

Write-Host "`nYou are about to rollback...`n`n$destFolder`nfrom`n$backupFolder\$realBackup\$backCompFolder" -Fore yellow
Write-Host "`nType yes and press Enter to continue: " -Fore yellow -NoNewLine
$input = Read-Host 

if ($input -ne 'yes')
{
	Write-Host "Exiting without rollback..."
	exit
}

Robocopy "$backupFolder\$realBackup\$backCompFolder" "$destFolder" $RobocopyOptions