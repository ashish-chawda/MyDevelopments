﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;

namespace NZ1JIlCreationWebUtility.Models
{
    public class DownloadOptions
    {
        public bool IsDevDownload
        {
            get;
            set;
        }
        public bool IsStageDownload
        {
            get;
            set;
        }
        public bool IsCtDownload
        {
            get;
            set;
        }
        public bool IsProdDownload
        {
            get;
            set;
        }
    }
}