﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace NZ1JIlCreationWebUtility.Models
{
    public class ReportData
    {
        public List<int> ListOfStatusCount { get; set; }
        public List<string> ListOfStatus { get; set; }

        public List<int> ListOfMachineCount { get; set; }
        public List<string> ListOfMachine { get; set; }

        public List<int> ListOfOwnerCount { get; set; }
        public List<string> ListOfOwner { get; set; }
    }

    public class JobNameAndPaths
    {
        public string BillerName { get; set; }
        public string FilePath { get; set; }
    }

    public class JobDetail
    {
        private string biller = string.Empty;
        public string BillerName
        {
            get
            {
                return biller;
            }
            set
            {
                biller = value;
            }
        }
        public string JobName { get; set; }
        public string JobType { get; set; }
        public string JobStatus { get; set; }
        private string boxName = string.Empty;
        public string BoxName
        {
            get
            {
                return boxName;
            }
            set
            {
                boxName = value;
            }
        }

        //below are some new parameters added.
        public string Condition { get; set; }
        public string Box_Success { get; set; }
        public string Box_Failure { get; set; }
        public string Date_Condition { get; set; }
        public string TimeZone { get; set; }

        private string schedule = string.Empty;
        public string Schedule
        {
            get
            {
                return schedule;
            }
            set
            {
                schedule = value;
            }
        }
        private string startRun = string.Empty;
        public string StartRun
        {
            get
            {
                return startRun;
            }
            set
            {
                startRun = value;
            }

        }

        public string StartRunTime
        {
            get;
            set;
        }


        private string lastRun = string.Empty;
        public string LastRun
        {
            get
            {
                return lastRun;
            }
            set
            {
                lastRun = value;
            }

        }

        public string LastRunTime
        {
            get;
            set;
        }

        private string runDay = string.Empty;
        public string RunDay
        {
            get { return runDay; }
            set { runDay = value; }
        }

        private string machine = string.Empty;
        public string Machine
        {
            get
            {
                return machine;
            }
            set
            {
                machine = value;
            }
        }
        public string Owner { get; set; }

        private string fileName = string.Empty;
        public string FileName
        {
            get
            {
                return fileName;
            }
            set
            {
                fileName = value;
            }
        }

        private string sourceFilePath = string.Empty;
        public string SourceFilePath
        {
            get
            {
                return sourceFilePath;
            }
            set
            {
                sourceFilePath = value;
            }
        }

        private string destFilePath = string.Empty;
        public string DestinationFilePath
        {
            get
            {
                return destFilePath;
            }
            set
            {
                destFilePath = value;
            }
        }

        private string command = string.Empty;
        public string Command
        {
            get
            {
                return command;
            }
            set
            {
                command = value;
            }
        }


        //private string must_start_times = string.Empty;
        //public string Must_Start_Time
        //{
        //    get
        //    {
        //        return must_start_times;
        //    }
        //    set
        //    {
        //        must_start_times = value;
        //    }
        //}


        //private string condition = string.Empty;
        //public string Condition
        //{
        //    get
        //    {
        //        return condition;
        //    }
        //    set { condition = value; }
        //}


        private string wrapperName = string.Empty;
        public string Wrapper
        {
            get
            {
                return wrapperName;
            }
            set
            {
                wrapperName = value;
            }
        }

        private string n_retry = string.Empty;
        private string run_calendar = string.Empty;
        private string profile = string.Empty;
        private string job_load = string.Empty;
        private string priority = string.Empty;

        public string N_Retry
        {
            get
            {
                return n_retry;
            }
            set
            {
                n_retry = value;
            }
        }
        public string Run_Calendar
        {
            get
            {
                return run_calendar;
            }
            set
            {
                run_calendar = value;
            }
        }
        public string Profile
        {
            get
            {
                return profile;
            }
            set
            {
                profile = value;
            }
        }
        public string Job_Load
        {
            get
            {
                return job_load;
            }
            set
            {
                job_load = value;
            }
        }
        public string Priority
        {
            get
            {
                return priority;
            }
            set
            {
                priority = value;
            }
        }

        private string application = string.Empty;
        public string Application
        {
            get
            {
                return application;
            }
            set
            {
                application = value;
            }
        }
    }

    public class FilteredJobs
    {
        private string run_day = string.Empty;
        public string Run_Day
        {
            get { return run_day; }
            set { run_day = value; }
        }

        private string start_times = string.Empty;
        public string Start_Times
        {
            get { return start_times; }
            set { start_times = value; }
        }

        private string must_start_times = string.Empty;
        public string Must_Start_Times
        {
            get { return must_start_times; }
            set { must_start_times = value; }
        }

        private string machine = string.Empty;
        public string Machine
        {
            get
            {
                return machine;
            }
            set
            {
                machine = value;
            }
        }
        private string command = string.Empty;
        public string Command
        {
            get
            {
                return command;
            }
            set
            {
                command = value;
            }
        }
       
        public string Header { get; set; }
        public string Insert_job { get; set; }
        public string Owner { get; set; }
        public string Permission { get; set; }
        public string DateCondition { get; set; }
        public string Description { get; set; }
        public string Boxname { get; set; }
        public string Condition { get; set; }
        public string Profile { get; set; }
        public string StdOutFile { get; set; }
        public string StdErrFile { get; set; }
        public string AlarmIfFail { get; set; }
        public string JobLoad { get; set; }
        public string Priority { get; set; }
        public string MaxRunAlarm { get; set; }
        public string Group { get; set; }
        public string Box_Failure { get; set; }
        public string Box_Success { get; set; }
        public string Application { get; set; }
        public string N_Retrys { get; set; }
        public string Run_Calendar { get; set; }
        public string Max_Exit_Success { get; set; }
        public string Success_Codes { get; set; }
        public string Fail_Codes { get; set; }
        public string Must_Complete_Times { get; set; }

        public string Ftp_Transfer_Type { get; set; }
        public string Ftp_Transfer_Direction { get; set; }
        public string Ftp_Local_Name { get; set; }
        public string Ftp_Remote_Name { get; set; }
        public string Ftp_Server_Name { get; set; }
        public string Ftp_Server_port { get; set; }
        public string Ftp_Use_Ssl { get; set; }
        public string Ftp_Local_User { get; set; }
        public string Start_Mins { get; set; }
        public string Watch_File { get; set; } 
        public string Watch_File_Recurrsive { get; set; }
        public string Watch_File_Type { get; set; }
        public string Watch_File_Win_User { get; set; }
        public string Continous { get; set; }
        public string Watch_Interval { get; set; }
        public string Win_Event_Op { get; set; }
        public string Monitor_Mode { get; set; }
        public string Term_Run_Time { get; set; }
        public string Send_Notification { get; set; }
        public string Notification_Id { get; set; }
        public string Notification_Msg { get; set; }
        public string Exclude_Calendar { get; set; }
        public string Std_In_File { get; set; }
        public string TimeZone { get; set; }

        public string Job_terminator { get; set; }
        public string Win_log_name { get; set; }
        public string Win_event_type { get; set; }
        public string Win_event_id { get; set; }
        public string Min_run_alarm { get; set; }
        public string Alarm_if_terminated { get; set; }
        public string Status { get; set; }
    }
}
