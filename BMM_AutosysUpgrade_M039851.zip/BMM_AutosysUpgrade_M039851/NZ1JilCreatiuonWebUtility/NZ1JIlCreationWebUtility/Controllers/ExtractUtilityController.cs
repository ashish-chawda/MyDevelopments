﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.Mvc;
using NZ1JIlCreationWebUtility.Models;
using System.IO;
using System.Data;
using System.Xml;
using System.Text;

namespace NZ1JIlCreationWebUtility.Controllers
{
    public class ExtractUtilityController : Controller
    {
        //
        // GET: /ExtractUtility/

        public ActionResult ExtractUtil()
        {
            return View();
        }

        [AcceptVerbs(HttpVerbs.Post)]
        //[HttpPost]
        public FileResult ExtractUtil(HttpPostedFileBase jilfile, HttpPostedFileBase extractfile)
        {
            //if (extractfile != null && jilfile != null)
            //{
            string outputFileName = "JilExtractReport_" + DateTime.Now.Date.ToString("ddMMyyyy") + ".xls";
                string extractFilePath = System.IO.Path.Combine(System.IO.Path.GetTempPath(), extractfile.FileName);
                string jilFilePath = System.IO.Path.Combine(System.IO.Path.GetTempPath(), jilfile.FileName);
                string outputFilePath = System.IO.Path.Combine(System.IO.Path.GetTempPath(), outputFileName);
                if (System.IO.File.Exists(extractFilePath))
                    System.IO.File.Delete(extractFilePath);

                if (System.IO.File.Exists(jilFilePath))
                    System.IO.File.Delete(jilFilePath);

                if (System.IO.File.Exists(outputFilePath))
                    System.IO.File.Delete(outputFilePath);

                extractfile.SaveAs(extractFilePath);
                jilfile.SaveAs(jilFilePath);

                List<FilteredJobs> filteredJobs = new List<FilteredJobs>();                
                JobDetail objJobDetail;
                string billerName = string.Empty;
                List<JobDetail> listOfJobDetail = new List<JobDetail>();
                List<FilteredJobs> listOFilteredJobs = new List<FilteredJobs>();
                Dictionary<string, string> dictionaryOfJobsWithLastRunDate = new Dictionary<string, string>();
                Dictionary<string, string> dictionaryOfJobsWithLastRunTimings = new Dictionary<string, string>();
                Dictionary<string, string> dictionaryOfJobsWithStartRunDate = new Dictionary<string, string>();
                Dictionary<string, string> dictionaryOfJobsWithStartRunTimings = new Dictionary<string, string>();

                Dictionary<string, string> dictionaryOfJobsWithStatus = GetStatusAndOtherInfoFromExtractFile(extractFilePath, ref dictionaryOfJobsWithLastRunDate, ref dictionaryOfJobsWithLastRunTimings, ref dictionaryOfJobsWithStartRunDate, ref dictionaryOfJobsWithStartRunTimings);
                List<string> listOfBillers = GetBillerNamesListAndListOfAllJobs(jilFilePath, ref listOFilteredJobs).Distinct().ToList<string>();

                foreach (var biller in listOfBillers)
                {
                 //   Console.WriteLine(StringConstants.BILLERCOUNT_AND_PENDINGBILLERS, ++billercount, listOfBillers.Count - (billercount));
                    //SEMLogger.LogInformation("Getting jil information for biller: {0}", biller);
                    filteredJobs.Clear();
                    foreach (var item in listOFilteredJobs)
                    {
                        string insertJobName = item.Insert_job;
                        List<string> listOfItemsInJob = insertJobName.Trim().Split('-').ToList<string>();
                        try
                        {
                            if (insertJobName.StartsWith(StringConstants.BSL_JOBS_SUBSTRING))
                            {
                                if (listOfItemsInJob.Count >= 6)
                                    billerName = item.Insert_job.Split(StringConstants.SPLIT_WITH_HYPHEN)[5].Trim();

                                if (billerName.Equals(biller))
                                    filteredJobs.Add(item);
                            }
                            else if (insertJobName.StartsWith(StringConstants.BIS_JOBS_SUBSTRING))
                            {
                                if (listOfItemsInJob.Count >= 6)
                                    billerName = insertJobName.Split(StringConstants.SPLIT_WITH_HYPHEN)[6].Trim();

                                if (billerName.Equals(biller))
                                    filteredJobs.Add(item);
                            }
                            else
                            {
                                //insertJobName = string.Concat(insertJobName.TakeWhile(c => c != ' '));
                                if (insertJobName.Equals(biller))
                                {
                                    filteredJobs.Add(item);
                                }
                            }
                        }
                        catch (Exception ex)
                        {
                            //SEMLogger.LogError("Error while getting the information of jobs for biller : {0}. Please see below error message: \n {1}", biller, ex.Message);
                            insertJobName = string.Concat(insertJobName.TakeWhile(c => c != ' '));
                            if (insertJobName.Equals(biller))
                                filteredJobs.Add(item);
                            if (ex.Message.ToLower().Contains(StringConstants.INDEX))
                                continue;
                        }
                    }

                    //SEMLogger.LogInformation("Total no. of jobs found for biller: {0} is: {1}", biller, filteredJobs.Count);
                    foreach (var item in filteredJobs)
                    {
                        string sourceFilePath = string.Empty;
                        string destFilePath = string.Empty;
                        objJobDetail = new JobDetail();
                        objJobDetail.RunDay = string.IsNullOrEmpty(item.Run_Day) ? "N/A" : item.Run_Day.Replace(StringConstants.COMMA, StringConstants.COLON).Trim();
                        objJobDetail.Schedule = string.IsNullOrEmpty(item.Start_Times) ? "N/A" : item.Start_Times;
                        objJobDetail.BillerName = biller.ToLower();
                        objJobDetail.BoxName = string.IsNullOrEmpty(item.Boxname) ? "N/A" : item.Boxname;
                        objJobDetail.Command = item.Command;
                        objJobDetail.JobName = item.Insert_job;

                        objJobDetail.StartRun = dictionaryOfJobsWithStartRunDate.ContainsKey(objJobDetail.JobName) ? dictionaryOfJobsWithStartRunDate[objJobDetail.JobName] : "N/A";
                        objJobDetail.LastRun = dictionaryOfJobsWithLastRunDate.ContainsKey(objJobDetail.JobName) ? dictionaryOfJobsWithLastRunDate[objJobDetail.JobName] : "N/A";
                        objJobDetail.JobStatus = dictionaryOfJobsWithStatus.ContainsKey(objJobDetail.JobName) ? dictionaryOfJobsWithStatus[objJobDetail.JobName] : "N/A";
                        objJobDetail.StartRunTime = dictionaryOfJobsWithStartRunTimings.ContainsKey(objJobDetail.JobName) ? dictionaryOfJobsWithStartRunTimings[objJobDetail.JobName] : "N/A";
                        objJobDetail.LastRunTime = dictionaryOfJobsWithLastRunTimings.ContainsKey(objJobDetail.JobName) ? dictionaryOfJobsWithLastRunTimings[objJobDetail.JobName] : "N/A";

                        objJobDetail.Machine = item.Machine;
                        objJobDetail.Owner = item.Owner;
                        objJobDetail.Wrapper = string.IsNullOrEmpty(objJobDetail.Command) ? "N/A" : GetWrapperName(objJobDetail.Command);
                        objJobDetail.Wrapper = string.IsNullOrEmpty(objJobDetail.Wrapper) ? "N/A" : objJobDetail.Wrapper;
                        objJobDetail.JobType = string.IsNullOrEmpty(objJobDetail.Wrapper) ? "N/A" : GetJobType(objJobDetail.Wrapper);
                        objJobDetail.JobType = string.IsNullOrEmpty(objJobDetail.JobType) ? "N/A" : objJobDetail.JobType;
                        objJobDetail.FileName = string.IsNullOrEmpty(objJobDetail.Command) ? "N/A" : GetFileNameAndPath(objJobDetail.Command, ref sourceFilePath, ref destFilePath);
                        objJobDetail.FileName = string.IsNullOrEmpty(objJobDetail.FileName) ? "N/A" : objJobDetail.FileName;
                        objJobDetail.SourceFilePath = string.IsNullOrEmpty(sourceFilePath) ? "N/A" : sourceFilePath;
                        objJobDetail.DestinationFilePath = string.IsNullOrEmpty(destFilePath) ? "N/A" : destFilePath;
                        objJobDetail.N_Retry = string.IsNullOrEmpty(item.N_Retrys) ? "N/A" : item.N_Retrys;
                        objJobDetail.Profile = string.IsNullOrEmpty(item.Profile) ? "N/A" : item.Profile;
                        objJobDetail.Run_Calendar = string.IsNullOrEmpty(item.Run_Calendar) ? "N/A" : item.Run_Calendar;
                        objJobDetail.Job_Load = string.IsNullOrEmpty(item.JobLoad) ? "N/A" : item.JobLoad;
                        objJobDetail.Priority = string.IsNullOrEmpty(item.Priority) ? "N/A" : item.Priority;

                        //adding new parameters to report
                        objJobDetail.Condition = string.IsNullOrEmpty(item.Condition) ? "N/A" : item.Condition.Trim();
                        objJobDetail.Box_Success = string.IsNullOrEmpty(item.Box_Success) ? "N/A" : item.Box_Success.Trim();
                        objJobDetail.Box_Failure = string.IsNullOrEmpty(item.Box_Failure) ? "N/A" : item.Box_Failure.Trim();
                        objJobDetail.TimeZone = string.IsNullOrEmpty(item.TimeZone) ? "N/A" : item.TimeZone.Trim();
                        objJobDetail.Date_Condition = string.IsNullOrEmpty(item.DateCondition) ? "N/A" : item.DateCondition.Trim();
                        listOfJobDetail.Add(objJobDetail);
                        sourceFilePath = string.Empty;
                    }
                }

               // SEMLogger.LogInformation("Writing job contents to CSV/XLS file.");
                DataTable jobDetailTable = new FileOperations().ConvertListToDataTable(listOfJobDetail);
                
                ExcelCreator.Create(jobDetailTable, outputFilePath);
                               //var valueLines = jobDetailTable.AsEnumerable().Select(row => string.Join(StringConstants.COMMA, row.ItemArray));
                //lines.AddRange(valueLines);
                //File.WriteAllLines(outputFileName, lines);
                //SEMLogger.LogInformation("Writing of job contents to CSV file finished.");

                //listOfBillers = GetListOfJobsFromJil(filePath, SessionID);
                System.IO.File.Delete(extractFilePath);
                System.IO.File.Delete(jilFilePath);
               

                return File(outputFilePath, StringConstants.FILE_TYPE, outputFileName);
        }

        private static string GetFileNameAndPath(string command, ref string sourceFilePath, ref string destinationFilePath)
        {
            string fileName = string.Empty;
            try
            {
                if (command.Contains("\\\\"))
                {
                    string result = string.Empty;
                    string path = string.Empty;
                    command = command.ToLower();
                    //string commandWithoutColon = command.Split(new string[] { "command:"}, StringSplitOptions.None).Last();
                    if (command.Contains("<yyyy>") || command.Contains("<mm>") || command.Contains("<dd>"))
                    {
                        command = command.Replace("<yyyy>", "YYYY");
                        command = command.Replace("<mm>", "MM");
                        command = command.Replace("<dd>", "DD");
                    }

                    if (command.Contains("filename"))
                    {
                        if (command.Contains("destinationfilepath") && command.Contains("isupload=0"))
                        {
                            destinationFilePath = command.Split(new string[] { "destinationfilepath=" }, StringSplitOptions.None).Last();
                            destinationFilePath = destinationFilePath.Replace("$$", "##");
                            destinationFilePath = string.Concat(destinationFilePath.TakeWhile((c) => c != '"'));
                            destinationFilePath = sourceFilePath.Replace("##", "$$");
                        }
                        if (command.Contains("destinationpath") && command.Contains("isupload=0"))
                        {
                            if (command.Contains("destinationpath="))
                                destinationFilePath = command.Split(new string[] { "destinationpath=" }, StringSplitOptions.None).Last();
                            else
                                destinationFilePath = command.Split(new string[] { "destinationpath " }, StringSplitOptions.None).Last();
                            destinationFilePath = destinationFilePath.Replace("$$", "##");
                            destinationFilePath = string.Concat(destinationFilePath.TakeWhile((c) => c != '"'));
                            destinationFilePath = destinationFilePath.Replace("##", "$$");
                        }
                        if (command.Contains("sourcepath"))
                        {
                            sourceFilePath = command.Split(new string[] { "sourcepath=" }, StringSplitOptions.None).Last();
                            sourceFilePath = sourceFilePath.Replace("$$", "##");
                            sourceFilePath = string.Concat(sourceFilePath.TakeWhile((c) => c != '$'));
                            sourceFilePath = sourceFilePath.Replace("##", "$$");
                        }
                        if (command.Contains("sourcefilepath"))
                        {
                            if (command.Contains("sourcefilepath="))
                                sourceFilePath = command.Split(new string[] { "sourcefilepath=" }, StringSplitOptions.None).Last();
                            else
                                sourceFilePath = command.Split(new string[] { "sourcefilepath " }, StringSplitOptions.None).Last();
                            sourceFilePath = sourceFilePath.Replace("$$", "##");
                            if (sourceFilePath.Contains("$"))
                                sourceFilePath = string.Concat(sourceFilePath.TakeWhile((c) => c != '$'));
                            else
                                sourceFilePath = string.Concat(sourceFilePath.TakeWhile((c) => c != '-'));
                            sourceFilePath = sourceFilePath.Replace("##", "$$");
                        }
                        if (command.Contains("destinationfilepath"))
                        {
                            if (command.Contains("destinationfilepath="))
                                destinationFilePath = command.Split(new string[] { "destinationfilepath=" }, StringSplitOptions.None).Last();
                            else
                                destinationFilePath = command.Split(new string[] { "destinationfilepath " }, StringSplitOptions.None).Last();
                            destinationFilePath = destinationFilePath.Replace("$$", "##");
                            if (destinationFilePath.Contains("$"))
                                destinationFilePath = string.Concat(destinationFilePath.TakeWhile((c) => c != '$'));

                            destinationFilePath = destinationFilePath.Replace("##", "$$");
                        }

                        if (command.Contains("-filepath"))
                        {
                            sourceFilePath = command.Split(new string[] { "-filepath " }, StringSplitOptions.None).Last();
                            sourceFilePath = string.Concat(sourceFilePath.Trim().TakeWhile((c) => c != '-'));
                        }

                        if (command.Contains("filename="))
                            path = command.Split(new string[] { "filename=" }, StringSplitOptions.None).Last();
                        else if (command.Contains("filename "))
                            path = command.Split(new string[] { "filename " }, StringSplitOptions.None).Last();
                        result = string.Concat(path.TakeWhile((c) => c != '$'));
                    }
                    else
                    {
                        path = command.Substring(command.IndexOf("\\\\"));
                        if (!command.Contains("rename"))
                            path = path.Replace("\"", string.Empty).TrimEnd(new char[] { '\\' });
                        if (path.ToUpper().Contains("DO"))
                        {
                            if (command.Contains("rename"))
                            {
                                path = path.Trim().Split(new string[] { " \"" }, StringSplitOptions.None)[0];
                                path = path.Replace("\"", string.Empty).TrimEnd(new char[] { '\\' });
                            }
                            else
                            {
                                if ((command.Trim().StartsWith("copy") || command.Trim().StartsWith("move")) && path.Contains(" \\\\"))
                                    destinationFilePath = path.Trim().Split(new string[] { " \\\\" }, StringSplitOptions.None)[1];
                                else if (command.Trim().StartsWith("for"))
                                {
                                    if (command.Contains("copy"))
                                    {
                                        if (command.Contains("copy "))
                                            destinationFilePath = path.Trim().Split(new string[] { "copy " }, StringSplitOptions.None)[1];
                                        else
                                            destinationFilePath = path.Trim().Split(new string[] { "copy" }, StringSplitOptions.None)[1];

                                        if (destinationFilePath.Contains(" \\\\"))
                                            destinationFilePath = destinationFilePath.Trim().Split(new string[] { " \\\\" }, StringSplitOptions.None)[1];
                                        destinationFilePath = string.Concat(destinationFilePath.TakeWhile((c) => c != '&'));
                                    }
                                    else if (command.Contains("move"))
                                    {
                                        if (command.Contains("move "))
                                            destinationFilePath = path.Trim().Split(new string[] { "move " }, StringSplitOptions.None)[1];
                                        else
                                            destinationFilePath = path.Trim().Split(new string[] { "move" }, StringSplitOptions.None)[1];

                                        if (destinationFilePath.Contains(" \\\\"))
                                            destinationFilePath = destinationFilePath.Trim().Split(new string[] { " \\\\" }, StringSplitOptions.None)[1];
                                        destinationFilePath = string.Concat(destinationFilePath.TakeWhile((c) => c != '&'));
                                    }
                                }

                                path = path.Trim().Split(new string[] { " \\\\" }, StringSplitOptions.None)[0];
                            }

                            result = string.Concat(path.TakeWhile((c) => c != '/'));
                            sourceFilePath = result.Split('/')[0];

                            result = Path.GetFileName(sourceFilePath);
                        }
                        else
                        {
                            if (command.Contains("rename"))
                            {
                                path = path.Trim().Split(new string[] { " \"" }, StringSplitOptions.None)[0];
                                path = path.Replace("\"", string.Empty).TrimEnd(new char[] { '\\' });
                            }


                            if ((command.Trim().StartsWith("copy") || command.Trim().StartsWith("move")) && path.Contains(" \\\\"))
                                destinationFilePath = path.Trim().Split(new string[] { " \\\\" }, StringSplitOptions.None)[1];

                            sourceFilePath = path.Trim().Split(new string[] { " \\\\" }, StringSplitOptions.None)[0];
                            if (sourceFilePath.Contains("-o"))
                                sourceFilePath = sourceFilePath.Split(new string[] { "-o" }, StringSplitOptions.None).First();

                            result = Path.GetFileName(sourceFilePath.Replace("/", string.Empty));
                            if (result.Contains(")"))
                                result = result.Split(new string[] { ")" }, StringSplitOptions.None).First();
                        }

                        if (result.Contains(' '))
                        {
                            string firstFileName = result.Split(' ')[0].Trim();
                            string secondFileName = result.Split(' ')[1].Trim();
                            if (!string.IsNullOrEmpty(secondFileName) && (secondFileName.Contains(firstFileName) || firstFileName.Contains(secondFileName)))
                                result = secondFileName;

                        }
                    }

                    if (result.Contains(' '))
                        result = result.Split(new string[] { " " }, StringSplitOptions.None).First();
                    fileName = result;
                }
                else
                {
                    if (command.Contains("folderpath"))
                    {
                        sourceFilePath = command.Split(new string[] { "folderpath=" }, StringSplitOptions.None).Last();
                        sourceFilePath = string.Concat(sourceFilePath.TakeWhile((c) => c != '$'));

                        fileName = command.Split(new string[] { "filename=" }, StringSplitOptions.None).Last();
                        fileName = string.Concat(fileName.TakeWhile((c) => c != '"'));
                    }
                }

                if (sourceFilePath.Contains(".exe "))
                {
                    sourceFilePath = string.Empty;
                }
                if (destinationFilePath.Contains(".exe "))
                {
                    destinationFilePath = string.Empty;
                }
            }
            catch (Exception ex)
            {
               // SEMLogger.LogError(ex.Message + "\nat function : " + System.Reflection.MethodBase.GetCurrentMethod().Name);
                Console.WriteLine(ex.Message);
            }

            return fileName;
        }

        private static string GetJobType(string wrapperName)
        {
            string jobType = string.Empty;
            if (wrapperName.ToLower().Contains("bdc"))
            {
                jobType = StringConstants.BDC_JOBTYPE;
            }
            else if (wrapperName.ToLower().Contains("rdc"))
            {
                jobType = StringConstants.RDC_JOBTYPE;
            }
            else if (wrapperName.ToLower().Contains("eod"))
            {
                jobType = StringConstants.EOD_JOBTYPE;
            }
            else if (wrapperName.ToLower().Contains("remit"))
            {
                jobType = StringConstants.REMIT_JOBTYPE;
            }
            else if (wrapperName.ToLower().Contains("ajb") && wrapperName.ToLower().Contains("settlement"))
            {
                jobType = StringConstants.AJBSETTLEMENT_JOBTYPE;
            }
            else if (wrapperName.ToLower().Contains("settlement"))
            {
                jobType = StringConstants.SETTLEMENT_JOBTYPE;
            }

            return jobType;
        }
        private static string GetWrapperName(string command)
        {
            string wrapperName = string.Empty;
            command = command.ToLower();
            //command = command.Replace("command:", string.Empty).Trim();
            try
            {

                if (command.Contains(".exe\""))
                {
                    command = command.Replace(".exe", ".exe#");
                    wrapperName = string.Concat(command.TakeWhile((c) => c != '#'));
                    if (wrapperName.ToUpper().Contains(@"C\"))
                    {
                        wrapperName = wrapperName.Substring(wrapperName.ToUpper().IndexOf(@"C\"));
                        wrapperName = Path.GetFileName(wrapperName);
                    }
                    else
                    {
                        try
                        {
                            wrapperName = Path.GetFileName(wrapperName);
                        }
                        catch (Exception)
                        {
                            if (wrapperName.Contains(@"\"))
                                wrapperName = wrapperName.Split(new string[] { @"\" }, StringSplitOptions.None).Last();
                        }
                    }

                }
                else if (command.Contains(".exe "))
                {
                    command = command.Replace(".exe ", ".exe#");
                    wrapperName = string.Concat(command.TakeWhile((c) => c != '#'));
                    if (wrapperName.ToUpper().Contains(@"C\"))
                    {
                        wrapperName = wrapperName.Substring(wrapperName.ToUpper().IndexOf(@"C\"));
                        wrapperName = Path.GetFileName(wrapperName);
                    }
                    else
                    {
                        try
                        {
                            wrapperName = Path.GetFileName(wrapperName);
                            if (wrapperName.Contains(' '))
                            {
                                string wrapper = wrapperName.Split(new string[] { " " }, StringSplitOptions.None).Last();
                                if (!wrapper.Contains(".exe"))
                                    wrapperName = wrapperName.Split(new string[] { " " }, StringSplitOptions.None).First();
                                else
                                    wrapperName = wrapper.Replace("(", string.Empty).Trim();
                            }
                        }
                        catch (Exception)
                        {
                            if (wrapperName.Contains(@"\"))
                                wrapperName = wrapperName.Split(new string[] { @"\" }, StringSplitOptions.None).Last();
                        }
                    }

                    // wrapperName = wrapperName.Substring(wrapperName.ToLower().IndexOf("command:") + 1);
                }
                else if (command.Contains(".exe"))
                {
                    try
                    {
                        wrapperName = Path.GetFileName(command);
                    }
                    catch (Exception)
                    { }
                }

                if (wrapperName.Contains(@"\"))
                    wrapperName = wrapperName.Split(new string[] { @"\" }, StringSplitOptions.None).Last();

                if (wrapperName.ToUpper().Contains("FOR "))
                {
                    wrapperName = wrapperName.Split(new string[] { "DO (" }, StringSplitOptions.None).Last();
                }

                if (wrapperName.ToLower().Contains("powershell"))
                {
                    wrapperName = command.Split(new string[] { "-file " }, StringSplitOptions.None).Last().Replace(".ps1", ".ps1#");
                    wrapperName = string.Concat(wrapperName.TakeWhile((c) => c != '#')).Replace("\"", string.Empty);
                    try
                    {
                        wrapperName = Path.GetFileName(wrapperName);
                    }
                    catch (Exception)
                    {
                    }

                    wrapperName = "PowerShell.exe " + wrapperName;
                }


                if (string.IsNullOrEmpty(wrapperName))
                {
                    command = command.Replace("\"", string.Empty);

                    if (command.Contains("do ( copy") || command.Contains("do (copy") || command.Contains("(copy") || command.Contains("( copy") || command.Trim().StartsWith("copy"))
                        wrapperName = "Copy";
                    else if (command.Contains("sleep.bat"))
                        wrapperName = "Sleep.bat";
                    else if (command.Contains("do ( move") || command.Contains("do (move") || command.Trim().StartsWith("move"))
                        wrapperName = "Move";
                    else if (command.Trim().StartsWith("del") || command.Trim().StartsWith("del ") || command.Contains("del ") || command.Contains("delete") || command.Contains("do ( del") || command.Contains("do (del"))
                    {
                        wrapperName = "Delete";
                        if (command.Contains(".bat"))
                        {
                            try
                            {
                                wrapperName = Path.GetFileName(command.Trim().Replace("\"", string.Empty));
                            }
                            catch (Exception)
                            {
                            }
                        }
                    }
                    else if (command.Contains("echo"))
                        wrapperName = "Echo";
                    else if (command.Contains("autorep"))
                        wrapperName = "Autorep";
                    else if (command.Contains("sendevent"))
                        wrapperName = "SendEvent";
                    else if (command.Contains("forecast"))
                        wrapperName = "Forecast";
                    else if (command.Contains("mkdir"))
                        wrapperName = "MkDir";
                    else if (command.Contains("rename ") || command.Contains("ren "))
                        wrapperName = "Rename";
                    else if (command.Trim().StartsWith("dir") || command.Trim().StartsWith("\"dir"))
                        wrapperName = "Dir";
                    else if (command.Contains("md ") && !command.Contains("cmd"))
                        wrapperName = "Md";
                    else if (command.Contains("rd "))
                        wrapperName = "Rd";
                    else if (command.Contains("job_depends"))
                        wrapperName = "Job_Depends";
                    else if (command.Contains("autocal_asc"))
                        wrapperName = "Autocal_Asc";
                    else if (command.Contains("autosys_generic"))
                        wrapperName = "Autosys_Generic";
                    else if (command.Contains(@"7-zip\7z"))
                        wrapperName = "7-zip";
                    else
                    {
                        if (command.Contains(".bat"))
                        {
                            wrapperName = command.Trim().Split(new string[] { ".bat" }, StringSplitOptions.None).First().Trim().Replace("\"", string.Empty);
                            try
                            {
                                wrapperName = Path.GetFileName(wrapperName);
                                if (!wrapperName.Contains(".bat"))
                                    wrapperName = wrapperName + ".bat";
                            }
                            catch (Exception)
                            { }
                        }
                    }

                }
            }
            catch (Exception ex)
            {
                //SEMLogger.LogError(ex.Message + "\nat function : " + System.Reflection.MethodBase.GetCurrentMethod().Name);
                Console.WriteLine(ex.Message);
            }

            return wrapperName.Replace("\"", string.Empty).Trim();
        }
        private Dictionary<string, string> GetStatusAndOtherInfoFromExtractFile(string fileName, ref Dictionary<string, string> dictionaryOfJobsWithLastRunDates, ref Dictionary<string, string> dictionaryOfJobsWithLastRunTimings, ref Dictionary<string, string> dictionaryOfJobsWithStartRunDates, ref Dictionary<string, string> dictionaryOfJobsWithStartRunTimings)
        {
            Dictionary<string, string> dictionaryOfJobsAndItsStatus = new Dictionary<string, string>();
            try
            {
                var lines = System.IO.File.ReadAllLines(@fileName).Select(x => x.Split(','));

                int count = lines.Count();
                var csvData = lines.Skip(3)
                           .SelectMany(x => x)
                           .Select((v, i) => new { Value = v, Index = i % count })
                           .Select(x => x.Value);
                foreach (var data in csvData)
                {
                    List<string> listOfItems = data.Split(' ').ToList<string>();
                    listOfItems.RemoveAll(x => x.Equals(string.Empty));
                    foreach (var item in listOfItems)
                    {
                        try
                        {
                            if (item.Length == 8 && item.Count(x => x == ':') > 1)
                            {
                                if (!dictionaryOfJobsWithStartRunTimings.ContainsKey(listOfItems[0].Trim()))
                                    dictionaryOfJobsWithStartRunTimings.Add(listOfItems[0].Trim(), item.Trim());
                                //break;
                            }
                            if (item.Length == 10 && item.Count(x => x == '/') > 1)
                            {
                                if (!dictionaryOfJobsWithStartRunDates.ContainsKey(listOfItems[0].Trim()))
                                    dictionaryOfJobsWithStartRunDates.Add(listOfItems[0].Trim(), item.Trim());
                            }

                            if (item.Length == 2)
                            {
                                dictionaryOfJobsAndItsStatus.Add(listOfItems[0].Trim(), item.Trim());
                                break;
                            }
                        }
                        catch (Exception ex)
                        {
                            //SEMLogger.LogError(ex.Message + "\nat function : " + System.Reflection.MethodBase.GetCurrentMethod().Name);
                            Console.WriteLine(ex.Message);
                        }
                    }
                    listOfItems.Reverse();
                    foreach (var item in listOfItems)
                    {
                        try
                        {
                            if (item.Length == 8 && item.Count(x => x == ':') > 1)
                            {
                                dictionaryOfJobsWithLastRunTimings.Add(listOfItems[listOfItems.Count - 1].Trim(), item.Trim());
                                //break;
                            }
                            if (item.Length == 10 && item.Count(x => x == '/') > 1)
                            {
                                dictionaryOfJobsWithLastRunDates.Add(listOfItems[listOfItems.Count - 1].Trim(), item.Trim());
                                break;
                            }
                        }
                        catch (Exception ex)
                        {
                            //SEMLogger.LogError(ex.Message + "\nat function : " + System.Reflection.MethodBase.GetCurrentMethod().Name);
                            Console.WriteLine(ex.Message);
                        }
                    }

                }
            }
            catch (Exception ex)
            {
                //SEMLogger.LogError(ex.Message + "\nat function : " + System.Reflection.MethodBase.GetCurrentMethod().Name);
            }

            return dictionaryOfJobsAndItsStatus;
        }

        private List<string> GetBillerNamesListAndListOfAllJobs(string inputFileName, ref List<FilteredJobs> listOfJobs)
        {
            string billerName = string.Empty;
            List<string> listOfBillerNames = new List<string>();
            List<string> listOfNewParameters = new List<string>();
            foreach (FilteredJobs item in listOfJobs = GetListOfJobs(inputFileName, ref listOfNewParameters))
            {
                string insertJobName = item.Insert_job;
                List<string> listOfItemsInJob = insertJobName.Trim().Split('-').ToList<string>();
                try
                {
                    if (insertJobName.StartsWith(StringConstants.BSL_JOBS_SUBSTRING) && listOfItemsInJob.Count >= 6)
                    {
                        billerName = item.Insert_job.Split(StringConstants.SPLIT_WITH_HYPHEN)[5].Trim();
                        listOfBillerNames.Add(billerName);
                    }
                    else if (insertJobName.StartsWith(StringConstants.BIS_JOBS_SUBSTRING) && listOfItemsInJob.Count >= 6)
                    {
                        billerName = item.Insert_job.Split(StringConstants.SPLIT_WITH_HYPHEN)[6].Trim();
                        listOfBillerNames.Add(billerName);
                    }
                    else
                    {
                        billerName = string.Concat(insertJobName.TakeWhile(c => c != ' '));
                        listOfBillerNames.Add(billerName.Trim());
                    }
                }
                catch (Exception ex)
                {
                    //SEM.Logging.SEMLogger.LogError(ex.Message + " for job name : {0}", item.Insert_job);
                    if (ex.Message.ToLower().Contains(StringConstants.INDEX))
                    {
                        billerName = string.Concat(insertJobName.TakeWhile(c => c != ' '));
                        listOfBillerNames.Add(billerName.Trim());
                        continue;
                    }
                }
            }

            return listOfBillerNames;
        }

        private List<FilteredJobs> GetListOfJobs(string inputFileName, ref List<string> listOfNewParameters)
        {
            FilteredJobs job = new FilteredJobs();

            List<FilteredJobs> listOfJobs = new List<FilteredJobs>();
            int linesCount = System.IO.File.ReadLines(inputFileName).Count();
            string[] lines = new string[linesCount];
            lines = System.IO.File.ReadLines(inputFileName).ToArray<string>();
            for (int i = 0; i < lines.Length; i++)
            {
                if (lines[i].Trim().StartsWith(StringConstants.HEADER))
                {
                    if (job.Header != (null))
                    {
                        listOfJobs.Add(job);
                        job = new FilteredJobs();
                    }

                    job.Header = lines[i];
                }

                switch (lines[i].Split(StringConstants.SPLIT_WITH_COLON)[0].Trim())
                {
                    case StringConstants.INSERT_JOB:

                        job.Insert_job = lines[i].Split(':')[1].Trim();
                        job.Insert_job = job.Insert_job.Split(new string[] { "job_type" }, StringSplitOptions.None).First().Trim();

                        break;
                    case StringConstants.MACHINE:
                        job.Machine = lines[i].Split(':')[1].Trim();
                        break;
                    case StringConstants.BOX_NAME:
                        job.Boxname = lines[i].Split(':')[1].Trim();
                        break;
                    case StringConstants.CONDITION:
                        job.Condition = lines[i].Split(':')[1].Trim();
                        break;
                    case StringConstants.COMMAND:
                        job.Command = lines[i].Split(new string[] { "command:" }, StringSplitOptions.None).Last();
                        break;
                    case StringConstants.OWNER:
                        job.Owner = lines[i].Split(':')[1].Trim();
                        break;
                    case StringConstants.PERMISSION:
                        job.Permission = lines[i].Split(':')[1].Trim();
                        break;
                    case StringConstants.DATE_CONDITIONS:
                        job.DateCondition = lines[i].Split(':')[1].Trim();
                        break;
                    case StringConstants.DESCRIPTION:
                        job.Description = lines[i].Split(':')[1].Trim();
                        break;
                    case StringConstants.STD_OUT_FILE:
                        job.StdOutFile = lines[i].Split(':')[1].Trim();
                        break;
                    case StringConstants.STD_ERR_FILE:
                        job.StdErrFile = lines[i].Split(':')[1].Trim();
                        break;
                    case StringConstants.MAX_RUN_ALARM:
                        job.MaxRunAlarm = lines[i].Split(':')[1].Trim();
                        break;
                    case StringConstants.ALARF_IF_FAIL:
                        job.AlarmIfFail = lines[i].Split(':')[1].Trim();
                        break;
                    case StringConstants.PROFILE:
                        job.Profile = lines[i].Split(':')[1].Trim();
                        break;
                    case StringConstants.JOB_LOAD:
                        job.JobLoad = lines[i].Split(':')[1].Trim();
                        break;
                    case StringConstants.PRIORITY:
                        job.Priority = lines[i].Split(':')[1].Trim();
                        break;
                    case StringConstants.GROUP:
                        job.Group = lines[i].Split(':')[1].Trim();
                        break;
                    case StringConstants.BOX_SUCCESS:
                        job.Box_Success = lines[i].Split(':')[1].Trim();
                        break;
                    case StringConstants.BOX_FAILURE:
                        job.Box_Failure = lines[i].Split(':')[1].Trim();
                        break;
                    case StringConstants.APPLICATION:
                        job.Application = lines[i].Split(':')[1].Trim();
                        break;
                    case StringConstants.MUST_START_TIMES:
                        job.Must_Start_Times = lines[i].Split(new string[] { "must_start_times:" }, StringSplitOptions.None).Last().Trim();
                        break;
                    case StringConstants.DAYS_OF_WEEK:
                        job.Run_Day = lines[i].Split(':')[1].Trim();
                        break;
                    case StringConstants.START_TIMES:
                        job.Start_Times = lines[i].Split(new string[] { "start_times:" }, StringSplitOptions.None).Last().Trim();
                        break;
                    case StringConstants.RUN_CALENDAR:
                        job.Run_Calendar = lines[i].Split(':')[1].Trim();
                        break;
                    case StringConstants.N_RETRYS:
                        job.N_Retrys = lines[i].Split(':')[1].Trim();
                        break;
                    case StringConstants.TIMEZONE:
                        job.TimeZone = lines[i].Split(':')[1].Trim();
                        break;

                    case StringConstants.MAX_EXIT_SUCCESS:
                        job.Max_Exit_Success = lines[i].Split(':')[1].Trim();
                        break;
                    case StringConstants.SUCCESS_CODES:
                        job.Success_Codes = lines[i].Split(':')[1].Trim();
                        break;
                    case StringConstants.FAIL_CODES:
                        job.Fail_Codes = lines[i].Split(':')[1].Trim();
                        break;
                    case StringConstants.MUST_COMPLETE_TIMES:
                        job.Must_Complete_Times = lines[i].Split(':')[1].Trim();
                        break;
                    case StringConstants.FTP_TRANSFER_TYPE:
                        job.Ftp_Transfer_Type = lines[i].Split(':')[1].Trim();
                        break;

                    case StringConstants.FTP_TRANSFER_DIRECTION:
                        job.Ftp_Transfer_Direction = lines[i].Split(':')[1].Trim();
                        break;
                    case StringConstants.FTP_LOCAL_NAME:
                        job.Ftp_Local_Name = lines[i].Split(':')[1].Trim();
                        break;
                    case StringConstants.FTP_REMOTE_NAME:
                        job.Ftp_Remote_Name = lines[i].Split(':')[1].Trim();
                        break;
                    case StringConstants.FTP_SERVER_NAME:
                        job.Ftp_Server_Name = lines[i].Split(':')[1].Trim();
                        break;
                    case StringConstants.FTP_SERVER_PORT:
                        job.Ftp_Server_port = lines[i].Split(':')[1].Trim();
                        break;
                    case StringConstants.FTP_USE_SSL:
                        job.Ftp_Use_Ssl = lines[i].Split(':')[1].Trim();
                        break;
                    case StringConstants.FTP_LOCAL_USER:
                        job.Ftp_Local_User = lines[i].Split(':')[1].Trim();
                        break;
                    case StringConstants.START_MINS:
                        job.Start_Mins = lines[i].Split(':')[1].Trim();
                        break;
                    case StringConstants.WATCH_FILE:
                        job.Watch_File = lines[i].Split(':')[1].Trim();
                        break;
                    case StringConstants.WATCH_FILE_RECURRSIVE:
                        job.Watch_File_Recurrsive = lines[i].Split(':')[1].Trim();
                        break;
                    case StringConstants.WATCH_FILE_TYPE:
                        job.Watch_File_Type = lines[i].Split(':')[1].Trim();
                        break;
                    case StringConstants.WATCH_FILE_WIN_USER:
                        job.Watch_File_Win_User = lines[i].Split(':')[1].Trim();
                        break;
                    case StringConstants.CONTINOUS:
                        job.Continous = lines[i].Split(':')[1].Trim();
                        break;
                    case StringConstants.WATCH_INTERVAL:
                        job.Watch_Interval = lines[i].Split(':')[1].Trim();
                        break;
                    case StringConstants.WIN_EVENT_OP:
                        job.Win_Event_Op = lines[i].Split(':')[1].Trim();
                        break;
                    case StringConstants.MONITOR_MODE:
                        job.Monitor_Mode = lines[i].Split(':')[1].Trim();
                        break;
                    case StringConstants.TERM_RUN_TIME:
                        job.Term_Run_Time = lines[i].Split(':')[1].Trim();
                        break;
                    case StringConstants.SEND_NOTIFICATION:
                        job.Send_Notification = lines[i].Split(':')[1].Trim();
                        break;
                    case StringConstants.NOTIFICATION_ID:
                        job.Notification_Id = lines[i].Split(':')[1].Trim();
                        break;
                    case StringConstants.NOTIFICATION_MSG:
                        job.Notification_Msg = lines[i].Split(':')[1].Trim();
                        break;
                    case StringConstants.EXCLUDE_CALENDAR:
                        job.Exclude_Calendar = lines[i].Split(':')[1].Trim();
                        break;
                    case StringConstants.STD_IN_FILE:
                        job.Std_In_File = lines[i].Split(':')[1].Trim();
                        break;

                    case StringConstants.JOB_TERMINATOR:
                        job.Job_terminator = lines[i].Split(':')[1].Trim();
                        break;
                    case StringConstants.WIN_LOG_NAME:
                        job.Win_log_name = lines[i].Split(':')[1].Trim();
                        break;
                    case StringConstants.WIN_EVENT_TYPE:
                        job.Win_event_type = lines[i].Split(':')[1].Trim();
                        break;
                    case StringConstants.WIN_EVENT_ID:
                        job.Win_event_id = lines[i].Split(':')[1].Trim();
                        break;
                    case StringConstants.MIN_RUN_ALARM:
                        job.Min_run_alarm = lines[i].Split(':')[1].Trim();
                        break;

                    default:
                        if (!string.IsNullOrEmpty(lines[i]) && lines[i].Contains(":"))
                        {
                            listOfNewParameters.Add(lines[i].Split(':').First().Trim());
                        }
                        continue;
                }
            }

            if (job != null)
                listOfJobs.Add(job);
            Console.WriteLine(StringConstants.TOTAL_JOBS_COUNT + listOfJobs.Count);
            List<FilteredJobs> listOfJobsCopy = new List<FilteredJobs>();
            listOfJobsCopy.AddRange(listOfJobs);

            foreach (var item in listOfJobsCopy)
            {
                try
                {
                    if (item.Insert_job.Contains(StringConstants.BSL_JOBS_SUBSTRING))
                    {
                        string billerName = item.Insert_job.Split('-')[5].Trim();
                    }
                    else if (item.Insert_job.Contains(StringConstants.BIS_JOBS_SUBSTRING))
                    {
                        string billerName = item.Insert_job.Split('-')[6].Trim();
                    }
                }
                catch (Exception ex)
                {
                    //if (ex.Message.ToLower().Contains(StringConstants.INDEX))
                    //{
                    //    listOfJobs.Remove(item);
                    //}
                   // SEM.Logging.SEMLogger.LogError(ex.Message + "\nat function : " + System.Reflection.MethodBase.GetCurrentMethod().Name);
                    continue;
                }
            }

            return listOfJobs;
        }
    }

    public class ExcelCreator
    {
        /// <summary>       
        /// Create one Excel-XML-Document with SpreadsheetML from a DataTable
        /// </summary>        
        /// <param name="dataSource">Datasource which would be exported in Excel</param>
        /// <param name="fileName">Name of exported file</param>
        public static void Create(DataTable dtSource, string strFileName)
        {
            try
            {
                // Create XMLWriter
                using (XmlTextWriter xtwWriter = new XmlTextWriter(strFileName, Encoding.UTF8))
                {

                    //Format the output file for reading easier
                    xtwWriter.Formatting = Formatting.Indented;

                    // <?xml version="1.0"?>
                    xtwWriter.WriteStartDocument();

                    // <?mso-application progid="Excel.Sheet"?>
                    xtwWriter.WriteProcessingInstruction("mso-application", "progid=\"Excel.Sheet\"");

                    // <Workbook xmlns="urn:schemas-microsoft-com:office:spreadsheet >"
                    xtwWriter.WriteStartElement("Workbook", "urn:schemas-microsoft-com:office:spreadsheet");

                    //Write definition of namespace
                    xtwWriter.WriteAttributeString("xmlns", "o", null, "urn:schemas-microsoft-com:office:office");
                    xtwWriter.WriteAttributeString("xmlns", "x", null, "urn:schemas-microsoft-com:office:excel");
                    xtwWriter.WriteAttributeString("xmlns", "ss", null, "urn:schemas-microsoft-com:office:spreadsheet");
                    xtwWriter.WriteAttributeString("xmlns", "html", null, "http://www.w3.org/TR/REC-html40");

                    // <DocumentProperties xmlns="urn:schemas-microsoft-com:office:office">
                    xtwWriter.WriteStartElement("DocumentProperties", "urn:schemas-microsoft-com:office:office");

                    // Write document properties
                    xtwWriter.WriteElementString("Author", Environment.UserName);
                    xtwWriter.WriteElementString("LastAuthor", Environment.UserName);
                    xtwWriter.WriteElementString("Created", DateTime.Now.ToString("u") + "Z");
                    xtwWriter.WriteElementString("Company", "Unknown");
                    xtwWriter.WriteElementString("Version", "1.000");

                    // </DocumentProperties>
                    xtwWriter.WriteEndElement();

                    // <ExcelWorkbook xmlns="urn:schemas-microsoft-com:office:excel">
                    xtwWriter.WriteStartElement("ExcelWorkbook", "urn:schemas-microsoft-com:office:excel");

                    // Write settings of workbook
                    xtwWriter.WriteElementString("WindowHeight", "13170");
                    xtwWriter.WriteElementString("WindowWidth", "17580");
                    xtwWriter.WriteElementString("WindowTopX", "120");
                    xtwWriter.WriteElementString("WindowTopY", "60");
                    xtwWriter.WriteElementString("ProtectStructure", "False");
                    xtwWriter.WriteElementString("ProtectWindows", "False");

                    // </ExcelWorkbook>
                    xtwWriter.WriteEndElement();

                    // <Styles>
                    xtwWriter.WriteStartElement("Styles");

                    // <Style ss:ID="Default" ss:Name="Normal">
                    xtwWriter.WriteStartElement("Style");
                    xtwWriter.WriteAttributeString("ss", "ID", null, "Default");
                    xtwWriter.WriteAttributeString("ss", "Name", null, "Normal");

                    // <Alignment ss:Vertical="Bottom"/>
                    xtwWriter.WriteStartElement("Alignment");
                    xtwWriter.WriteAttributeString("ss", "Vertical", null, "Bottom");
                    xtwWriter.WriteEndElement();

                    // Write null on the other properties
                    xtwWriter.WriteElementString("Borders", null);
                    xtwWriter.WriteElementString("Font", null);
                    xtwWriter.WriteElementString("Interior", null);
                    xtwWriter.WriteElementString("NumberFormat", null);
                    xtwWriter.WriteElementString("Protection", null);

                    // </Style>
                    xtwWriter.WriteEndElement();

                    // </Styles>
                    xtwWriter.WriteEndElement();

                    // <Worksheet ss:Name="xxx">
                    xtwWriter.WriteStartElement("Worksheet");
                    xtwWriter.WriteAttributeString("ss", "Name", null, dtSource.TableName);

                    // <Table ss:ExpandedColumnCount="2" ss:ExpandedRowCount="3" x:FullColumns="1" x:FullRows="1" ss:DefaultColumnWidth="60">
                    xtwWriter.WriteStartElement("Table");
                    xtwWriter.WriteAttributeString("ss", "ExpandedColumnCount", null, dtSource.Columns.Count.ToString());
                    xtwWriter.WriteAttributeString("ss", "ExpandedRowCount", null, (dtSource.Rows.Count + 1).ToString());
                    xtwWriter.WriteAttributeString("x", "FullColumns", null, "1");
                    xtwWriter.WriteAttributeString("x", "FullRows", null, "1");
                    xtwWriter.WriteAttributeString("ss", "DefaultColumnWidth", null, "60");

                    xtwWriter.WriteStartElement("Row");
                    foreach (DataColumn item in dtSource.Columns)
                    {

                        xtwWriter.WriteStartElement("Cell");
                        xtwWriter.WriteStartElement("Data");
                        xtwWriter.WriteAttributeString("ss", "Type", null, "String");
                        xtwWriter.WriteValue(item.ColumnName);
                        // </Data>
                        xtwWriter.WriteEndElement();

                        // </Cell>
                        xtwWriter.WriteEndElement();

                    }

                    xtwWriter.WriteEndElement();
                    foreach (DataRow row in dtSource.Rows)
                    {                        
                            // Run through all rows of data source

                            // <Row>
                            xtwWriter.WriteStartElement("Row");

                            // Run through all cell of current rows
                            foreach (object cellValue in row.ItemArray)
                            {
                                try
                                {
                                    // <Cell>
                                    xtwWriter.WriteStartElement("Cell");

                                    // <Data ss:Type="String">xxx</Data>
                                    xtwWriter.WriteStartElement("Data");
                                    xtwWriter.WriteAttributeString("ss", "Type", null, "String");

                                    // Write content of cell
                                    xtwWriter.WriteValue(cellValue);

                                    // </Data>
                                    xtwWriter.WriteEndElement();

                                    // </Cell>
                                    xtwWriter.WriteEndElement();
                                }
                                catch(Exception ex)
                                {
                                    Console.WriteLine(ex.Message);
                                }

                            }
                            // </Row>
                            xtwWriter.WriteEndElement();
                       
                    }

                        // </Table>
                        xtwWriter.WriteEndElement();
                   

                    // <WorksheetOptions xmlns="urn:schemas-microsoft-com:office:excel">
                    xtwWriter.WriteStartElement("WorksheetOptions", "urn:schemas-microsoft-com:office:excel");

                    // Write settings of page
                    xtwWriter.WriteStartElement("PageSetup");
                    xtwWriter.WriteStartElement("Header");
                    xtwWriter.WriteAttributeString("x", "Margin", null, "0.4921259845");
                    xtwWriter.WriteEndElement();
                    xtwWriter.WriteStartElement("Footer");
                    xtwWriter.WriteAttributeString("x", "Margin", null, "0.4921259845");
                    xtwWriter.WriteEndElement();
                    xtwWriter.WriteStartElement("PageMargins");
                    xtwWriter.WriteAttributeString("x", "Bottom", null, "0.984251969");
                    xtwWriter.WriteAttributeString("x", "Left", null, "0.78740157499999996");
                    xtwWriter.WriteAttributeString("x", "Right", null, "0.78740157499999996");
                    xtwWriter.WriteAttributeString("x", "Top", null, "0.984251969");
                    xtwWriter.WriteEndElement();
                    xtwWriter.WriteEndElement();

                    // <Selected/>
                    xtwWriter.WriteElementString("Selected", null);

                    // <Panes>
                    xtwWriter.WriteStartElement("Panes");

                    // <Pane>
                    xtwWriter.WriteStartElement("Pane");

                    // Write settings of active field
                    xtwWriter.WriteElementString("Number", "1");
                    xtwWriter.WriteElementString("ActiveRow", "1");
                    xtwWriter.WriteElementString("ActiveCol", "1");

                    // </Pane>
                    xtwWriter.WriteEndElement();

                    // </Panes>
                    xtwWriter.WriteEndElement();

                    // <ProtectObjects>False</ProtectObjects>
                    xtwWriter.WriteElementString("ProtectObjects", "False");

                    // <ProtectScenarios>False</ProtectScenarios>
                    xtwWriter.WriteElementString("ProtectScenarios", "False");

                    // </WorksheetOptions>
                    xtwWriter.WriteEndElement();

                    // </Worksheet>
                    xtwWriter.WriteEndElement();

                    // </Workbook>
                    xtwWriter.WriteEndElement();

                    // Write file on hard disk
                    xtwWriter.Flush();
                    xtwWriter.Close();
                    xtwWriter.Dispose();
                }
            }
            catch (Exception ex)
            {
                Console.WriteLine(ex.Message);
            }
        }
    }
}
