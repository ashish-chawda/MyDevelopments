﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.IO;



namespace Autosys_JILFileDetailsExtractUtility
{
    public class JilOperations
    {
        public List<string> GetBillerNamesListAndListOfAllJobs(string inputFileName, ref List<FilteredJobs> listOfJobs)
        {
            string billerName = string.Empty;
            List<string> listOfBillerNames = new List<string>();
            List<string> listOfNewParameters = new List<string>();
            foreach (FilteredJobs item in listOfJobs = GetListOfJobs(inputFileName, ref listOfNewParameters))
            {
                string insertJobName = item.Insert_job;
                List<string> listOfItemsInJob = insertJobName.Trim().Split('-').ToList<string>();
                try
                {
                    if (insertJobName.StartsWith(StringConstants.BSL_JOBS_SUBSTRING) && listOfItemsInJob.Count >= 6)
                    {
                        billerName = item.Insert_job.Split(StringConstants.SPLIT_WITH_HYPHEN)[5].Trim();
                        listOfBillerNames.Add(billerName);
                    }
                    else if (insertJobName.StartsWith(StringConstants.BIS_JOBS_SUBSTRING) && listOfItemsInJob.Count >= 6)
                    {
                        billerName = item.Insert_job.Split(StringConstants.SPLIT_WITH_HYPHEN)[6].Trim();
                        listOfBillerNames.Add(billerName);
                    }
                    else
                    {
                        billerName = string.Concat(insertJobName.TakeWhile(c => c != ' '));
                        listOfBillerNames.Add(billerName.Trim());
                    }
                }
                catch (Exception ex)
                {
                    SEM.Logging.SEMLogger.LogError(ex.Message + " for job name : {0}", item.Insert_job);
                    if (ex.Message.ToLower().Contains(StringConstants.INDEX))
                    {
                        billerName = string.Concat(insertJobName.TakeWhile(c => c != ' '));
                        listOfBillerNames.Add(billerName.Trim());
                        continue;
                    }
                }
            }

            return listOfBillerNames;
        }

        public List<string> GetListOfJobsWithBillerNames(string inputFileName, ref List<FilteredJobs> listOfJobs)
        {
            string billerName = string.Empty;
            List<string> listOfBillerNames = new List<string>();
            foreach (FilteredJobs item in listOfJobs = GetListOfJobs12(inputFileName))
            {
                string insertJobName = item.Insert_job.Split(new string[] { "job_type" }, StringSplitOptions.None).First().Trim().Split(':')[1].Trim();
                List<string> listOfItemsInJob = insertJobName.Trim().Split('-').ToList<string>();
                try
                {
                    if (insertJobName.StartsWith(StringConstants.BSL_JOBS_SUBSTRING) && listOfItemsInJob.Count >= 6)
                    {
                        billerName = item.Insert_job.Split(StringConstants.SPLIT_WITH_HYPHEN)[5].Trim();
                        listOfBillerNames.Add(billerName);
                    }
                    else if (insertJobName.StartsWith(StringConstants.BIS_JOBS_SUBSTRING) && listOfItemsInJob.Count >= 6)
                    {
                        billerName = item.Insert_job.Split(StringConstants.SPLIT_WITH_HYPHEN)[6].Trim();
                        listOfBillerNames.Add(billerName);
                    }
                    else
                    {
                        billerName = string.Concat(insertJobName.TakeWhile(c => c != ' '));
                        listOfBillerNames.Add(billerName.Trim());
                    }
                }
                catch (Exception ex)
                {
                    SEM.Logging.SEMLogger.LogError(ex.Message + " for job name : {0}", item.Insert_job);
                    if (ex.Message.ToLower().Contains(StringConstants.INDEX))
                    {
                        billerName = string.Concat(insertJobName.TakeWhile(c => c != ' '));
                        listOfBillerNames.Add(billerName.Trim());
                        continue;
                    }
                }
            }

            return listOfBillerNames;
        }
        public List<FilteredJobs> GetListOfJobs(string inputFileName, ref List<string> listOfNewParameters)
        {
            FilteredJobs job = new FilteredJobs();

            List<FilteredJobs> listOfJobs = new List<FilteredJobs>();
            int linesCount = File.ReadLines(inputFileName).Count();
            string[] lines = new string[linesCount];
            lines = File.ReadLines(inputFileName).ToArray<string>();
            for (int i = 0; i < lines.Length; i++)
            {
                if (lines[i].Trim().StartsWith(StringConstants.HEADER))
                {
                    if (job.Header != (null))
                    {
                        listOfJobs.Add(job);
                        job = new FilteredJobs();
                    }

                    job.Header = lines[i];
                }

                switch (lines[i].Split(StringConstants.SPLIT_WITH_COLON)[0].Trim())
                {
                    case StringConstants.INSERT_JOB:

                        job.Insert_job = lines[i].Split(':')[1].Trim();
                        job.Insert_job = job.Insert_job.Split(new string[] { "job_type" }, StringSplitOptions.None).First().Trim();

                        break;
                    case StringConstants.MACHINE:
                        job.Machine = lines[i].Split(':')[1].Trim();
                        break;
                    case StringConstants.BOX_NAME:
                        job.Boxname = lines[i].Split(':')[1].Trim();
                        break;
                    case StringConstants.CONDITION:
                        job.Condition = lines[i].Split(':')[1].Trim();
                        break;
                    case StringConstants.COMMAND:
                        job.Command = lines[i].Split(new string[] { "command:" }, StringSplitOptions.None).Last();
                        break;
                    case StringConstants.OWNER:
                        job.Owner = lines[i].Split(':')[1].Trim();
                        break;
                    case StringConstants.PERMISSION:
                        job.Permission = lines[i].Split(':')[1].Trim();
                        break;
                    case StringConstants.DATE_CONDITIONS:
                        job.DateCondition = lines[i].Split(':')[1].Trim();
                        break;
                    case StringConstants.DESCRIPTION:
                        job.Description = lines[i].Split(':')[1].Trim();
                        break;
                    case StringConstants.STD_OUT_FILE:
                        job.StdOutFile = lines[i].Split(':')[1].Trim();
                        break;
                    case StringConstants.STD_ERR_FILE:
                        job.StdErrFile = lines[i].Split(':')[1].Trim();
                        break;
                    case StringConstants.MAX_RUN_ALARM:
                        job.MaxRunAlarm = lines[i].Split(':')[1].Trim();
                        break;
                    case StringConstants.ALARF_IF_FAIL:
                        job.AlarmIfFail = lines[i].Split(':')[1].Trim();
                        break;
                    case StringConstants.PROFILE:
                        job.Profile = lines[i].Split(':')[1].Trim();
                        break;
                    case StringConstants.JOB_LOAD:
                        job.JobLoad = lines[i].Split(':')[1].Trim();
                        break;
                    case StringConstants.PRIORITY:
                        job.Priority = lines[i].Split(':')[1].Trim();
                        break;
                    case StringConstants.GROUP:
                        job.Group = lines[i].Split(':')[1].Trim();
                        break;
                    case StringConstants.BOX_SUCCESS:
                        job.Box_Success = lines[i].Split(':')[1].Trim();
                        break;
                    case StringConstants.BOX_FAILURE:
                        job.Box_Failure = lines[i].Split(':')[1].Trim();
                        break;
                    case StringConstants.APPLICATION:
                        job.Application = lines[i].Split(':')[1].Trim();
                        break;
                    case StringConstants.MUST_START_TIMES:
                        job.Must_Start_Times = lines[i].Split(new string[] { "must_start_times:" }, StringSplitOptions.None).Last().Trim();
                        break;
                    case StringConstants.DAYS_OF_WEEK:
                        job.Run_Day = lines[i].Split(':')[1].Trim();
                        break;
                    case StringConstants.START_TIMES:
                        job.Start_Times = lines[i].Split(new string[] { "start_times:" }, StringSplitOptions.None).Last().Trim();
                        break;
                    case StringConstants.RUN_CALENDAR:
                        job.Run_Calendar = lines[i].Split(':')[1].Trim();
                        break;
                    case StringConstants.N_RETRYS:
                        job.N_Retrys = lines[i].Split(':')[1].Trim();
                        break;
                    case StringConstants.TIMEZONE:
                        job.TimeZone = lines[i].Split(':')[1].Trim();
                        break;

                    case StringConstants.MAX_EXIT_SUCCESS:
                        job.Max_Exit_Success = lines[i].Split(':')[1].Trim();
                        break;
                    case StringConstants.SUCCESS_CODES:
                        job.Success_Codes = lines[i].Split(':')[1].Trim();
                        break;
                    case StringConstants.FAIL_CODES:
                        job.Fail_Codes = lines[i].Split(':')[1].Trim();
                        break;
                    case StringConstants.MUST_COMPLETE_TIMES:
                        job.Must_Complete_Times = lines[i].Split(':')[1].Trim();
                        break;
                    case StringConstants.FTP_TRANSFER_TYPE:
                        job.Ftp_Transfer_Type = lines[i].Split(':')[1].Trim();
                        break;

                    case StringConstants.FTP_TRANSFER_DIRECTION:
                        job.Ftp_Transfer_Direction = lines[i].Split(':')[1].Trim();
                        break;
                    case StringConstants.FTP_LOCAL_NAME:
                        job.Ftp_Local_Name = lines[i].Split(':')[1].Trim();
                        break;
                    case StringConstants.FTP_REMOTE_NAME:
                        job.Ftp_Remote_Name = lines[i].Split(':')[1].Trim();
                        break;
                    case StringConstants.FTP_SERVER_NAME:
                        job.Ftp_Server_Name = lines[i].Split(':')[1].Trim();
                        break;
                    case StringConstants.FTP_SERVER_PORT:
                        job.Ftp_Server_port = lines[i].Split(':')[1].Trim();
                        break;
                    case StringConstants.FTP_USE_SSL:
                        job.Ftp_Use_Ssl = lines[i].Split(':')[1].Trim();
                        break;
                    case StringConstants.FTP_LOCAL_USER:
                        job.Ftp_Local_User = lines[i].Split(':')[1].Trim();
                        break;
                    case StringConstants.START_MINS:
                        job.Start_Mins = lines[i].Split(':')[1].Trim();
                        break;
                    case StringConstants.WATCH_FILE:
                        job.Watch_File = lines[i].Split(':')[1].Trim();
                        break;
                    case StringConstants.WATCH_FILE_RECURRSIVE:
                        job.Watch_File_Recurrsive = lines[i].Split(':')[1].Trim();
                        break;
                    case StringConstants.WATCH_FILE_TYPE:
                        job.Watch_File_Type = lines[i].Split(':')[1].Trim();
                        break;
                    case StringConstants.WATCH_FILE_WIN_USER:
                        job.Watch_File_Win_User = lines[i].Split(':')[1].Trim();
                        break;
                    case StringConstants.CONTINOUS:
                        job.Continous = lines[i].Split(':')[1].Trim();
                        break;
                    case StringConstants.WATCH_INTERVAL:
                        job.Watch_Interval = lines[i].Split(':')[1].Trim();
                        break;
                    case StringConstants.WIN_EVENT_OP:
                        job.Win_Event_Op = lines[i].Split(':')[1].Trim();
                        break;
                    case StringConstants.MONITOR_MODE:
                        job.Monitor_Mode = lines[i].Split(':')[1].Trim();
                        break;
                    case StringConstants.TERM_RUN_TIME:
                        job.Term_Run_Time = lines[i].Split(':')[1].Trim();
                        break;
                    case StringConstants.SEND_NOTIFICATION:
                        job.Send_Notification = lines[i].Split(':')[1].Trim();
                        break;
                    case StringConstants.NOTIFICATION_ID:
                        job.Notification_Id = lines[i].Split(':')[1].Trim();
                        break;
                    case StringConstants.NOTIFICATION_MSG:
                        job.Notification_Msg = lines[i].Split(':')[1].Trim();
                        break;
                    case StringConstants.EXCLUDE_CALENDAR:
                        job.Exclude_Calendar = lines[i].Split(':')[1].Trim();
                        break;
                    case StringConstants.STD_IN_FILE:
                        job.Std_In_File = lines[i].Split(':')[1].Trim();
                        break;

                    case StringConstants.JOB_TERMINATOR:
                        job.Job_terminator = lines[i].Split(':')[1].Trim();
                        break;
                    case StringConstants.WIN_LOG_NAME:
                        job.Win_log_name = lines[i].Split(':')[1].Trim();
                        break;
                    case StringConstants.WIN_EVENT_TYPE:
                        job.Win_event_type = lines[i].Split(':')[1].Trim();
                        break;
                    case StringConstants.WIN_EVENT_ID:
                        job.Win_event_id = lines[i].Split(':')[1].Trim();
                        break;
                    case StringConstants.MIN_RUN_ALARM:
                        job.Min_run_alarm = lines[i].Split(':')[1].Trim();
                        break;
                   
                    default:
                        if (!string.IsNullOrEmpty(lines[i]) && lines[i].Contains(":"))
                        {
                            listOfNewParameters.Add(lines[i].Split(':').First().Trim());
                        }
                        continue;
                }
            }

            if (job != null)
                listOfJobs.Add(job);
            Console.WriteLine(StringConstants.TOTAL_JOBS_COUNT + listOfJobs.Count);
            List<FilteredJobs> listOfJobsCopy = new List<FilteredJobs>();
            listOfJobsCopy.AddRange(listOfJobs);

            foreach (var item in listOfJobsCopy)
            {
                try
                {
                    if (item.Insert_job.Contains(StringConstants.BSL_JOBS_SUBSTRING))
                    {
                        string billerName = item.Insert_job.Split('-')[5].Trim();
                    }
                    else if (item.Insert_job.Contains(StringConstants.BIS_JOBS_SUBSTRING))
                    {
                        string billerName = item.Insert_job.Split('-')[6].Trim();
                    }
                }
                catch (Exception ex)
                {
                    //if (ex.Message.ToLower().Contains(StringConstants.INDEX))
                    //{
                    //    listOfJobs.Remove(item);
                    //}
                    SEM.Logging.SEMLogger.LogError(ex.Message + "\nat function : " + System.Reflection.MethodBase.GetCurrentMethod().Name);
                    continue;
                }
            }

            return listOfJobs;
        }

        public List<FilteredJobs> GetListOfJobs12(string inputFileName)
        {
            FilteredJobs job = new FilteredJobs();

            List<FilteredJobs> listOfJobs = new List<FilteredJobs>();
            int linesCount = File.ReadLines(inputFileName).Count();
            string[] lines = new string[linesCount];
            lines = File.ReadLines(inputFileName).ToArray<string>();
            for (int i = 0; i < lines.Length; i++)
            {
                if (lines[i].Trim().StartsWith(StringConstants.HEADER))
                {
                    if (job.Header != (null))
                    {
                        listOfJobs.Add(job);
                        job = new FilteredJobs();
                    }

                    job.Header = lines[i];
                }

                switch (lines[i].Split(StringConstants.SPLIT_WITH_COLON)[0].Trim())
                {
                    case StringConstants.INSERT_JOB:

                        job.Insert_job = lines[i].Trim();
                       // job.Insert_job = job.Insert_job.Trim();

                        break;
                    case StringConstants.MACHINE:
                        job.Machine = lines[i].Trim();
                        break;
                    case StringConstants.BOX_NAME:
                        job.Boxname = lines[i].Trim();
                        break;
                    case StringConstants.CONDITION:
                        job.Condition = lines[i].Trim();
                        break;
                    case StringConstants.COMMAND:
                        job.Command = lines[i].Trim();
                        break;
                    case StringConstants.OWNER:
                        job.Owner = lines[i].Trim();
                        break;
                    case StringConstants.PERMISSION:
                        job.Permission = lines[i].Trim();
                        break;
                    case StringConstants.DATE_CONDITIONS:
                        job.DateCondition = lines[i].Trim();
                        break;
                    case StringConstants.DESCRIPTION:
                        job.Description = lines[i].Trim();
                        break;
                    case StringConstants.STD_OUT_FILE:
                        job.StdOutFile = lines[i].Trim();
                        break;
                    case StringConstants.STD_ERR_FILE:
                        job.StdErrFile = lines[i].Trim();
                        break;
                    case StringConstants.MAX_RUN_ALARM:
                        job.MaxRunAlarm = lines[i].Trim();
                        break;
                    case StringConstants.ALARF_IF_FAIL:
                        job.AlarmIfFail = lines[i].Trim();
                        break;
                    case StringConstants.PROFILE:
                        job.Profile = lines[i].Trim();
                        break;
                    case StringConstants.JOB_LOAD:
                        job.JobLoad = lines[i].Trim();
                        break;
                    case StringConstants.PRIORITY:
                        job.Priority = lines[i].Trim();
                        break;
                    case StringConstants.GROUP:
                        job.Group = lines[i].Trim();
                        break;
                    case StringConstants.BOX_SUCCESS:
                        job.Box_Success = lines[i].Trim();
                        break;
                    case StringConstants.BOX_FAILURE:
                        job.Box_Failure = lines[i].Trim();
                        break;
                    case StringConstants.APPLICATION:
                        job.Application = lines[i].Trim();
                        break;
                    case StringConstants.MUST_START_TIMES:
                        job.Must_Start_Times = lines[i].Trim();
                        break;
                    case StringConstants.DAYS_OF_WEEK:
                        job.Run_Day = lines[i].Trim();
                        break;
                    case StringConstants.START_TIMES:
                        job.Start_Times = lines[i].Trim();
                        break;
                    case StringConstants.RUN_CALENDAR:
                        job.Run_Calendar = lines[i].Trim();
                        break;
                    case StringConstants.N_RETRYS:
                        job.N_Retrys = lines[i].Trim();
                        break;
                    case StringConstants.TIMEZONE:
                        job.TimeZone = lines[i].Trim();
                        break;

                    case StringConstants.MAX_EXIT_SUCCESS:
                        job.Max_Exit_Success = lines[i].Trim();
                        break;
                    case StringConstants.SUCCESS_CODES:
                        job.Success_Codes = lines[i].Trim();
                        break;
                    case StringConstants.FAIL_CODES:
                        job.Fail_Codes = lines[i].Trim();
                        break;
                    case StringConstants.MUST_COMPLETE_TIMES:
                        job.Must_Complete_Times = lines[i].Trim();
                        break;
                    case StringConstants.FTP_TRANSFER_TYPE:
                        job.Ftp_Transfer_Type = lines[i].Trim();
                        break;

                    case StringConstants.FTP_TRANSFER_DIRECTION:
                        job.Ftp_Transfer_Direction = lines[i].Trim();
                        break;
                    case StringConstants.FTP_LOCAL_NAME:
                        job.Ftp_Local_Name = lines[i].Trim();
                        break;
                    case StringConstants.FTP_REMOTE_NAME:
                        job.Ftp_Remote_Name = lines[i].Trim();
                        break;
                    case StringConstants.FTP_SERVER_NAME:
                        job.Ftp_Server_Name = lines[i].Trim();
                        break;
                    case StringConstants.FTP_SERVER_PORT:
                        job.Ftp_Server_port = lines[i].Trim();
                        break;
                    case StringConstants.FTP_USE_SSL:
                        job.Ftp_Use_Ssl = lines[i].Trim();
                        break;
                    case StringConstants.FTP_LOCAL_USER:
                        job.Ftp_Local_User = lines[i].Trim();
                        break;
                    case StringConstants.START_MINS:
                        job.Start_Mins = lines[i].Trim();
                        break;
                    case StringConstants.WATCH_FILE:
                        job.Watch_File = lines[i].Trim();
                        break;
                    case StringConstants.WATCH_FILE_RECURRSIVE:
                        job.Watch_File_Recurrsive = lines[i].Trim();
                        break;
                    case StringConstants.WATCH_FILE_TYPE:
                        job.Watch_File_Type = lines[i].Trim();
                        break;
                    case StringConstants.WATCH_FILE_WIN_USER:
                        job.Watch_File_Win_User = lines[i].Trim();
                        break;
                    case StringConstants.CONTINOUS:
                        job.Continous = lines[i].Trim();
                        break;
                    case StringConstants.WATCH_INTERVAL:
                        job.Watch_Interval = lines[i].Trim();
                        break;
                    case StringConstants.WIN_EVENT_OP:
                        job.Win_Event_Op = lines[i].Trim();
                        break;
                    case StringConstants.MONITOR_MODE:
                        job.Monitor_Mode = lines[i].Trim();
                        break;
                    case StringConstants.TERM_RUN_TIME:
                        job.Term_Run_Time = lines[i].Trim();
                        break;
                    case StringConstants.SEND_NOTIFICATION:
                        job.Send_Notification = lines[i].Trim();
                        break;
                    case StringConstants.NOTIFICATION_ID:
                        job.Notification_Id = lines[i].Trim();
                        break;
                    case StringConstants.NOTIFICATION_MSG:
                        job.Notification_Msg = lines[i].Trim();
                        break;
                    case StringConstants.EXCLUDE_CALENDAR:
                        job.Exclude_Calendar = lines[i].Trim();
                        break;
                    case StringConstants.STD_IN_FILE:
                        job.Std_In_File = lines[i].Trim();
                        break;

                    case StringConstants.JOB_TERMINATOR:
                        job.Job_terminator = lines[i].Trim();
                        break;
                    case StringConstants.WIN_LOG_NAME:
                        job.Win_log_name = lines[i].Trim();
                        break;
                    case StringConstants.WIN_EVENT_TYPE:
                        job.Win_event_type = lines[i].Trim();
                        break;
                    case StringConstants.WIN_EVENT_ID:
                        job.Win_event_id = lines[i].Trim();
                        break;
                    case StringConstants.MIN_RUN_ALARM:
                        job.Min_run_alarm = lines[i].Trim();
                        break;
                    case StringConstants.STATUS:
                        job.Status = lines[i].Trim();
                        break;
                    default:
                        continue;
                }
            }

            if (job != null)
                listOfJobs.Add(job);
            Console.WriteLine(StringConstants.TOTAL_JOBS_COUNT + listOfJobs.Count);
            List<FilteredJobs> listOfJobsCopy = new List<FilteredJobs>();
            listOfJobsCopy.AddRange(listOfJobs);

            foreach (var item in listOfJobsCopy)
            {
                try
                {
                    if (item.Insert_job.Contains(StringConstants.BSL_JOBS_SUBSTRING))
                    {
                        string billerName = item.Insert_job.Split('-')[5].Trim();
                    }
                    else if (item.Insert_job.Contains(StringConstants.BIS_JOBS_SUBSTRING))
                    {
                        string billerName = item.Insert_job.Split('-')[6].Trim();
                    }
                }
                catch (Exception ex)
                {
                    //if (ex.Message.ToLower().Contains(StringConstants.INDEX))
                    //{
                    //    listOfJobs.Remove(item);
                    //}
                    SEM.Logging.SEMLogger.LogError(ex.Message + "\nat function : " + System.Reflection.MethodBase.GetCurrentMethod().Name);
                    continue;
                }
            }

            return listOfJobs;
        }
    }
}
