﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Configuration;
using System.IO;
using System.Data;
using SEM.Logging;
using System.Text;

using System.Xml;
using System.Text.RegularExpressions;
using System.Diagnostics;

namespace Autosys_JILFileDetailsExtractUtility
{
   public  class ExcelCreator
    {
        /// <summary>       
        /// Create one Excel-XML-Document with SpreadsheetML from a DataTable
        /// </summary>        
        /// <param name="dataSource">Datasource which would be exported in Excel</param>
        /// <param name="fileName">Name of exported file</param>
        public static void Create(DataTable dtSource, string strFileName)
        {
            try
            {
                // Create XMLWriter
                XmlTextWriter xtwWriter = new XmlTextWriter(strFileName, Encoding.UTF8);

                //Format the output file for reading easier
                xtwWriter.Formatting = Formatting.Indented;

                // <?xml version="1.0"?>
                xtwWriter.WriteStartDocument();

                // <?mso-application progid="Excel.Sheet"?>
                xtwWriter.WriteProcessingInstruction("mso-application", "progid=\"Excel.Sheet\"");

                // <Workbook xmlns="urn:schemas-microsoft-com:office:spreadsheet >"
                xtwWriter.WriteStartElement("Workbook", "urn:schemas-microsoft-com:office:spreadsheet");

                //Write definition of namespace
                xtwWriter.WriteAttributeString("xmlns", "o", null, "urn:schemas-microsoft-com:office:office");
                xtwWriter.WriteAttributeString("xmlns", "x", null, "urn:schemas-microsoft-com:office:excel");
                xtwWriter.WriteAttributeString("xmlns", "ss", null, "urn:schemas-microsoft-com:office:spreadsheet");
                xtwWriter.WriteAttributeString("xmlns", "html", null, "http://www.w3.org/TR/REC-html40");

                // <DocumentProperties xmlns="urn:schemas-microsoft-com:office:office">
                xtwWriter.WriteStartElement("DocumentProperties", "urn:schemas-microsoft-com:office:office");

                // Write document properties
                xtwWriter.WriteElementString("Author", Environment.UserName);
                xtwWriter.WriteElementString("LastAuthor", Environment.UserName);
                xtwWriter.WriteElementString("Created", DateTime.Now.ToString("u") + "Z");
                xtwWriter.WriteElementString("Company", "Unknown");
                xtwWriter.WriteElementString("Version", "1.000");

                // </DocumentProperties>
                xtwWriter.WriteEndElement();

                // <ExcelWorkbook xmlns="urn:schemas-microsoft-com:office:excel">
                xtwWriter.WriteStartElement("ExcelWorkbook", "urn:schemas-microsoft-com:office:excel");

                // Write settings of workbook
                xtwWriter.WriteElementString("WindowHeight", "13170");
                xtwWriter.WriteElementString("WindowWidth", "17580");
                xtwWriter.WriteElementString("WindowTopX", "120");
                xtwWriter.WriteElementString("WindowTopY", "60");
                xtwWriter.WriteElementString("ProtectStructure", "False");
                xtwWriter.WriteElementString("ProtectWindows", "False");

                // </ExcelWorkbook>
                xtwWriter.WriteEndElement();

                // <Styles>
                xtwWriter.WriteStartElement("Styles");

                // <Style ss:ID="Default" ss:Name="Normal">
                xtwWriter.WriteStartElement("Style");
                xtwWriter.WriteAttributeString("ss", "ID", null, "Default");
                xtwWriter.WriteAttributeString("ss", "Name", null, "Normal");

                // <Alignment ss:Vertical="Bottom"/>
                xtwWriter.WriteStartElement("Alignment");
                xtwWriter.WriteAttributeString("ss", "Vertical", null, "Bottom");
                xtwWriter.WriteEndElement();

                // Write null on the other properties
                xtwWriter.WriteElementString("Borders", null);
                xtwWriter.WriteElementString("Font", null);
                xtwWriter.WriteElementString("Interior", null);
                xtwWriter.WriteElementString("NumberFormat", null);
                xtwWriter.WriteElementString("Protection", null);

                // </Style>
                xtwWriter.WriteEndElement();

                // </Styles>
                xtwWriter.WriteEndElement();

                // <Worksheet ss:Name="xxx">
                xtwWriter.WriteStartElement("Worksheet");
                xtwWriter.WriteAttributeString("ss", "Name", null, dtSource.TableName);

                // <Table ss:ExpandedColumnCount="2" ss:ExpandedRowCount="3" x:FullColumns="1" x:FullRows="1" ss:DefaultColumnWidth="60">
                xtwWriter.WriteStartElement("Table");
                xtwWriter.WriteAttributeString("ss", "ExpandedColumnCount", null, dtSource.Columns.Count.ToString());
                xtwWriter.WriteAttributeString("ss", "ExpandedRowCount", null, (dtSource.Rows.Count + 1).ToString());
                xtwWriter.WriteAttributeString("x", "FullColumns", null, "1");
                xtwWriter.WriteAttributeString("x", "FullRows", null, "1");
                xtwWriter.WriteAttributeString("ss", "DefaultColumnWidth", null, "60");

                xtwWriter.WriteStartElement("Row");
                foreach (DataColumn item in dtSource.Columns)
                {
                   
                    xtwWriter.WriteStartElement("Cell");
                    xtwWriter.WriteStartElement("Data");
                    xtwWriter.WriteAttributeString("ss", "Type", null, "String");
                    xtwWriter.WriteValue(item.ColumnName);
                    // </Data>
                    xtwWriter.WriteEndElement();

                    // </Cell>
                    xtwWriter.WriteEndElement();
                     
                }

                xtwWriter.WriteEndElement(); 
                foreach (DataRow row in dtSource.Rows)
                   {
                     
                    // Run through all rows of data source
                   
                        // <Row>
                        xtwWriter.WriteStartElement("Row");

                        // Run through all cell of current rows
                        foreach (object cellValue in row.ItemArray)
                        {
                            // <Cell>
                            xtwWriter.WriteStartElement("Cell");

                            // <Data ss:Type="String">xxx</Data>
                            xtwWriter.WriteStartElement("Data");
                            xtwWriter.WriteAttributeString("ss", "Type", null, "String");

                            // Write content of cell
                            xtwWriter.WriteValue(cellValue);

                            // </Data>
                            xtwWriter.WriteEndElement();

                            // </Cell>
                            xtwWriter.WriteEndElement();
                        }
                        // </Row>
                        xtwWriter.WriteEndElement();               
                    }
               
                // </Table>
                xtwWriter.WriteEndElement();

                // <WorksheetOptions xmlns="urn:schemas-microsoft-com:office:excel">
                xtwWriter.WriteStartElement("WorksheetOptions", "urn:schemas-microsoft-com:office:excel");

                // Write settings of page
                xtwWriter.WriteStartElement("PageSetup");
                xtwWriter.WriteStartElement("Header");
                xtwWriter.WriteAttributeString("x", "Margin", null, "0.4921259845");
                xtwWriter.WriteEndElement();
                xtwWriter.WriteStartElement("Footer");
                xtwWriter.WriteAttributeString("x", "Margin", null, "0.4921259845");
                xtwWriter.WriteEndElement();
                xtwWriter.WriteStartElement("PageMargins");
                xtwWriter.WriteAttributeString("x", "Bottom", null, "0.984251969");
                xtwWriter.WriteAttributeString("x", "Left", null, "0.78740157499999996");
                xtwWriter.WriteAttributeString("x", "Right", null, "0.78740157499999996");
                xtwWriter.WriteAttributeString("x", "Top", null, "0.984251969");
                xtwWriter.WriteEndElement();
                xtwWriter.WriteEndElement();

                // <Selected/>
                xtwWriter.WriteElementString("Selected", null);

                // <Panes>
                xtwWriter.WriteStartElement("Panes");

                // <Pane>
                xtwWriter.WriteStartElement("Pane");

                // Write settings of active field
                xtwWriter.WriteElementString("Number", "1");
                xtwWriter.WriteElementString("ActiveRow", "1");
                xtwWriter.WriteElementString("ActiveCol", "1");

                // </Pane>
                xtwWriter.WriteEndElement();

                // </Panes>
                xtwWriter.WriteEndElement();

                // <ProtectObjects>False</ProtectObjects>
                xtwWriter.WriteElementString("ProtectObjects", "False");

                // <ProtectScenarios>False</ProtectScenarios>
                xtwWriter.WriteElementString("ProtectScenarios", "False");

                // </WorksheetOptions>
                xtwWriter.WriteEndElement();

                // </Worksheet>
                xtwWriter.WriteEndElement();

                // </Workbook>
                xtwWriter.WriteEndElement();

                // Write file on hard disk
                xtwWriter.Flush();
                xtwWriter.Close();
            }
            catch (Exception ex)
            {
                Console.WriteLine(ex.Message);
            }
        }
    }

    public class Program
    {
        static int Main(string[] args)
        {
            int result = 0;
            try
            {
                Stopwatch timer = new Stopwatch();
                timer.Start();
                List<string> listOfNewParameters = new List<string>();
                SEMLogger logger = new SEMLogger(@"\Autosys_JILFileDetailsExtractUtility\log4net.config");
                SEMLogger.LogInformation("Logger initialized..." + Environment.NewLine);
                FileOperations fileOperationsObj = new FileOperations();
                JilOperations jilOperationsObj = new JilOperations();
                string inputFileName = ConfigurationManager.AppSettings[StringConstants.INPUT_FILENAME_WITHPATH];
                if (inputFileName.Contains("$$sysdate"))
                {
                    inputFileName = inputFileName.Replace("$$sysdate", System.DateTime.Now.ToString("yyyyMMdd"));
                }
                SEMLogger.LogInformation("Checking if configured input file exists or not.");
                if (!File.Exists(inputFileName))
                {
                    SEMLogger.LogInformation(StringConstants.INPUT_FILE_DOESNOTEXISTS);
                    return 4;
                }

                SEMLogger.LogInformation("Configured input file exists, proceeding further in execution.");
                string functionToBePerformed = ConfigurationManager.AppSettings[StringConstants.FUNCTION_TOBE_PERFORMED] ?? string.Empty;
                string outputFileName = ConfigurationManager.AppSettings[StringConstants.OUTPUT_FILENAME_WITHPATH];
                
                if (outputFileName.Contains("$$sysdate"))
                {
                    outputFileName = outputFileName.Replace("$$sysdate", System.DateTime.Now.ToString("yyyyMMdd"));
                }
                if (!functionToBePerformed.Equals(StringConstants.FUNCTION_PERFORMED11))
                {
                    if (!File.Exists(outputFileName))
                    {
                        SEMLogger.LogInformation(StringConstants.OUTPUT_FILE_DOESNOTEXISTS);
                        FileStream outFile = File.Create(outputFileName);
                        outFile.Close();
                    }

                    SEMLogger.LogInformation("Erasing output file contents as file already exists.");
                    //erasing output file contents
                    FileStream fileStream = File.Open(outputFileName, FileMode.Open);
                    fileStream.SetLength(0);
                    fileStream.Close();
                }

                //getting the flag which decides the function to be performed
                // string functionToBePerformed = ConfigurationManager.AppSettings[StringConstants.FUNCTION_TOBE_PERFORMED] ?? string.Empty;
                switch (functionToBePerformed)
                {
                    case StringConstants.FUNCTION_PERFORMED01:
                        // for taking out biller names from all jobs   
                        SEMLogger.LogInformation(StringConstants.FETCHING_BILLER_NAMES);
                        List<FilteredJobs> listOfJobs = new List<FilteredJobs>();
                        using (StreamWriter writerObj = new StreamWriter(outputFileName, true))
                        {
                            writerObj.WriteLine(string.Join(Environment.NewLine, jilOperationsObj.GetBillerNamesListAndListOfAllJobs(inputFileName, ref listOfJobs).Distinct().ToArray()));
                        }

                        SEMLogger.LogInformation("Biller names fetched from input file, please see below path for output file :\n {0}", outputFileName);
                        break;

                    case StringConstants.FUNCTION_PERFORMED02:
                        // for extracting all jobs
                       
                        using (StreamWriter writerObj = new StreamWriter(outputFileName, true))
                        {
                            Console.WriteLine(StringConstants.FETCHING_JOBS_FROMINPUT);
                            foreach (FilteredJobs item in jilOperationsObj.GetListOfJobs(inputFileName, ref listOfNewParameters))
                            {
                                writerObj.WriteLine(item.Insert_job.Trim());
                            }
                        }
                        break;

                    case StringConstants.FUNCTION_PERFORMED03:
                        // for extracting all jobs based on some search string
                        using (StreamWriter writerObj = new StreamWriter(outputFileName, true))
                        {
                            Console.WriteLine(StringConstants.FETCHING_FILTERED_JOBS);
                            string job_name = string.Empty;
                            foreach (var item in jilOperationsObj.GetListOfJobs(inputFileName, ref listOfNewParameters))
                            {
                                job_name = item.Insert_job.Trim().Split(StringConstants.SPLIT_WITH_COLON)[1].Trim().ToLower();
                                if (job_name.Contains(ConfigurationManager.AppSettings[StringConstants.SEARCH_STRING]))
                                {
                                    writerObj.WriteLine(job_name.Trim().Split(StringConstants.SPLIT_WITH_SPACE)[0]);
                                }
                            }
                        }
                        break;

                    case StringConstants.FUNCTION_PERFORMED04:
                        //for getting job details with all parameters based on machine name passed.
                        Console.WriteLine(StringConstants.FETCHING_JOBSBY_MACHINENAME);
                        List<FilteredJobs> filteredJobsViaMachineName = (from x in jilOperationsObj.GetListOfJobs(inputFileName, ref listOfNewParameters) where x.Machine.ToLower().Contains(ConfigurationManager.AppSettings["SearchString"].ToLower().ToString()) select x).ToList<FilteredJobs>();
                        Console.WriteLine(StringConstants.FILTERED_JOBS_COUNT + filteredJobsViaMachineName.Count());
                        fileOperationsObj.PrintDataToOutputFile(filteredJobsViaMachineName, outputFileName);
                        break;

                    case StringConstants.FUNCTION_PERFORMED05:
                        //for getting job details with all parameters based on biller name or any string passed.
                        Console.WriteLine(StringConstants.FETCHING_JOBSBY_SEARCHSTRING);
                        List<FilteredJobs> filteredJobsViaJobName = (from x in jilOperationsObj.GetListOfJobs(inputFileName, ref listOfNewParameters) where x.Insert_job.ToLower().Contains(ConfigurationManager.AppSettings["SearchString"].ToLower().ToString()) select x).ToList<FilteredJobs>();
                        Console.WriteLine(StringConstants.FILTERED_JOBS_COUNT + filteredJobsViaJobName.Count());
                        fileOperationsObj.PrintDataToOutputFile(filteredJobsViaJobName, outputFileName);
                        break;

                    case StringConstants.FUNCTION_PERFORMED06:
                        //for getting job details with all parameters based on owner name passed.
                        Console.WriteLine(StringConstants.FETCHING_JOBSBY_COMMANDNAME);
                        List<FilteredJobs> filteredJobsViaOwnerName = (from x in jilOperationsObj.GetListOfJobs(inputFileName, ref listOfNewParameters) where x.Owner.ToLower().Contains(ConfigurationManager.AppSettings["SearchString"].ToLower().ToString()) select x).ToList<FilteredJobs>();
                        Console.WriteLine(StringConstants.FILTERED_JOBS_COUNT + filteredJobsViaOwnerName.Count());
                        fileOperationsObj.PrintDataToOutputFile(filteredJobsViaOwnerName, outputFileName);
                        break;

                    case StringConstants.FUNCTION_PERFORMED07:
                        
                        Console.WriteLine(StringConstants.FETCHING_JOBSBY_COMMANDNAME);
                        List<FilteredJobs> filteredJobsViaCommandName = (from x in jilOperationsObj.GetListOfJobs(inputFileName, ref listOfNewParameters) where x.Command.ToLower().Contains(ConfigurationManager.AppSettings["SearchString"].ToLower().ToString()) select x).ToList<FilteredJobs>();
                        Console.WriteLine(StringConstants.FILTERED_JOBS_COUNT + filteredJobsViaCommandName.Count());
                        using (StreamWriter writerObj = new StreamWriter(outputFileName, true))
                        {
                            foreach (var item in filteredJobsViaCommandName)
                            {
                                writerObj.WriteLine(item.Insert_job.Trim().Split(StringConstants.SPLIT_WITH_COLON)[1].Trim().Split(StringConstants.SPLIT_WITH_SPACE)[0].Trim());
                            }
                        }
                        break;

                    case StringConstants.FUNCTION_PERFORMED08:
                        //for getting job details with all parameters based on wrapper name passed.
                        
                        Console.WriteLine(StringConstants.FETCHING_JOBSBY_WRAPPERNAME);
                        List<FilteredJobs> filteredJobsWraperName = (from x in jilOperationsObj.GetListOfJobs(inputFileName, ref listOfNewParameters) where x.Command.ToLower().Contains(ConfigurationManager.AppSettings["SearchString"].ToLower().ToString()) select x).ToList<FilteredJobs>();
                        Console.WriteLine(StringConstants.FILTERED_JOBS_COUNT + filteredJobsWraperName.Count());
                        fileOperationsObj.PrintDataToOutputFile(filteredJobsWraperName, outputFileName);
                        break;

                    case "13":
                        List<FilteredJobs> listOFilteredJobs13 = new List<FilteredJobs>();
                        List<string> listOfBillers13 = jilOperationsObj.GetListOfJobsWithBillerNames(inputFileName, ref listOFilteredJobs13).Distinct().ToList<string>();
                        List<string> listOfStringTODelete13 = new List<string>();
                        listOfStringTODelete13 = ConfigurationManager.AppSettings["RemoveJobsWildCardString"].Split(';').ToList<string>();
                        foreach (var str in listOfStringTODelete13)
                        {
                            listOFilteredJobs13.RemoveAll(x => Regex.IsMatch(x.Insert_job.ToLower(), WildCardToRegular(str.Trim())));                          
                        }

                        fileOperationsObj.PrintDataToOutputFile(listOFilteredJobs13.Distinct().ToList<FilteredJobs>(), outputFileName);

                        break;

                    case "14":
                        List<FilteredJobs> listOFilteredJobs14 = new List<FilteredJobs>();
                        List<string> listOfBillers14 = jilOperationsObj.GetListOfJobsWithBillerNames(inputFileName, ref listOFilteredJobs14).Distinct().ToList<string>();
                        List<FilteredJobs> listOfJobsWithNasChanges = (from x in listOFilteredJobs14 where x.Command.Contains(@"corp.bmc.corp") select x).ToList<FilteredJobs>();
                        listOfJobsWithNasChanges = listOfJobsWithNasChanges.Distinct().ToList<FilteredJobs>();
                        //foreach (var job in listOfJobsWithNasChanges)
                        //{
                        //    if (job.Insert_job.Contains("bsl-app-odbt1-") || job.Insert_job.Contains("bis-2-b-s-") || job.Insert_job.Contains("bis-2-c-s-"))
                        //    {
                        //        job.Command = job.Command.Replace(@"\\npkcrpdat01", @"\\nwipnas01");
                        //        job.Command = job.Command.Replace(@"Incoming_Files_Test", @"Incoming_Files");
                        //    }
                        //    else if (job.Insert_job.Contains("bsl-app-odbt2-") || job.Insert_job.Contains("bis-2-b-c-") || job.Insert_job.Contains("bis-2-c-c-"))
                        //    {
                        //        job.Command = job.Command.Replace(@"\\npkcrpdat01", @"\\nwcpnas01");
                        //        job.Command = job.Command.Replace(@"Incoming_Files_Test", @"Incoming_Files");
                        //    }
                        //    else
                        //    {
                        //        job.Command = job.Command.Replace(@"\\npkcrpdat01", @"\\nwdpnas01");
                        //        job.Command = job.Command.Replace(@"Incoming_Files_Test", @"Incoming_Files");
                        //    }
                        //}

                        fileOperationsObj.PrintDataToOutputFile(listOfJobsWithNasChanges, outputFileName);
                        break;


                    case "19":
                        List<FilteredJobs> listOFilteredJobs19 = new List<FilteredJobs>();
                        listOFilteredJobs19 = jilOperationsObj.GetListOfJobs(inputFileName, ref listOfNewParameters);
                        if (listOfNewParameters.Count > 0)
                            fileOperationsObj.PrintDataToTextFileFromListOfString(listOfNewParameters, outputFileName);
                        else
                        {
                            using (StreamWriter writerObj = new StreamWriter(outputFileName, true))
                            {
                                writerObj.WriteLine("No new items found");                               
                            }
                        }
                        break;

                    case "22":
                        List<FilteredJobs> listOfAllInputJobs = new List<FilteredJobs>();
                        List<string> listOfInputIceJobs = File.ReadAllLines(ConfigurationManager.AppSettings["OnIceJobsListFilePath"]).Where(x => x != string.Empty).ToList<string>();
                        List<string> listOfInputBillers = jilOperationsObj.GetListOfJobsWithBillerNames(inputFileName, ref listOfAllInputJobs).ToList<string>();
                        foreach (FilteredJobs job in listOfAllInputJobs)
                        {
                            string jobName = job.Insert_job.Split(new string[] { "job_type" }, StringSplitOptions.None).First().Trim().Split(':').Last().Trim();
                            if (listOfInputIceJobs.Contains(jobName))
                                job.Status = "ON_ICE";
                        }

                        fileOperationsObj.PrintDataToOutputFile(listOfAllInputJobs, outputFileName);
                        break;

                    case "24":
                        List<FilteredJobs> listOfCloseTo1000Jobs1 = new List<FilteredJobs>();
                        List<FilteredJobs> listOfCloseTo1000Jobs2 = new List<FilteredJobs>();
                        List<FilteredJobs> listOfCloseTo1000Jobs3 = new List<FilteredJobs>();
                        string splitFilesPath = ConfigurationManager.AppSettings["PathForSplitFiles"];

                        FileStream fileStream1 = File.Open(splitFilesPath + @"\SplitFile1.jil", FileMode.Open);
                        fileStream1.SetLength(0);
                        fileStream1.Close();
                        FileStream fileStream2 = File.Open(splitFilesPath + @"\SplitFile2.jil", FileMode.Open);
                        fileStream2.SetLength(0);
                        fileStream2.Close();
                        FileStream fileStream3 = File.Open(splitFilesPath + @"\SplitFile3.jil", FileMode.Open);
                        fileStream3.SetLength(0);
                        fileStream3.Close();

                        List<FilteredJobs> listOFilteredJobsForSplitFiles = new List<FilteredJobs>();
                        List<string> listOfBillersForSplitFiles = jilOperationsObj.GetListOfJobsWithBillerNames(inputFileName, ref listOFilteredJobsForSplitFiles).Distinct().ToList<string>();
                        int jobsCount = 0;
                        foreach (string biller in listOfBillersForSplitFiles)
                        {
                            List<FilteredJobs> listOfJobsSplit = (from x in listOFilteredJobsForSplitFiles where x.Insert_job.Contains("-" + biller.ToLower() + "-") select x).ToList<FilteredJobs>();
                            jobsCount += listOfJobsSplit.Count;

                            if (jobsCount <= 1000)
                            {
                                listOfCloseTo1000Jobs1.AddRange(from x in listOfJobsSplit where (from y in listOfCloseTo1000Jobs1 where y.Insert_job.Contains(x.Insert_job) select y).Count() == 0 select x);
                            }
                            else if (jobsCount > 1000 && jobsCount <= 2000)
                            {
                                listOfCloseTo1000Jobs2.AddRange(from x in listOfJobsSplit where 
                                                                    (from y in listOfCloseTo1000Jobs2 where y.Insert_job.Contains(x.Insert_job) select y).Count() == 0
                                                                && (from y in listOfCloseTo1000Jobs1 where y.Insert_job.Contains(x.Insert_job) select y).Count() == 0                                                                
                                                                select x);
                            }
                            else
                            {
                                listOfCloseTo1000Jobs3.AddRange(from x in listOfJobsSplit
                                                                where
                                                                    (from y in listOfCloseTo1000Jobs1 where y.Insert_job.Contains(x.Insert_job) select y).Count() == 0
                                                                    && (from y in listOfCloseTo1000Jobs2 where y.Insert_job.Contains(x.Insert_job) select y).Count() == 0
                                                                    && (from y in listOfCloseTo1000Jobs3 where y.Insert_job.Contains(x.Insert_job) select y).Count() == 0
                                                                select x);
                            }
                        }

                        if(listOfCloseTo1000Jobs1.Count > 0)
                        fileOperationsObj.PrintDataToOutputFile(listOfCloseTo1000Jobs1, splitFilesPath + @"\SplitFile1.jil");
                        if (listOfCloseTo1000Jobs2.Count > 0)
                        fileOperationsObj.PrintDataToOutputFile(listOfCloseTo1000Jobs2, splitFilesPath + @"\SplitFile2.jil");
                        if (listOfCloseTo1000Jobs3.Count > 0)
                        fileOperationsObj.PrintDataToOutputFile(listOfCloseTo1000Jobs3, splitFilesPath + @"\SplitFile3.jil");
                        break;
                    case "21":
                        List<FilteredJobs> listOfJobsAsPerBillers = new List<FilteredJobs>();
                       
                        List<string> listOfBillerFromJil = jilOperationsObj.GetListOfJobsWithBillerNames(inputFileName, ref listOfJobsAsPerBillers).ToList<string>();
                        //listOfJobsAsPerBillers = jilOperationsObj.GetListOfJobs(inputFileName, ref listOfNewParameters);
                        List<string> listOfAllBillers = ConfigurationManager.AppSettings["AllBillersList"].Split(',').ToList<string>();
                        List<FilteredJobs> listOfJobsForProcessing = new List<FilteredJobs>();
                        List<FilteredJobs> listOfAllJobsToPrint = new List<FilteredJobs>();
                        foreach (string biller in listOfAllBillers)
                        {
                            listOfJobsForProcessing.Clear();
                            listOfJobsForProcessing = (from x in listOfJobsAsPerBillers where x.Insert_job.ToLower().Contains(biller.ToLower().Trim()) select x).ToList<FilteredJobs>();
                            listOfAllJobsToPrint.AddRange(from x in listOfJobsForProcessing where (from y in listOfAllJobsToPrint where y.Insert_job.Contains(x.Insert_job) select y).Count() == 0 select x);

                            //foreach (var job in listOfAllJobsToPrint)
                            //{
                            //    string jobName = job.Insert_job.Split(new string[] { "job_type" }, StringSplitOptions.None).First().Trim().Split(':').Last().Trim();
                            //    if (!listOfJobsInFile.Contains(jobName))
                            //    {
                            //        if (jobName.Contains("bsl-"))
                            //        {
                            //            string bisJobName = jobName.Replace("bsl-app-od-", "bis-2-p-o-");
                            //            if (!listOfJobsInFile.Contains(bisJobName))
                            //                listOfExtraJobs.Add(jobName);
                            //        }
                            //        else
                            //        {
                            //            listOfExtraJobs.Add(jobName);
                            //        }
                            //    }
                            //}
                        }

                        //string extraJobsOutputFile = ConfigurationManager.AppSettings["ExtraJobsOutputFile"];
                        //if (File.Exists(extraJobsOutputFile))
                        //{
                        //    FileStream extrafileStream = File.Open(extraJobsOutputFile, FileMode.Open);
                        //    extrafileStream.SetLength(0);
                        //    extrafileStream.Close();
                        //}

                        // fileOperationsObj.PrintDataToTextFileFromListOfString(listOfExtraJobs.Distinct().Where(x => x != string.Empty).ToList<string>(), extraJobsOutputFile);
                        fileOperationsObj.PrintDataToOutputFile(listOfAllJobsToPrint, outputFileName);
                        break;



                        //below is the code to create the update JIL for rollback with provided no. of parameters in config 
                    case "23":
                        List<FilteredJobs> listOFilteredJobs23 = new List<FilteredJobs>();
                        FilteredJobs jobsToUpdate =  null;
                        List<string> listOfParameters = ConfigurationManager.AppSettings["RequiredParameters"].Split(',').Select(x => x.Trim()).ToList<string>();
                        List<string> listOfBillers23 = jilOperationsObj.GetListOfJobsWithBillerNames(inputFileName, ref listOFilteredJobs23).Distinct().ToList<string>();
                        List<FilteredJobs> listOfExtractJobs23 = new List<FilteredJobs>();
                        List<string> jobsInFile23 = File.ReadLines(ConfigurationManager.AppSettings["UpdateJobsListPath"]).Where(x => !string.IsNullOrEmpty(x)).Select(x => x.Trim()).ToList<string>();
                        foreach (string job in jobsInFile23)
                        {
                            FilteredJobs jobFromSource = (from x in listOFilteredJobs23 where x.Insert_job.Split(new string[] { "job_type" }, StringSplitOptions.None).First().Trim().Split(':')[1].Trim().Equals(job) select x).FirstOrDefault();
                            if (jobFromSource != null)
                            {
                                jobsToUpdate = new FilteredJobs();
                                foreach (string param in listOfParameters)
                                {
                                    switch (param)
                                    {
                                        case StringConstants.HEADER_NAME:
                                            jobsToUpdate.Header = jobFromSource.Header;
                                            break;
                                        case StringConstants.INSERT_JOB:
                                            jobsToUpdate.Insert_job = jobFromSource.Insert_job.Replace(StringConstants.INSERT_JOB, StringConstants.UPDATE_JOB);
                                            break;
                                        case StringConstants.MACHINE:
                                            jobsToUpdate.Machine = jobFromSource.Machine;
                                            break;
                                        case StringConstants.BOX_NAME:
                                            jobsToUpdate.Boxname = jobFromSource.Boxname;
                                            break;
                                        case StringConstants.CONDITION:
                                            jobsToUpdate.Condition = jobFromSource.Condition;
                                            break;
                                        case StringConstants.COMMAND:
                                            jobsToUpdate.Command = jobFromSource.Command;
                                            break;
                                        case StringConstants.OWNER:
                                            jobsToUpdate.Owner = jobFromSource.Owner;
                                            break;
                                        case StringConstants.PERMISSION:
                                            jobsToUpdate.Permission = jobFromSource.Permission;
                                            break;
                                        case StringConstants.DATE_CONDITIONS:
                                            jobsToUpdate.DateCondition = jobFromSource.DateCondition;
                                            break;
                                        case StringConstants.DESCRIPTION:
                                            jobsToUpdate.Description = jobFromSource.Description;
                                            break;
                                        case StringConstants.STD_OUT_FILE:
                                            jobsToUpdate.StdOutFile = jobFromSource.StdOutFile;
                                            break;
                                        case StringConstants.STD_ERR_FILE:
                                            jobsToUpdate.StdErrFile = jobFromSource.StdErrFile;
                                            break;
                                        case StringConstants.MAX_RUN_ALARM:
                                            jobsToUpdate.MaxRunAlarm = jobFromSource.MaxRunAlarm;
                                            break;
                                        case StringConstants.ALARF_IF_FAIL:
                                            jobsToUpdate.AlarmIfFail = jobFromSource.AlarmIfFail;
                                            break;
                                        case StringConstants.PROFILE:
                                            jobsToUpdate.Profile = jobFromSource.Profile;
                                            break;
                                        case StringConstants.JOB_LOAD:
                                            jobsToUpdate.JobLoad = jobFromSource.JobLoad;
                                            break;
                                        case StringConstants.PRIORITY:
                                            jobsToUpdate.Priority = jobFromSource.Priority;
                                            break;
                                        case StringConstants.GROUP:
                                            jobsToUpdate.Group = jobFromSource.Group;
                                            break;
                                        case StringConstants.BOX_SUCCESS:
                                            jobsToUpdate.Box_Success = jobFromSource.Box_Success;
                                            break;
                                        case StringConstants.BOX_FAILURE:
                                            jobsToUpdate.Box_Failure = jobFromSource.Box_Failure;
                                            break;
                                        case StringConstants.APPLICATION:
                                            jobsToUpdate.Application = jobFromSource.Application;
                                            break;
                                        case StringConstants.MUST_START_TIMES:
                                            jobsToUpdate.Must_Start_Times = jobFromSource.Must_Start_Times;
                                            break;
                                        case StringConstants.DAYS_OF_WEEK:
                                            jobsToUpdate.Run_Day = jobFromSource.Run_Day;
                                            break;
                                        case StringConstants.START_TIMES:
                                            jobsToUpdate.Start_Times = jobFromSource.Start_Times;
                                            break;
                                        case StringConstants.RUN_CALENDAR:
                                            jobsToUpdate.Run_Calendar = jobFromSource.Run_Calendar;
                                            break;
                                        case StringConstants.N_RETRYS:
                                            jobsToUpdate.N_Retrys = jobFromSource.N_Retrys;
                                            break;
                                        case StringConstants.TIMEZONE:
                                            jobsToUpdate.TimeZone = jobFromSource.TimeZone;
                                            break;
                                        case StringConstants.MAX_EXIT_SUCCESS:
                                            jobsToUpdate.Max_Exit_Success = jobFromSource.Max_Exit_Success;
                                            break;
                                        case StringConstants.SUCCESS_CODES:
                                            jobsToUpdate.Success_Codes = jobFromSource.Success_Codes;
                                            break;
                                        case StringConstants.FAIL_CODES:
                                            jobsToUpdate.Fail_Codes = jobFromSource.Fail_Codes;
                                            break;
                                        case StringConstants.MUST_COMPLETE_TIMES:
                                            jobsToUpdate.Must_Complete_Times = jobFromSource.Must_Complete_Times;
                                            break;
                                        case StringConstants.FTP_TRANSFER_TYPE:
                                            jobsToUpdate.Ftp_Transfer_Type = jobFromSource.Ftp_Transfer_Type;
                                            break;
                                        case StringConstants.FTP_TRANSFER_DIRECTION:
                                            jobsToUpdate.Ftp_Transfer_Direction = jobFromSource.Ftp_Transfer_Direction;
                                            break;
                                        case StringConstants.FTP_LOCAL_NAME:
                                            jobsToUpdate.Ftp_Local_Name = jobFromSource.Ftp_Local_Name;
                                            break;
                                        case StringConstants.FTP_REMOTE_NAME:
                                            jobsToUpdate.Ftp_Remote_Name = jobFromSource.Ftp_Remote_Name;
                                            break;
                                        case StringConstants.FTP_SERVER_NAME:
                                            jobsToUpdate.Ftp_Server_Name = jobFromSource.Ftp_Server_Name;
                                            break;
                                        case StringConstants.FTP_SERVER_PORT:
                                            jobsToUpdate.Ftp_Server_port = jobFromSource.Ftp_Server_port;
                                            break;
                                        case StringConstants.FTP_USE_SSL:
                                            jobsToUpdate.Ftp_Use_Ssl = jobFromSource.Ftp_Use_Ssl;
                                            break;
                                        case StringConstants.FTP_LOCAL_USER:
                                            jobsToUpdate.Ftp_Local_User = jobFromSource.Ftp_Local_User;
                                            break;
                                        case StringConstants.START_MINS:
                                            jobsToUpdate.Start_Mins = jobFromSource.Start_Mins;
                                            break;
                                        case StringConstants.WATCH_FILE:
                                            jobsToUpdate.Watch_File = jobFromSource.Watch_File;
                                            break;
                                        case StringConstants.WATCH_FILE_RECURRSIVE:
                                            jobsToUpdate.Watch_File_Recurrsive = jobFromSource.Watch_File_Recurrsive;
                                            break;
                                        case StringConstants.WATCH_FILE_TYPE:
                                            jobsToUpdate.Watch_File_Type = jobFromSource.Watch_File_Type;
                                            break;
                                        case StringConstants.WATCH_FILE_WIN_USER:
                                            jobsToUpdate.Watch_File_Win_User = jobFromSource.Watch_File_Win_User;
                                            break;
                                        case StringConstants.CONTINOUS:
                                            jobsToUpdate.Continous = jobFromSource.Continous;
                                            break;
                                        case StringConstants.WATCH_INTERVAL:
                                            jobsToUpdate.Watch_Interval = jobFromSource.Watch_Interval;
                                            break;
                                        case StringConstants.WIN_EVENT_OP:
                                            jobsToUpdate.Win_Event_Op = jobFromSource.Win_Event_Op;
                                            break;
                                        case StringConstants.MONITOR_MODE:
                                            jobsToUpdate.Monitor_Mode = jobFromSource.Monitor_Mode;
                                            break;
                                        case StringConstants.TERM_RUN_TIME:
                                            jobsToUpdate.Term_Run_Time = jobFromSource.Term_Run_Time;
                                            break;
                                        case StringConstants.SEND_NOTIFICATION:
                                            jobsToUpdate.Send_Notification = jobFromSource.Send_Notification;
                                            break;
                                        case StringConstants.NOTIFICATION_ID:
                                            jobsToUpdate.Notification_Id = jobFromSource.Notification_Id;
                                            break;
                                        case StringConstants.NOTIFICATION_MSG:
                                            jobsToUpdate.Notification_Msg = jobFromSource.Notification_Msg;
                                            break;
                                        case StringConstants.EXCLUDE_CALENDAR:
                                            jobsToUpdate.Exclude_Calendar = jobFromSource.Exclude_Calendar;
                                            break;
                                        case StringConstants.STD_IN_FILE:
                                            jobsToUpdate.Std_In_File = jobFromSource.Std_In_File;
                                            break;
                                        case StringConstants.JOB_TERMINATOR:
                                            jobsToUpdate.Job_terminator = jobFromSource.Job_terminator;
                                            break;
                                        case StringConstants.WIN_LOG_NAME:
                                            jobsToUpdate.Win_log_name = jobFromSource.Win_log_name;
                                            break;
                                        case StringConstants.WIN_EVENT_TYPE:
                                            jobsToUpdate.Win_event_type = jobFromSource.Win_event_type;
                                            break;
                                        case StringConstants.WIN_EVENT_ID:
                                            jobsToUpdate.Win_event_id = jobFromSource.Win_event_id;
                                            break;
                                        case StringConstants.MIN_RUN_ALARM:
                                            jobsToUpdate.Min_run_alarm = jobFromSource.Min_run_alarm;
                                            break;

                                        default:
                                           
                                            continue;
                                    }
                                }

                                listOfExtractJobs23.Add(jobsToUpdate);
                            }                           
                        }

                        fileOperationsObj.PrintDataToOutputFile(listOfExtractJobs23, outputFileName);
                        break;


                    case "20":
                        List<FilteredJobs> listOfRegionJobs = new List<FilteredJobs>();
                        List<FilteredJobs> listOfBillerJobsToPrint = new List<FilteredJobs>();
                        List<string> listOfBillersInRegion = jilOperationsObj.GetListOfJobsWithBillerNames(inputFileName, ref listOfRegionJobs).Distinct().ToList<string>();
                        List<string> regionBillers = ConfigurationManager.AppSettings["RegionBillerList"].Split(',').ToList<string>();
                        regionBillers = regionBillers.Select(x => x.Trim()).ToList<string>();
                        string folderPath = ConfigurationManager.AppSettings["PathForCreatingJilFiles"].Trim();
                        Array.ForEach(Directory.GetFiles(folderPath), delegate (string path) { File.Delete(path); });

                        if (!Directory.Exists(folderPath + @"\Rollback\"))
                            Directory.CreateDirectory(folderPath + @"\Rollback\");
                        if (!Directory.Exists(folderPath + @"\Rollout\"))
                            Directory.CreateDirectory(folderPath + @"\Rollout\");

                        Array.ForEach(Directory.GetFiles(folderPath + @"\Rollback\"), delegate (string path) { File.Delete(path); });
                        Array.ForEach(Directory.GetFiles(folderPath + @"\Rollout\"), delegate (string path) { File.Delete(path); });

                        foreach (var biller in regionBillers)
                        {
                            List<FilteredJobs> billerJobsList = (from x in listOfRegionJobs where x.Insert_job.Contains(biller) select x).ToList<FilteredJobs>();

                            foreach (FilteredJobs item in billerJobsList)
                            {
                                item.Insert_job = item.Insert_job.Replace("insert_job", "update_job");
                            }
                            fileOperationsObj.PrintOnlyUpdateandMachineForBillers(billerJobsList, folderPath + @"\Rollback\" + biller + ".jil");

                            foreach (FilteredJobs item in billerJobsList)
                            {
                                if(item.Command.ToLower().Contains(@"\\nwdppasa01\"))
                                {
                                    item.Command = item.Command.Replace(@"\\nwdppasa01\", @"\\nwdppasa03\");
                                }
                                else if (item.Command.ToLower().Contains(@"\\nwdppasa02\"))
                                {
                                    item.Command = item.Command.Replace(@"\\nwdppasa02\", @"\\nwdppasa04\");
                                }
                                else if (item.Command.ToLower().Contains(@"\\nwippasa01\"))
                                {
                                    item.Command = item.Command.Replace(@"\\nwippasa01\", @"\\nwippasa03\");
                                }
                                else if (item.Command.ToLower().Contains(@"\\nwippasa02\"))
                                {
                                    item.Command = item.Command.Replace(@"\\nwippasa02\", @"\\nwippasa04\");
                                }
                                else if (item.Command.ToLower().Contains(@"\\nwcppasa01\"))
                                {
                                    item.Command = item.Command.Replace(@"\\nwcppasa01\", @"\\nwcppasa03\");
                                }
                                else if (item.Command.ToLower().Contains(@"\\nwcppasa02\"))
                                {
                                    item.Command = item.Command.Replace(@"\\nwcppasa02\", @"\\nwcppasa04\");
                                }
                                                                                                                          
                                // item.Insert_job = item.Insert_job.Replace("insert_job", "update_job");
                                if (item.Machine.ToLower().Contains("od_asa_alp") || item.Machine.ToLower().Contains("devasa") || item.Machine.ToLower().Contains("nwdppasa"))
                                {
                                    item.Machine = "machine: " + ConfigurationManager.AppSettings["2012DevASAMachineName"];
                                }
                               else if(item.Machine.ToLower().Contains("od_asa_bt1") || item.Machine.ToLower().Contains("staasa") || item.Machine.ToLower().Contains("nwippasa"))
                                {
                                    item.Machine = "machine: " + ConfigurationManager.AppSettings["2012StageASAMachineName"];
                                }
                                else if (item.Machine.ToLower().Contains("od_asa_bt2") || item.Machine.ToLower().Contains("ct1asa") || item.Machine.ToLower().Contains("nwcppasa"))
                                {
                                    item.Machine = "machine: " + ConfigurationManager.AppSettings["2012CtASAMachineName"];
                                }
                                else if (item.Machine.ToLower().Contains("od_cc_settlement_alp"))
                                {
                                    item.Machine = "machine: " + ConfigurationManager.AppSettings["2012DevCCSettlementMachineName"];
                                }
                                else if (item.Machine.ToLower().Contains("od_cc_settlement_bt1"))
                                {
                                    item.Machine = "machine: " + ConfigurationManager.AppSettings["2012StageCCSettlementMachineName"];
                                }
                                else if (item.Machine.ToLower().Contains("od_cc_settlement_bt2"))
                                {
                                    item.Machine = "machine: " + ConfigurationManager.AppSettings["2012CtCCSettlementMachineName"];
                                }
                                else if (item.Machine.ToLower().Contains("od_ach_settlement_alp"))
                                {
                                    item.Machine = "machine: " + ConfigurationManager.AppSettings["2012DevACHSettlementMachineName"];
                                }
                                else if (item.Machine.ToLower().Contains("od_ach_settlement_bt1"))
                                {
                                    item.Machine = "machine: " + ConfigurationManager.AppSettings["2012StageACHSettlementMachineName"];
                                }
                                else if (item.Machine.ToLower().Contains("od_ach_settlement_bt2"))
                                {
                                    item.Machine = "machine: " + ConfigurationManager.AppSettings["2012CtACHSettlementMachineName"];
                                }
                                else if (item.Machine.ToLower().Contains("od_processor_settlement_alp"))
                                {
                                    item.Machine = "machine: " + ConfigurationManager.AppSettings["2012DevProcessorSettlementMachineName"];
                                }
                                else if (item.Machine.ToLower().Contains("od_processor_settlement_bt1"))
                                {
                                    item.Machine = "machine: " + ConfigurationManager.AppSettings["2012StageProcessorSettlementMachineName"];
                                }
                                else if (item.Machine.ToLower().Contains("od_processor_settlement_bt2"))
                                {
                                    item.Machine = "machine: " + ConfigurationManager.AppSettings["2012CtProcessorSettlementMachineName"];
                                }
                                else if(item.Machine.ToLower().Contains("dppgwy") || item.Machine.ToLower().Contains("dpgwy"))
                                {
                                    item.Machine = "machine: " + ConfigurationManager.AppSettings["2012DevGWYMachineName"];
                                }
                                else if (item.Machine.ToLower().Contains("ippgwy") || item.Machine.ToLower().Contains("ipgwy"))
                                {
                                    item.Machine = "machine: " + ConfigurationManager.AppSettings["2012StageGWYMachineName"];
                                }
                                else if (item.Machine.ToLower().Contains("cppgwy") || item.Machine.ToLower().Contains("cpgwy"))
                                {
                                    item.Machine = "machine: " + ConfigurationManager.AppSettings["2012CtGWYMachineName"];
                                }                                
                            }


                            fileOperationsObj.PrintOnlyUpdateandMachineForBillers(billerJobsList, folderPath + @"\Rollout\" + biller + ".jil");                     
                        }



                        break;

                    //below is the case to extract or delete jobs from JIL based on provided job list.
                    case "18":
                        
                        string extractOrDeleteFilePath = ConfigurationManager.AppSettings["ExtractOrDeleteJobsTextFilePath"];
                        bool isDelete = ConfigurationManager.AppSettings["IsDelete"].ToLower().Equals("no") ? false : true ;
                        List<FilteredJobs> listOFilteredJobs18 = new List<FilteredJobs>();
                        List<string> listOfBillers18 = jilOperationsObj.GetListOfJobsWithBillerNames(inputFileName, ref listOFilteredJobs18).Distinct().ToList<string>();
                        List<FilteredJobs> listOfExtractJobs = new List<FilteredJobs>();
                        List<FilteredJobs> listOfDeleteJobs = new List<FilteredJobs>();
                        List<string> jobsInFile = File.ReadLines(extractOrDeleteFilePath).Where(x => !string.IsNullOrEmpty(x)).Select(x => x.Trim()).ToList<string>();
                        //int linesCount = File.ReadLines(extractOrDeleteFilePath).Count();
                        //string[] jobsInFile = new string[linesCount];
                        //jobsInFile = File.ReadLines(extractOrDeleteFilePath).Select(x => x.Trim()).ToArray<string>();
                        foreach (string job in jobsInFile)
                        {
                            if (isDelete)
                            {
                                FilteredJobs jobFromSource = (from x in listOFilteredJobs18 where x.Insert_job.Split(new string[] { "job_type" }, StringSplitOptions.None).First().Trim().Split(':')[1].Trim().Equals(job) select x).FirstOrDefault();
                                if (jobFromSource != null)
                                {
                                    listOfDeleteJobs.Add(jobFromSource);
                                    listOFilteredJobs18.Remove(jobFromSource);
                                }
                            }
                            else
                            {
                                FilteredJobs jobFromSource = (from x in listOFilteredJobs18 where x.Insert_job.Split(new string[] { "job_type" }, StringSplitOptions.None).First().Trim().Split(':')[1].Trim().Equals(job) select x).FirstOrDefault();
                                if (jobFromSource != null)
                                    listOfExtractJobs.Add(jobFromSource);
                            }
                        }

                        if (isDelete)
                        {
                            //foreach (var item in listOfDeleteJobs)
                            //{
                            //    listOFilteredJobs18.Remove(item);
                            //}

                            fileOperationsObj.PrintDataToOutputFile(listOFilteredJobs18, outputFileName);
                        }
                        else
                            fileOperationsObj.PrintDataToOutputFile(listOfExtractJobs, outputFileName);


                        break;                         


                   //below is the case to prepare biller wise JIL from config file in a folder with On-Ice seperated jobs per biller.
                    case "17":
                         List<string> listOfExtraJobs = new List<string>();
                        List<string> listOfJobsInFile = File.ReadAllLines(ConfigurationManager.AppSettings["JobListPath"]).Where(x => x != string.Empty).ToList<string>();
                         if (!Directory.Exists(ConfigurationManager.AppSettings["FolderPathForBillerWiseJil"] + @"\Active"))
                                Directory.CreateDirectory(ConfigurationManager.AppSettings["FolderPathForBillerWiseJil"] + @"\Active");
                            if (!Directory.Exists(ConfigurationManager.AppSettings["FolderPathForBillerWiseJil"] + @"\On_Ice"))
                                Directory.CreateDirectory(ConfigurationManager.AppSettings["FolderPathForBillerWiseJil"] + @"\On_Ice");
                            
                        Array.ForEach(Directory.GetFiles(@ConfigurationManager.AppSettings["FolderPathForBillerWiseJil"]), delegate(string path) { File.Delete(path); });
                        Array.ForEach(Directory.GetFiles(@ConfigurationManager.AppSettings["FolderPathForBillerWiseJil"] + @"\Active"), delegate(string path) { File.Delete(path); });
                        Array.ForEach(Directory.GetFiles(@ConfigurationManager.AppSettings["FolderPathForBillerWiseJil"] + @"\On_Ice"), delegate(string path) { File.Delete(path); });

                        List<FilteredJobs> listOfJobsFromJil = new List<FilteredJobs>();
                        List<FilteredJobs> listOfAllInOneJobsFromJil = new List<FilteredJobs>();
                        List<string> billersList = ConfigurationManager.AppSettings["BillerList"].Split(',').ToList<string>();
                        billersList = billersList.Select(x => x.Trim()).ToList<string>();
                        string dailyExtractFilePath = ConfigurationManager.AppSettings["DailyExtractFilePath"];
                        List<string> listOfBillers17 = jilOperationsObj.GetListOfJobsWithBillerNames(inputFileName, ref listOfJobsFromJil).Distinct().ToList<string>();                        
                        Dictionary<string, string> dictOfJobsWithLastRunDate = new Dictionary<string, string>();
                        Dictionary<string, string> dictOfJobsWithLastRunTimings = new Dictionary<string, string>();
                         Dictionary<string, string> dictOfJobsWithStartRunDate = new Dictionary<string, string>();
                        Dictionary<string, string> dictOfJobsWithStartRunTimings = new Dictionary<string, string>();

                        Dictionary<string, string> dictOfJobsWithStatus = GetDictionaryObjectOfJobFromExtractFile(dailyExtractFilePath, ref dictOfJobsWithLastRunDate, ref dictOfJobsWithLastRunTimings, ref dictOfJobsWithStartRunDate, ref dictOfJobsWithStartRunTimings);
                       

                        foreach (var biller in billersList)
                        {                            
                            List<FilteredJobs> listOfOnIceJobs = new List<FilteredJobs>();
                            List<FilteredJobs> listOfActiveJobs = new List<FilteredJobs>();
                            List<FilteredJobs> listOfJobsForBiller = (from x in listOfJobsFromJil where x.Insert_job.Contains(biller) select x).ToList<FilteredJobs>();
                            foreach (var job in listOfJobsForBiller)
                            {
                                string statusOfJob = dictOfJobsWithStatus[job.Insert_job.Split(new string[] { "job_type" }, StringSplitOptions.None).First().Trim().Split(':')[1].Trim()];
                                if (statusOfJob.Equals("OI"))
                                    listOfOnIceJobs.Add(job);
                                else
                                    listOfActiveJobs.Add(job);
                            }                          

                            string activeJobsOutputFilePath = ConfigurationManager.AppSettings["FolderPathForBillerWiseJil"] + @"\Active\" + biller + "_ActiveJobs.jil";
                            string onIceJobsOutputFilePath = ConfigurationManager.AppSettings["FolderPathForBillerWiseJil"] + @"\On_Ice\" + biller + "_OnIceJobs.jil";
                            fileOperationsObj.PrintDataToOutputFile(listOfActiveJobs, activeJobsOutputFilePath);
                            fileOperationsObj.PrintDataToOutputFile(listOfOnIceJobs, onIceJobsOutputFilePath);
                        }

                        foreach (var biller in billersList)
                        {
                            List<FilteredJobs> listOfJobsForBiller = (from x in listOfJobsFromJil where x.Insert_job.ToLower().Contains(biller.ToLower()) select x).ToList<FilteredJobs>();
                            listOfAllInOneJobsFromJil.AddRange(listOfJobsForBiller);
                            foreach (var job in listOfAllInOneJobsFromJil)
                            {
                                string jobName = job.Insert_job.Split(new string[] { "job_type" }, StringSplitOptions.None).First().Trim().Split(':').Last().Trim();
                                if (!listOfJobsInFile.Contains(jobName))
                                {
                                    if (jobName.Contains("bsl-"))
                                    {
                                        string bisJobName = jobName.Replace("bsl-app-od-", "bis-2-p-o-");
                                        if (!listOfJobsInFile.Contains(bisJobName))
                                            listOfExtraJobs.Add(jobName);
                                    }
                                    else
                                    {
                                        listOfExtraJobs.Add(jobName);
                                    }
                                }
                            }
                        }

                         string extraJobsOutputFile = ConfigurationManager.AppSettings["ExtraJobsOutputFile"];
                        if (File.Exists(extraJobsOutputFile))
                        {
                            FileStream extrafileStream = File.Open(extraJobsOutputFile, FileMode.Open);
                            extrafileStream.SetLength(0);
                            extrafileStream.Close();
                        }

                        fileOperationsObj.PrintDataToOutputFile(listOfAllInOneJobsFromJil.Distinct().ToList<FilteredJobs>(), ConfigurationManager.AppSettings["FolderPathForBillerWiseJil"] + @"\AllInOneJobs.jil");
                        fileOperationsObj.PrintDataToTextFileFromListOfString(listOfExtraJobs.Where(x => x != string.Empty).Distinct().ToList<string>(), extraJobsOutputFile);
                        break;
                     
                    //below is the case added to find out jobs which are mentioned in condition, box_success, box_failure but not present in JIL.
                    case "16":
                        List<FilteredJobs> listOfAllJobsInJilFile = new List<FilteredJobs>();
                        Regex regex = new Regex(@"\(.*?\)");
                        List<string> listOfBillers16 = jilOperationsObj.GetListOfJobsWithBillerNames(inputFileName, ref listOfAllJobsInJilFile).Distinct().ToList<string>();
                        List<string> listOfAllJobNames = listOfAllJobsInJilFile.Select(x => x.Insert_job.Split(new string[] { "job_type" }, StringSplitOptions.None).First().Trim().Split(':')[1].Trim()).ToList<string>();
                        List<string> listOfConditionJobNames = new List<string>();
                        List<string> listOfBoxSuccessJobNames = new List<string>();
                        List<string> listOfBoxFailureJobNames = new List<string>();
                        List<string> listOfBoxNames = new List<string>();
                        List<string> listOfJobsToWrite = new List<string>();

                        foreach (var job in listOfAllJobsInJilFile)
                        {
                            if (!string.IsNullOrEmpty(job.Condition))
                            {
                                string conditionValue = job.Condition.Split(':').Last().Trim();
                                List<string> jobsList = regex.Matches(conditionValue).Cast<Match>().Select(m => m.Value.Split(',').First().Trim()).ToList<string>();
                                foreach (var item in jobsList)
                                {
                                    if (item.Contains("bsl-"))
                                        listOfConditionJobNames.Add(item.Substring(item.LastIndexOf("bsl-")).Replace("(", string.Empty).Replace(")", string.Empty).Trim());
                                    else if (item.Contains("bis-"))
                                        listOfConditionJobNames.Add(item.Substring(item.LastIndexOf("bis-")).Replace("(", string.Empty).Replace(")", string.Empty).Trim());
                                    else
                                    {
                                        listOfConditionJobNames.Add(item.Replace("(", string.Empty).Replace(")", string.Empty).Trim());
                                    }
                                }
                            }
                        }

                        foreach (var job in listOfAllJobsInJilFile)
                        {
                            if (!string.IsNullOrEmpty(job.Box_Success))
                            {
                                string boxSuccessValue = job.Box_Success.Split(':').Last().Trim();
                                List<string> jobsList = regex.Matches(boxSuccessValue).Cast<Match>().Select(m => m.Value.Split(',').First().Trim()).ToList<string>();
                                foreach (var item in jobsList)
                                {
                                    if (item.Contains("bsl-"))
                                        listOfBoxSuccessJobNames.Add(item.Substring(item.LastIndexOf("bsl-")).Replace("(", string.Empty).Replace(")", string.Empty).Trim());
                                    else if (item.Contains("bis-"))
                                        listOfBoxSuccessJobNames.Add(item.Substring(item.LastIndexOf("bis-")).Replace("(", string.Empty).Replace(")", string.Empty).Trim());
                                    else
                                    {
                                        listOfBoxSuccessJobNames.Add(item.Replace("(", string.Empty).Replace(")", string.Empty).Trim());
                                    }
                                }
                            }
                        }

                        foreach (var job in listOfAllJobsInJilFile)
                        {
                            if (!string.IsNullOrEmpty(job.Box_Failure))
                            {
                                string boxFailureValue = job.Box_Failure.Split(':').Last().Trim();
                                List<string> jobsList = regex.Matches(boxFailureValue).Cast<Match>().Select(m => m.Value.Split(',').First().Trim()).ToList<string>();
                                foreach (var item in jobsList)
                                {
                                    if (item.Contains("bsl-"))
                                        listOfBoxFailureJobNames.Add(item.Substring(item.LastIndexOf("bsl-")).Replace("(", string.Empty).Replace(")", string.Empty).Trim());
                                    else if (item.Contains("bis-"))
                                        listOfBoxFailureJobNames.Add(item.Substring(item.LastIndexOf("bis-")).Replace("(", string.Empty).Replace(")", string.Empty).Trim());
                                    else
                                    {
                                        listOfBoxFailureJobNames.Add(item.Replace("(", string.Empty).Replace(")", string.Empty).Trim());
                                    }
                                }
                            }
                        }

                        foreach (var job in listOfAllJobsInJilFile)
                        {
                            if (!string.IsNullOrEmpty(job.Boxname))
                            {
                                string boxName = job.Boxname.Split(':').Last().Trim();
                                listOfBoxNames.Add(boxName);
                            }
                        }

                        listOfConditionJobNames = listOfConditionJobNames.Distinct().ToList<string>();
                        listOfBoxSuccessJobNames = listOfBoxSuccessJobNames.Distinct().ToList<string>();
                        listOfBoxFailureJobNames = listOfBoxFailureJobNames.Distinct().ToList<string>();
                        listOfBoxNames = listOfBoxNames.Distinct().ToList<string>();

                        foreach (var job in listOfConditionJobNames)
                        {
                            if (!listOfAllJobNames.Contains(job))
                                listOfJobsToWrite.Add("Condition: " + job);
                        }
                        foreach (var job in listOfBoxSuccessJobNames)
                        {
                            if (!listOfAllJobNames.Contains(job))
                                listOfJobsToWrite.Add("Box_Success: " + job);
                        }
                        foreach (var job in listOfBoxFailureJobNames)
                        {
                            if (!listOfAllJobNames.Contains(job))
                                listOfJobsToWrite.Add("Box_Failure: " + job);
                        }

                        foreach (var job in listOfBoxNames)
                        {
                            if (!listOfAllJobNames.Contains(job))
                                listOfJobsToWrite.Add("Box_Name: " + job);
                        }

                        fileOperationsObj.PrintDataToTextFileFromListOfString(listOfJobsToWrite, outputFileName);
                        break;


                    case "15":
                        List<FilteredJobs> listOFilteredJobs15 = new List<FilteredJobs>();
                        List<string> listOfBillers15 = jilOperationsObj.GetListOfJobsWithBillerNames(inputFileName, ref listOFilteredJobs15).Distinct().ToList<string>();
                        string devFilePath = ConfigurationManager.AppSettings["DevFileOutputPath"];
                        string stageFilePath = ConfigurationManager.AppSettings["StageFileOutputPath"];
                        string ctFilePath = ConfigurationManager.AppSettings["CtFileOutputPath"];
                        if (File.Exists(devFilePath))
                        {
                            FileStream fileStream = File.Open(devFilePath, FileMode.Open);
                            fileStream.SetLength(0);
                            fileStream.Close();
                        }
                        if (File.Exists(stageFilePath))
                        {
                            FileStream fileStream = File.Open(stageFilePath, FileMode.Open);
                            fileStream.SetLength(0);
                            fileStream.Close();
                        }
                        if (File.Exists(ctFilePath))
                        {
                            FileStream fileStream = File.Open(ctFilePath, FileMode.Open);
                            fileStream.SetLength(0);
                            fileStream.Close();
                        }

                        List<FilteredJobs> listOfDevJobs = (from x in listOFilteredJobs15 where (x.Owner.ToLower().Contains("dev_") || x.Owner.ToLower().Contains("nwd_")) && (x.Insert_job.ToLower().Contains("bsl-app-odalp-") || x.Insert_job.ToLower().Contains("bis-2-b-d-") || x.Insert_job.ToLower().Contains("bis-2-p-o-")) select x).ToList<FilteredJobs>();
                        List<FilteredJobs> listOfStageJobs = (from x in listOFilteredJobs15 where (x.Owner.ToLower().Contains("sta_") || x.Owner.ToLower().Contains("nwi_")) && (x.Insert_job.ToLower().Contains("bsl-app-odbt1-") || x.Insert_job.ToLower().Contains("bis-2-b-s-") || x.Insert_job.ToLower().Contains("bis-2-p-o-")) select x).ToList<FilteredJobs>();
                        List<FilteredJobs> listOfCtJobs = (from x in listOFilteredJobs15 where (x.Owner.ToLower().Contains("ct1_") || x.Owner.ToLower().Contains("nwc_")) && (x.Insert_job.ToLower().Contains("bsl-app-odbt2-") || x.Insert_job.ToLower().Contains("bis-2-b-c-") || x.Insert_job.ToLower().Contains("bis-2-p-o-")) select x).ToList<FilteredJobs>();
                        fileOperationsObj.PrintDataToOutputFile(listOfDevJobs.Distinct().ToList<FilteredJobs>(), devFilePath);
                        fileOperationsObj.PrintDataToOutputFile(listOfStageJobs.Distinct().ToList<FilteredJobs>(), stageFilePath);
                        fileOperationsObj.PrintDataToOutputFile(listOfCtJobs.Distinct().ToList<FilteredJobs>(), ctFilePath);

                        break;
                    case "12":
                        List<FilteredJobs> listOFilteredJobs12 = new List<FilteredJobs>();
                        List<FilteredJobs> jobsToWrite = new List<FilteredJobs>();
                        List<FilteredJobs> listOfJobsDeleted = new List<FilteredJobs>();
                        string deletedJobsFilePath = ConfigurationManager.AppSettings["DeletedJobsOutputFile"];
                        string isBoxWriteFirst = ConfigurationManager.AppSettings["IsBoxWriteFirst"];
                        if (File.Exists(deletedJobsFilePath))
                        {
                            FileStream fileStream = File.Open(deletedJobsFilePath, FileMode.Open);
                            fileStream.SetLength(0);
                            fileStream.Close();
                        }
                        string isDeleteOnly = ConfigurationManager.AppSettings["DeleteJobsOnly"].ToLower();
                        List<string> listOfBillers12 = jilOperationsObj.GetListOfJobsWithBillerNames(inputFileName, ref listOFilteredJobs12).Distinct().ToList<string>();
                        if (!string.IsNullOrEmpty(isDeleteOnly) && isDeleteOnly.Equals("no"))
                        {                            
                            foreach (FilteredJobs item in listOFilteredJobs12)
                            {
                                if (item.Insert_job.Contains(ConfigurationManager.AppSettings["RegionWiseBslSubstring"]))
                                {
                                    string jobName = item.Insert_job.Split(':')[1].Split(new string[] { "job_type" }, StringSplitOptions.None).First().Replace(ConfigurationManager.AppSettings["RegionWiseBslSubstring"], ConfigurationManager.AppSettings["RegionWiseBisSubstring"]).Trim();
                                    int count = (from x in listOFilteredJobs12 where x.Insert_job.Contains(jobName) select x.Insert_job).Count();
                                    if (count == 0)
                                    {                                       
                                        jobsToWrite.Add(item);
                                    }
                                }
                                else
                                {                                   
                                    jobsToWrite.Add(item);
                                }
                            }

                            foreach (var item in listOFilteredJobs12)
                            {
                                int count = (from x in jobsToWrite where x.Insert_job.Equals(item.Insert_job) select x).Count();
                                if (count > 1)
                                    jobsToWrite.Remove(item);
                            }
                        }
                        else if (!string.IsNullOrEmpty(isDeleteOnly) && isDeleteOnly.Equals("yes"))
                        {
                            List<string> listOfStringTODelete = new List<string>();
                            jobsToWrite.Clear();
                            listOfStringTODelete = ConfigurationManager.AppSettings["SearchStringToDelete"].Split(';').ToList<string>();
                            int countOfDelete = 0;
                            foreach (string str in listOfStringTODelete)
                            {
                                foreach (var item in listOFilteredJobs12)
                                {
                                    bool isBslJobsFound = item.Insert_job.Contains(ConfigurationManager.AppSettings["RegionWiseBslSubstring"]) && Regex.IsMatch(item.Insert_job, WildCardToRegular(str.Trim()));
                                    if (!isBslJobsFound)
                                    {
                                        if (!jobsToWrite.Contains(item))
                                            jobsToWrite.Add(item);
                                    }
                                    else
                                    {
                                        if(!listOfJobsDeleted.Contains(item))
                                            listOfJobsDeleted.Add(item);
                                    }
                                }

                                foreach (var item in listOfJobsDeleted)
                                {
                                    listOFilteredJobs12.Remove(item);
                                }

                                ++countOfDelete;
                                if(!countOfDelete.Equals(listOfStringTODelete.Count))
                                  jobsToWrite.Clear();
                            } 

                            foreach (var item in listOFilteredJobs12)
                            {
                                int count = (from x in jobsToWrite where x.Insert_job.Equals(item.Insert_job) select x).Count();
                                if (count > 1)
                                    jobsToWrite.Remove(item);
                            }                           
                        }

                        if (isBoxWriteFirst.Equals("yes"))
                        {
                            List<FilteredJobs> listOfAllBoxes = (from x in jobsToWrite.Distinct().ToList<FilteredJobs>() where x.Insert_job.Contains("job_type: BOX") select x).ToList<FilteredJobs>();
                            List<FilteredJobs> listOfAllCmdJobs = (from x in jobsToWrite.Distinct().ToList<FilteredJobs>() where x.Insert_job.Contains("job_type: CMD") select x).ToList<FilteredJobs>();

                            if(listOfAllBoxes.Count > 0)
                            fileOperationsObj.PrintDataToOutputFile(listOfAllBoxes.Distinct().ToList<FilteredJobs>(), outputFileName);

                            if(listOfAllCmdJobs.Count > 0)
                                fileOperationsObj.PrintDataToOutputFile(listOfAllCmdJobs.Distinct().ToList<FilteredJobs>(), outputFileName);

                        }
                        else
                        {
                            fileOperationsObj.PrintDataToOutputFile(jobsToWrite.Distinct().ToList<FilteredJobs>(), outputFileName);
                            fileOperationsObj.PrintDataToOutputFile(listOfJobsDeleted.Distinct().ToList<FilteredJobs>(), deletedJobsFilePath);
                        }
                        
                        break;

                    case StringConstants.FUNCTION_PERFORMED09:
                        SEMLogger.LogInformation("Performing function 9 of JilExtractUtility i.e. getting all data from JIL file into a CSV file.");
                        List<FilteredJobs> filteredJobs = new List<FilteredJobs>();
                        int billercount = 0;
                        JobDetail objJobDetail;
                        string billerName = string.Empty;
                        List<JobDetail> listOfJobDetail = new List<JobDetail>();
                        List<string> lines = new List<string>();
                        List<FilteredJobs> listOFilteredJobs = new List<FilteredJobs>();
                        string extractFilePath = ConfigurationManager.AppSettings["DailyExtractFilePath"];
                        if (extractFilePath.Contains("$$sysdate"))
                        {
                            dailyExtractFilePath = extractFilePath.Replace("$$sysdate", System.DateTime.Now.ToString("yyyyMMdd"));
                        }
                        SEMLogger.LogInformation("Getting job status from daily extract file...");
                        Dictionary<string, string> dictionaryOfJobsWithLastRunDate = new Dictionary<string, string>();
                        Dictionary<string, string> dictionaryOfJobsWithLastRunTimings = new Dictionary<string, string>();
                         Dictionary<string, string> dictionaryOfJobsWithStartRunDate = new Dictionary<string, string>();
                        Dictionary<string, string> dictionaryOfJobsWithStartRunTimings = new Dictionary<string, string>();

                        Dictionary<string, string> dictionaryOfJobsWithStatus = GetDictionaryObjectOfJobFromExtractFile(extractFilePath, ref dictionaryOfJobsWithLastRunDate, ref dictionaryOfJobsWithLastRunTimings, ref dictionaryOfJobsWithStartRunDate, ref dictionaryOfJobsWithStartRunTimings);                       
                        SEMLogger.LogInformation("Completed fetching all job status from daily extract file.");                        
                        List<string> listOfBillers = jilOperationsObj.GetBillerNamesListAndListOfAllJobs(inputFileName, ref listOFilteredJobs).Distinct().ToList<string>();

                        //listOfBillers.Clear();
                        //listOfBillers = ConfigurationManager.AppSettings["ListOfBillerTest"].Split(',').Select(x => x.Trim()).ToList();

                        #region tempcode
                        //below code is temporary and must be commented when not required


                        //List<string> listOfHours = new List<string>();
                        //foreach (var item in listOFilteredJobs)
                        //{
                        //    try
                        //    {
                        //        if (dictionaryOfJobsWithLastRunTimings[item.Insert_job].Contains(':'))
                        //            listOfHours.Add(dictionaryOfJobsWithLastRunTimings[item.Insert_job].Split(':').First().Trim());
                        //    }
                        //    catch (Exception ex)
                        //    {
                        //        if(ex.Message.Contains("given key"))
                        //        continue;
                        //    }
                        //}

                        //listOfHours = listOfHours.Distinct().ToList<string>();
                        //listOfHours.Sort();
                        //Dictionary<string, string> dictSpecificJobs = new Dictionary<string, string>();
                        //List<string> listOfJobsAsPerHours = new List<string>();
                        //List<string> listOfJobsToWriteWithHrs = new List<string>();
                        //List<string> listOfAllJobs = (from x in listOFilteredJobs select x.Insert_job).ToList<string>();
                        //foreach (var item in listOfAllJobs)
                        //{                           
                        //    try
                        //    {
                        //        dictSpecificJobs.Add((string)(from x in dictionaryOfJobsWithLastRunTimings where x.Key.Trim().Equals(item.Trim()) select x.Key).FirstOrDefault(), (string)(from x in dictionaryOfJobsWithLastRunTimings where x.Key.Trim().Equals(item.Trim()) select x.Value).FirstOrDefault());
                        //    }
                        //    catch (Exception)
                        //    {
                        //        continue;
                        //    }
                        //}


                        //foreach (var item in listOfHours)
                        //{                            
                        //    listOfJobsAsPerHours.Add("Hour " + item + ": ");
                        //    List<string> listOfPhaseJobs = (from x in dictSpecificJobs where x.Value.Trim().StartsWith(item) select x.Key.Trim()).Distinct().ToList<string>();
                        //    List<string> billers = new List<string>();
                        //    foreach (var job in listOfPhaseJobs)
                        //    {
                        //        if (job.StartsWith("bsl"))
                        //            billers.Add(job.Split('-')[5].Trim());
                        //        else if (job.StartsWith("bis"))
                        //            billers.Add(job.Split('-')[6].Trim());
                        //        else
                        //            billers.Add(job);
                        //    }

                        //    billers = billers.Distinct().ToList<string>();
                        //    listOfJobsAsPerHours.AddRange(billers);
                        //    int jobsCount = 0;
                        //    foreach (var biller in billers)
                        //    {
                        //        jobsCount += (from x in listOFilteredJobs where x.Insert_job.Contains("-" + biller + "-") select x).Count();
                        //    }
                        //    listOfJobsAsPerHours.Add(string.Format("Count of jobs for above billers in hours {0} is : {1}", item, jobsCount));                               
                        //}




                        //fileOperationsObj.PrintDataToTextFileFromListOfString(listOfJobsAsPerHours, @"D:\AutoSys Upgrade\Production JIL Development\Production JIL from jobs list\Phase-7\Phase-7_ListOfHours.txt");
                        ////temp code end
                        #endregion

                        foreach (var biller in listOfBillers)
                        {
                            Console.WriteLine(StringConstants.BILLERCOUNT_AND_PENDINGBILLERS, ++billercount, listOfBillers.Count - (billercount));
                            SEMLogger.LogInformation("Getting jil information for biller: {0}", biller);                            
                            filteredJobs.Clear();
                            foreach (var item in listOFilteredJobs)
                            {
                                string insertJobName = item.Insert_job;
                                List<string> listOfItemsInJob = insertJobName.Trim().Split('-').ToList<string>();
                                try
                                {
                                    if (insertJobName.StartsWith(StringConstants.BSL_JOBS_SUBSTRING))
                                    {
                                        if (listOfItemsInJob.Count >= 6)
                                            billerName = item.Insert_job.Split(StringConstants.SPLIT_WITH_HYPHEN)[5].Trim();

                                        if (billerName.Equals(biller))
                                            filteredJobs.Add(item);
                                    }
                                    else if (insertJobName.StartsWith(StringConstants.BIS_JOBS_SUBSTRING))
                                    {
                                        if (listOfItemsInJob.Count >= 6)
                                            billerName = insertJobName.Split(StringConstants.SPLIT_WITH_HYPHEN)[6].Trim();

                                        if (billerName.Equals(biller))
                                            filteredJobs.Add(item);
                                    }
                                    else
                                    {
                                        //insertJobName = string.Concat(insertJobName.TakeWhile(c => c != ' '));
                                        if (insertJobName.Equals(biller))
                                        {
                                            filteredJobs.Add(item);
                                        }
                                    }
                                }
                                catch (Exception ex)
                                {
                                    SEMLogger.LogError("Error while getting the information of jobs for biller : {0}. Please see below error message: \n {1}", biller, ex.Message);
                                    insertJobName = string.Concat(insertJobName.TakeWhile(c => c != ' '));
                                    if (insertJobName.Equals(biller))
                                        filteredJobs.Add(item);
                                    if (ex.Message.ToLower().Contains(StringConstants.INDEX))
                                        continue;
                                }
                            }

                            SEMLogger.LogInformation("Total no. of jobs found for biller: {0} is: {1}", biller, filteredJobs.Count);
                            
                                foreach (var item in filteredJobs)
                                {

                                    string sourceFilePath = string.Empty;
                                    string destFilePath = string.Empty;
                                    objJobDetail = new JobDetail();
                                    objJobDetail.BillerJobsCount = (from x in filteredJobs where x.Insert_job.Contains("-" + biller + "-") select x).ToList().Count;
                                    objJobDetail.RunDay = string.IsNullOrEmpty(item.Run_Day) ? "N/A" : item.Run_Day.Replace(StringConstants.COMMA, StringConstants.COLON).Trim();
                                    objJobDetail.Schedule = string.IsNullOrEmpty(item.Start_Times) ? "N/A" : item.Start_Times;
                                    objJobDetail.BillerName = biller.ToLower();
                                    objJobDetail.BoxName = string.IsNullOrEmpty(item.Boxname) ? "N/A" : item.Boxname;
                                    objJobDetail.Command = item.Command;
                                    objJobDetail.JobName = item.Insert_job;

                                    objJobDetail.StartRun = dictionaryOfJobsWithStartRunDate.ContainsKey(objJobDetail.JobName) ? dictionaryOfJobsWithStartRunDate[objJobDetail.JobName] : "N/A";
                                    objJobDetail.LastRun = dictionaryOfJobsWithLastRunDate.ContainsKey(objJobDetail.JobName) ? dictionaryOfJobsWithLastRunDate[objJobDetail.JobName] : "N/A";
                                    objJobDetail.JobStatus = dictionaryOfJobsWithStatus.ContainsKey(objJobDetail.JobName) ? dictionaryOfJobsWithStatus[objJobDetail.JobName] : "N/A";
                                    objJobDetail.StartRunTime = dictionaryOfJobsWithStartRunTimings.ContainsKey(objJobDetail.JobName) ? dictionaryOfJobsWithStartRunTimings[objJobDetail.JobName] : "N/A";
                                    objJobDetail.LastRunTime = dictionaryOfJobsWithLastRunTimings.ContainsKey(objJobDetail.JobName) ? dictionaryOfJobsWithLastRunTimings[objJobDetail.JobName] : "N/A";

                                    objJobDetail.Machine = item.Machine;
                                    objJobDetail.Owner = item.Owner;
                                    objJobDetail.Wrapper = string.IsNullOrEmpty(objJobDetail.Command) ? "N/A" : GetWrapperName(objJobDetail.Command);
                                    objJobDetail.Wrapper = string.IsNullOrEmpty(objJobDetail.Wrapper) ? "N/A" : objJobDetail.Wrapper;
                                    objJobDetail.JobType = string.IsNullOrEmpty(objJobDetail.Wrapper) ? "N/A" : GetJobType(objJobDetail.JobName);
                                    objJobDetail.JobType = string.IsNullOrEmpty(objJobDetail.JobType) ? "N/A" : objJobDetail.JobType;
                                    objJobDetail.FileName = string.IsNullOrEmpty(objJobDetail.Command) ? "N/A" : GetFileNameAndPath(objJobDetail.Command, ref sourceFilePath, ref destFilePath);
                                    objJobDetail.FileName = string.IsNullOrEmpty(objJobDetail.FileName) ? "N/A" : objJobDetail.FileName;
                                    objJobDetail.SourceFilePath = string.IsNullOrEmpty(sourceFilePath) ? "N/A" : sourceFilePath;
                                    objJobDetail.DestinationFilePath = string.IsNullOrEmpty(destFilePath) ? "N/A" : destFilePath;
                                    objJobDetail.N_Retry = string.IsNullOrEmpty(item.N_Retrys) ? "N/A" : item.N_Retrys;
                                    objJobDetail.Profile = string.IsNullOrEmpty(item.Profile) ? "N/A" : item.Profile;
                                    objJobDetail.Run_Calendar = string.IsNullOrEmpty(item.Run_Calendar) ? "N/A" : item.Run_Calendar;
                                    objJobDetail.Job_Load = string.IsNullOrEmpty(item.JobLoad) ? "N/A" : item.JobLoad;
                                    objJobDetail.Priority = string.IsNullOrEmpty(item.Priority) ? "N/A" : item.Priority;

                                    //adding new parameters to report
                                    objJobDetail.Condition = string.IsNullOrEmpty(item.Condition) ? "N/A" : item.Condition.Trim();
                                    objJobDetail.Box_Success = string.IsNullOrEmpty(item.Box_Success) ? "N/A" : item.Box_Success.Trim();
                                    objJobDetail.Box_Failure = string.IsNullOrEmpty(item.Box_Failure) ? "N/A" : item.Box_Failure.Trim();
                                    objJobDetail.TimeZone = string.IsNullOrEmpty(item.TimeZone) ? "N/A" : item.TimeZone.Trim();
                                    objJobDetail.Date_Condition = string.IsNullOrEmpty(item.DateCondition) ? "N/A" : item.DateCondition.Trim();
                                    objJobDetail.Application = string.IsNullOrEmpty(item.Application) ? "N/A" : item.Application;
                                    listOfJobDetail.Add(objJobDetail);
                                    sourceFilePath = string.Empty;
                                }
                        }

                        //fileOperationsObj.PrintJobCountOfBiller(@"C:\Users\ashish.chawda\Documents\Work\BilleJobsCount.txt", listOfJobDetail);
                        SEMLogger.LogInformation("Writing job contents to CSV/XLS file.");
                        DataTable jobDetailTable = fileOperationsObj.ConvertListToDataTable(listOfJobDetail);
                        ExcelCreator.Create(jobDetailTable, outputFileName);
                        //var valueLines = jobDetailTable.AsEnumerable().Select(row => string.Join(StringConstants.COMMA, row.ItemArray));
                        //lines.AddRange(valueLines);
                        //File.WriteAllLines(outputFileName, lines);
                        SEMLogger.LogInformation("Writing of job contents to CSV file finished.");
                        break;

                    case StringConstants.FUNCTION_PERFORMED10:
                        int billerCount = 0;
                        var billerIdPathList = File.ReadLines(ConfigurationManager.AppSettings[StringConstants.BILLERID_FILEPATH]).ToList();
                        var processIdPathList = File.ReadLines(ConfigurationManager.AppSettings[StringConstants.PROCESSID_FILEPATH]).ToList();
                        List<KeyValuePair<int, string>> billerPathlist = new List<KeyValuePair<int, string>>();
                        List<KeyValuePair<int, string>> processPathlist = new List<KeyValuePair<int, string>>();
                        foreach (var biller in billerIdPathList)
                        {
                            billerPathlist.Add(new KeyValuePair<int, string>(Convert.ToInt32(biller.Split(StringConstants.SPLIT_WITH_DOLLAR).First()), biller.Split(StringConstants.SPLIT_WITH_DOLLAR).Last()));
                        }
                        foreach (var process in processIdPathList)
                        {
                            processPathlist.Add(new KeyValuePair<int, string>(Convert.ToInt32(process.Split(StringConstants.SPLIT_WITH_DOLLAR).First()), process.Split(StringConstants.SPLIT_WITH_DOLLAR).Last()));
                        }

                        List<FilteredJobs> listOfilteredJobs = new List<FilteredJobs>();
                        List<string> listOfBillerNames = jilOperationsObj.GetBillerNamesListAndListOfAllJobs(inputFileName, ref listOfilteredJobs).Distinct().ToList<string>();
                        List<JobNameAndPaths> listOfJobNameAndPaths = new List<JobNameAndPaths>();
                        JobNameAndPaths jobNamePathObject;
                        List<string> linesForFilePathAndJob = new List<string>();
                        // List<FilteredJobs> listOfilteredJobs = GetListOfJobs(inputFileName);
                        List<FilteredJobs> filteredJobsForFilePath = new List<FilteredJobs>();
                        foreach (var biller in listOfBillerNames)
                        {
                            Console.WriteLine(StringConstants.BILLERCOUNT_AND_PENDINGBILLERS, ++billerCount, listOfBillerNames.Count - (billerCount));
                            filteredJobsForFilePath.Clear();
                            foreach (var item in listOfilteredJobs)
                            {
                                try
                                {
                                    if (item.Insert_job.Trim().Split(StringConstants.SPLIT_WITH_COLON)[1].Trim().StartsWith(StringConstants.BSL_JOBS_SUBSTRING))
                                    {
                                        billerName = item.Insert_job.Trim().Split(StringConstants.SPLIT_WITH_COLON)[1].Trim().Split(StringConstants.SPLIT_WITH_SPACE)[0].Trim().Split(StringConstants.SPLIT_WITH_HYPHEN)[5].Trim();
                                        if (billerName.Equals(biller))
                                            filteredJobsForFilePath.Add(item);
                                    }

                                    else if (item.Insert_job.Trim().Split(StringConstants.SPLIT_WITH_COLON)[1].Trim().StartsWith(StringConstants.BIS_JOBS_SUBSTRING))
                                    {
                                        billerName = item.Insert_job.Trim().Split(StringConstants.SPLIT_WITH_COLON)[1].Trim().Split(StringConstants.SPLIT_WITH_SPACE)[0].Trim().Split(StringConstants.SPLIT_WITH_HYPHEN)[6].Trim();
                                        if (billerName.Equals(biller))
                                            filteredJobsForFilePath.Add(item);
                                    }
                                }
                                catch (Exception ex)
                                {
                                    SEMLogger.LogError(ex.Message + "\nat function : " + System.Reflection.MethodBase.GetCurrentMethod().Name);
                                    if (ex.Message.ToLower().Contains(StringConstants.INDEX))
                                        continue;
                                }
                            }

                            foreach (var job in filteredJobsForFilePath)
                            {
                                jobNamePathObject = new JobNameAndPaths();
                                jobNamePathObject.BillerName = biller;
                                bool isFilePathFoundInBillerList = false;
                                foreach (var item in billerPathlist)
                                {
                                    try
                                    {
                                        if (job.Insert_job.ToLower().Trim().Split(StringConstants.SPLIT_WITH_COLON)[1].Trim().StartsWith(StringConstants.BSL_JOBS_SUBSTRING))
                                        {
                                            if (job.Insert_job.ToLower().Trim().Split(StringConstants.SPLIT_WITH_COLON)[1].Trim().Split(StringConstants.SPLIT_WITH_SPACE)[0].Trim().Split(StringConstants.SPLIT_WITH_HYPHEN)[3].Trim().Equals(item.Key.ToString()) && item.Value.ToString().ToLower().Contains(biller.ToLower()))
                                            {
                                                jobNamePathObject.FilePath = item.Value.ToString();
                                                isFilePathFoundInBillerList = true;
                                            }
                                        }
                                        else if (job.Insert_job.ToLower().Trim().Split(StringConstants.SPLIT_WITH_COLON)[1].Trim().StartsWith(StringConstants.BIS_JOBS_SUBSTRING))
                                        {
                                            if (job.Insert_job.ToLower().Trim().Split(StringConstants.SPLIT_WITH_COLON)[1].Trim().Split(StringConstants.SPLIT_WITH_SPACE)[0].Trim().Split(StringConstants.SPLIT_WITH_HYPHEN)[4].Trim().Equals(item.Key.ToString()) && item.Value.ToString().ToLower().Contains(biller.ToLower()))
                                            {
                                                jobNamePathObject.FilePath = item.Value.ToString();
                                                isFilePathFoundInBillerList = true;
                                            }
                                        }
                                    }
                                    catch (Exception ex)
                                    {
                                        SEMLogger.LogError(ex.Message + "\nat function : " + System.Reflection.MethodBase.GetCurrentMethod().Name);
                                        if (ex.Message.ToLower().Contains(StringConstants.INDEX))
                                            continue;
                                    }
                                }

                                foreach (var item in processPathlist)
                                {
                                    try
                                    {
                                        if (job.Insert_job.Trim().Split(StringConstants.SPLIT_WITH_COLON)[1].Trim().StartsWith(StringConstants.BSL_JOBS_SUBSTRING))
                                        {
                                            if (job.Insert_job.Trim().Split(StringConstants.SPLIT_WITH_COLON)[1].Trim().Split(StringConstants.SPLIT_WITH_SPACE)[0].Trim().Split(StringConstants.SPLIT_WITH_HYPHEN)[3].Trim().Equals(item.Key.ToString()) && item.Value.ToString().ToLower().Contains(biller.ToLower()) && !isFilePathFoundInBillerList)
                                                jobNamePathObject.FilePath = item.Value.ToString();
                                        }
                                        else if (job.Insert_job.Trim().Split(StringConstants.SPLIT_WITH_COLON)[1].Trim().StartsWith(StringConstants.BIS_JOBS_SUBSTRING))
                                        {
                                            if (job.Insert_job.Trim().Split(StringConstants.SPLIT_WITH_COLON)[1].Trim().Split(StringConstants.SPLIT_WITH_SPACE)[0].Trim().Split(StringConstants.SPLIT_WITH_HYPHEN)[4].Trim().Equals(item.Key.ToString()) && item.Value.ToString().ToLower().Contains(biller.ToLower()) && !isFilePathFoundInBillerList)
                                                jobNamePathObject.FilePath = item.Value.ToString();
                                        }
                                    }
                                    catch (Exception ex)
                                    {
                                        SEMLogger.LogError(ex.Message + "\nat function : " + System.Reflection.MethodBase.GetCurrentMethod().Name);
                                        if (ex.Message.ToLower().Contains(StringConstants.INDEX))
                                            continue;
                                    }
                                }

                                listOfJobNameAndPaths.Add(jobNamePathObject);
                            }
                        }

                        DataTable jobWithPathDetailTable = fileOperationsObj.ConvertFilePathListToDataTable(listOfJobNameAndPaths, ref linesForFilePathAndJob);
                        var valueLinesForJobAndFilePath = jobWithPathDetailTable.AsEnumerable().Select(row => string.Join(StringConstants.COMMA, row.ItemArray));
                        linesForFilePathAndJob.AddRange(valueLinesForJobAndFilePath);
                        File.WriteAllLines(outputFileName, linesForFilePathAndJob);
                        break;

                    case StringConstants.FUNCTION_PERFORMED11:

                        //int linesCount = File.ReadLines(@"C:\Users\achawda\Desktop\Informixfer.txt").Count();
                        //string[] lines1 = new string[linesCount];
                        //lines1 = File.ReadLines(@"C:\Users\achawda\Desktop\Informixfer.txt").ToArray<string>();
                        //List<string> listOFINformixferJobs = lines1.ToList<string>();

                        List<JobDetail> jobDetailList = new List<JobDetail>();
                        string outputFilePath = ConfigurationManager.AppSettings[StringConstants.OUTPUT_FILENAME_WITHPATH];
                        List<string> linesOfFile = new List<string>();
                        List<FilteredJobs> filteredJobsList = new List<FilteredJobs>();
                        List<FilteredJobs> listOfJobsPerBiller = new List<FilteredJobs>();
                        List<FilteredJobs> listOfMonthEndJobs = new List<FilteredJobs>();
                        List<string> billerList = jilOperationsObj.GetBillerNamesListAndListOfAllJobs(inputFileName, ref filteredJobsList).Distinct().ToList<string>();

                        int billersCount = 0;
                        DirectoryInfo directoryInfo = null;
                        DirectoryInfo dirInfo = new DirectoryInfo(outputFilePath);
                        foreach (FileInfo file in dirInfo.GetFiles())
                        {
                            file.Delete();
                        }
                        foreach (DirectoryInfo dir in dirInfo.GetDirectories())
                        {
                            foreach (var files in dir.GetFiles())
                            {
                                files.Delete();
                            }
                            dir.Delete();
                        }


                        foreach (var biller in billerList.Select(x => x.ToLower()))
                        {
                            List<FilteredJobs> listOfJObsToKeep = new List<FilteredJobs>();

                            Console.WriteLine(StringConstants.BILLERCOUNT_AND_PENDINGBILLERS, ++billersCount, billerList.Count - billersCount);
                            listOfJobsPerBiller = (from x in filteredJobsList
                                                   where
                                                       x.Insert_job.ToLower().Split(StringConstants.SPLIT_WITH_COLON)[1].Trim().StartsWith(StringConstants.BSL_JOBS_SUBSTRING) ?
                                                       (x.Insert_job.ToLower().Contains(StringConstants.BSL_JOBS_SUBSTRING) ? x.Insert_job.ToLower().Split(StringConstants.SPLIT_WITH_COLON)[1].Trim().Split(StringConstants.SPLIT_WITH_SPACE)[0].Trim().Split(StringConstants.SPLIT_WITH_HYPHEN)[5].Equals(biller) : x.Insert_job.Equals(string.Empty)) :
                                                       (x.Insert_job.ToLower().Contains(StringConstants.BIS_JOBS_SUBSTRING) ? x.Insert_job.ToLower().Split(StringConstants.SPLIT_WITH_COLON)[1].Trim().Split(StringConstants.SPLIT_WITH_SPACE)[0].Trim().Split(StringConstants.SPLIT_WITH_HYPHEN)[6].Equals(biller) : x.Insert_job.Equals(string.Empty))
                                                   select x).ToList<FilteredJobs>();
                            //if (biller.Equals("integrys"))
                            //{

                            //    foreach (var item in listOFINformixferJobs)
                            //    {
                            //        listOfJObsToKeep.Add((from x in listOfJobsPerBiller where x.Insert_job.Trim().Split(StringConstants.SPLIT_WITH_COLON)[1].Trim().Split(StringConstants.SPLIT_WITH_SPACE)[0].Trim().Equals(item) select x).SingleOrDefault());
                            //       // listOfJobsPerBiller.Remove((from x in listOfJobsPerBiller where x.Insert_job.Trim().Split(StringConstants.SPLIT_WITH_COLON)[1].Trim().Split(StringConstants.SPLIT_WITH_SPACE)[0].Trim().Equals(item) select x).SingleOrDefault());

                            //    }
                            //    listOfJobsPerBiller.Clear();
                            //    listOfJobsPerBiller = listOfJObsToKeep;
                            //}
                            directoryInfo = fileOperationsObj.CreateDirectory(outputFilePath + StringConstants.FORWARDSLASH + biller);
                            if (!(directoryInfo == null))
                            {
                                foreach (var jobs in listOfJobsPerBiller)
                                {
                                    if (jobs.Insert_job.ToLower().Contains(StringConstants.MEMO_SUBSTRING))
                                    {
                                        string memoRollbackPath = directoryInfo.FullName + StringConstants.FORWARDSLASH + biller + StringConstants.MEMO_ROLLBACK_FILE;
                                        string memoRolloutPath = directoryInfo.FullName + StringConstants.FORWARDSLASH + biller + StringConstants.MEMO_ROLLOUT_FILE;
                                        fileOperationsObj.CreateFile(memoRollbackPath);
                                        fileOperationsObj.CreateFile(memoRolloutPath);
                                        fileOperationsObj.AppendTextToFile(memoRollbackPath, memoRolloutPath, jobs);
                                    }
                                    else if (jobs.Insert_job.ToLower().Contains(StringConstants.MAM_SUBSTRING))
                                    {
                                        string mamRollbackPath = directoryInfo.FullName + StringConstants.FORWARDSLASH + biller + StringConstants.MAM_ROLLBACK_FILE;
                                        string mamRolloutPath = directoryInfo.FullName + StringConstants.FORWARDSLASH + biller + StringConstants.MAM_ROLLOUT_FILE;
                                        fileOperationsObj.CreateFile(mamRollbackPath);
                                        fileOperationsObj.CreateFile(mamRolloutPath);
                                        fileOperationsObj.AppendTextToFile(mamRollbackPath, mamRolloutPath, jobs);
                                    }
                                    else
                                    {
                                        if (!jobs.Insert_job.ToLower().Contains(StringConstants.MONTHEND_SUBSTRING))
                                        {
                                            string eodRollbackPath = directoryInfo.FullName + StringConstants.FORWARDSLASH + biller + StringConstants.EOD_ROLLBACK_FILE;
                                            string eodRolloutPath = directoryInfo.FullName + StringConstants.FORWARDSLASH + biller + StringConstants.EOD_ROLLOUT_FILE;
                                            fileOperationsObj.CreateFile(eodRollbackPath);
                                            fileOperationsObj.CreateFile(eodRolloutPath);
                                            fileOperationsObj.AppendTextToFile(eodRollbackPath, eodRolloutPath, jobs);
                                        }
                                    }
                                }
                            }
                        }

                        // for Just MonthEnd Jobs
                        List<string> billerListDummyForMOnthEndJobs = jilOperationsObj.GetBillerNamesListAndListOfAllJobs(inputFileName, ref listOfMonthEndJobs).Distinct().ToList<string>();
                        listOfMonthEndJobs = (from x in listOfMonthEndJobs where x.Insert_job.ToLower().Trim().Contains(StringConstants.MONTHEND_SUBSTRING) select x).ToList<FilteredJobs>();
                        directoryInfo = fileOperationsObj.CreateDirectory(outputFilePath + StringConstants.FORWARDSLASH + StringConstants.MONTHEND_FOLDER);
                        string monthEndRollbackPath = directoryInfo.FullName + StringConstants.FORWARDSLASH + StringConstants.MONTHEND_ROLLBACK_FILE;
                        string monthEndRolloutPath = directoryInfo.FullName + StringConstants.FORWARDSLASH + StringConstants.MONTHEND_ROLLOUT_FILE;

                        foreach (var job in listOfMonthEndJobs)
                        {
                            fileOperationsObj.CreateFile(monthEndRollbackPath);
                            fileOperationsObj.CreateFile(monthEndRolloutPath);
                            fileOperationsObj.AppendTextToFile(monthEndRollbackPath, monthEndRolloutPath, job);
                        }
                        break;
                    default:
                        Console.WriteLine(StringConstants.WRONG_INPUT);
                        return 4;
                }

                SEMLogger.LogInformation(StringConstants.EXECUTION_COMPLETED);
                Console.WriteLine(StringConstants.EXECUTION_COMPLETED);
                timer.Stop();
                Console.WriteLine("Time taken in for execution:  {0}", timer.Elapsed);
                Console.ReadLine();
                //while (Console.ReadKey(true).Key != ConsoleKey.Enter)
                //{
                //    Console.WriteLine(StringConstants.WRONG_INPUT_PRESS_ENTER);
                //}
            }
            catch (Exception ex)
            {
                result = 4;
                SEMLogger.LogError(ex.Message + "\nat function : " + System.Reflection.MethodBase.GetCurrentMethod().Name);
                Console.WriteLine(ex.Message);
            }

            SEMLogger.LogInformation("Return to autosys value: {0}", result);
            return result;
        }


        private static string GetFileNameAndPath(string command, ref string sourceFilePath, ref string destinationFilePath)
        {
          string fileName = string.Empty;
          try
          {              
              if (command.Contains("\\\\"))
              {
                  string result = string.Empty;
                  string path = string.Empty;
                  command = command.ToLower();
                  //string commandWithoutColon = command.Split(new string[] { "command:"}, StringSplitOptions.None).Last();
                  if (command.Contains("<yyyy>") || command.Contains("<mm>") || command.Contains("<dd>"))
                  {
                      command = command.Replace("<yyyy>", "YYYY");
                      command = command.Replace("<mm>", "MM");
                      command = command.Replace("<dd>", "DD");
                  }

                  if (command.Contains("filename"))
                  {
                      if (command.Contains("destinationfilepath") && command.Contains("isupload=0"))
                      {
                          destinationFilePath = command.Split(new string[] { "destinationfilepath=" }, StringSplitOptions.None).Last();
                          destinationFilePath = destinationFilePath.Replace("$$", "##");
                          destinationFilePath = string.Concat(destinationFilePath.TakeWhile((c) => c != '"'));
                          destinationFilePath = sourceFilePath.Replace("##", "$$");
                      }
                      if (command.Contains("destinationpath") && command.Contains("isupload=0"))
                      {
                          if (command.Contains("destinationpath="))
                          destinationFilePath = command.Split(new string[] { "destinationpath=" }, StringSplitOptions.None).Last();
                          else
                              destinationFilePath = command.Split(new string[] { "destinationpath " }, StringSplitOptions.None).Last();
                          destinationFilePath = destinationFilePath.Replace("$$", "##");
                          destinationFilePath = string.Concat(destinationFilePath.TakeWhile((c) => c != '"'));
                          destinationFilePath = destinationFilePath.Replace("##", "$$");
                      }
                      if (command.Contains("sourcepath"))
                      {
                          sourceFilePath = command.Split(new string[] { "sourcepath=" }, StringSplitOptions.None).Last();
                          sourceFilePath = sourceFilePath.Replace("$$", "##");
                          sourceFilePath = string.Concat(sourceFilePath.TakeWhile((c) => c != '$'));
                          sourceFilePath = sourceFilePath.Replace("##", "$$");
                      }
                      if (command.Contains("sourcefilepath"))
                      {
                          if(command.Contains("sourcefilepath="))
                          sourceFilePath = command.Split(new string[] { "sourcefilepath=" }, StringSplitOptions.None).Last();
                          else
                          sourceFilePath = command.Split(new string[] { "sourcefilepath " }, StringSplitOptions.None).Last();
                          sourceFilePath = sourceFilePath.Replace("$$", "##");
                          if(sourceFilePath.Contains("$"))
                          sourceFilePath = string.Concat(sourceFilePath.TakeWhile((c) => c != '$'));
                          else
                              sourceFilePath = string.Concat(sourceFilePath.TakeWhile((c) => c != '-'));
                          sourceFilePath = sourceFilePath.Replace("##", "$$");
                      }
                      if (command.Contains("destinationfilepath"))
                      {
                          if (command.Contains("destinationfilepath="))
                              destinationFilePath = command.Split(new string[] { "destinationfilepath=" }, StringSplitOptions.None).Last();
                          else
                              destinationFilePath = command.Split(new string[] { "destinationfilepath " }, StringSplitOptions.None).Last();
                          destinationFilePath = destinationFilePath.Replace("$$", "##");
                          if (destinationFilePath.Contains("$"))
                              destinationFilePath = string.Concat(destinationFilePath.TakeWhile((c) => c != '$'));
                         
                          destinationFilePath = destinationFilePath.Replace("##", "$$");
                      }

                      if(command.Contains("-filepath"))
                      {
                          sourceFilePath = command.Split(new string[] { "-filepath " }, StringSplitOptions.None).Last();
                          sourceFilePath = string.Concat(sourceFilePath.Trim().TakeWhile((c) => c != '-'));
                      }

                      if(command.Contains("filename="))
                      path = command.Split(new string[] { "filename=" }, StringSplitOptions.None).Last();
                      else if(command.Contains("filename "))
                          path = command.Split(new string[] { "filename " }, StringSplitOptions.None).Last();
                      result = string.Concat(path.TakeWhile((c) => c != '$'));
                  }
                  else
                  {
                      path = command.Substring(command.IndexOf("\\\\"));
                      if (!command.Contains("rename"))
                          path = path.Replace("\"", string.Empty).TrimEnd(new char[] { '\\' });
                      if (path.ToUpper().Contains("DO"))
                      {
                          if (command.Contains("rename"))
                          {
                              path = path.Trim().Split(new string[] { " \"" }, StringSplitOptions.None)[0];
                              path = path.Replace("\"", string.Empty).TrimEnd(new char[] { '\\' });
                          }
                          else
                          {
                              if ((command.Trim().StartsWith("copy") || command.Trim().StartsWith("move")) && path.Contains(" \\\\"))
                              destinationFilePath = path.Trim().Split(new string[] { " \\\\" }, StringSplitOptions.None)[1];
                              else if (command.Trim().StartsWith("for"))
                              {
                                  if (command.Contains("copy"))
                                  {
                                      if (command.Contains("copy "))
                                      destinationFilePath = path.Trim().Split(new string[] { "copy " }, StringSplitOptions.None)[1];
                                      else
                                          destinationFilePath = path.Trim().Split(new string[] { "copy" }, StringSplitOptions.None)[1];

                                      if(destinationFilePath.Contains(" \\\\"))
                                      destinationFilePath = destinationFilePath.Trim().Split(new string[] { " \\\\" }, StringSplitOptions.None)[1];
                                      destinationFilePath = string.Concat(destinationFilePath.TakeWhile((c) => c != '&'));
                                  }
                                  else if (command.Contains("move"))
                                  {
                                      if (command.Contains("move "))
                                      destinationFilePath = path.Trim().Split(new string[] { "move " }, StringSplitOptions.None)[1];
                                      else
                                          destinationFilePath = path.Trim().Split(new string[] { "move" }, StringSplitOptions.None)[1];

                                      if (destinationFilePath.Contains(" \\\\"))
                                      destinationFilePath = destinationFilePath.Trim().Split(new string[] { " \\\\" }, StringSplitOptions.None)[1];
                                      destinationFilePath = string.Concat(destinationFilePath.TakeWhile((c) => c != '&'));
                                  }
                              }
                             
                              path = path.Trim().Split(new string[] { " \\\\" }, StringSplitOptions.None)[0];                              
                          }

                          result = string.Concat(path.TakeWhile((c) => c != '/'));
                          sourceFilePath = result.Split('/')[0];
                          
                          result = Path.GetFileName(sourceFilePath);
                      }
                      else
                      {
                          if (command.Contains("rename"))
                          {
                              path = path.Trim().Split(new string[] { " \"" }, StringSplitOptions.None)[0];
                              path = path.Replace("\"", string.Empty).TrimEnd(new char[] { '\\' });
                          }


                          if ((command.Trim().StartsWith("copy") || command.Trim().StartsWith("move")) && path.Contains(" \\\\"))
                              destinationFilePath = path.Trim().Split(new string[] { " \\\\" }, StringSplitOptions.None)[1];

                          sourceFilePath = path.Trim().Split(new string[] { " \\\\" }, StringSplitOptions.None)[0];
                          if (sourceFilePath.Contains("-o"))
                              sourceFilePath = sourceFilePath.Split(new string[] { "-o" }, StringSplitOptions.None).First();

                          result = Path.GetFileName(sourceFilePath.Replace("/", string.Empty));
                          if (result.Contains(")"))
                              result = result.Split(new string[] { ")" }, StringSplitOptions.None).First();
                      }

                      if (result.Contains(' '))
                      {
                          string firstFileName = result.Split(' ')[0].Trim();
                          string secondFileName = result.Split(' ')[1].Trim();
                          if (!string.IsNullOrEmpty(secondFileName) && (secondFileName.Contains(firstFileName) || firstFileName.Contains(secondFileName)))
                              result = secondFileName;

                      }
                  }

                  if (result.Contains(' '))
                      result = result.Split(new string[] { " " }, StringSplitOptions.None).First();
                  fileName = result;
              }
              else
              {
                  if (command.Contains("folderpath"))
                  {
                      sourceFilePath = command.Split(new string[] { "folderpath=" }, StringSplitOptions.None).Last();
                      sourceFilePath = string.Concat(sourceFilePath.TakeWhile((c) => c != '$'));

                      fileName = command.Split(new string[] { "filename=" }, StringSplitOptions.None).Last();
                      fileName = string.Concat(fileName.TakeWhile((c) => c != '"'));
                  }
              }

              if (sourceFilePath.Contains(".exe "))
              {
                  sourceFilePath = string.Empty;
              }
              if (destinationFilePath.Contains(".exe "))
              {
                  destinationFilePath = string.Empty;
              }
          }
          catch (Exception ex)
          {
              SEMLogger.LogError(ex.Message + "\nat function : " + System.Reflection.MethodBase.GetCurrentMethod().Name);
              Console.WriteLine(ex.Message);
          }

            return fileName;
        }

        private static string GetJobType(string jobName)
        {
            string jobType = string.Empty;            
            if (jobName.ToLower().Contains("bdc"))
            {
                jobType = StringConstants.BDC_JOBTYPE;
            }
            else if (jobName.ToLower().Contains("rdc"))
            {
                jobType = StringConstants.RDC_JOBTYPE;
            }
            else if (jobName.ToLower().Contains("eod"))
            {
                jobType = StringConstants.EOD_JOBTYPE;
            }
            else if (jobName.ToLower().Contains("remit"))
            {
                jobType = StringConstants.REMIT_JOBTYPE;
            }
            else if (jobName.ToLower().Contains("ajb") && jobName.ToLower().Contains("settlement"))
            {
                jobType = StringConstants.AJBSETTLEMENT_JOBTYPE;
            }
            else if (jobName.ToLower().Contains("settlement"))
            {
                jobType = StringConstants.SETTLEMENT_JOBTYPE;
            }
            else if (jobName.ToLower().Contains("sleep"))
            {
                jobType = StringConstants.SLEEP_JOBTYPE;
            }
            else if (jobName.ToLower().Contains("mam"))
            {
                jobType = StringConstants.MAM_JOBTYPE;
            }
            else if (jobName.ToLower().Contains("memo"))
            {
                jobType = StringConstants.MEMO_JOBTYPE;
            }
            else if (jobName.ToLower().Contains("replcheck") || jobName.ToLower().Contains("replicationcheck") || jobName.ToLower().Contains("replicationchk"))
            {
                jobType = StringConstants.REPLCHK_JOBTYPE;
            }
            else if (jobName.ToLower().Contains("test"))
            {
                jobType = StringConstants.TEST_JOBTYPE;
            }
            else if (jobName.ToLower().Contains("move"))
            {
                jobType = StringConstants.MOVE_JOBTYPE;
            }
            else if (jobName.ToLower().Contains("rename"))
            {
                jobType = StringConstants.RENAME_JOBTYPE;
            }
            else if (jobName.ToLower().Contains("remove"))
            {
                jobType = StringConstants.REMOVE_JOBTYPE;
            }
            else if (jobName.ToLower().Contains("-del-") || jobName.ToLower().Contains("delete"))
            {
                jobType = StringConstants.DELETE_JOBTYPE;
            }
            else if (jobName.ToLower().Contains("copy"))
            {
                jobType = StringConstants.COPY_JOBTYPE;
            }
            else if (jobName.ToLower().Contains("upload"))
            {
                jobType = StringConstants.UPLOAD_JOBTYPE;
            }
            else if (jobName.ToLower().Contains("download"))
            {
                jobType = StringConstants.DOWNLOAD_JOBTYPE;
            }
            else if (jobName.ToLower().Contains("archive"))
            {
                jobType = StringConstants.ARCHIVE_JOBTYPE;
            }
            else if (jobName.ToLower().Contains("filerecheck"))
            {
                jobType = StringConstants.FILERECHECK_JOBTYPE;
            }
            else if (jobName.ToLower().Contains("filecheck"))
            {
                jobType = StringConstants.FILECHECK_JOBTYPE;
            }
            else if (jobName.ToLower().Contains("filedelivery"))
            {
                jobType = StringConstants.FILEDELIVERY_JOBTYPE;
            }
            else if (jobName.ToLower().Contains("filecreation"))
            {
                jobType = StringConstants.FILECREATION_JOBTYPE;
            }
            else if (jobName.ToLower().Contains("checkftp_as") || jobName.ToLower().Contains("checkftpas") || jobName.ToLower().Contains("checkftp-as") || jobName.ToLower().Contains("chkftp_as") || jobName.ToLower().Contains("chkftpas") )
            {
                jobType = StringConstants.CHECKFTPAS_JOBTYPE;
            }
            else if (jobName.ToLower().Contains("checkproce"))
            {
                jobType = StringConstants.CHECKPROCESSING_JOBTYPE;
            }
            else if (jobName.ToLower().Contains("checknas"))
            {
                jobType = StringConstants.CHECKNAS_JOBTYPE;
            }
            else if (jobName.ToLower().Contains("checkfile"))
            {
                jobType = StringConstants.CHECKFILE_JOBTYPE;
            }
            else if (jobName.ToLower().Contains("sent2ftp"))
            {
                jobType = StringConstants.SENT2FTP_JOBTYPE;
            }
            else if (jobName.ToLower().Contains("sendemail"))
            {
                jobType = StringConstants.SENDEMAIL_JOBTYPE;
            }
            else if (jobName.ToLower().Contains("chkprocfilntexist") || jobName.ToLower().Contains("checkprfilentexist") || jobName.ToLower().Contains("checkprocingfilentexist") || jobName.ToLower().Contains("chkprocfilentexist") || jobName.ToLower().Contains("chkproceingfilntexist"))
            {
                jobType = StringConstants.CHECKPROCESSINGNTEXIST_JOBTYPE;
            }
            

            return jobType;
        }

        private static string GetWrapperName(string command)
        {           
            string wrapperName = string.Empty;
            command = command.ToLower();
            //command = command.Replace("command:", string.Empty).Trim();
            try
            {

                if (command.Contains(".exe\""))
                {
                    command = command.Replace(".exe", ".exe#");
                    wrapperName = string.Concat(command.TakeWhile((c) => c != '#'));
                    if (wrapperName.ToUpper().Contains(@"C\"))
                    {
                        wrapperName = wrapperName.Substring(wrapperName.ToUpper().IndexOf(@"C\"));
                        wrapperName = Path.GetFileName(wrapperName);
                    }
                    else
                    {
                        try
                        {
                            wrapperName = Path.GetFileName(wrapperName);
                        }
                        catch (Exception)
                        {
                            if(wrapperName.Contains(@"\"))
                            wrapperName = wrapperName.Split(new string[] { @"\" }, StringSplitOptions.None).Last();                        
                        }
                    }

                }
                else if (command.Contains(".exe "))
                {
                    command = command.Replace(".exe ", ".exe#");
                    wrapperName = string.Concat(command.TakeWhile((c) => c != '#'));
                    if (wrapperName.ToUpper().Contains(@"C\"))
                    {
                        wrapperName = wrapperName.Substring(wrapperName.ToUpper().IndexOf(@"C\"));
                        wrapperName = Path.GetFileName(wrapperName);
                    }
                    else
                    {
                        try
                        {
                            wrapperName = Path.GetFileName(wrapperName);
                            if (wrapperName.Contains(' '))
                            {
                                string wrapper = wrapperName.Split(new string[] { " " }, StringSplitOptions.None).Last();
                                if (!wrapper.Contains(".exe"))
                                    wrapperName = wrapperName.Split(new string[] { " " }, StringSplitOptions.None).First();
                                else
                                    wrapperName = wrapper.Replace("(", string.Empty).Trim();
                            }
                        }
                        catch (Exception)
                        {
                            if (wrapperName.Contains(@"\"))
                                wrapperName = wrapperName.Split(new string[] { @"\" }, StringSplitOptions.None).Last();
                        }
                    }

                    // wrapperName = wrapperName.Substring(wrapperName.ToLower().IndexOf("command:") + 1);
                }
                else if (command.Contains(".exe"))
                {
                    try
                    {
                        wrapperName = Path.GetFileName(command);
                    }
                    catch (Exception)
                    { }
                }
                
                if (wrapperName.Contains(@"\"))
                    wrapperName = wrapperName.Split(new string[] { @"\" }, StringSplitOptions.None).Last();

                if (wrapperName.ToUpper().Contains("FOR "))
                {
                    wrapperName = wrapperName.Split(new string[] { "DO (" }, StringSplitOptions.None).Last();
                }

                if (wrapperName.ToLower().Contains("powershell"))
                {
                    wrapperName = command.Split(new string[] { "-file " }, StringSplitOptions.None).Last().Replace(".ps1", ".ps1#");
                    wrapperName = string.Concat(wrapperName.TakeWhile((c) => c != '#')).Replace("\"", string.Empty);
                    try
                    {
                        wrapperName = Path.GetFileName(wrapperName);
                    }
                    catch (Exception)
                    {                                
                    }

                    wrapperName = "PowerShell.exe " + wrapperName;
                }


                if (string.IsNullOrEmpty(wrapperName))
                {
                    command = command.Replace("\"", string.Empty);

                    if (command.Contains("do ( copy") || command.Contains("do (copy") || command.Contains("(copy") || command.Contains("( copy") || command.Trim().StartsWith("copy"))
                        wrapperName = "Copy";                    
                    else if (command.Contains("sleep.bat"))
                        wrapperName = "Sleep.bat";
                    else if (command.Contains("do ( move") || command.Contains("do (move") || command.Trim().StartsWith("move"))
                        wrapperName = "Move";
                    else if (command.Trim().StartsWith("del") || command.Trim().StartsWith("del ") || command.Contains("del ") || command.Contains("delete") || command.Contains("do ( del") || command.Contains("do (del"))
                    {
                        wrapperName = "Delete";
                        if (command.Contains(".bat"))
                        {
                            try
                            {
                                wrapperName = Path.GetFileName(command.Trim().Replace("\"", string.Empty));
                            }
                            catch (Exception)
                            {
                            }
                        }
                    }
                    else if (command.Contains("echo"))
                        wrapperName = "Echo";
                    else if (command.Contains("autorep"))
                        wrapperName = "Autorep";
                    else if (command.Contains("sendevent"))
                        wrapperName = "SendEvent";
                    else if (command.Contains("forecast"))
                        wrapperName = "Forecast";
                    else if (command.Contains("mkdir"))
                        wrapperName = "MkDir";
                    else if (command.Contains("rename ") || command.Contains("ren "))
                        wrapperName = "Rename";
                    else if (command.Trim().StartsWith("dir") || command.Trim().StartsWith("\"dir"))
                        wrapperName = "Dir";
                    else if (command.Contains("md ") && !command.Contains("cmd"))
                        wrapperName = "Md";
                    else if (command.Contains("rd "))
                        wrapperName = "Rd";
                    else if (command.Contains("job_depends"))
                        wrapperName = "Job_Depends";
                    else if (command.Contains("autocal_asc"))
                        wrapperName = "Autocal_Asc";
                    else if (command.Contains("autosys_generic"))  
                        wrapperName = "Autosys_Generic";
                    else if (command.Contains(@"7-zip\7z"))
                        wrapperName = "7-zip";
                    else
                    {
                        if (command.Contains(".bat"))
                        {
                            wrapperName = command.Trim().Split(new string[] { ".bat" }, StringSplitOptions.None).First().Trim().Replace("\"", string.Empty);
                            try
                            {
                                wrapperName = Path.GetFileName(wrapperName);
                                if (!wrapperName.Contains(".bat"))
                                    wrapperName = wrapperName + ".bat";
                            }
                            catch (Exception)
                            { }
                        }
                    }
                    
                }
            }
            catch (Exception ex)
            {
                SEMLogger.LogError(ex.Message + "\nat function : " + System.Reflection.MethodBase.GetCurrentMethod().Name);
                Console.WriteLine(ex.Message);
            }

            return wrapperName.Replace("\"", string.Empty).Trim();
        }

        private static String WildCardToRegular(String value)
        {
            return "^" + Regex.Escape(value).Replace("\\*", ".*") + "$";
        }


        private static Dictionary<string, string> GetDictionaryObjectOfJobFromExtractFile(string fileName, ref Dictionary<string, string> dictionaryOfJobsWithLastRunDates, ref Dictionary<string, string> dictionaryOfJobsWithLastRunTimings, ref Dictionary<string, string> dictionaryOfJobsWithStartRunDates, ref Dictionary<string, string> dictionaryOfJobsWithStartRunTimings)
        {
            Dictionary<string, string> dictionaryOfJobsAndItsStatus = new Dictionary<string, string>();
            try
            {
                var lines = File.ReadAllLines(@fileName).Select(x => x.Split(','));

                int count = lines.Count();
                var csvData = lines.Skip(3)
                           .SelectMany(x => x)
                           .Select((v, i) => new { Value = v, Index = i % count })
                           .Select(x => x.Value);
                foreach (var data in csvData)
                {
                    List<string> listOfItems = data.Split(' ').ToList<string>();
                    listOfItems.RemoveAll(x => x.Equals(string.Empty));
                    foreach (var item in listOfItems)
                    {
                        try
                        {
                            if (item.Length == 8 && item.Count(x => x == ':') > 1)
                            {
                                if (!dictionaryOfJobsWithStartRunTimings.ContainsKey(listOfItems[0].Trim()))
                                    dictionaryOfJobsWithStartRunTimings.Add(listOfItems[0].Trim(), item.Trim());
                                //break;
                            }
                            if (item.Length == 10 && item.Count(x => x == '/') > 1)
                            {
                                if(!dictionaryOfJobsWithStartRunDates.ContainsKey(listOfItems[0].Trim()))
                                    dictionaryOfJobsWithStartRunDates.Add(listOfItems[0].Trim(), item.Trim());                                
                            }    

                            if (item.Length == 2)
                            {
                                dictionaryOfJobsAndItsStatus.Add(listOfItems[0].Trim(), item.Trim());
                                break;
                            }
                        }
                        catch (Exception ex)
                        {
                            SEMLogger.LogError(ex.Message + "\nat function : " + System.Reflection.MethodBase.GetCurrentMethod().Name);
                            Console.WriteLine(ex.Message);
                        }
                    }
                    listOfItems.Reverse();
                    foreach (var item in listOfItems)
                    {
                        try
                        {                            
                            if (item.Length == 8 && item.Count(x => x == ':') > 1)
                            {
                                dictionaryOfJobsWithLastRunTimings.Add(listOfItems[listOfItems.Count - 1].Trim(), item.Trim());
                                //break;
                            }
                            if (item.Length == 10 && item.Count(x=> x=='/') > 1)
                            {
                                dictionaryOfJobsWithLastRunDates.Add(listOfItems[listOfItems.Count - 1].Trim(), item.Trim());
                                break;
                            }                            
                        }
                        catch (Exception ex)
                        {
                            SEMLogger.LogError(ex.Message + "\nat function : " + System.Reflection.MethodBase.GetCurrentMethod().Name);
                            Console.WriteLine(ex.Message);
                        }
                    }

                }
            }
            catch (Exception ex)
            {
                SEMLogger.LogError(ex.Message + "\nat function : " + System.Reflection.MethodBase.GetCurrentMethod().Name);
            }

            return dictionaryOfJobsAndItsStatus;
        }     
    }
}

