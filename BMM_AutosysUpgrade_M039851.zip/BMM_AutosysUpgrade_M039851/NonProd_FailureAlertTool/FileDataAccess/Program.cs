﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.IO;
using System.Configuration;
using SendEmail.Common;
using EmailServiceProxy = Fiserv.BillerSolutions.OnDemand.NotificationService.Proxy.EMailNotificationService;
using SEM.Logging;
using System.Globalization;

namespace FileDataAccess
{
    class Program
    {
        static int Main(string[] args)
        {
            int ReturnToAutoSys = 4;
            string startdate = string.Empty;
            string enddate = DateTime.Now.ToString("yyyy/MM/dd HH:mm:ss");
            int failurecount = 0;
            int CTfailurecount = 0;
            int Stagefailurecount = 0;
            int Devfailurecount = 0;
            int Genericfailurecount = 0;
            int counter = 0;
            int CustomBillerjobfailurecount = 0;
            

            string BillerNameList = string.Empty;

            try
            {
                SEMLogger logger = new SEMLogger(@"\FileDataAccess\log4net.config");

                string consolidatedMail = ConfigurationManager.AppSettings["Consolidated_Mail"];
                string ToEmail = ConfigurationManager.AppSettings["KEY_To_Email"];
                string Bcc = ConfigurationManager.AppSettings["KEY_To_BCC"];
                string CC = ConfigurationManager.AppSettings["KEY_To_CC"];
                string EMAILSUBJECT = ConfigurationManager.AppSettings["KEY_EMAILSUBJECT"];
                string EmailFormat = ConfigurationManager.AppSettings["KEY_EmailFormat"];

                string EmailTemplatePath = ConfigurationManager.AppSettings["KEY_EMAILTEMPLATEPATH"];
                string CTEmailTemplatePath = ConfigurationManager.AppSettings["KEY_CTEMAILTEMPLATEPATH"];
                string StageEmailTemplatePath = ConfigurationManager.AppSettings["KEY_StageEMAILTEMPLATEPATH"];
                string DevEmailTemplatePath = ConfigurationManager.AppSettings["KEY_DevEMAILTEMPLATEPATH"];
                string GenericEmailTemplatePath = ConfigurationManager.AppSettings["KEY_GenericEMAILTEMPLATEPATH"];
                string CustomEmailTemplatepath = ConfigurationManager.AppSettings["Key_CustomEmailTemplatePath"];

                string FromEmail = ConfigurationManager.AppSettings["KEY_From_Email"];
                string sourcelogfilepath = ConfigurationManager.AppSettings["Log_File_Path"];

                string failurefilepath = ConfigurationManager.AppSettings["Failure_File_Path"];
                string CTfailurefilepath = ConfigurationManager.AppSettings["CTFailure_File_Path"];
                string Stagefailurefilepath = ConfigurationManager.AppSettings["StageFailure_File_Path"];
                string Devfailurefilepath = ConfigurationManager.AppSettings["DevFailure_File_Path"];
                string Genericfailurefilepath = ConfigurationManager.AppSettings["GenericFailure_File_Path"];
                string Customfailurefilepath = ConfigurationManager.AppSettings["CustomFailure_File_Path"];

                string linecountfilepath = ConfigurationManager.AppSettings["Line_Scanned_count_Filepath"];
                string templogfilepath = ConfigurationManager.AppSettings["Temp_Log_File_Path"];

                string Custom_Mail = ConfigurationManager.AppSettings["KEY_Custom_Mail"];
                string Custom_Billername = ConfigurationManager.AppSettings["Custom_KEY_Billername"];

                string Custom_ToEmail = ConfigurationManager.AppSettings["Custom_KEY_To_Email"];
                string Custom_ToBCC = ConfigurationManager.AppSettings["Custom_KEY_To_BCC"];
                string Custom_ToCC = ConfigurationManager.AppSettings["Custom_KEY_To_CC"];
                string Custom_FromEmail = ConfigurationManager.AppSettings["Custom_KEY_From_Email"];
                
                bool consmailvalue = Convert.ToBoolean(consolidatedMail);
                bool customemailkey = Convert.ToBoolean(Custom_Mail);

                //File validadtion
                if (!File.Exists(failurefilepath))
                {
                    FileStream fs = File.Create(failurefilepath);
                    fs.Close();
                }
                else
                {
                    File.Delete(failurefilepath);
                    FileStream fs = File.Create(failurefilepath);
                    fs.Close();
                }

                if (!File.Exists(linecountfilepath))
                {
                    FileStream fs = File.Create(linecountfilepath);
                    fs.Close();
                }

                if (!File.Exists(CTfailurefilepath))
                {
                    FileStream fs = File.Create(CTfailurefilepath);
                    fs.Close();
                }
                else
                {
                    File.Delete(CTfailurefilepath);
                    FileStream fs = File.Create(CTfailurefilepath);
                    fs.Close();
                }

                if (!File.Exists(Stagefailurefilepath))
                {
                    FileStream fs = File.Create(Stagefailurefilepath);
                    fs.Close();
                }
                else
                {
                    File.Delete(Stagefailurefilepath);
                    FileStream fs = File.Create(Stagefailurefilepath);
                    fs.Close();
                }

                if (!File.Exists(Devfailurefilepath))
                {
                    FileStream fs = File.Create(Devfailurefilepath);
                    fs.Close();
                }
                else
                {
                    File.Delete(Devfailurefilepath);
                    FileStream fs = File.Create(Devfailurefilepath);
                    fs.Close();
                }

                if (!File.Exists(Genericfailurefilepath))
                {
                    FileStream fs = File.Create(Genericfailurefilepath);
                    fs.Close();
                }
                else
                {
                    File.Delete(Genericfailurefilepath);
                    FileStream fs = File.Create(Genericfailurefilepath);
                    fs.Close();
                }

                if (!File.Exists(Customfailurefilepath))
                {
                    FileStream fs = File.Create(Customfailurefilepath);
                    fs.Close();
                }
                else
                {
                    File.Delete(Customfailurefilepath);
                    FileStream fs = File.Create(Customfailurefilepath);
                    fs.Close();
                }



                ClsEmailProperties eobj = new ClsEmailProperties();
                ClsEmailFunctionality clsobjEF = new ClsEmailFunctionality();
                string Strbodypath = null;

                eobj.EmailTextFormats = EmailFormat;
                eobj.BillerID = 111;
                eobj.EmailSubject = EMAILSUBJECT + " | Start Date Time: " + startdate + " - End Date Time: " + enddate;
                eobj.attchmentPath = string.Empty;


                List<string> lines = new List<string>();
                List<string> CTlines = new List<string>();
                List<string> Stagelines = new List<string>();
                List<string> Devlines = new List<string>();
                List<string> Genericlines = new List<string>();
                List<string> Customlines = new List<string>();
                List<string> BillersName = new List<string>();

                BillersName = Custom_Billername.Split(',').ToList();

                File.Copy(sourcelogfilepath, templogfilepath, true);
                StreamReader logfile = new StreamReader(templogfilepath);

                

                StreamReader countfile = new StreamReader(linecountfilepath);

                string CounterLine = countfile.ReadLine();
                countfile.Close();
                if (CounterLine != null)
                {
                    string[] words = CounterLine.Split(',').ToArray<string>();
                    startdate = words[0].ToString();
                    DateTime dateTime = DateTime.Parse(startdate);
                    string justDateStr = dateTime.ToString("MM/dd/yyyy", CultureInfo.InvariantCulture);
                    string currentdate = DateTime.Now.ToString("MM/dd/yyyy");
                    if (currentdate == justDateStr)
                    {
                        counter = Convert.ToInt32(words[1]);
                    }
                    else
                    {
                        File.Delete(linecountfilepath);
                    }

                }
                else
                {
                    startdate = System.DateTime.Now.ToString("yyyy/MM/dd hh:mm:ss");
                }

                int skiplinevalue = counter;
                var texts = File.ReadLines(templogfilepath);

                foreach (string text in texts.Skip(skiplinevalue))
                {
                    if (text.Contains("STATUS: FAILURE") && text.Contains("JOB:"))
                    {
                        lines.Add(text);
                        failurecount++;

                    }
                    ++counter;
                }


                using (StreamWriter writetext = new StreamWriter(failurefilepath))
                {

                    foreach (var line in lines)
                    {

                        writetext.WriteLine(line);

                    }
                }

                if (customemailkey)
                {
                    eobj.EmailTo = Custom_ToEmail;
                    eobj.EmailBCC = Custom_ToBCC;
                    eobj.EmailToCC = Custom_ToCC;
                    eobj.EmailFrom = Custom_FromEmail;
                    var forcustomerrorlog = File.ReadLines(failurefilepath);
 
                    foreach (var item in BillersName)
                    {
                        var customerror = forcustomerrorlog;
                        foreach (string text in customerror)
                        {
                            if (text.Contains(item))
                            {
                                Customlines.Add(text);
                                CustomBillerjobfailurecount++;
                            }
                        }
                       
                    }
                    
                        
                   
                    
                   using (StreamWriter writetext = new StreamWriter(Customfailurefilepath))
                    {

                        foreach (var line in Customlines)
                        {

                            writetext.WriteLine(line);

                        }
                    }

                    if (new FileInfo(Customfailurefilepath).Length == 0)
                    {
                        eobj.EmailBody = "This hour does not have any failure" + "\n\n" + "Start Date Time: " + startdate + "\n\n" + "End Date Time: " + enddate + "\n\n\n" + "Regards, \n Autosys Upgrade Team";
                        ReturnToAutoSys = clsobjEF.SendEmail(eobj);
                    }

                    else
                        {
                            eobj.EmailSubject = "Custom Billers- " + EMAILSUBJECT + " | Start Date Time: " + startdate + " - End Date Time: " + enddate;
                            Strbodypath = CustomEmailTemplatepath;
                            string stremailbody= "Total job failure count for cutsom Billers: " + CustomBillerjobfailurecount + "\n\n" + "Start Date Time:" + startdate + "\n\n" + "End Date Time:" + enddate + "\n\n" + File.ReadAllText(Strbodypath) + "\n\n\n" + "Regards, \nAutosys Upgrade Team";
                            foreach (var item in BillersName)
                            {
                                BillerNameList = BillerNameList + item + "\n" ;  
                            }

                            eobj.EmailBody = "Custom Biller's List:\n " + BillerNameList + "\n" + stremailbody;
                            ReturnToAutoSys = clsobjEF.SendEmail(eobj);

                            if (ReturnToAutoSys == 0)
                            {

                                File.Delete(Customfailurefilepath);
                            }
                        }
                }

               
                    eobj.EmailTo = ToEmail;
                    eobj.EmailBCC = Bcc;
                    eobj.EmailToCC = CC;
                    eobj.EmailFrom = FromEmail;

                    if (consmailvalue)
                    {
                        eobj.EmailSubject = EMAILSUBJECT + " | Start Date Time: " + startdate + " - End Date Time: " + enddate;
                        if (new FileInfo(failurefilepath).Length == 0)
                        {
                            eobj.EmailBody = "This hour does not have any failure" + "\n\n" + "Start Date Time: " + startdate + "\n\n" + "End Date Time: " + enddate + "\n\n\n" + "Regards, \n Autosys Upgrade Team";
                            ReturnToAutoSys = clsobjEF.SendEmail(eobj);
                        }
                        else
                        {
                            Strbodypath = EmailTemplatePath;
                            eobj.EmailBody = "Total job failure count:" + failurecount + "\n\n" + "Start Date Time:" + startdate + "\n\n" + "End Date Time:" + enddate + "\n\n" + File.ReadAllText(Strbodypath) + "\n\n\n" + "Regards, \nAutosys Upgrade Team";
                            ReturnToAutoSys = clsobjEF.SendEmail(eobj);

                            if (ReturnToAutoSys == 0)
                            {

                                File.Delete(failurefilepath);
                            }
                        }
                    }
                    else
                    {
                        var forGenericerrorlog = File.ReadLines(failurefilepath);
                        foreach (string text in forGenericerrorlog)
                        {
                            if (!text.Contains("bis-2-b-c-") && !text.Contains("bsl-app-odbt2-") && !text.Contains("bis-2-b-s-") && !text.Contains("bsl-app-odbt1-") && !text.Contains("bis-2-b-d-") && !text.Contains("bsl-app-odalp-"))
                            {
                                Genericlines.Add(text);
                                Genericfailurecount++;
                            }

                        }
                        using (StreamWriter writetext = new StreamWriter(Genericfailurefilepath))
                        {

                            foreach (var line in Genericlines)
                            {

                                writetext.WriteLine(line);

                            }
                        }

                        var forCTerrorlog = File.ReadLines(failurefilepath);
                        foreach (string text in forCTerrorlog)
                        {
                            if (text.Contains("bis-2-b-c-") || text.Contains("bsl-app-odbt2-"))
                            {
                                CTlines.Add(text);
                                CTfailurecount++;
                            }

                        }
                        using (StreamWriter writetext = new StreamWriter(CTfailurefilepath))
                        {

                            foreach (var line in CTlines)
                            {

                                writetext.WriteLine(line);

                            }
                        }


                        var forStageerrorlog = File.ReadLines(failurefilepath);
                        foreach (string text in forStageerrorlog)
                        {
                            if (text.Contains("bis-2-b-s-") || text.Contains("bsl-app-odbt1-"))
                            {
                                Stagelines.Add(text);
                                Stagefailurecount++;
                            }

                        }
                        using (StreamWriter writetext = new StreamWriter(Stagefailurefilepath))
                        {

                            foreach (var line in Stagelines)
                            {

                                writetext.WriteLine(line);

                            }
                        }


                        var forDeverrorlog = File.ReadLines(failurefilepath);
                        foreach (string text in forDeverrorlog)
                        {
                            if (text.Contains("bis-2-b-d-") || text.Contains("bsl-app-odalp-"))
                            {
                                Devlines.Add(text);
                                Devfailurecount++;
                            }

                        }
                        using (StreamWriter writetext = new StreamWriter(Devfailurefilepath))
                        {

                            foreach (var line in Devlines)
                            {

                                writetext.WriteLine(line);

                            }
                        }

                        //send email if the failure occurs at CT
                        if (new FileInfo(CTfailurefilepath).Length == 0)
                        {
                            eobj.EmailSubject = "CT- " + EMAILSUBJECT + "for CT | Start Date Time: " + startdate + " - End Date Time: " + enddate;
                            eobj.EmailBody = "This hour does not have any failure on CT" + "\n\n" + "Start Date Time: " + startdate + "\n\n" + "End Date Time: " + enddate + "\n\n\n" + "Regards, \n Autosys Upgrade Team";
                            ReturnToAutoSys = clsobjEF.SendEmail(eobj);
                        }
                        else
                        {
                            eobj.EmailSubject = "CT- " + EMAILSUBJECT + "for CT | Start Date Time: " + startdate + " - End Date Time: " + enddate;
                            Strbodypath = CTEmailTemplatePath;
                            eobj.EmailBody = "Total job failure count on CT: " + CTfailurecount + "\n\n" + "Start Date Time:" + startdate + "\n\n" + "End Date Time:" + enddate + "\n\n" + File.ReadAllText(Strbodypath) + "\n\n\n" + "Regards, \nAutosys Upgrade Team";
                            ReturnToAutoSys = clsobjEF.SendEmail(eobj);

                            if (ReturnToAutoSys == 0)
                            {

                                File.Delete(CTfailurefilepath);
                            }
                        }

                        //send email if the failure occurs at stage
                        if (new FileInfo(Stagefailurefilepath).Length == 0)
                        {
                            eobj.EmailSubject = "Stage- " + EMAILSUBJECT + "for Stage | Start Date Time: " + startdate + " - End Date Time: " + enddate;
                            eobj.EmailBody = "This hour does not have any failure on CT" + "\n\n" + "Start Date Time: " + startdate + "\n\n" + "End Date Time: " + enddate + "\n\n\n" + "Regards, \n Autosys Upgrade Team";
                            ReturnToAutoSys = clsobjEF.SendEmail(eobj);
                        }
                        else
                        {
                            eobj.EmailSubject = "Stage- " + EMAILSUBJECT + "for Stage | Start Date Time: " + startdate + " - End Date Time: " + enddate;
                            Strbodypath = StageEmailTemplatePath;
                            eobj.EmailBody = "Total job failure count on Stage: " + Stagefailurecount + "\n\n" + "Start Date Time:" + startdate + "\n\n" + "End Date Time:" + enddate + "\n\n" + File.ReadAllText(Strbodypath) + "\n\n\n" + "Regards, \nAutosys Upgrade Team";
                            ReturnToAutoSys = clsobjEF.SendEmail(eobj);

                            if (ReturnToAutoSys == 0)
                            {

                                File.Delete(Stagefailurefilepath);
                            }
                        }

                        //send email if the failure occurs at Dev
                        if (new FileInfo(Devfailurefilepath).Length == 0)
                        {
                            eobj.EmailSubject = "Dev- " + EMAILSUBJECT + "for Dev | Start Date Time: " + startdate + " - End Date Time: " + enddate;
                            eobj.EmailBody = "This hour does not have any failure on Dev" + "\n\n" + "Start Date Time: " + startdate + "\n\n" + "End Date Time: " + enddate + "\n\n\n" + "Regards, \n Autosys Upgrade Team";
                            ReturnToAutoSys = clsobjEF.SendEmail(eobj);
                        }
                        else
                        {
                            eobj.EmailSubject = "Dev- " + EMAILSUBJECT + "for Dev | Start Date Time: " + startdate + " - End Date Time: " + enddate;
                            Strbodypath = DevEmailTemplatePath;
                            eobj.EmailBody = "Total job failure count on Dev: " + Devfailurecount + "\n\n" + "Start Date Time:" + startdate + "\n\n" + "End Date Time:" + enddate + "\n\n" + File.ReadAllText(Strbodypath) + "\n\n\n" + "Regards, \nAutosys Upgrade Team";
                            ReturnToAutoSys = clsobjEF.SendEmail(eobj);

                            if (ReturnToAutoSys == 0)
                            {

                                File.Delete(Devfailurefilepath);
                            }
                        }
                        //send email if the generic job failure occurs
                        if (new FileInfo(Genericfailurefilepath).Length == 0)
                        {
                            eobj.EmailSubject = "Wrong Naming Convention/Generic/System jobs- " + EMAILSUBJECT + "for CT | Start Date Time: " + startdate + " - End Date Time: " + enddate;
                            eobj.EmailBody = "This hour does not have any generic job failure" + "\n\n" + "Start Date Time: " + startdate + "\n\n" + "End Date Time: " + enddate + "\n\n\n" + "Regards, \n Autosys Upgrade Team";
                            ReturnToAutoSys = clsobjEF.SendEmail(eobj);
                        }
                        else
                        {
                            eobj.EmailSubject = "Wrong Naming Convention/Generic/System jobs- " + EMAILSUBJECT + "for CT | Start Date Time: " + startdate + " - End Date Time: " + enddate;
                            Strbodypath = GenericEmailTemplatePath;
                            eobj.EmailBody = "Total job failure count : " + CTfailurecount + "\n\n" + "Start Date Time:" + startdate + "\n\n" + "End Date Time:" + enddate + "\n\n" + File.ReadAllText(Strbodypath) + "\n\n\n" + "Regards, \nAutosys Upgrade Team";
                            ReturnToAutoSys = clsobjEF.SendEmail(eobj);

                            if (ReturnToAutoSys == 0)
                            {

                                File.Delete(Genericfailurefilepath);
                            }
                        }
                    }

                    string today = System.DateTime.Now.ToString("yyyy/MM/dd hh:mm:ss");
                    using (StreamWriter writetext = new StreamWriter(linecountfilepath))
                    {
                        writetext.WriteLine("{0},{1}", today, counter);

                    }


                }
            
            catch (Exception ex)
            {

                SEMLogger.LogError(ex.Message);
            }
            return ReturnToAutoSys;
        }
    }
}
