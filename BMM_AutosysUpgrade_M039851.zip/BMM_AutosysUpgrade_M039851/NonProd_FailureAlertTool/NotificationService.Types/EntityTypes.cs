﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace Fiserv.BillerSolutions.OnDemand.NotificationManagement.Types
{
    public class FileAttachment
    {
        public string Uri { get; set; }
        public string FriendlyName { get; set; }
    }

    public enum Result
    {
        Success = 1,
        NotFound = 2,
        Exception = 3
    }

    public class NotificationDetail
    {
        public int BillerId { get; set; }
        public string BillingAccount { get; set; }
        public string BillingSubAccount { get; set; }
        public TransactionDetail TransactionDetail { get; set; }
        public string EmailAddress { get; set; }
        public string PhoneNumber { get; set; }
        public string LanguageInd { get; set; }
    }

    public class EmailContent
    {
        public string FromAddress { get; set; }

        public string ToAddress { get; set; }
       
        public string MailBody { get; set; }

        public string Subject { get; set; }

        public List<FileAttachment> FileAttachment { get; set; }
    }


    public class NotificationTemplate
    {
        public string TemplateName { get; set; }
        public string TemplateUrl { get; set; }
        public bool AttachPrivacyPolicy { get; set; }
        public bool AttachTermsAndConditions { get; set; }
        public string TimeZoneAbbrevation { get; set; }
        public string BillerShortName { get; set; }
    }


    public class NotificationTemplateVariable
    {
        public string VariableName { get; set; }
        //public string VariableLevelFlag { get; set; }
        public bool IsBillerLevelVariable { get; set; }
        public string VariableValueEnglish { get; set; }

        public string VariableValueSpanish { get; set; }
    }

    public class NotificationTemplateDetail
    {
        public NotificationTemplate NotificationTemplate { get; set; }
        public List<NotificationTemplateVariable> NotificationTemplateVariables { get; set; }
    }

}
