﻿using System;
using System.Collections.Generic;
using System.Runtime.Serialization;

namespace Fiserv.BillerSolutions.OnDemand.NotificationManagement.Types
{
    [DataContract(Name = "NotificationConfiguration", Namespace = "fiserv.com/BillerSolutions/OnDemand/NotificationManagement/V20151215/GetConfiguration")]
    public class NotificationConfiguration
    {
        [DataMember(IsRequired = true)]
        public int BillerId { get; set; }

        [DataMember(IsRequired = true)]
        public int NotificationActivitySourceId { get; set; }

        [DataMember(IsRequired = true)]
        public string NotificationActivitySource { get; set; }

        [DataMember(IsRequired = true)]
        public int NotificationActivityTypeId { get; set; }

        [DataMember(IsRequired = true)]
        public string NotificationActivityType { get; set; }

        [DataMember(IsRequired = true)]
        public int NotificationChannelTypeId { get; set; }

        [DataMember(IsRequired = true)]
        public string NotificationChannelType { get; set; }

        [DataMember(IsRequired = true)]
        public int LookBackMinuteMin { get; set; }

        [DataMember(IsRequired = true)]
        public int LookBackMinuteMax { get; set; }

        [DataMember(IsRequired = true)]
        public int LookBackMinuteForFailed { get; set; }

        [DataMember(IsRequired = true)]
        public int MaxAttemptCount { get; set; }
    }


    [DataContract(Name = "GetNotificationResponse", Namespace = "fiserv.com/BillerSolutions/OnDemand/NotificationManagement/V20151215/GetConfiguration")]
    public class GetNotificationResponse : ResponseBase
    {
        [DataMember(IsRequired = true)]
        public SummaryResult Result { get; set; }

        [DataMember(IsRequired = true)]
        public string ResultDescription { get; set; }

        [DataMember(IsRequired = true)]
        public List<NotificationConfiguration> NotificationsConfigs { get; set; }

    }

    [DataContract(Name = "GetNotificationConfigRequest", Namespace = "fiserv.com/BillerSolutions/OnDemand/NotificationManagement/V20151215/GetConfiguration")]
    public class GetNotificationConfigRequest : RequestBase
    {
        [DataMember(IsRequired = true)]
        public int BillerId { get; set; }

        [DataMember(IsRequired = true)]
        public bool ReturnParentChildConfig { get; set; }

        [DataMember(IsRequired = false)]
        public List<AdditionalFilterCriteria> AdditionalFilterCriterias { get; set; }
    }

    public class AdditionalFilterCriteria
    {
        [DataMember(IsRequired = true)]
        public string FilterKey { get; set; }

        [DataMember(IsRequired = false)]
        public string FilterValue { get; set; }
    }

    [DataContract(Name = "NotificationActivityRequest", Namespace = "fiserv.com/BillerSolutions/OnDemand/NotificationManagement/V20151215/SendNotification")]
    public class NotificationActivityRequest : RequestBase, INotificationActivity
    {
        [DataMember(IsRequired = true)]
        public int BillerId { get; set; }

        [DataMember(IsRequired = false)]
        public string BillingAccount { get; set; }

        [DataMember(IsRequired = false)]
        public string BillingSubAccount { get; set; }

        [DataMember(IsRequired = true)]
        public int NotificationActivitySourceId { get; set; }

        [DataMember(IsRequired = true)]
        public int NotificationActivityTypeId { get; set; }
        
        [DataMember(IsRequired = false)]
        public string EmailAddress { get; set; }

        [DataMember(IsRequired = false)]
        public string LanguageInd { get; set; }

        [DataMember(IsRequired = false)]
        public string MobileNumber { get; set; }

        [DataMember(IsRequired = true)]
        public long TransactionReferenceId { get; set; }

        [DataMember(IsRequired = false)]
        public TransactionDetail TransactionDetail { get; set; }
    }

    [DataContract(Name = "NotificationActivityResponse", Namespace = "fiserv.com/BillerSolutions/OnDemand/NotificationManagement/V20151215/SendNotification")]
    public class NotificationActivityResponse : ResponseBase
    {
        [DataMember(IsRequired = true)]
        public SummaryResult Result { get; set; }

        [DataMember(IsRequired = true)]
        public string ResultDescription { get; set; }
    }

    [DataContract(Name = "RequestBase", Namespace = "fiserv.com/BillerSolutions/OnDemand/NotificationManagement/V20151215/Common")]
    public class RequestBase
    {
        [DataMember(IsRequired = true)]
        public string ApplicationName { get; set; }

        [DataMember(IsRequired = true)]
        public string UserName { get; set; }

        [DataMember(IsRequired = true)]
        public string MachineName { get; set; }

        [DataMember(IsRequired = true)]
        public string RequestGuid { get; set; }

        [DataMember(IsRequired = true)]
        public string SessionGuid { get; set; }

        [DataMember(IsRequired = true)]
        public DateTime RequestTimeStamp { get; set; }

    }

    [DataContract(Name = "ResponseBase", Namespace = "fiserv.com/BillerSolutions/OnDemand/NotificationManagement/V20151215/Common")]
    public class ResponseBase
    {
        [DataMember(IsRequired = true)]
        public string ApplicationName { get; set; }

        [DataMember(IsRequired = true)]
        public string UserName { get; set; }

        [DataMember(IsRequired = true)]
        public string RequestId { get; set; }

        [DataMember(IsRequired = true)]
        public string SessionId { get; set; }

        [DataMember(IsRequired = true)]
        public DateTime RequestTimeStamp { get; set; }

        [DataMember(IsRequired = true)]
        public DateTime ResponseTimeStamp { get; set; }

        [DataMember(IsRequired = true)]
        public string MachineName { get; set; }


    }

    [DataContract(Name = "SummaryResult", Namespace = "fiserv.com/BillerSolutions/OnDemand/NotificationManagement/V20151215/Common")]
    public enum SummaryResult
    {
        [EnumMember]
        UnKnown,

        [EnumMember]
        Success,

        [EnumMember]
        NotFound,

        [EnumMember]
        TimeOut,

        [EnumMember]
        Failed,

        [EnumMember]
        ValidationFailed,

        [EnumMember]
        DataAccessError,

        [EnumMember]
        InternalError,

        [EnumMember]
        OptOut,

    }

    public enum FrequencyEnd
    {
        [EnumMember]
        WhenCanceled,

        [EnumMember]
        OnDate,

        [EnumMember]
        AfterNumberOfOccurances,
    }

    [DataContract(Name = "SecureString", Namespace = "fiserv.com/BillerSolutions/OnDemand/NotificationManagement/V20151215/Common")]
    public partial class SecureString
    {
        [DataMember(IsRequired = true)]
        public string Value { get; set; }

        [DataMember(IsRequired = true)]
        public int MaskLength { get; set; }

        [DataMember(IsRequired = true)]
        public string MaskCharacter { get; set; }

        [DataMember(IsRequired = true)]
        public string MaskedValue
        {
            get
            {
                return this.MaskValue(Value);
            }
            set { }
        }

        private string MaskValue(string realValue)
        {
            string temp = string.Empty;
            const char maskChar = '*';

            if (realValue != null)
            {
                //16 Digits - Leave 4 real digits and replace remainder with mask.
                if (realValue.Length >= 8)
                {
                    temp = new string(maskChar, realValue.Length - 4);
                    temp += realValue.Substring(realValue.Length - 4, 4);

                }//Digits <=4 - Mask Complete Field(****) for ECV / CVV2 / code masking
                else if (realValue.Length <= 4)
                {
                    temp = new string(maskChar, realValue.Length);
                } //Anything else
                else
                {
                    int len = realValue.Length;
                    int digits = (len % 2 == 0 ? (len / 2) : ((len + 1) / 2));
                    temp = new string(maskChar, digits);
                    temp += realValue.Substring(digits, len - digits);
                }
            }
            return temp;
        }
    }

    public class PingReq : RequestBase
    {

    }

    public class PingResponse : ResponseBase
    {
        [DataMember(IsRequired = true)]
        public SummaryResult Result { get; set; }

        [DataMember(IsRequired = true)]
        public string ResultDescription { get; set; }

        [DataMember(IsRequired = false)]
        public string PingRsp { get; set; }
    }


    [DataContract(Name = "RefreshCacheRequest", Namespace = "fiserv.com/BillerSolutions/OnDemand/NotificationManagement/V20151215/Diagnostics")]
    public class RefreshCacheRequest : RequestBase
    {
        [DataMember(IsRequired = true)]
        public int BillerId { get; set; }
    }

    [DataContract(Name = "RefreshCacheResponse", Namespace = "fiserv.com/BillerSolutions/OnDemand/NotificationManagement/V20151215/Diagnostics")]
    public class RefreshCacheResponse : ResponseBase
    {
        [DataMember(IsRequired = true)]
        public SummaryResult Result { get; set; }

        [DataMember(IsRequired = true)]
        public string ResultDescription { get; set; }
    }

    [DataContract(Name = "TransactionDetail", Namespace = "fiserv.com/BillerSolutions/OnDemand/NotificationManagement/V20151215/SendNotification")]
    public class TransactionDetail
    {
        [DataMember(IsRequired = true)]
        public bool IsTransactionPassed { get; set; }

        [DataMember(IsRequired = false)]
        public PaymentDetail PaymentDetail { get; set; }

        [DataMember(IsRequired = false)]
        public FundingAccount FundingAccount { get; set; }

        [DataMember(IsRequired = false)]
        public BillDetail BillDetail { get; set; }
    }

    [DataContract(Name = "PaymentDetail", Namespace = "fiserv.com/BillerSolutions/OnDemand/NotificationManagement/V20151215/SendNotification")]
    public class PaymentDetail
    {
        [DataMember(IsRequired = false)]
        public decimal? PaymentAmount { get; set; }

        [DataMember(IsRequired = false)]
        public decimal? FeeAmount { get; set; }

        [DataMember(IsRequired = false)]
        public DateTime? PaymentDate { get; set; }

        [DataMember(IsRequired = false)]
        public string ConfirmationCode { get; set; }

        [DataMember(IsRequired = false)]
        public string ReferenceCode { get; set; }

        [DataMember(IsRequired = false)]
        public PaymentFrequency PaymentFrequency { get; set; }

        [DataMember(IsRequired = false)]
        public List<PaymentCustomData> PaymentCustomDataList { get; set; }

        [DataMember(IsRequired = false)]
        public DateTime? InitiationtDate { get; set; }

        [DataMember(IsRequired = false)]
        public DateTime? ModificationDate { get; set; }
    }

    [DataContract(Name = "PaymentFrequency", Namespace = "fiserv.com/BillerSolutions/OnDemand/NotificationManagement/V20151215/SendNotification")]
    public class PaymentFrequency
    {
        [DataMember(IsRequired = true)]
        public string FrequencyType { get; set; }
        
        [DataMember(IsRequired = true)]
        public int FrequencyInterval { get; set; }

        [DataMember(IsRequired = false)]
        public List<FrequencyAttribute> FrequencyAttributes { get; set; }

        [DataMember(IsRequired = true)]
        public FrequencyEnd FrequencyEnd { get; set; }

        [DataMember(IsRequired = false)]
        public int? FrequencyEndAfterOccurances { get; set; }

        [DataMember(IsRequired = false)]
        public DateTime? FrequencyEndOnDate { get; set; }
    }

    [DataContract(Name = "FrequencyAttribute", Namespace = "fiserv.com/BillerSolutions/OnDemand/NotificationManagement/V20151215/SendNotification")]
    public class FrequencyAttribute
    {
        [DataMember(IsRequired = false)]
        public string Attribute { get; set; }

        [DataMember(IsRequired = false)]
        public string Value { get; set; }
    }

    [DataContract(Name = "FundingAccount", Namespace = "fiserv.com/BillerSolutions/OnDemand/NotificationManagement/V20151215/SendNotification")]
    public class FundingAccount
    {
        [DataMember(IsRequired = false)]
        //public string LastFourDigits { get; set; }
        public string AcctLastFourDigits { get; set; }

        [DataMember(IsRequired = false)]
        public string PaymentCategory { get; set; }

        [DataMember(IsRequired = false)]
        public string PaymentMethod { get; set; }

        [DataMember(IsRequired = false)]
        public string NickName { get; set; }
    }

    [DataContract(Name = "BillDetail", Namespace = "fiserv.com/BillerSolutions/OnDemand/NotificationManagement/V20151215/SendNotification")]
    public class BillDetail
    {
        [DataMember(IsRequired = false)]
        public decimal? CurrentDue { get; set; }

        [DataMember(IsRequired = false)]
        public decimal? BalanceDue { get; set; }

        [DataMember(IsRequired = false)]
        public decimal? TotalDue { get; set; }

        [DataMember(IsRequired = false)]
        //public DateTime DueDate { get; set; }
        public DateTime PaymentDueDate { get; set; }
    }

    [DataContract(Name = "PaymentCustomData", Namespace = "fiserv.com/BillerSolutions/OnDemand/NotificationManagement/V20151215/SendNotification")]
    public class PaymentCustomData
    {
        [DataMember(IsRequired = false)]
        public string FieldName { get; set; }

        [DataMember(IsRequired = false)]
        public string FieldValue { get; set; }

    }

    public class TemplateConfiguration
    {
        [DataMember(IsRequired = true)]
        public string TemplateName { get; set; }

        [DataMember(IsRequired = true)]
        public string TemplateUrl { get; set; }
    }

    [DataContract(Name = "PoolNotificationActivityRequest", Namespace = "fiserv.com/BillerSolutions/OnDemand/NotificationManagement/V20151215/SendNotification")]
    public class PoolNotificationActivityRequest : RequestBase
    {
        [DataMember(IsRequired = true)]
        public List<PoolNotificationTransaction> NotificationTransactions { get; set; }

    }

    public interface INotificationActivity
    {
        [DataMember(IsRequired = true)]
        int BillerId { get; set; }

        [DataMember(IsRequired = false)]
        string BillingAccount { get; set; }

        [DataMember(IsRequired = false)]
        string BillingSubAccount { get; set; }

        [DataMember(IsRequired = true)]
        int NotificationActivitySourceId { get; set; }

        [DataMember(IsRequired = true)]
        int NotificationActivityTypeId { get; set; }

        [DataMember(IsRequired = false)]
        string EmailAddress { get; set; }

        [DataMember(IsRequired = false)]
        string MobileNumber { get; set; }

        //Accept for logging purpose only
        [DataMember(IsRequired = false)]
        long TransactionReferenceId { get; set; }

        [DataMember(IsRequired = false)]
        string LanguageInd { get; set; }

        [DataMember(IsRequired = false)]
        TransactionDetail TransactionDetail { get; set; }

    }

    [DataContract(Name = "PoolNotificationTransaction", Namespace = "fiserv.com/BillerSolutions/OnDemand/NotificationManagement/V20151215/SendNotification")]
    public class PoolNotificationTransaction : INotificationActivity
    {
        [DataMember(IsRequired = true)]
        public int BillerId { get; set; }

        [DataMember(IsRequired = false)]
        public string BillingAccount { get; set; }

        [DataMember(IsRequired = false)]
        public string BillingSubAccount { get; set; }


        [DataMember(IsRequired = true)]
        public int NotificationActivityTypeId { get; set; }

        [DataMember(IsRequired = true)]
        public int NotificationActivitySourceId { get; set; }

        [DataMember(IsRequired = true)]
        public int NotificationChannelTypeId { get; set; }

        [DataMember(IsRequired = true)]
        public long NotificationActivityQueueId { get; set; }

        [DataMember(IsRequired = false)]
        public string EmailAddress { get; set; }

        [DataMember(IsRequired = false)]
        public string MobileNumber { get; set; }

        [DataMember(IsRequired = false)]
        public string LanguageInd { get; set; }

        [DataMember(IsRequired = false)]
        public bool IsEmailNotificationOptedOut { get; set; }

        [DataMember(IsRequired = false)]
        public bool IsSMSNotificationOptedOut { get; set; }

        [DataMember(IsRequired = true)]
        public long TransactionReferenceId { get; set; }

        [DataMember(IsRequired = false)]
        public TransactionDetail TransactionDetail { get; set; }
    }

    public class PoolNotificationActivityResponse : ResponseBase
    {
        public List<PoolNotificationResponse> NotificationResponses { get; set; }

    }

    public class PoolNotificationResponse
    {
        [DataMember(IsRequired = true)]
        public SummaryResult Result { get; set; }

        [DataMember(IsRequired = true)]
        public string ResultDescription { get; set; }

        public long TransactionReferenceId { get; set; }
    }

    public class ConsumerOptOutRequest : RequestBase
    {
        [DataMember(IsRequired = true)]
        public int BillerId { get; set; }

        [DataMember(IsRequired = false)]
        public string BillingAccount { get; set; }

        [DataMember(IsRequired = true)]
        public int NotificationActivitySourceId { get; set; }

        [DataMember(IsRequired = true)]
        public int NotificationActivityTypeId { get; set; }

        [DataMember(IsRequired = true)]
        public List<NotificationChannelAddress> NotificationChannelAddresses { get; set; }
    }

    public class NotificationChannelAddress
    {
        [DataMember(IsRequired = true)]
        public string ChannelAddress { get; set; }

        [DataMember(IsRequired = true)]
        public string ChannelAddressType { get; set; }
    }

    public class ConsumerOptOutResponse : ResponseBase
    {
        public List<ConsumerNotificationOptOut> ConsumerNotificationsOptOut { get; set; }
    }

    public class ConsumerNotificationOptOut
    {
        [DataMember(IsRequired = true)]
        public int NotificationChannelTypeId { get; set; }

        [DataMember(IsRequired = true)]
        public int NotificationActivitySourceId { get; set; }

        [DataMember(IsRequired = true)]
        public int NotificationActivityTypeId { get; set; }

        [DataMember(IsRequired = true)]
        public DateTime DateOfOptOut { get; set; }

        [DataMember(IsRequired = false)]
        public string OptOutReason { get; set; }

        [DataMember(IsRequired = true)]
        public SummaryResult Result { get; set; }

        [DataMember(IsRequired = true)]
        public string ResultDescription { get; set; }
    }

}
