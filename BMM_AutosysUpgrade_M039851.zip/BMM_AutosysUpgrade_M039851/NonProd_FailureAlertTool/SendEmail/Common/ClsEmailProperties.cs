﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace SendEmail.Common
{
    public class ClsEmailProperties
    {
        int billerID;
        public int BillerID
        {
            get
            {
                return billerID;
            }
            set
            {
                billerID = value;
            }
        }

        string emailTo;
        public string EmailTo
        {
            get
            {
                return emailTo;
            }
            set
            {
                emailTo = value;
            }
        }

        string emailBcc;
        public string EmailBCC
        {
            get
            {
                return emailBcc;
            }
            set
            {
                emailBcc = value;
            }
        }

        string emailTocc;
        public string EmailToCC
        {
            get
            {
                return emailTocc;
            }
            set
            {
                emailTocc = value;
            }
        }

        string emailFrom;
        public string EmailFrom
        {
            get
            {
                return emailFrom;
            }
            set
            {
                emailFrom = value;
            }
        }
        string emailSubject;
        public string EmailSubject
        {
            get
            {
                return emailSubject;
            }
            set
            {
                emailSubject = value;
            }
        }

        string emailBody;
        public string EmailBody
        {
            get
            {
                return emailBody;
            }
            set
            {
                emailBody = value;
            }
        }

        public string MachineName
        {
            get
            {
                return MachineName;
            }
            set
            {
                MachineName = value;
            }
        }

        public string UserName
        {
            get
            {
                return UserName;
            }
            set
            {
                UserName = value;
            }
        }





        public string templatePath { get; set; }
        public string mailSubject { get; set; }
        public string isAttachments { get; set; }
        public string attchmentPath { get; set; }
        public string EmailTextFormats { get; set; }
    }
    public enum Result
    {
        Success = 1,
        NotFound = 2,
        Exception = 3
    }
}
