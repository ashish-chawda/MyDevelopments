﻿using System;
using System.Collections.Generic;
using System.IO;
using System.Linq;
using EmailServiceProxy = Fiserv.BillerSolutions.OnDemand.NotificationService.Proxy.EMailNotificationService;
using System.ServiceModel;
using Fiserv.BillerSolutions.OnDemand.NotificationManagement.Types;
using SEM.Logging;
using SEM.Framework;
using SendEmail.Common;
using System.Configuration;

namespace SendEmail.Common
{
    public class ClsEmailFunctionality
    {


        // Author: Nitin Patil
        // Created on : 14 Aug 2017
        //MOdified date:18 Sept 2017

        public int SendEmail(ClsEmailProperties eobj)
        {

            List<string> EmailToAddresses = new List<string>();
            List<string> EmailBCCAddresses = new List<string>();
            List<string> EmailToCCAddresses = new List<string>();


            try
            {
               
                    EmailToAddresses = eobj.EmailTo.Split(',').Select(sValue => sValue.Trim()).ToList();
                    if (eobj.EmailBCC != null && eobj.EmailBCC != string.Empty)
                        EmailBCCAddresses = eobj.EmailBCC.Split(',').Select(sValue => sValue.Trim()).ToList();


                    if (eobj.EmailToCC != null)
                        EmailToCCAddresses = eobj.EmailToCC.Split(',').Select(sValue => sValue.Trim()).ToList();

                    EmailServiceProxy.EmailNotificationRequest emailReq = new EmailServiceProxy.EmailNotificationRequest()
                    {
                        //Store data in email variables
                        ApplicationName = "Email Notification Management Service",
                        UserName = Environment.UserName,
                        MachineName = Environment.MachineName,
                        RequestGuid = Guid.NewGuid().ToString(),
                        RequestTimeStamp = DateTime.Now,
                        EmailFrom = eobj.EmailFrom,
                        EmailBody = eobj.EmailBody,
                        EmailSubject = eobj.EmailSubject,
                        BillerId=eobj.BillerID

                    };




                    emailReq.EmailTo = new List<EmailServiceProxy.EMailAddress>();

                    foreach (var emailid in EmailToAddresses)
                        emailReq.EmailTo.Add(new EmailServiceProxy.EMailAddress() { Address = emailid });

                    emailReq.EmailBcc = new List<EmailServiceProxy.EMailAddress>();
                    if (EmailBCCAddresses != null)
                    {
                        foreach (var emailid in EmailBCCAddresses)
                            emailReq.EmailBcc.Add(new EmailServiceProxy.EMailAddress() { Address = emailid });
                    }

                    emailReq.EmailCc = new List<EmailServiceProxy.EMailAddress>();
                    if (EmailToCCAddresses != null)
                    {
                        foreach (var emailid in EmailToCCAddresses)
                            emailReq.EmailCc.Add(new EmailServiceProxy.EMailAddress() { Address = emailid });
                    }

                    if (eobj.EmailTextFormats == "RichText")
                        emailReq.EmailFormat = Fiserv.BillerSolutions.OnDemand.NotificationService.Proxy.EMailNotificationService.EmailFormat.RichText;
                    else if (eobj.EmailTextFormats == "HTML")
                        emailReq.EmailFormat = Fiserv.BillerSolutions.OnDemand.NotificationService.Proxy.EMailNotificationService.EmailFormat.HTML;
                    else
                        emailReq.EmailFormat = Fiserv.BillerSolutions.OnDemand.NotificationService.Proxy.EMailNotificationService.EmailFormat.PlainText;

                    System.Net.ServicePointManager.ServerCertificateValidationCallback = new System.Net.Security.RemoteCertificateValidationCallback(AcceptAllCertifications);

                    var binding = new BasicHttpBinding(BasicHttpSecurityMode.Transport)
                    {
                        MaxBufferSize = 102400000,
                        MaxReceivedMessageSize = 102400000,
                        SendTimeout = TimeSpan.FromMilliseconds(60000)
                    };

                    binding.Security.Transport.ClientCredentialType = HttpClientCredentialType.None;

                    string StrEndPointAddress = ConfigurationManager.AppSettings["EndPointAddress"];


                    var address = new EndpointAddress(StrEndPointAddress);


                    using (var factory = new ChannelFactory<EmailServiceProxy.IEmailNotification>(binding, address))
                    {
                        var channel = factory.CreateChannel();
                        //var stp = Stopwatch.StartNew();
                        var res = channel.SendEmailNotification(emailReq);
                        if (res.Result == EmailServiceProxy.SummaryResult.Success)
                        {
                            SEMLogger.LogInformation("Response from email service: {0}: for billerID: {1}", res.ResultDescription, eobj.BillerID);
                            return 0;
                        }
                        else
                        {
                            SEMLogger.LogInformation("Response from email service: {0}: for billerID: {1}", res.ResultDescription, eobj.BillerID);
                            return 4;
                        }

                    }

                }
            

            catch (Exception ex)
            {


                SEMLogger.LogError("Thrown Exception {0}: BillerID: {1}", ex.Message, eobj.BillerID);
                return 4; // Return 4 if fails

            }

        }

        private static bool AcceptAllCertifications(object sender, System.Security.Cryptography.X509Certificates.X509Certificate certification, System.Security.Cryptography.X509Certificates.X509Chain chain, System.Net.Security.SslPolicyErrors sslPolicyErrors)
        {
            return true;
        }


    }
}
