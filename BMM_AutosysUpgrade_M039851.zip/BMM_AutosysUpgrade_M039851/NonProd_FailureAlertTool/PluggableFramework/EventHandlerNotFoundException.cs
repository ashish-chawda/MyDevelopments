﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace SEM.Framework
{
    public class EventHandlerNotFoundException : ApplicationException 
    {
        public EventHandlerNotFoundException(string message)
            : base(message)
        {
 
        }
    }
}
