﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Collections.Specialized;

namespace SEM.Framework
{
    public class SEMEventHandler : ISEMEventHandler 
    {
        public StringDictionary EventParameters { get; set; }

        public virtual EventStatus ExecuteEvent(SystemEventParameters Parameters)
        {
            return EventStatus.FAILED;  
        }

        public void ExtractEventParameters(string workItem)
        {
            if (!string.IsNullOrEmpty(workItem))
            {
                string[] parameters = workItem.Split(new char[] { '$' });
                EventParameters = new StringDictionary();
                foreach (string s in parameters)
                {
                    string[] str = s.Split(new char[] { '=' });
                    EventParameters.Add(str[0], str[1]);
                }
            }
        
          
        }
    }
}
