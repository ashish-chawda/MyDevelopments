﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace SEM.Framework
{
    public class SystemEventParameters
    {
        //public long EventId { get; set; }
        public Object Parameters { get; set; }
    }
}
