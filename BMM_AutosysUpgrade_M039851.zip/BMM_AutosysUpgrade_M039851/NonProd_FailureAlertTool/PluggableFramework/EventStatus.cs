﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace SEM.Framework
{
    public enum EventStatus
    {
        PENDING = 1,
        IN_PROGRESS=2,
        IDLE=3,
        //COMPLETE=4,
        COMPLETE = 0,
        //FAILED=5,
        FAILED = 4,
        AVAILABLE=6,
        FAILED_AVAILABLE=7,
        FAILED_UNAVAILABLE=8
    }
}
