﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using log4net;
using log4net.Appender;
using System.IO;

namespace SEM.Logging
{
    class ConcurrentMinimalLock : RollingFileAppender.MinimalLock
    {
        
       
        
        private string m_filename;
        private bool m_append;
        private Stream m_stream = null;
        private ConcurrentStream c_stream = null;
        public override void OpenFile(string filename, bool append, Encoding encoding)
        {
           
            m_filename = filename;
            m_append = append;
        }
        public override void CloseFile()
        {
            base.CloseFile();
        }
        public override Stream AcquireLock()
        {
            if (m_stream == null)
            {
                try
                {
                    using (CurrentAppender.SecurityContext.Impersonate(this))
                    {
                        //m_filename = m_filepath + datetime + fileExtension;
                        string directoryFullName = Path.GetDirectoryName(m_filename);
                        if (!Directory.Exists(directoryFullName))
                        {
                            Directory.CreateDirectory(directoryFullName);
                        }

                          c_stream = ConcurrentStream.GetInstance(m_filename, true, FileAccess.Write, FileShare.Read);
                       

                        m_stream = c_stream;
                        m_append = true;
                    }
                }
                catch (Exception e1)
                {
                    CurrentAppender.ErrorHandler.Error("Unable to acquire lock on file " + m_filename + ". " + e1.Message);
                }
            }
            return m_stream;
        }
        public override void ReleaseLock()
        {
            using (CurrentAppender.SecurityContext.Impersonate(this))
            {
                m_stream.Close();
                m_stream = null;
            }
        }
    }
}