﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace SEM.Logging
{
    public enum PathSelector
    {
        Error=1,
        Log=2,
        Trace=3
    };

    internal class CachedEntry
    {
        private byte[] buffer;
        private int offset;
        private int count;
        private PathSelector fileType;
        internal byte[] Buffer
        {
            get { return buffer; }
        }

        internal PathSelector FileType
        {
            get 
            { 
                return fileType; 
            }
            set
            {
                fileType= value; 
            }

           
        }

        internal int Offset
        {
            get { return offset; }
        }
        internal int Count
        {
            get { return count; }
        }
        internal CachedEntry(byte[] buffer, int offset, int count)
        {
            this.buffer = new byte[buffer.Length];
            buffer.CopyTo(this.buffer, 0);
            this.offset = offset;
            this.count = count;
        }

    }
}
