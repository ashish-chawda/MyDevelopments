using System;
//using System.Collections.Generic;
using System.Text;
using System.Xml;
using System.Xml.Serialization;
using System.IO;

namespace L4NLogging
{
    public class LogXMLSerializer
    {
        private static string utf8BytesToString(Byte[] bytes)
        {
            UTF8Encoding encoding = new UTF8Encoding();
            return encoding.GetString(bytes);
        }

        private static Byte[] stringToUTF8Bytes(String xmlString)
        {
            UTF8Encoding encoding = new UTF8Encoding();
            return encoding.GetBytes(xmlString);
        }

        private static string stripHeader(String xmlString)
        {
            string xmlNote = xmlString;
            xmlNote = xmlNote.Replace("<?xml version=\"1.0\"?>\r\n", "");
            return xmlNote;
        }

        public static string SerializeObject(object theObject)
        {
            try
            {
                if (theObject.GetType() == typeof(Exception))
                {
                    return theObject.ToString();
                }
                XmlSerializer xs = new XmlSerializer(theObject.GetType());
                MemoryStream stream = new MemoryStream();
                xs.Serialize(stream, theObject);

                string serializedXML = utf8BytesToString(stream.ToArray());

                serializedXML = MaskData(serializedXML);

                return stripHeader(serializedXML);
            }
            catch (Exception e)
            {
                return "Object cannot be serialized into XML string: " + e.Message +
                  " Object.ToString(): " + theObject.ToString();
            }
        }

        public static object DeserializeObject(string xmlString, Type type)
        {
            try
            {
                XmlSerializer xs = new XmlSerializer(type);
                MemoryStream stream = new MemoryStream(stringToUTF8Bytes(xmlString));
                XmlTextReader xmlReader = new XmlTextReader(stream);
                return xs.Deserialize(xmlReader);
            }
            catch (Exception e)
            {
                return "XML string cannot be deserialized into object: " + e.Message;
            }
        }

        #region Commented

        //private static string MaskData(string requestXML)
        //{
        //    XmlDocument originalDoc = new XmlDocument();
        //    originalDoc.LoadXml(requestXML);

        //    XmlDocument originalCopyDoc = new XmlDocument();
        //    originalCopyDoc.LoadXml(requestXML);

        //    XmlNodeList chlist = originalDoc.GetElementsByTagName("ClientHeader");
        //    for (int c = 0; c < chlist.Count; c++)
        //    {
        //        chlist[c].RemoveAll();
        //    }

        //    XmlNodeList rhlist = originalDoc.GetElementsByTagName("RequestHeader");
        //    for (int r = 0; r < rhlist.Count; r++)
        //    {
        //        rhlist[r].RemoveAll();
        //    }

        //    XmlNodeList resphlist = originalDoc.GetElementsByTagName("ResponseHeader");
        //    for (int p = 0; p < resphlist.Count; p++)
        //    {
        //        resphlist[p].RemoveAll();
        //    }

        //    XmlNodeList shlist = originalDoc.GetElementsByTagName("ServiceHeader");
        //    for (int s = 0; s < shlist.Count; s++)
        //    {
        //        shlist[s].RemoveAll();
        //    }


        //    XmlNodeList list = originalDoc.SelectNodes("descendant::*");//.GetElementsByTagName("Value");
        //    for (int i = 0; i < list.Count; i++)
        //    {
        //        if(list[i].NodeType == XmlNodeType.Element && list[i].ChildNodes.Count == 1 && list[i].InnerText != string.Empty )
        //            list[i].InnerText = _maskValue(list[i].InnerText);
        //    }

        //    return originalDoc.OuterXml;
        //}

        private static string MaskData(string requestXML)
        {
            XmlDocument originalDoc = new XmlDocument();
            originalDoc.LoadXml(requestXML);

            XmlNodeList list = originalDoc.GetElementsByTagName("Value");
            for (int i = 0; i < list.Count; i++)
            {
                list[i].InnerText = _maskValue(list[i].InnerText);
            }

            return originalDoc.OuterXml;
        }

        //helper function to mask Check & CC/DB card values
        private static string _maskValue(string realValue)
        {
            string temp = string.Empty;
            char _maskChar = '*';

            //16 Digits - Leave 4 real digits and replace remainder with mask.
            if (realValue.Length >= 8)
            {
                temp = new string(_maskChar, realValue.Length - 4);
                temp += realValue.Substring(realValue.Length - 4, 4);

            }//Digits <=4 - Mask Complete Field(****) for ECV / CVV2 / code masking
            else if (realValue.Length <= 4)
            {
                temp = new string(_maskChar, realValue.Length);
            } //Anything else
            else
            {
                int len = realValue.Length;
                int digits = (len % 2 == 0 ? (len / 2) : ((len + 1) / 2));
                temp = new string(_maskChar, digits);
                temp += realValue.Substring(digits, len - digits);
            }
            return temp;
        }

        #endregion
    }
}
