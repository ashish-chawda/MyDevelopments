﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using log4net;
using System.IO;

namespace SEM.Logging
{

    public class ConcurrentStream : Stream, IDisposable
    {
        private string path;       
        private bool append;
        private FileAccess access;
        private FileShare share;
        private QueueManager queueManager;
        private Stream m_realStream = null;       
        private int m_readTotal = -1;
        private ConcurrentMinimalLock m_lockingModel;
        private static ConcurrentStream instance;
       

        public static ConcurrentStream GetInstance(string path,bool append, FileAccess access, FileShare share)
        {
            if (path.Contains("Error_"))
            {
                if (instance == null)
                {
                    instance = new ConcurrentStream(path, append, access, share);
                }
                else
                {
                    instance.Path = path;
                }               
                instance.queueManager.Error_filename = path;                
                return instance;
            }
            else if (path.Contains("Trace_"))
            {
                if (instance == null)
                {
                    instance = new ConcurrentStream(path, append, access, share);
                }                
                else
                {
                    instance.Path = path;
                }
                instance.queueManager.Trace_filename = path;
                return instance;
            }   
            else 
            {
                if (instance == null)
                {
                    instance = new ConcurrentStream(path, append, access, share);
                }               
                else
                {
                    instance.Path = path;
                }
                instance.queueManager.Log_filename = path;
                return instance;
            }                               
           
        }
        private ConcurrentStream(
         string path,
         bool append,
         FileAccess access,
         FileShare share
         )
        {
            this.path = path;
            this.append = append;
            this.access = access;
            this.share = share;
            this.queueManager = QueueManager.GetInstance(path, append, access, share);
        }
        public string Path
        {
            get { return path; }
            set { path = value; }
        }
        #region Override Implementation of Stream

        // Methods
        public override void Write(byte[] buffer, int offset, int count)
        {
            CachedEntry entry = new CachedEntry(buffer, offset, count);
            if (path.Contains("Error_"))
            {
                entry.FileType = PathSelector.Error;
            }
            if (path.Contains("Log_"))
            {
                entry.FileType = PathSelector.Log;
            }
            if (path.Contains("Trace_"))
            {
                entry.FileType = PathSelector.Trace;
            }
            queueManager.Enqueue(entry);
        }

       
        public override IAsyncResult BeginRead(byte[] buffer, int offset, int count, AsyncCallback callback, object state)
        {
            
            IAsyncResult ret = m_realStream.BeginRead(buffer, offset, count, callback, state);
            m_readTotal = EndRead(ret);
            return ret;
        }

        /// <summary>
        /// True asynchronous writes are not supported, the implementation forces a synchronous write.
        /// </summary>
        public override IAsyncResult BeginWrite(byte[] buffer, int offset, int count, AsyncCallback callback, object state)
        {
            
            IAsyncResult ret = m_realStream.BeginWrite(buffer, offset, count, callback, state);
            EndWrite(ret);
            return ret;
        }

        public override void Close()
        {
            m_lockingModel = new ConcurrentMinimalLock();
            m_lockingModel.CloseFile();
        }

        public override int EndRead(IAsyncResult asyncResult)
        {
            
            return m_readTotal;
        }
        public override void EndWrite(IAsyncResult asyncResult)
        {
            //No-op, it has already been handled
        }
        public override void Flush()
        {
            
            //m_realStream.Flush();
        }
        public override int Read(byte[] buffer, int offset, int count)
        {
            return m_realStream.Read(buffer, offset, count);
        }
        public override int ReadByte()
        {
            return m_realStream.ReadByte();
        }
        public override long Seek(long offset, SeekOrigin origin)
        {
            
            return m_realStream.Seek(offset, origin);
        }
        public override void SetLength(long value)
        {
            
            m_realStream.SetLength(value);
        }
        void IDisposable.Dispose()
        {
            this.Close();
        }
        
        public override void WriteByte(byte value)
        {
            
            m_realStream.WriteByte(value);
        }

        // Properties
        public override bool CanRead
        {
            get { return false; }
        }
        public override bool CanSeek
        {
            get
            {

                return true;
            }
        }
        public override bool CanWrite
        {
            get
            {
                
                return true;
            }
        }
        public override long Length
        {
            get
            {
                
                return m_realStream.Length;
            }
        }
        public override long Position
        {
            get
            {
                
                return 0;
            }
            set
            {
                
                m_realStream.Position = value;
            }
        }

        #endregion Override Implementation of Stream
       
    }
    
}
