﻿using System;
using System.IO;
using L4NLogging;

namespace SEM.Logging
{    
    public class SEMLogger
    {
        public static L4NLogger logger;
        public static L4NErrorLogger errorLogger;
        //logconfigPath = @"\log4net.config";
        
        public SEMLogger(string logconfigPath)
        {
            string folderName = System.Reflection.Assembly.GetExecutingAssembly().Location;
            folderName = folderName.Substring(0,folderName.LastIndexOf("\\"));

            string configFilePath = folderName + logconfigPath;

            //log4net.Config.XmlConfigurator.ConfigureAndWatch(new FileInfo(Environment.CurrentDirectory + logconfigPath));
            log4net.Config.XmlConfigurator.ConfigureAndWatch(new FileInfo(configFilePath));

            //log4net.Config.XmlConfigurator.ConfigureAndWatch(new FileInfo(logconfigPath));
            logger = L4NLogging.L4NLogger.CreateLogger();
            errorLogger = L4NLogging.L4NErrorLogger.CreateLogger();
        }    

        public static void LogInformation(string LogInfo)
        {
            logger.LogInformation("",LogInfo); 
        }        

        public static void LogInformation(string information, params object[] args)
        {
            string msg = string.Format(information, args);
            LogInformation(msg);
        }        

        /// <summary>
        /// Logs the error.
        /// </summary>
        /// <param name="errorMessage">The error message.</param>
        public static void LogError(string errorMessage)
        {
            errorLogger.LogError("", errorMessage);
        }

        /// <summary>
        /// Logs the error.
        /// </summary>
        /// <param name="errorMessage">The error message.</param>
        /// <param name="args">The args.</param>
        public static void LogError(string errorMessage, params object[] args)
        {  
            string msg = string.Format(errorMessage, args);
            LogError(msg);
        }
    }
}
