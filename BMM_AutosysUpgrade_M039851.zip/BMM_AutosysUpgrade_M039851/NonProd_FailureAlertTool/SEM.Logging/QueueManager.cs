﻿using System;
using System.Collections;
using System.Linq;
using System.Text;
using System.IO;
using System.Threading;
using log4net;
using System.Reflection;
using System;
using System.Configuration;

namespace SEM.Logging
{
    class QueueManager
    {
        
        private string path;        
        private bool append;
        private FileAccess access;
        private FileShare share;
        private static ILog logger;
        private Queue syncQueue = Queue.Synchronized(new Queue());
        private string m_error_filename;       
        private string m_log_filename;
        private string m_trace_filename;
        private bool running = false;
        private Random rnd = new Random();
        private DateTime retryTime = DateTime.MaxValue;

        private static TimeSpan RETRY_MAX_SPAN = TimeSpan.FromMinutes(1);        
        private static QueueManager instance;
        private const int MAX_BATCH_SIZE = 100;


        public static QueueManager GetInstance(string path,
            bool append,
            FileAccess access,
            FileShare share)
        {

            if (instance == null)
            {
                instance = new QueueManager(path, append, access, share);
            }
            return instance;
        }
       
        private QueueManager(
         string path,
         bool append,
         FileAccess access,
         FileShare share)
        {
            this.path = path;
            this.append = append;
            this.access = access;
            this.share = share;
        }
        
        internal void Enqueue(CachedEntry entry)
        {
            syncQueue.Enqueue(entry);
           
            if (!running)
            {
                lock (this)
                {
                    running = true;
                    Thread th = new Thread(new ThreadStart(this.Dequeue));
                    th.Start();
                }
            }
        }
        private void Dequeue()
        {
            CachedEntry entry = null;
            try
            {   
                
                    int processedCount = 0;
                    while (true)
                    {
                        processedCount++;
                        if (syncQueue.Count == 0)
                        {
                            //quit when queue is empty
                            lock (this)
                            {
                                running = false;
                                return;
                            }
                        }
                        else
                        {
                            entry = (CachedEntry)syncQueue.Dequeue();
                        }

                        if (entry != null)
                        {
                            if (entry.FileType == PathSelector.Error)
                            {
                              
                                using (FileStream fs = new FileStream(m_error_filename , FileMode.Append, access, share))
                                {

                                    Write(entry, fs);
                                }
                                
                            }
                            if (entry.FileType == PathSelector.Log)
                            {
                                
                                using (FileStream fs = new FileStream(m_log_filename, FileMode.Append, access, share))
                                {

                                    Write(entry, fs);
                                }
                            }
                            if (entry.FileType == PathSelector.Trace)
                            {
                                
                                using (FileStream fs = new FileStream(m_trace_filename, FileMode.Append, access, share))
                                {

                                    Write(entry, fs);
                                }
                            }
                            
                        }
                    }
                
            }
            catch (IOException ioe)
            {
                if (DateTime.Now - retryTime > RETRY_MAX_SPAN)
                {
                    lock (this)
                    {
                        running = false;
                    }
                    throw;
                }
                //When can't aquire lock
                //Wait random time then retry
                Thread.Sleep(rnd.Next(1000));
                retryTime = DateTime.Now;
                Dequeue();
            }
        }
        private void Write(CachedEntry entry, FileStream fs)
        {
            fs.Write(entry.Buffer, entry.Offset, entry.Count);
            fs.Flush();
        }
        public string Error_filename
        {
            get { return m_error_filename; }
            set { m_error_filename = value; }
        }
        public string Log_filename
        {
            get { return m_log_filename; }
            set { m_log_filename = value; }
        }

        public string Trace_filename
        {
            get { return m_trace_filename; }
            set { m_trace_filename = value; }
        }
    }
}