﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace SEM.Logging
{
    public class TimeTracker
    {
        private DateTime _startTime;
        private DateTime _stopTime;

        public TimeTracker(DateTime startTime)
        {
            _startTime = startTime;
        }
        public double CalculateTimeTaken(DateTime stopTime)
        {
            TimeSpan perf = stopTime.Subtract(_startTime);
            return perf.TotalSeconds;
        }

    }
}
